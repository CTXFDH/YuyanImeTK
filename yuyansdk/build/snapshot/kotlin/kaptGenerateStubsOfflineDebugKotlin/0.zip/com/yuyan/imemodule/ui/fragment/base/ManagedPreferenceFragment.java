package com.yuyan.imemodule.ui.fragment.base;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\'\u0018\u00002\u00020\u0001B\u0019\u0012\u0012\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003\"\u00020\u0004\u00a2\u0006\u0002\u0010\u0005J\u001c\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0017J\b\u0010\u000f\u001a\u00020\nH\u0016J\u0010\u0010\u0010\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u0012H\u0016J\b\u0010\u0013\u001a\u00020\nH\u0016R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0018\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\b\u00a8\u0006\u0014"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/base/ManagedPreferenceFragment;", "Lcom/yuyan/imemodule/ui/fragment/base/CsPreferenceFragment;", "preferenceProvider", "", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "([Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;)V", "evaluator", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceVisibilityEvaluator;", "[Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "onCreatePreferences", "", "savedInstanceState", "Landroid/os/Bundle;", "rootKey", "", "onDestroy", "onPreferenceUiCreated", "screen", "Landroidx/preference/PreferenceScreen;", "onStop", "yuyansdk_offlineDebug"})
public abstract class ManagedPreferenceFragment extends com.yuyan.imemodule.ui.fragment.base.CsPreferenceFragment {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.ManagedPreferenceProvider[] preferenceProvider = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.ManagedPreferenceVisibilityEvaluator evaluator = null;
    
    public ManagedPreferenceFragment(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.ManagedPreferenceProvider... preferenceProvider) {
        super();
    }
    
    public void onPreferenceUiCreated(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceScreen screen) {
    }
    
    @java.lang.Override()
    @androidx.annotation.CallSuper()
    public void onCreatePreferences(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState, @org.jetbrains.annotations.Nullable()
    java.lang.String rootKey) {
    }
    
    @java.lang.Override()
    public void onStop() {
    }
    
    @java.lang.Override()
    public void onDestroy() {
    }
}
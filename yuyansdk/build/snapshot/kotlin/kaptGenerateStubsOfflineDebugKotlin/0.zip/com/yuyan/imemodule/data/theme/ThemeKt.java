package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u0003\u0010\u0004\u00a8\u0006\u0005"}, d2 = {"displayName", "", "Lcom/yuyan/imemodule/data/theme/Theme;", "getDisplayName", "(Lcom/yuyan/imemodule/data/theme/Theme;)Ljava/lang/String;", "yuyansdk_offlineDebug"})
public final class ThemeKt {
    
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String getDisplayName(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme $this$displayName) {
        return null;
    }
}
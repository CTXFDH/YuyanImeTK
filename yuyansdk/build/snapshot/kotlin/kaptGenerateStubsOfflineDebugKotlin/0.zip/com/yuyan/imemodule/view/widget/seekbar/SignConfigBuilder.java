package com.yuyan.imemodule.view.widget.seekbar;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\'\n\u0002\u0010\u0002\n\u0002\b\b\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\u0005\u001a\u00020\u00002\u0006\u0010;\u001a\u00020\u0006J\u0006\u0010\u0007\u001a\u00020\u0000J\u001b\u0010\t\u001a\u00020\u00002\u000e\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\n\u00a2\u0006\u0002\u0010<J\u0006\u0010=\u001a\u00020>J\u0006\u0010\r\u001a\u00020\u0000J\u0010\u0010\u000e\u001a\u00020\u00002\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fJ\u000e\u0010\u0010\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u0011J\u000e\u0010\u0012\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u0011J\u000e\u0010\u0013\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u0011J\u0006\u0010\u0014\u001a\u00020\u0000J\u0010\u0010\u0015\u001a\u00020\u00002\b\b\u0001\u0010?\u001a\u00020\u0016J\u000e\u0010\u0017\u001a\u00020\u00002\u0006\u0010@\u001a\u00020\u0016J\u0010\u0010\u0018\u001a\u00020\u00002\b\b\u0001\u0010A\u001a\u00020\u0016J\u0010\u0010\u0019\u001a\u00020\u00002\b\b\u0001\u0010?\u001a\u00020\u0016J\u0010\u0010\u001a\u001a\u00020\u00002\b\b\u0001\u0010B\u001a\u00020\u0016J\u000e\u0010\u001b\u001a\u00020\u00002\u0006\u0010C\u001a\u00020\u0016J\u000e\u0010\u001c\u001a\u00020\u00002\u0006\u0010D\u001a\u00020\u0016J\u0006\u0010\u001d\u001a\u00020\u0000J\u0010\u0010E\u001a\u00020\u00002\b\u0010:\u001a\u0004\u0018\u00010\u000bJ\u0006\u0010\u001e\u001a\u00020\u0000J\u0006\u0010\u001f\u001a\u00020\u0000J\u0006\u0010 \u001a\u00020\u0000J\u0006\u0010!\u001a\u00020\u0000J\u000e\u0010\"\u001a\u00020\u00002\u0006\u0010\"\u001a\u00020\bJ\u000e\u0010#\u001a\u00020\u00002\u0006\u0010#\u001a\u00020\bJ\u0006\u0010$\u001a\u00020\u0000J\u000e\u0010%\u001a\u00020\u00002\u0006\u0010%\u001a\u00020\bJ\u000e\u0010&\u001a\u00020\u00002\u0006\u0010&\u001a\u00020\u0016J\u000e\u0010\'\u001a\u00020\u00002\u0006\u0010\'\u001a\u00020\u0016J\u000e\u0010(\u001a\u00020\u00002\u0006\u0010(\u001a\u00020\u0016J\u000e\u0010)\u001a\u00020\u00002\u0006\u0010)\u001a\u00020\u0016J\u0010\u0010*\u001a\u00020\u00002\b\b\u0001\u0010?\u001a\u00020\u0016J\u000e\u0010+\u001a\u00020\u00002\u0006\u0010+\u001a\u00020\u0016J\u000e\u0010,\u001a\u00020\u00002\u0006\u0010,\u001a\u00020\u0016J\u0010\u0010-\u001a\u00020\u00002\b\b\u0001\u0010?\u001a\u00020\u0016J\u000e\u0010.\u001a\u00020\u00002\u0006\u0010D\u001a\u00020\u0016J\u000e\u0010/\u001a\u00020\u00002\u0006\u0010/\u001a\u00020\u0016J\u000e\u00100\u001a\u00020\u00002\u0006\u00100\u001a\u00020\u0011J\u0010\u00101\u001a\u00020\u00002\b\b\u0001\u0010?\u001a\u00020\u0016J\u000e\u00102\u001a\u00020\u00002\u0006\u0010@\u001a\u00020\u0016J\u000e\u00103\u001a\u00020\u00002\u0006\u0010@\u001a\u00020\u0016J\u000e\u00104\u001a\u00020\u00002\u0006\u00104\u001a\u00020\u0011J\u0010\u00105\u001a\u00020\u00002\b\b\u0001\u0010?\u001a\u00020\u0016J\u000e\u00106\u001a\u00020\u00002\u0006\u0010D\u001a\u00020\u0016J\u0006\u00107\u001a\u00020\u0000J\u0010\u00108\u001a\u00020\u00002\b\b\u0001\u0010?\u001a\u00020\u0016J\u000e\u00109\u001a\u00020\u00002\u0006\u0010@\u001a\u00020\u0016R\u0012\u0010\u0005\u001a\u00020\u00068\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0007\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0004\n\u0002\u0010\fR\u0012\u0010\r\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\u0004\u0018\u00010\u000f8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0010\u001a\u00020\u00118\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0012\u001a\u00020\u00118\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0013\u001a\u00020\u00118\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0014\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0015\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0017\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0018\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0019\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001a\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001b\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001c\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001d\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001e\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001f\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010 \u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010!\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\"\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010#\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010$\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010%\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010&\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\'\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010(\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010)\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010*\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010+\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010,\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010-\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010.\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010/\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00100\u001a\u00020\u00118\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00101\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00102\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00103\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00104\u001a\u00020\u00118\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00105\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00106\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00107\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00108\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00109\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010:\u001a\u0004\u0018\u00010\u000b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006F"}, d2 = {"Lcom/yuyan/imemodule/view/widget/seekbar/SignConfigBuilder;", "", "signSeekBar", "Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar;", "(Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar;)V", "animDuration", "", "autoAdjustSectionMark", "", "bottomSidesLabels", "", "", "[Ljava/lang/String;", "floatType", "format", "Ljava/text/NumberFormat;", "max", "", "min", "progress", "reverse", "secondTrackColor", "", "secondTrackSize", "sectionCount", "sectionTextColor", "sectionTextInterval", "sectionTextPosition", "sectionTextSize", "seekBySection", "showProgressInFloat", "showSectionMark", "showSectionText", "showSign", "showSignBorder", "showThumbShadow", "showThumbText", "signArrowAutofloat", "signArrowHeight", "signArrowWidth", "signBorderColor", "signBorderSize", "signColor", "signHeight", "signRound", "signTextColor", "signTextSize", "signWidth", "thumbBgAlpha", "thumbColor", "thumbRadius", "thumbRadiusOnDragging", "thumbRatio", "thumbTextColor", "thumbTextSize", "touchToSeek", "trackColor", "trackSize", "unit", "duration", "([Ljava/lang/String;)Lcom/yuyan/imemodule/view/widget/seekbar/SignConfigBuilder;", "build", "", "color", "dp", "count", "interval", "position", "sp", "setUnit", "yuyansdk_offlineDebug"})
@kotlin.Suppress(names = {"unused", "MemberVisibilityCanBePrivate"})
public final class SignConfigBuilder {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.widget.seekbar.SignSeekBar signSeekBar = null;
    @kotlin.jvm.JvmField()
    public float min = 0.0F;
    @kotlin.jvm.JvmField()
    public float max = 100.0F;
    @kotlin.jvm.JvmField()
    public float progress = 0.0F;
    @kotlin.jvm.JvmField()
    public boolean floatType = false;
    @kotlin.jvm.JvmField()
    public int trackSize = 0;
    @kotlin.jvm.JvmField()
    public int secondTrackSize = 0;
    @kotlin.jvm.JvmField()
    public int thumbRadius = 0;
    @kotlin.jvm.JvmField()
    public int thumbRadiusOnDragging = 0;
    @kotlin.jvm.JvmField()
    public int trackColor = 0;
    @kotlin.jvm.JvmField()
    public int secondTrackColor = 0;
    @kotlin.jvm.JvmField()
    public int thumbColor = 0;
    @kotlin.jvm.JvmField()
    public int sectionCount = 0;
    @kotlin.jvm.JvmField()
    public boolean showSectionMark = false;
    @kotlin.jvm.JvmField()
    public boolean autoAdjustSectionMark = false;
    @kotlin.jvm.JvmField()
    public boolean showSectionText = false;
    @kotlin.jvm.JvmField()
    public int sectionTextSize = 0;
    @kotlin.jvm.JvmField()
    public int sectionTextColor = 0;
    @kotlin.jvm.JvmField()
    public int sectionTextPosition = -1;
    @kotlin.jvm.JvmField()
    public int sectionTextInterval = 0;
    @kotlin.jvm.JvmField()
    public boolean showThumbText = false;
    @kotlin.jvm.JvmField()
    public int thumbTextSize = 0;
    @kotlin.jvm.JvmField()
    public int thumbTextColor = 0;
    @kotlin.jvm.JvmField()
    public boolean showProgressInFloat = false;
    @kotlin.jvm.JvmField()
    public long animDuration = 0L;
    @kotlin.jvm.JvmField()
    public boolean touchToSeek = false;
    @kotlin.jvm.JvmField()
    public boolean seekBySection = false;
    @kotlin.jvm.JvmField()
    public int signColor = 0;
    @kotlin.jvm.JvmField()
    public int signTextSize = 0;
    @kotlin.jvm.JvmField()
    public int signTextColor = 0;
    @kotlin.jvm.JvmField()
    public boolean showSign = false;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.String[] bottomSidesLabels;
    @kotlin.jvm.JvmField()
    public float thumbBgAlpha = 0.0F;
    @kotlin.jvm.JvmField()
    public float thumbRatio = 0.0F;
    @kotlin.jvm.JvmField()
    public boolean showThumbShadow = false;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.String unit;
    @kotlin.jvm.JvmField()
    public int signArrowHeight = 0;
    @kotlin.jvm.JvmField()
    public int signArrowWidth = 0;
    @kotlin.jvm.JvmField()
    public int signRound = 0;
    @kotlin.jvm.JvmField()
    public int signHeight = 0;
    @kotlin.jvm.JvmField()
    public int signWidth = 0;
    @kotlin.jvm.JvmField()
    public int signBorderSize = 0;
    @kotlin.jvm.JvmField()
    public boolean showSignBorder = false;
    @kotlin.jvm.JvmField()
    public boolean signArrowAutofloat = false;
    @kotlin.jvm.JvmField()
    public int signBorderColor = 0;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.text.NumberFormat format;
    @kotlin.jvm.JvmField()
    public boolean reverse = false;
    
    public SignConfigBuilder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.widget.seekbar.SignSeekBar signSeekBar) {
        super();
    }
    
    public final void build() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder min(float min) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder max(float max) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder progress(float progress) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder floatType() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder trackSize(int dp) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder secondTrackSize(int dp) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder thumbRadius(int dp) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder thumbRadiusOnDragging(int dp) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder trackColor(@androidx.annotation.ColorInt()
    int color) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder secondTrackColor(@androidx.annotation.ColorInt()
    int color) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder thumbColor(@androidx.annotation.ColorInt()
    int color) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder sectionCount(@androidx.annotation.IntRange(from = 1L)
    int count) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder showSectionMark() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder autoAdjustSectionMark() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder showSectionText() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder sectionTextSize(int sp) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder sectionTextColor(@androidx.annotation.ColorInt()
    int color) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder sectionTextPosition(int position) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder sectionTextInterval(@androidx.annotation.IntRange(from = 1L)
    int interval) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder showThumbText() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder thumbTextSize(int sp) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder thumbTextColor(@androidx.annotation.ColorInt()
    int color) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder showProgressInFloat() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder animDuration(long duration) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder touchToSeek() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder seekBySection() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder bottomSidesLabels(@org.jetbrains.annotations.Nullable()
    java.lang.String[] bottomSidesLabels) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder thumbBgAlpha(float thumbBgAlpha) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder thumbRatio(float thumbRatio) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder showThumbShadow(boolean showThumbShadow) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signColor(@androidx.annotation.ColorInt()
    int color) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signTextSize(int sp) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signTextColor(@androidx.annotation.ColorInt()
    int color) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder showSign() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signArrowHeight(int signArrowHeight) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signArrowWidth(int signArrowWidth) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signRound(int signRound) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signHeight(int signHeight) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signWidth(int signWidth) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signBorderSize(int signBorderSize) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder showSignBorder(boolean showSignBorder) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signBorderColor(int signBorderColor) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder signArrowAutofloat(boolean signArrowAutofloat) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder setUnit(@org.jetbrains.annotations.Nullable()
    java.lang.String unit) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder format(@org.jetbrains.annotations.Nullable()
    java.text.NumberFormat format) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder reverse() {
        return null;
    }
}
package com.yuyan.imemodule.view;

/**
 * 候选词集装箱
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u00ce\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u000f\b\u0007\u0018\u0000 \u007f2\u00020\u0001:\u0003\u007f\u0080\u0001B\u0019\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010G\u001a\u00020-2\u0006\u0010H\u001a\u00020\u00152\u0006\u0010I\u001a\u00020\bH\u0002J \u0010G\u001a\u00020-2\u0006\u0010H\u001a\u00020\u00152\u0006\u0010J\u001a\u00020\b2\u0006\u0010I\u001a\u00020\bH\u0002J\u0010\u0010K\u001a\u00020\b2\u0006\u0010L\u001a\u00020MH\u0002J\u0012\u0010N\u001a\u00020-2\b\u0010H\u001a\u0004\u0018\u00010\u0015H\u0002J\u0012\u0010O\u001a\u0004\u0018\u00010P2\u0006\u0010Q\u001a\u00020RH\u0002J\u0010\u0010S\u001a\u00020-2\u0006\u0010T\u001a\u00020UH\u0014J\u0018\u0010V\u001a\u00020-2\u0006\u0010T\u001a\u00020U2\u0006\u0010W\u001a\u00020XH\u0002J\u0006\u0010Y\u001a\u00020\bJ\b\u0010Z\u001a\u0004\u0018\u00010[J\u0010\u0010\\\u001a\u00020P2\u0006\u0010]\u001a\u00020PH\u0002J\b\u0010^\u001a\u0004\u0018\u00010[J\b\u0010_\u001a\u00020-H\u0002J\u0006\u0010`\u001a\u00020-J\u000e\u0010a\u001a\u00020-2\u0006\u0010b\u001a\u00020!J\u0006\u0010c\u001a\u00020\u0010J\u0010\u0010d\u001a\u00020\u00102\u0006\u0010e\u001a\u00020fH\u0002J\u001a\u0010g\u001a\u00020-2\u0006\u0010h\u001a\u00020i2\b\u0010H\u001a\u0004\u0018\u00010[H\u0002J\b\u0010j\u001a\u00020-H\u0014J\u0010\u0010k\u001a\u00020-2\u0006\u0010T\u001a\u00020UH\u0014J\u0018\u0010l\u001a\u00020-2\u0006\u0010m\u001a\u00020\b2\u0006\u0010n\u001a\u00020\bH\u0014J\u0016\u0010o\u001a\u00020-2\f\u0010p\u001a\b\u0012\u0004\u0012\u00020r0qH\u0002J\u0006\u0010s\u001a\u00020-J\u000e\u0010t\u001a\u00020-2\u0006\u0010u\u001a\u00020\nJ\u0006\u0010v\u001a\u00020-J\u0006\u0010w\u001a\u00020-J\u0006\u0010x\u001a\u00020-J\u0010\u0010y\u001a\u00020-2\u0006\u0010z\u001a\u00020[H\u0002J\u000e\u0010{\u001a\u00020-2\u0006\u0010|\u001a\u00020\bJ\b\u0010}\u001a\u00020-H\u0003J\u0010\u0010~\u001a\u00020-2\u0006\u0010I\u001a\u00020\bH\u0007R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\t\u001a\u00020\n8F\u00a2\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u000e\u0010\r\u001a\u00020\u000eX\u0082.\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000f\u001a\u00020\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u000eX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u000eX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0015X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u000eX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001fX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020!X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u001fX\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010#\u001a\u0004\u0018\u00010\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u000eX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u000eX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0015X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\'\u001a\u00020(X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020(X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0015X\u0082.\u00a2\u0006\u0002\n\u0000R\"\u0010+\u001a\n\u0012\u0004\u0012\u00020-\u0018\u00010,X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b.\u0010/\"\u0004\b0\u00101R\"\u00102\u001a\n\u0012\u0004\u0012\u00020-\u0018\u00010,X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b3\u0010/\"\u0004\b4\u00101R\"\u00105\u001a\n\u0012\u0004\u0012\u00020-\u0018\u00010,X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b6\u0010/\"\u0004\b7\u00101R\u0010\u00108\u001a\u0004\u0018\u000109X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010:\u001a\u0004\u0018\u00010\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b;\u0010\f\"\u0004\b<\u0010=R$\u0010@\u001a\u00020?2\u0006\u0010>\u001a\u00020?@FX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bA\u0010B\"\u0004\bC\u0010DR\u000e\u0010E\u001a\u00020FX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0081\u0001"}, d2 = {"Lcom/yuyan/imemodule/view/CandidatesBar;", "Landroid/widget/RelativeLayout;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "activeCandNo", "", "activeTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "getActiveTheme", "()Lcom/yuyan/imemodule/data/theme/Theme;", "candidatesData", "Landroid/widget/LinearLayout;", "isEditMode", "", "()Z", "setEditMode", "(Z)V", "mCandidateLogoView", "Landroid/widget/ImageView;", "mCandidatesAdapter", "Lcom/yuyan/imemodule/adapter/CandidatesBarAdapter;", "mCandidatesDataContainer", "mCandidatesMenuAdapter", "Lcom/yuyan/imemodule/adapter/CandidatesMenuAdapter;", "mCandidatesMenuContainer", "mCloseAssociateBtn", "mComposingTagContainer", "mComposingView", "Landroid/widget/TextView;", "mCvListener", "Lcom/yuyan/imemodule/callback/CandidateViewListener;", "mFlowerType", "mIvMenuSetting", "mLlContainer", "mLlMenuHolder", "mMenuRightArrowBtn", "mRVCandidates", "Landroidx/recyclerview/widget/RecyclerView;", "mRVContainerMenu", "mRightArrowBtn", "onArrowClick", "Lkotlin/Function0;", "", "getOnArrowClick", "()Lkotlin/jvm/functions/Function0;", "setOnArrowClick", "(Lkotlin/jvm/functions/Function0;)V", "onLogoClick", "getOnLogoClick", "setOnLogoClick", "onToolbarClick", "getOnToolbarClick", "setOnToolbarClick", "pendingMenuJob", "Lkotlinx/coroutines/Job;", "previewTheme", "getPreviewTheme", "setPreviewTheme", "(Lcom/yuyan/imemodule/data/theme/Theme;)V", "value", "Lcom/yuyan/imemodule/view/CandidatesBar$SelectionArea;", "selectedArea", "getSelectedArea", "()Lcom/yuyan/imemodule/view/CandidatesBar$SelectionArea;", "setSelectedArea", "(Lcom/yuyan/imemodule/view/CandidatesBar$SelectionArea;)V", "serviceScope", "Lkotlinx/coroutines/CoroutineScope;", "applyCircleBackground", "view", "textColor", "bgColor", "calculateInSampleSize", "options", "Landroid/graphics/BitmapFactory$Options;", "clearLogoTint", "decodeSampledBitmapFromFile", "Landroid/graphics/Bitmap;", "path", "", "dispatchDraw", "canvas", "Landroid/graphics/Canvas;", "drawMarqueeBox", "rectF", "Landroid/graphics/RectF;", "getActiveCandNo", "getArrowView", "Landroid/view/View;", "getCircularBitmap", "srcBitmap", "getLogoView", "initCandidateView", "initMenuView", "initialize", "cvListener", "isActiveCand", "isGifFile", "file", "Ljava/io/File;", "onClickMenu", "skbMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "onDetachedFromWindow", "onDraw", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "saveBarMenuOrderToDatabase", "items", "", "Lcom/yuyan/imemodule/entity/SkbFunItem;", "scheduleShowCandidates", "setTheme", "theme", "showCandidates", "showEmoji", "showFlowerTypeface", "showViewVisibility", "candidatesContainer", "updateActiveCandidateNo", "keyCode", "updateLogoView", "updateTheme", "Companion", "SelectionArea", "yuyansdk_offlineDebug"})
public final class CandidatesBar extends android.widget.RelativeLayout {
    private boolean isEditMode = false;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.view.CandidatesBar.SelectionArea selectedArea = com.yuyan.imemodule.view.CandidatesBar.SelectionArea.None;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.data.theme.Theme previewTheme;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function0<kotlin.Unit> onLogoClick;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function0<kotlin.Unit> onToolbarClick;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function0<kotlin.Unit> onArrowClick;
    private com.yuyan.imemodule.callback.CandidateViewListener mCvListener;
    private android.widget.ImageView mRightArrowBtn;
    private android.widget.ImageView mCloseAssociateBtn;
    private android.widget.ImageView mMenuRightArrowBtn;
    private android.widget.LinearLayout mCandidatesDataContainer;
    private android.widget.LinearLayout mCandidatesMenuContainer;
    private android.widget.LinearLayout mComposingTagContainer;
    private android.widget.TextView mComposingView;
    private androidx.recyclerview.widget.RecyclerView mRVCandidates;
    @org.jetbrains.annotations.Nullable()
    private android.widget.ImageView mIvMenuSetting;
    @org.jetbrains.annotations.Nullable()
    private android.widget.ImageView mCandidateLogoView;
    private android.widget.LinearLayout mLlContainer;
    private android.widget.LinearLayout mLlMenuHolder;
    private android.widget.TextView mFlowerType;
    private com.yuyan.imemodule.adapter.CandidatesBarAdapter mCandidatesAdapter;
    private androidx.recyclerview.widget.RecyclerView mRVContainerMenu;
    private com.yuyan.imemodule.adapter.CandidatesMenuAdapter mCandidatesMenuAdapter;
    private android.widget.LinearLayout candidatesData;
    private int activeCandNo = 0;
    @org.jetbrains.annotations.Nullable()
    private kotlinx.coroutines.Job pendingMenuJob;
    @org.jetbrains.annotations.NotNull()
    private final kotlinx.coroutines.CoroutineScope serviceScope = null;
    @org.jetbrains.annotations.NotNull()
    private static final android.util.LruCache<java.lang.String, android.graphics.Bitmap> logoCache = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.view.CandidatesBar.Companion Companion = null;
    
    public CandidatesBar(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null);
    }
    
    public final boolean isEditMode() {
        return false;
    }
    
    public final void setEditMode(boolean p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.CandidatesBar.SelectionArea getSelectedArea() {
        return null;
    }
    
    public final void setSelectedArea(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.CandidatesBar.SelectionArea value) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.data.theme.Theme getPreviewTheme() {
        return null;
    }
    
    public final void setPreviewTheme(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.data.theme.Theme p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme getActiveTheme() {
        return null;
    }
    
    public final void setTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final kotlin.jvm.functions.Function0<kotlin.Unit> getOnLogoClick() {
        return null;
    }
    
    public final void setOnLogoClick(@org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final kotlin.jvm.functions.Function0<kotlin.Unit> getOnToolbarClick() {
        return null;
    }
    
    public final void setOnToolbarClick(@org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final kotlin.jvm.functions.Function0<kotlin.Unit> getOnArrowClick() {
        return null;
    }
    
    public final void setOnArrowClick(@org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final android.view.View getLogoView() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final android.view.View getArrowView() {
        return null;
    }
    
    @java.lang.Override()
    protected void onDraw(@org.jetbrains.annotations.NotNull()
    android.graphics.Canvas canvas) {
    }
    
    @java.lang.Override()
    protected void dispatchDraw(@org.jetbrains.annotations.NotNull()
    android.graphics.Canvas canvas) {
    }
    
    private final void drawMarqueeBox(android.graphics.Canvas canvas, android.graphics.RectF rectF) {
    }
    
    public final void initialize(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.callback.CandidateViewListener cvListener) {
    }
    
    private final void initCandidateView() {
    }
    
    public final void initMenuView() {
    }
    
    private final void saveBarMenuOrderToDatabase(java.util.List<com.yuyan.imemodule.entity.SkbFunItem> items) {
    }
    
    private final void onClickMenu(com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode, android.view.View view) {
    }
    
    @java.lang.Override()
    protected void onDetachedFromWindow() {
    }
    
    public final void scheduleShowCandidates() {
    }
    
    /**
     * 显示候选词
     */
    public final void showCandidates() {
    }
    
    /**
     * 显示表情
     */
    public final void showEmoji() {
    }
    
    /**
     * 更新激活的候选词
     */
    public final void updateActiveCandidateNo(int keyCode) {
    }
    
    /**
     * 获取激活的候选词
     */
    public final int getActiveCandNo() {
        return 0;
    }
    
    /**
     * 是否操作选词
     */
    public final boolean isActiveCand() {
        return false;
    }
    
    /**
     * 选择花漾字
     */
    public final void showFlowerTypeface() {
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    private final void showViewVisibility(android.view.View candidatesContainer) {
    }
    
    @android.annotation.SuppressLint(value = {"WrongThread"})
    public final void updateTheme(int textColor) {
    }
    
    private final android.graphics.Bitmap getCircularBitmap(android.graphics.Bitmap srcBitmap) {
        return null;
    }
    
    private final boolean isGifFile(java.io.File file) {
        return false;
    }
    
    private final void clearLogoTint(android.widget.ImageView view) {
    }
    
    @android.annotation.SuppressLint(value = {"WrongThread"})
    private final void updateLogoView() {
    }
    
    private final void applyCircleBackground(android.widget.ImageView view, int bgColor, int textColor) {
    }
    
    private final void applyCircleBackground(android.widget.ImageView view, int textColor) {
    }
    
    private final android.graphics.Bitmap decodeSampledBitmapFromFile(java.lang.String path) {
        return null;
    }
    
    private final int calculateInSampleSize(android.graphics.BitmapFactory.Options options) {
        return 0;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0007\u001a\u00020\bR\u001a\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/view/CandidatesBar$Companion;", "", "()V", "logoCache", "Landroid/util/LruCache;", "", "Landroid/graphics/Bitmap;", "clearLogoCache", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        public final void clearLogoCache() {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/view/CandidatesBar$SelectionArea;", "", "(Ljava/lang/String;I)V", "None", "Logo", "Toolbar", "Arrow", "yuyansdk_offlineDebug"})
    public static enum SelectionArea {
        /*public static final*/ None /* = new None() */,
        /*public static final*/ Logo /* = new Logo() */,
        /*public static final*/ Toolbar /* = new Toolbar() */,
        /*public static final*/ Arrow /* = new Arrow() */;
        
        SelectionArea() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.view.CandidatesBar.SelectionArea> getEntries() {
            return null;
        }
    }
}
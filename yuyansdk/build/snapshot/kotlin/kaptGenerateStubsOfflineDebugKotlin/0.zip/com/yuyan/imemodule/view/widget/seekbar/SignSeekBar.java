package com.yuyan.imemodule.view.widget.seekbar;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\r\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b#\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0015\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\f\b\u0007\u0018\u00002\u00020\u0001:\u0002rsB%\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bJ\u000e\u0010X\u001a\u00020Y2\u0006\u0010Z\u001a\u00020\u0018J\u0006\u0010[\u001a\u00020\u0018J\u0010\u0010\\\u001a\u00020Y2\u0006\u0010]\u001a\u00020^H\u0014J\u0018\u0010_\u001a\u00020Y2\u0006\u0010`\u001a\u00020\u00072\u0006\u0010a\u001a\u00020\u0007H\u0014J\u0012\u0010b\u001a\u00020Y2\b\u0010c\u001a\u0004\u0018\u00010dH\u0014J\b\u0010e\u001a\u00020dH\u0014J\u0010\u0010f\u001a\u00020\n2\u0006\u0010g\u001a\u00020hH\u0017J\u0010\u0010i\u001a\u00020Y2\b\u0010j\u001a\u0004\u0018\u00010\u001eJ\u000e\u0010+\u001a\u00020Y2\u0006\u0010(\u001a\u00020\u001cJ\u0018\u0010k\u001a\u00020Y2\u0006\u0010l\u001a\u00020\u001c2\u0006\u0010m\u001a\u00020\nH\u0002J \u0010n\u001a\u00020Y2\u0006\u0010o\u001a\u00020\u001c2\u0006\u0010p\u001a\u00020\u001c2\u0006\u0010q\u001a\u00020\u001cH\u0002R\u001a\u0010\t\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\u000b\"\u0004\b\f\u0010\rR\u001a\u0010\u000e\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000b\"\u0004\b\u000f\u0010\rR\u001a\u0010\u0010\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u000b\"\u0004\b\u0011\u0010\rR\u001a\u0010\u0012\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u000b\"\u0004\b\u0013\u0010\rR\u000e\u0010\u0014\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0015\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u000b\"\u0004\b\u0016\u0010\rR\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001d\u001a\u0004\u0018\u00010\u001eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R$\u0010 \u001a\u00020\u001c2\u0006\u0010\u001f\u001a\u00020\u001c@FX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\"\"\u0004\b#\u0010$R$\u0010%\u001a\u00020\u001c2\u0006\u0010\u001f\u001a\u00020\u001c@FX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b&\u0010\"\"\u0004\b\'\u0010$R$\u0010(\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00078F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b)\u0010*\"\u0004\b+\u0010,R\u0011\u0010-\u001a\u00020\u001c8F\u00a2\u0006\u0006\u001a\u0004\b.\u0010\"R\u001a\u0010/\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b0\u0010*\"\u0004\b1\u0010,R\u001a\u00102\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b3\u0010*\"\u0004\b4\u0010,R\u001a\u00105\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b6\u0010*\"\u0004\b7\u0010,R\u001a\u00108\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b9\u0010*\"\u0004\b:\u0010,R\u001a\u0010;\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b<\u0010*\"\u0004\b=\u0010,R\u001a\u0010>\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b?\u0010*\"\u0004\b@\u0010,R$\u0010A\u001a\n\u0012\u0004\u0012\u00020C\u0018\u00010BX\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010H\u001a\u0004\bD\u0010E\"\u0004\bF\u0010GR\u001a\u0010I\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bJ\u0010*\"\u0004\bK\u0010,R\u001a\u0010L\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bM\u0010*\"\u0004\bN\u0010,R\u001a\u0010O\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bP\u0010*\"\u0004\bQ\u0010,R\u001a\u0010R\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bS\u0010*\"\u0004\bT\u0010,R\u001a\u0010U\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bV\u0010*\"\u0004\bW\u0010,\u00a8\u0006t"}, d2 = {"Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyleAttr", "", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "isAutoAdjustSectionMark", "", "()Z", "setAutoAdjustSectionMark", "(Z)V", "isFloatType", "setFloatType", "isShowSectionMark", "setShowSectionMark", "isShowSectionText", "setShowSectionText", "isThumbOnDragging", "isTouchToSeek", "setTouchToSeek", "mConfigBuilder", "Lcom/yuyan/imemodule/view/widget/seekbar/SignConfigBuilder;", "mPaint", "Landroid/graphics/Paint;", "mProgress", "", "mProgressListener", "Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar$OnProgressChangedListener;", "value", "max", "getMax", "()F", "setMax", "(F)V", "min", "getMin", "setMin", "progress", "getProgress", "()I", "setProgress", "(I)V", "progressFloat", "getProgressFloat", "secondTrackColor", "getSecondTrackColor", "setSecondTrackColor", "secondTrackSize", "getSecondTrackSize", "setSecondTrackSize", "sectionCount", "getSectionCount", "setSectionCount", "sectionTextColor", "getSectionTextColor", "setSectionTextColor", "sectionTextPosition", "getSectionTextPosition", "setSectionTextPosition", "sectionTextSize", "getSectionTextSize", "setSectionTextSize", "sidesLabels", "", "", "getSidesLabels", "()[Ljava/lang/String;", "setSidesLabels", "([Ljava/lang/String;)V", "[Ljava/lang/String;", "thumbColor", "getThumbColor", "setThumbColor", "thumbRadius", "getThumbRadius", "setThumbRadius", "thumbRadiusOnDragging", "getThumbRadiusOnDragging", "setThumbRadiusOnDragging", "trackColor", "getTrackColor", "setTrackColor", "trackSize", "getTrackSize", "setTrackSize", "config", "", "builder", "getConfigBuilder", "onDraw", "canvas", "Landroid/graphics/Canvas;", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "onRestoreInstanceState", "state", "Landroid/os/Parcelable;", "onSaveInstanceState", "onTouchEvent", "event", "Landroid/view/MotionEvent;", "setOnProgressChangedListener", "listener", "updateProgress", "newProgress", "fromUser", "updateProgressByX", "x", "startX", "trackLength", "OnProgressChangedListener", "TextPosition", "yuyansdk_offlineDebug"})
@kotlin.Suppress(names = {"unused", "MemberVisibilityCanBePrivate"})
public final class SignSeekBar extends android.view.View {
    private float min = 0.0F;
    private float max = 100.0F;
    private float mProgress = 0.0F;
    private boolean isFloatType = false;
    private int trackSize;
    private int secondTrackSize;
    private int thumbRadius;
    private int thumbRadiusOnDragging;
    private int trackColor = android.graphics.Color.GRAY;
    private int secondTrackColor = android.graphics.Color.BLUE;
    private int thumbColor = android.graphics.Color.BLUE;
    private int sectionCount = 10;
    private boolean isShowSectionMark = false;
    private boolean isAutoAdjustSectionMark = false;
    private boolean isShowSectionText = false;
    private int sectionTextSize;
    private int sectionTextColor = android.graphics.Color.GRAY;
    private int sectionTextPosition = -1;
    private boolean isTouchToSeek = true;
    @org.jetbrains.annotations.Nullable()
    private java.lang.String[] sidesLabels;
    private boolean isThumbOnDragging = false;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.view.widget.seekbar.SignSeekBar.OnProgressChangedListener mProgressListener;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder mConfigBuilder;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Paint mPaint = null;
    
    @kotlin.jvm.JvmOverloads()
    public SignSeekBar(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null);
    }
    
    @kotlin.jvm.JvmOverloads()
    public SignSeekBar(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null);
    }
    
    @kotlin.jvm.JvmOverloads()
    public SignSeekBar(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs, int defStyleAttr) {
        super(null);
    }
    
    public final float getMin() {
        return 0.0F;
    }
    
    public final void setMin(float value) {
    }
    
    public final float getMax() {
        return 0.0F;
    }
    
    public final void setMax(float value) {
    }
    
    public final int getProgress() {
        return 0;
    }
    
    public final void setProgress(int value) {
    }
    
    public final boolean isFloatType() {
        return false;
    }
    
    public final void setFloatType(boolean p0) {
    }
    
    public final int getTrackSize() {
        return 0;
    }
    
    public final void setTrackSize(int p0) {
    }
    
    public final int getSecondTrackSize() {
        return 0;
    }
    
    public final void setSecondTrackSize(int p0) {
    }
    
    public final int getThumbRadius() {
        return 0;
    }
    
    public final void setThumbRadius(int p0) {
    }
    
    public final int getThumbRadiusOnDragging() {
        return 0;
    }
    
    public final void setThumbRadiusOnDragging(int p0) {
    }
    
    public final int getTrackColor() {
        return 0;
    }
    
    public final void setTrackColor(int p0) {
    }
    
    public final int getSecondTrackColor() {
        return 0;
    }
    
    public final void setSecondTrackColor(int p0) {
    }
    
    public final int getThumbColor() {
        return 0;
    }
    
    public final void setThumbColor(int p0) {
    }
    
    public final int getSectionCount() {
        return 0;
    }
    
    public final void setSectionCount(int p0) {
    }
    
    public final boolean isShowSectionMark() {
        return false;
    }
    
    public final void setShowSectionMark(boolean p0) {
    }
    
    public final boolean isAutoAdjustSectionMark() {
        return false;
    }
    
    public final void setAutoAdjustSectionMark(boolean p0) {
    }
    
    public final boolean isShowSectionText() {
        return false;
    }
    
    public final void setShowSectionText(boolean p0) {
    }
    
    public final int getSectionTextSize() {
        return 0;
    }
    
    public final void setSectionTextSize(int p0) {
    }
    
    public final int getSectionTextColor() {
        return 0;
    }
    
    public final void setSectionTextColor(int p0) {
    }
    
    public final int getSectionTextPosition() {
        return 0;
    }
    
    public final void setSectionTextPosition(int p0) {
    }
    
    public final boolean isTouchToSeek() {
        return false;
    }
    
    public final void setTouchToSeek(boolean p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String[] getSidesLabels() {
        return null;
    }
    
    public final void setSidesLabels(@org.jetbrains.annotations.Nullable()
    java.lang.String[] p0) {
    }
    
    public final void config(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder builder) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.widget.seekbar.SignConfigBuilder getConfigBuilder() {
        return null;
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    @java.lang.Override()
    protected void onDraw(@org.jetbrains.annotations.NotNull()
    android.graphics.Canvas canvas) {
    }
    
    @java.lang.Override()
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public boolean onTouchEvent(@org.jetbrains.annotations.NotNull()
    android.view.MotionEvent event) {
        return false;
    }
    
    private final void updateProgressByX(float x, float startX, float trackLength) {
    }
    
    private final void updateProgress(float newProgress, boolean fromUser) {
    }
    
    public final void setProgress(float progress) {
    }
    
    public final float getProgressFloat() {
        return 0.0F;
    }
    
    public final void setOnProgressChangedListener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.view.widget.seekbar.SignSeekBar.OnProgressChangedListener listener) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    protected android.os.Parcelable onSaveInstanceState() {
        return null;
    }
    
    @java.lang.Override()
    protected void onRestoreInstanceState(@org.jetbrains.annotations.Nullable()
    android.os.Parcelable state) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\bf\u0018\u00002\u00020\u0001J\"\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH&J*\u0010\n\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\fH&J*\u0010\r\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\fH&\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar$OnProgressChangedListener;", "", "getProgressOnActionUp", "", "signSeekBar", "Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar;", "progress", "", "progressFloat", "", "getProgressOnFinally", "fromUser", "", "onProgressChanged", "yuyansdk_offlineDebug"})
    public static abstract interface OnProgressChangedListener {
        
        public abstract void onProgressChanged(@org.jetbrains.annotations.Nullable()
        com.yuyan.imemodule.view.widget.seekbar.SignSeekBar signSeekBar, int progress, float progressFloat, boolean fromUser);
        
        public abstract void getProgressOnActionUp(@org.jetbrains.annotations.Nullable()
        com.yuyan.imemodule.view.widget.seekbar.SignSeekBar signSeekBar, int progress, float progressFloat);
        
        public abstract void getProgressOnFinally(@org.jetbrains.annotations.Nullable()
        com.yuyan.imemodule.view.widget.seekbar.SignSeekBar signSeekBar, int progress, float progressFloat, boolean fromUser);
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar$TextPosition;", "", "()V", "BELOW_SECTION_MARK", "", "BOTTOM_SIDES", "NONE", "SIDES", "yuyansdk_offlineDebug"})
    public static final class TextPosition {
        public static final int NONE = -1;
        public static final int SIDES = 0;
        public static final int BOTTOM_SIDES = 1;
        public static final int BELOW_SECTION_MARK = 2;
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.view.widget.seekbar.SignSeekBar.TextPosition INSTANCE = null;
        
        private TextPosition() {
            super();
        }
    }
}
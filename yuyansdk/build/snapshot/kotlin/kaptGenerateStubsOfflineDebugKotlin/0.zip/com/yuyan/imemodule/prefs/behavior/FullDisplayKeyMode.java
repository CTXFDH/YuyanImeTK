package com.yuyan.imemodule.prefs.behavior;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\b\b\u0086\u0081\u0002\u0018\u0000 \b2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\bB\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/prefs/behavior/FullDisplayKeyMode;", "", "(Ljava/lang/String;I)V", "SwitchIme", "SwitchLanguage", "Clipboard", "Phrases", "None", "Companion", "yuyansdk_offlineDebug"})
public enum FullDisplayKeyMode {
    /*public static final*/ SwitchIme /* = new SwitchIme() */,
    /*public static final*/ SwitchLanguage /* = new SwitchLanguage() */,
    /*public static final*/ Clipboard /* = new Clipboard() */,
    /*public static final*/ Phrases /* = new Phrases() */,
    /*public static final*/ None /* = new None() */;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.prefs.behavior.FullDisplayKeyMode.Companion Companion = null;
    
    FullDisplayKeyMode() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public static kotlin.enums.EnumEntries<com.yuyan.imemodule.prefs.behavior.FullDisplayKeyMode> getEntries() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0006H\u0016\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/prefs/behavior/FullDisplayKeyMode$Companion;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "Lcom/yuyan/imemodule/prefs/behavior/FullDisplayKeyMode;", "()V", "decode", "raw", "", "yuyansdk_offlineDebug"})
    public static final class Companion implements com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<com.yuyan.imemodule.prefs.behavior.FullDisplayKeyMode> {
        
        private Companion() {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.prefs.behavior.FullDisplayKeyMode decode(@org.jetbrains.annotations.NotNull()
        java.lang.String raw) {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String encode(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.prefs.behavior.FullDisplayKeyMode x) {
            return null;
        }
    }
}
package com.yuyan.imemodule.entity.keyboard;

/**
 * Class used to represent a soft keyboard definition, including the height, the
 * background image, the image for high light, the keys, etc.
 * 一个软件盘的定义，包括按键的排列布局，宽度高度。
 * The width of the soft keyboard. 键盘的宽度
 * The height of the soft keyboard. 键盘的高度
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0019\u0012\u0012\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u00030\u0003\u00a2\u0006\u0002\u0010\u0005J\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0010\u001a\u00020\u0007J\u0018\u0010\u0011\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u0007J\u0006\u0010\u0014\u001a\u00020\u0015R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\n\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\tR&\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u00030\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u0005\u00a8\u0006\u0016"}, d2 = {"Lcom/yuyan/imemodule/entity/keyboard/SoftKeyboard;", "", "mKeyRows", "", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "(Ljava/util/List;)V", "keyXMargin", "", "getKeyXMargin", "()I", "keyYMargin", "getKeyYMargin", "getMKeyRows", "()Ljava/util/List;", "setMKeyRows", "getKeyByCode", "code", "mapToKey", "x", "y", "releaseAllKeys", "", "yuyansdk_offlineDebug"})
public final class SoftKeyboard {
    @org.jetbrains.annotations.NotNull()
    private java.util.List<? extends java.util.List<? extends com.yuyan.imemodule.entity.keyboard.SoftKey>> mKeyRows;
    private final int keyXMargin = 0;
    private final int keyYMargin = 0;
    
    public SoftKeyboard(@org.jetbrains.annotations.NotNull()
    java.util.List<? extends java.util.List<? extends com.yuyan.imemodule.entity.keyboard.SoftKey>> mKeyRows) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<java.util.List<com.yuyan.imemodule.entity.keyboard.SoftKey>> getMKeyRows() {
        return null;
    }
    
    public final void setMKeyRows(@org.jetbrains.annotations.NotNull()
    java.util.List<? extends java.util.List<? extends com.yuyan.imemodule.entity.keyboard.SoftKey>> p0) {
    }
    
    public final int getKeyXMargin() {
        return 0;
    }
    
    public final int getKeyYMargin() {
        return 0;
    }
    
    /**
     * 根据坐标查找按键，如果坐标在某个按键区域内，就返回这个按键，如果坐标不在所有的按键区域内，返回离它最近的按键。
     * 可以在判断坐标在某个按键区域内的时候，并且加上判断离它最近的按键，这样就只需要一次遍历就行了。
     */
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.entity.keyboard.SoftKey mapToKey(int x, int y) {
        return null;
    }
    
    /**
     * 根据code值查询按键，由于符号键无code&部分键盘可能存在重复键，因此该方式可能无法精确查询。
     */
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.entity.keyboard.SoftKey getKeyByCode(int code) {
        return null;
    }
    
    public final void releaseAllKeys() {
    }
}
package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u000fJ \u0010\u0010\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00062\u0006\u0010\u0014\u001a\u00020\u0006H\u0002R\u001d\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/utils/CardPreferenceStyler;", "", "()V", "expandedStates", "", "", "", "getExpandedStates", "()Ljava/util/Map;", "styleGroup", "", "group", "Landroidx/preference/PreferenceGroup;", "stylePreferenceScreen", "screen", "Landroidx/preference/PreferenceScreen;", "styleSingleItem", "pref", "Landroidx/preference/Preference;", "isFirst", "isLast", "yuyansdk_offlineDebug"})
public final class CardPreferenceStyler {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.String, java.lang.Boolean> expandedStates = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.CardPreferenceStyler INSTANCE = null;
    
    private CardPreferenceStyler() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.String, java.lang.Boolean> getExpandedStates() {
        return null;
    }
    
    public final void stylePreferenceScreen(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceScreen screen) {
    }
    
    public final void styleGroup(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceGroup group) {
    }
    
    private final void styleSingleItem(androidx.preference.Preference pref, boolean isFirst, boolean isLast) {
    }
}
package com.yuyan.imemodule.utils;

/**
 * 时间工具类
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\b\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0016\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00070\n2\b\b\u0002\u0010\u000b\u001a\u00020\u0007J\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00070\nJ\u0017\u0010\r\u001a\u00020\u00072\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000f\u00a2\u0006\u0002\u0010\u0010R \u0010\u0003\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u00060\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/utils/TimeUtils;", "", "()V", "daysGregorianFestivalPreset", "", "", "", "", "diffDaysPreset", "getData", "", "day", "getTime", "iso8601UTCDateTime", "timeMillis", "", "(Ljava/lang/Long;)Ljava/lang/String;", "yuyansdk_offlineDebug"})
public final class TimeUtils {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.String, java.lang.Integer> diffDaysPreset = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.lang.String[]> daysGregorianFestivalPreset = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.TimeUtils INSTANCE = null;
    
    private TimeUtils() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String iso8601UTCDateTime(@org.jetbrains.annotations.Nullable()
    java.lang.Long timeMillis) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<java.lang.String> getData(@org.jetbrains.annotations.NotNull()
    java.lang.String day) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<java.lang.String> getTime() {
        return null;
    }
}
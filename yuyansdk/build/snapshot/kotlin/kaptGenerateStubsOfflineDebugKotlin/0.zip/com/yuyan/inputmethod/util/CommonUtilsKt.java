package com.yuyan.inputmethod.util;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\u001a%\u0010\u0000\u001a\u00020\u00012\u0017\u0010\u0002\u001a\u0013\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003\u00a2\u0006\u0002\b\u0006H\u0086\b\u00f8\u0001\u0000\u001a1\u0010\u0007\u001a\u00020\u0004*\u00020\u00042\u0006\u0010\b\u001a\u00020\t2\u0017\u0010\u0002\u001a\u0013\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00050\u0003\u00a2\u0006\u0002\b\u0006H\u0086\b\u00f8\u0001\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001\u00a8\u0006\n"}, d2 = {"buildSpannedString", "", "builderAction", "Lkotlin/Function1;", "Landroid/text/SpannableStringBuilder;", "", "Lkotlin/ExtensionFunctionType;", "inSpans", "span", "", "yuyansdk_offlineDebug"})
public final class CommonUtilsKt {
    
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String buildSpannedString(@org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super android.text.SpannableStringBuilder, kotlin.Unit> builderAction) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final android.text.SpannableStringBuilder inSpans(@org.jetbrains.annotations.NotNull()
    android.text.SpannableStringBuilder $this$inSpans, @org.jetbrains.annotations.NotNull()
    java.lang.Object span, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super android.text.SpannableStringBuilder, kotlin.Unit> builderAction) {
        return null;
    }
}
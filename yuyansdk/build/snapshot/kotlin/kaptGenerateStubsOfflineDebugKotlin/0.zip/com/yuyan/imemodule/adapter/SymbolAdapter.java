package com.yuyan.imemodule.adapter;

/**
 * 表情或符号界面适配器
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001!B9\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0018\u0010\t\u001a\u0014\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\f0\n\u00a2\u0006\u0002\u0010\rJ\b\u0010\u001a\u001a\u00020\bH\u0016J\u001c\u0010\u001b\u001a\u00020\f2\n\u0010\u001c\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u001d\u001a\u00020\bH\u0016J\u001c\u0010\u001e\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010\u0005\u001a\u00020\bH\u0016R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\"\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R \u0010\t\u001a\u0014\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\f0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019\u00a8\u0006\""}, d2 = {"Lcom/yuyan/imemodule/adapter/SymbolAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/adapter/SymbolAdapter$SymbolHolder;", "context", "Landroid/content/Context;", "viewType", "Lcom/yuyan/imemodule/prefs/behavior/SymbolMode;", "pagerIndex", "", "onClickSymbol", "Lkotlin/Function2;", "", "", "(Landroid/content/Context;Lcom/yuyan/imemodule/prefs/behavior/SymbolMode;ILkotlin/jvm/functions/Function2;)V", "halfWidthSymbolsMode", "Lcom/yuyan/imemodule/prefs/behavior/HalfWidthSymbolsMode;", "inflater", "Landroid/view/LayoutInflater;", "mDatas", "", "getMDatas", "()Ljava/util/List;", "setMDatas", "(Ljava/util/List;)V", "getViewType", "()Lcom/yuyan/imemodule/prefs/behavior/SymbolMode;", "getItemCount", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "SymbolHolder", "yuyansdk_offlineDebug"})
public final class SymbolAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.adapter.SymbolAdapter.SymbolHolder> {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.behavior.SymbolMode viewType = null;
    private final int pagerIndex = 0;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function2<java.lang.String, java.lang.Integer, kotlin.Unit> onClickSymbol = null;
    @org.jetbrains.annotations.NotNull()
    private final android.view.LayoutInflater inflater = null;
    @org.jetbrains.annotations.Nullable()
    private java.util.List<java.lang.String> mDatas;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.behavior.HalfWidthSymbolsMode halfWidthSymbolsMode = null;
    
    public SymbolAdapter(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SymbolMode viewType, int pagerIndex, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function2<? super java.lang.String, ? super java.lang.Integer, kotlin.Unit> onClickSymbol) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.behavior.SymbolMode getViewType() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.util.List<java.lang.String> getMDatas() {
        return null;
    }
    
    public final void setMDatas(@org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> p0) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.adapter.SymbolAdapter.SymbolHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.adapter.SymbolAdapter.SymbolHolder holder, int position) {
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/adapter/SymbolAdapter$SymbolHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "(Lcom/yuyan/imemodule/adapter/SymbolAdapter;Landroid/view/View;)V", "tVSdb", "Landroid/widget/TextView;", "getTVSdb", "()Landroid/widget/TextView;", "setTVSdb", "(Landroid/widget/TextView;)V", "textView", "Landroidx/emoji2/widget/EmojiTextView;", "getTextView", "()Landroidx/emoji2/widget/EmojiTextView;", "setTextView", "(Landroidx/emoji2/widget/EmojiTextView;)V", "yuyansdk_offlineDebug"})
    public final class SymbolHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.NotNull()
        private androidx.emoji2.widget.EmojiTextView textView;
        @org.jetbrains.annotations.NotNull()
        private android.widget.TextView tVSdb;
        
        public SymbolHolder(@org.jetbrains.annotations.NotNull()
        android.view.View view) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final androidx.emoji2.widget.EmojiTextView getTextView() {
            return null;
        }
        
        public final void setTextView(@org.jetbrains.annotations.NotNull()
        androidx.emoji2.widget.EmojiTextView p0) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.TextView getTVSdb() {
            return null;
        }
        
        public final void setTVSdb(@org.jetbrains.annotations.NotNull()
        android.widget.TextView p0) {
        }
    }
}
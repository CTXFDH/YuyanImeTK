package com.yuyan.imemodule.service;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\t\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0006\u001a\u00020\u0007J\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\fJ\u0018\u0010\r\u001a\u00020\u00072\u0006\u0010\u000e\u001a\u00020\t2\b\b\u0002\u0010\u000f\u001a\u00020\u0004J\u000e\u0010\u0010\u001a\u00020\u00072\u0006\u0010\u0011\u001a\u00020\u0012J\u0006\u0010\u0013\u001a\u00020\u0007J\u000e\u0010\u0014\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\tJ\u0006\u0010\u0016\u001a\u00020\u0007J\u0006\u0010\u0017\u001a\u00020\u0007J\u000e\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\u0019\u001a\u00020\u00072\u0006\u0010\u001a\u001a\u00020\fR\u0011\u0010\u0003\u001a\u00020\u00048F\u00a2\u0006\u0006\u001a\u0004\b\u0003\u0010\u0005\u00a8\u0006\u001b"}, d2 = {"Lcom/yuyan/imemodule/service/InputDispatcher;", "", "()V", "isFinish", "", "()Z", "deleteAction", "", "getCurrentRimeSchema", "", "getWordSelectedWord", "index", "", "initImeSchema", "schema", "force", "inputKeyCode", "event", "Landroid/view/KeyEvent;", "nativeUpdateImeOption", "predictAssociationWords", "words", "reset", "resetIme", "selectPrefix", "setCharCase", "charCase", "yuyansdk_offlineDebug"})
public final class InputDispatcher {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.service.InputDispatcher INSTANCE = null;
    
    private InputDispatcher() {
        super();
    }
    
    @kotlin.jvm.Synchronized()
    public final synchronized void initImeSchema(@org.jetbrains.annotations.NotNull()
    java.lang.String schema, boolean force) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getCurrentRimeSchema() {
        return null;
    }
    
    public final void inputKeyCode(@org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
    }
    
    public final boolean isFinish() {
        return false;
    }
    
    public final void selectPrefix(int index) {
    }
    
    public final void getWordSelectedWord(int index) {
    }
    
    public final void deleteAction() {
    }
    
    public final void reset() {
    }
    
    public final void resetIme() {
    }
    
    public final void predictAssociationWords(@org.jetbrains.annotations.NotNull()
    java.lang.String words) {
    }
    
    public final void nativeUpdateImeOption() {
    }
    
    public final void setCharCase(int charCase) {
    }
}
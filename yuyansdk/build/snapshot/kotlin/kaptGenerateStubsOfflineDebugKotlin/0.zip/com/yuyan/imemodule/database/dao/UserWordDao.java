package com.yuyan.imemodule.database.dao;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0004\bg\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\b\u0010\u0003\u001a\u00020\u0004H\'J\u0010\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\'J\u0010\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\nH\'J\u000e\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00020\fH\'J\u0016\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00020\f2\u0006\u0010\u000e\u001a\u00020\nH\'J\u0012\u0010\u000f\u001a\u0004\u0018\u00010\u00022\u0006\u0010\t\u001a\u00020\nH\'\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/database/dao/UserWordDao;", "Lcom/yuyan/imemodule/database/BaseDao;", "Lcom/yuyan/imemodule/database/entry/UserWord;", "deleteAll", "", "deleteById", "id", "", "deleteByWord", "word", "", "getAll", "", "query", "py", "queryByWord", "yuyansdk_offlineDebug"})
@androidx.room.Dao()
public abstract interface UserWordDao extends com.yuyan.imemodule.database.BaseDao<com.yuyan.imemodule.database.entry.UserWord> {
    
    @androidx.room.Query(value = "SELECT * FROM user_word ORDER BY frequency DESC, time DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.UserWord> getAll();
    
    @androidx.room.Query(value = "SELECT * FROM user_word WHERE pinyin = :py OR pinyin LIKE :py || \'%\' OR pinyinHead = :py OR t9 = :py OR word = :py ORDER BY frequency DESC, time DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.UserWord> query(@org.jetbrains.annotations.NotNull()
    java.lang.String py);
    
    @androidx.room.Query(value = "DELETE FROM user_word WHERE id = :id")
    public abstract void deleteById(long id);
    
    @androidx.room.Query(value = "DELETE FROM user_word WHERE word = :word")
    public abstract void deleteByWord(@org.jetbrains.annotations.NotNull()
    java.lang.String word);
    
    @androidx.room.Query(value = "SELECT * FROM user_word WHERE word = :word LIMIT 1")
    @org.jetbrains.annotations.Nullable()
    public abstract com.yuyan.imemodule.database.entry.UserWord queryByWord(@org.jetbrains.annotations.NotNull()
    java.lang.String word);
    
    @androidx.room.Query(value = "DELETE FROM user_word")
    public abstract void deleteAll();
}
package com.yuyan.imemodule.keyboard;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010$\n\u0002\u0010\b\n\u0002\u0010\u000e\n\u0002\b\u000f\"\u001d\u0010\u0000\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005\"\u001d\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\u0005\"\u001d\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\u0005\"\u001d\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0005\"\u001d\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u0005\"\u001d\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0005\"\u001d\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0005\u00a8\u0006\u0012"}, d2 = {"doubleAbcMnemonicPreset", "", "", "", "getDoubleAbcMnemonicPreset", "()Ljava/util/Map;", "doubleFlyMnemonicPreset", "getDoubleFlyMnemonicPreset", "doubleMSMnemonicPreset", "getDoubleMSMnemonicPreset", "doubleNaturalMnemonicPreset", "getDoubleNaturalMnemonicPreset", "doubleSogouMnemonicPreset", "getDoubleSogouMnemonicPreset", "doubleZiguangMnemonicPreset", "getDoubleZiguangMnemonicPreset", "lx17MnemonicPreset", "getLx17MnemonicPreset", "yuyansdk_offlineDebug"})
public final class KeyMnemonicPresetKt {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.lang.String> doubleFlyMnemonicPreset = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.lang.String> doubleNaturalMnemonicPreset = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.lang.String> doubleAbcMnemonicPreset = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.lang.String> doubleZiguangMnemonicPreset = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.lang.String> doubleMSMnemonicPreset = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.lang.String> doubleSogouMnemonicPreset = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.lang.String> lx17MnemonicPreset = null;
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.Integer, java.lang.String> getDoubleFlyMnemonicPreset() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.Integer, java.lang.String> getDoubleNaturalMnemonicPreset() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.Integer, java.lang.String> getDoubleAbcMnemonicPreset() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.Integer, java.lang.String> getDoubleZiguangMnemonicPreset() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.Integer, java.lang.String> getDoubleMSMnemonicPreset() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.Integer, java.lang.String> getDoubleSogouMnemonicPreset() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.Integer, java.lang.String> getLx17MnemonicPreset() {
        return null;
    }
}
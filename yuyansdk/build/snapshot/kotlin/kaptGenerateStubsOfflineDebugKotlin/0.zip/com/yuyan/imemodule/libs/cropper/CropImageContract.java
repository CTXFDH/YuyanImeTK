package com.yuyan.imemodule.libs.cropper;

/**
 * An [ActivityResultContract] to start an activity that allows the user to crop an image.
 * The UI can be customized using [CropImageOptions].
 * If you do not provide an [CropImageContractOptions.uri] in the input the user will be asked to pick an image before cropping.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\b\u0007\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001B\u0005\u00a2\u0006\u0002\u0010\u0004J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u0002H\u0016J\u001a\u0010\n\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u0006H\u0016\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageContract;", "Landroidx/activity/result/contract/ActivityResultContract;", "Lcom/yuyan/imemodule/libs/cropper/CropImageContractOptions;", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropResult;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "parseResult", "resultCode", "", "intent", "yuyansdk_offlineDebug"})
public final class CropImageContract extends androidx.activity.result.contract.ActivityResultContract<com.yuyan.imemodule.libs.cropper.CropImageContractOptions, com.yuyan.imemodule.libs.cropper.CropImageView.CropResult> {
    
    public CropImageContract() {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.content.Intent createIntent(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageContractOptions input) {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.libs.cropper.CropImageView.CropResult parseResult(int resultCode, @org.jetbrains.annotations.Nullable()
    android.content.Intent intent) {
        return null;
    }
}
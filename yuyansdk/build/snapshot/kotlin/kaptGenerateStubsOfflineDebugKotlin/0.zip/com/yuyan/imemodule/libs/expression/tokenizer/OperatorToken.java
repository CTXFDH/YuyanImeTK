package com.yuyan.imemodule.libs.expression.tokenizer;

/**
 * Represents an operator used in expressions
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0002\u0010\u0004R\u0010\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/OperatorToken;", "Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "op", "Lcom/yuyan/imemodule/libs/expression/operator/Operator;", "(Lcom/yuyan/imemodule/libs/expression/operator/Operator;)V", "operator", "yuyansdk_offlineDebug"})
public final class OperatorToken extends com.yuyan.imemodule.libs.expression.tokenizer.Token {
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.expression.operator.Operator operator = null;
    
    public OperatorToken(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.libs.expression.operator.Operator op) {
        super(0);
    }
}
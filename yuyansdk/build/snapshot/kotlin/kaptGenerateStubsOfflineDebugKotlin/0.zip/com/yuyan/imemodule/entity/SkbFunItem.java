package com.yuyan.imemodule.entity;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bJ\u0013\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001H\u0096\u0002R\u0010\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/entity/SkbFunItem;", "", "funName", "", "funImgResource", "", "skbMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "(Ljava/lang/String;ILcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;)V", "getFunName", "()Ljava/lang/String;", "getSkbMenuMode", "()Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "equals", "", "other", "yuyansdk_offlineDebug"})
public final class SkbFunItem {
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String funName = null;
    @kotlin.jvm.JvmField()
    public final int funImgResource = 0;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode = null;
    
    public SkbFunItem(@org.jetbrains.annotations.NotNull()
    java.lang.String funName, int funImgResource, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getFunName() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.behavior.SkbMenuMode getSkbMenuMode() {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
}
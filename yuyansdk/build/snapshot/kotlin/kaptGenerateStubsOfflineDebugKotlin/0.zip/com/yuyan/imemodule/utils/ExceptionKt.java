package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u001c\u0010\u0000\u001a\u00020\u00012\b\b\u0001\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u001a@\u0010\u0006\u001a\u00020\u0001\"\b\b\u0000\u0010\u0007*\u00020\b2\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u0002H\u00070\n2\b\b\u0001\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005H\u0086\b\u00f8\u0001\u0000\u0082\u0002\u0007\n\u0005\b\u009920\u0001\u00a8\u0006\u000b"}, d2 = {"errorRuntime", "", "messageTemplate", "", "messageArg", "", "errorT", "T", "", "cons", "Lkotlin/Function1;", "yuyansdk_offlineDebug"})
public final class ExceptionKt {
    
    @org.jetbrains.annotations.NotNull()
    public static final <T extends java.lang.Throwable>java.lang.Void errorT(@org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.lang.String, ? extends T> cons, @androidx.annotation.StringRes()
    int messageTemplate, @org.jetbrains.annotations.Nullable()
    java.lang.String messageArg) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.Void errorRuntime(@androidx.annotation.StringRes()
    int messageTemplate, @org.jetbrains.annotations.Nullable()
    java.lang.String messageArg) {
        return null;
    }
}
package com.yuyan.imemodule.entity.keyboard;

/**
 * 按键的可切换状态
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\n\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004B\u0017\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0007R\u001a\u0010\b\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0004\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/entity/keyboard/ToggleState;", "", "stateId", "", "(I)V", "keyLabel", "", "(Ljava/lang/String;I)V", "label", "getLabel", "()Ljava/lang/String;", "setLabel", "(Ljava/lang/String;)V", "getStateId", "()I", "setStateId", "yuyansdk_offlineDebug"})
public final class ToggleState {
    private int stateId = 0;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String label = "";
    
    public final int getStateId() {
        return 0;
    }
    
    public final void setStateId(int p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getLabel() {
        return null;
    }
    
    public final void setLabel(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    public ToggleState(int stateId) {
        super();
    }
    
    public ToggleState(@org.jetbrains.annotations.NotNull()
    java.lang.String keyLabel, int stateId) {
        super();
    }
}
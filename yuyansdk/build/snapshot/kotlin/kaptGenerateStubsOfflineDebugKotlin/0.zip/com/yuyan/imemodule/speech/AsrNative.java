package com.yuyan.imemodule.speech;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\b\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0019\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0087 J)\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\u000bH\u0087 J\u0011\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u0006H\u0087 J\u0011\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u0006H\u0087 J\u0011\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0087 J\u0011\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0087 \u00a8\u0006\u0013"}, d2 = {"Lcom/yuyan/imemodule/speech/AsrNative;", "", "()V", "nativeAcceptPcm", "", "handle", "", "pcm", "", "nativeCreate", "encoder", "", "decoder", "joiner", "tokens", "nativeFinalize", "nativeGetPartial", "nativeRelease", "nativeReset", "yuyansdk_offlineDebug"})
public final class AsrNative {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.speech.AsrNative INSTANCE = null;
    
    private AsrNative() {
        super();
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native long nativeCreate(@org.jetbrains.annotations.NotNull()
    java.lang.String encoder, @org.jetbrains.annotations.NotNull()
    java.lang.String decoder, @org.jetbrains.annotations.NotNull()
    java.lang.String joiner, @org.jetbrains.annotations.NotNull()
    java.lang.String tokens) {
        return 0L;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native void nativeReset(long handle) {
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native void nativeAcceptPcm(long handle, @org.jetbrains.annotations.NotNull()
    byte[] pcm) {
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.NotNull()
    public static final native java.lang.String nativeGetPartial(long handle) {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.NotNull()
    public static final native java.lang.String nativeFinalize(long handle) {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native void nativeRelease(long handle) {
    }
}
package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u001e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ\u0018\u0010\u000b\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\f\u001a\u00020\n\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ThemeArchiveUtils;", "", "()V", "exportThemeToYus", "", "context", "Landroid/content/Context;", "theme", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "outputUri", "Landroid/net/Uri;", "importThemeFromYus", "inputUri", "yuyansdk_offlineDebug"})
public final class ThemeArchiveUtils {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.theme.ThemeArchiveUtils INSTANCE = null;
    
    private ThemeArchiveUtils() {
        super();
    }
    
    public final void exportThemeToYus(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme.Custom theme, @org.jetbrains.annotations.NotNull()
    android.net.Uri outputUri) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.data.theme.Theme.Custom importThemeFromYus(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    android.net.Uri inputUri) {
        return null;
    }
}
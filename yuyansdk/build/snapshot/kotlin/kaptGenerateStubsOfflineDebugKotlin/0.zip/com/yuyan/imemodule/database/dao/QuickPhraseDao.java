package com.yuyan.imemodule.database.dao;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\bg\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\b\u0010\u0003\u001a\u00020\u0004H\'J\u0010\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\'J\u000e\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00020\tH\'J\u0012\u0010\n\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0006\u001a\u00020\u0007H\'\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/database/dao/QuickPhraseDao;", "Lcom/yuyan/imemodule/database/BaseDao;", "Lcom/yuyan/imemodule/database/entry/QuickPhrase;", "deleteAll", "", "deleteByContent", "content", "", "getAll", "", "queryByContent", "yuyansdk_offlineDebug"})
@androidx.room.Dao()
public abstract interface QuickPhraseDao extends com.yuyan.imemodule.database.BaseDao<com.yuyan.imemodule.database.entry.QuickPhrase> {
    
    @androidx.room.Query(value = "SELECT * FROM quick_phrase ORDER BY time DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.QuickPhrase> getAll();
    
    @androidx.room.Query(value = "DELETE FROM quick_phrase WHERE content = :content")
    public abstract void deleteByContent(@org.jetbrains.annotations.NotNull()
    java.lang.String content);
    
    @androidx.room.Query(value = "SELECT * FROM quick_phrase WHERE content = :content LIMIT 1")
    @org.jetbrains.annotations.Nullable()
    public abstract com.yuyan.imemodule.database.entry.QuickPhrase queryByContent(@org.jetbrains.annotations.NotNull()
    java.lang.String content);
    
    @androidx.room.Query(value = "DELETE FROM quick_phrase")
    public abstract void deleteAll();
}
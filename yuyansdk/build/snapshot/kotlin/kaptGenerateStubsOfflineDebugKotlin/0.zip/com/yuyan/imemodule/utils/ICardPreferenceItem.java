package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\u0018\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0017R\u0018\u0010\u0002\u001a\u00020\u0003X\u00a6\u000e\u00a2\u0006\f\u001a\u0004\b\u0002\u0010\u0004\"\u0004\b\u0005\u0010\u0006R\u0018\u0010\u0007\u001a\u00020\u0003X\u00a6\u000e\u00a2\u0006\f\u001a\u0004\b\u0007\u0010\u0004\"\u0004\b\b\u0010\u0006\u00a8\u0006\u000f"}, d2 = {"Lcom/yuyan/imemodule/utils/ICardPreferenceItem;", "", "isFirstInGroup", "", "()Z", "setFirstInGroup", "(Z)V", "isLastInGroup", "setLastInGroup", "bindCardViewHolder", "", "holder", "Landroidx/preference/PreferenceViewHolder;", "pref", "Landroidx/preference/Preference;", "yuyansdk_offlineDebug"})
public abstract interface ICardPreferenceItem {
    
    public abstract boolean isFirstInGroup();
    
    public abstract void setFirstInGroup(boolean p0);
    
    public abstract boolean isLastInGroup();
    
    public abstract void setLastInGroup(boolean p0);
    
    @android.annotation.SuppressLint(value = {"RestrictedApi"})
    public abstract void bindCardViewHolder(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceViewHolder holder, @org.jetbrains.annotations.NotNull()
    androidx.preference.Preference pref);
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 3, xi = 48)
    public static final class DefaultImpls {
        
        @android.annotation.SuppressLint(value = {"RestrictedApi"})
        public static void bindCardViewHolder(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.utils.ICardPreferenceItem $this, @org.jetbrains.annotations.NotNull()
        androidx.preference.PreferenceViewHolder holder, @org.jetbrains.annotations.NotNull()
        androidx.preference.Preference pref) {
        }
    }
}
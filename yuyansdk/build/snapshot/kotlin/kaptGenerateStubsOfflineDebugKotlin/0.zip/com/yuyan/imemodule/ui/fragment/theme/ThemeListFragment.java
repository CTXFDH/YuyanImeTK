package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0015\u001a\u00020\u0016H\u0002J\u0010\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0010H\u0002J\u0010\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0010H\u0002J\u0012\u0010\u001a\u001a\u00020\u00162\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cH\u0016J$\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\b\u0010!\u001a\u0004\u0018\u00010\"2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cH\u0016J\u0010\u0010#\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020$H\u0002J\u0014\u0010%\u001a\u00020\u00162\n\b\u0002\u0010&\u001a\u0004\u0018\u00010$H\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R+\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u00078B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\b\r\u0010\u000e\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u0016\u0010\u000f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00100\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\'"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ThemeListFragment;", "Landroidx/fragment/app/Fragment;", "()V", "exportYusLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "", "<set-?>", "", "followSystemDayNightTheme", "getFollowSystemDayNightTheme", "()Z", "setFollowSystemDayNightTheme", "(Z)V", "followSystemDayNightTheme$delegate", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "imageLauncher", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "importYusLauncher", "themeListAdapter", "Lcom/yuyan/imemodule/ui/fragment/theme/ThemeListAdapter;", "themeToExport", "addTheme", "", "editTheme", "theme", "exportTheme", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "selectTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "updateSelectedThemes", "activeTheme", "yuyansdk_offlineDebug"})
public final class ThemeListFragment extends androidx.fragment.app.Fragment {
    private androidx.activity.result.ActivityResultLauncher<com.yuyan.imemodule.data.theme.Theme.Custom> imageLauncher;
    private androidx.activity.result.ActivityResultLauncher<java.lang.String> importYusLauncher;
    private androidx.activity.result.ActivityResultLauncher<java.lang.String> exportYusLauncher;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.data.theme.Theme.Custom themeToExport;
    private com.yuyan.imemodule.ui.fragment.theme.ThemeListAdapter themeListAdapter;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool followSystemDayNightTheme$delegate = null;
    
    public ThemeListFragment() {
        super();
    }
    
    private final boolean getFollowSystemDayNightTheme() {
        return false;
    }
    
    private final void setFollowSystemDayNightTheme(boolean p0) {
    }
    
    @java.lang.Override()
    public void onCreate(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateView(@org.jetbrains.annotations.NotNull()
    android.view.LayoutInflater inflater, @org.jetbrains.annotations.Nullable()
    android.view.ViewGroup container, @org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
        return null;
    }
    
    private final void updateSelectedThemes(com.yuyan.imemodule.data.theme.Theme activeTheme) {
    }
    
    private final void addTheme() {
    }
    
    private final void selectTheme(com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    private final void editTheme(com.yuyan.imemodule.data.theme.Theme.Custom theme) {
    }
    
    private final void exportTheme(com.yuyan.imemodule.data.theme.Theme.Custom theme) {
    }
}
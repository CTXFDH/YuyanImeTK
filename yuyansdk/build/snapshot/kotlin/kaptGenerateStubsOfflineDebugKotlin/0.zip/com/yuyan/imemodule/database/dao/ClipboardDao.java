package com.yuyan.imemodule.database.dao;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\bg\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\b\u0010\u0003\u001a\u00020\u0004H\'J\b\u0010\u0005\u001a\u00020\u0004H\'J\u0010\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\bH\'J\u0010\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u000bH\'J\u000e\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00020\rH\'J\b\u0010\u000e\u001a\u00020\u000bH\'\u00a8\u0006\u000f"}, d2 = {"Lcom/yuyan/imemodule/database/dao/ClipboardDao;", "Lcom/yuyan/imemodule/database/BaseDao;", "Lcom/yuyan/imemodule/database/entry/Clipboard;", "deleteAll", "", "deleteAllExceptKeep", "deleteByContent", "content", "", "deleteOldest", "overflow", "", "getAll", "", "getCount", "yuyansdk_offlineDebug"})
@androidx.room.Dao()
public abstract interface ClipboardDao extends com.yuyan.imemodule.database.BaseDao<com.yuyan.imemodule.database.entry.Clipboard> {
    
    @androidx.room.Query(value = "select * from clipboard ORDER BY isKeep DESC, time DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.Clipboard> getAll();
    
    @androidx.room.Query(value = "delete from clipboard where content = :content")
    public abstract void deleteByContent(@org.jetbrains.annotations.NotNull()
    java.lang.String content);
    
    @androidx.room.Query(value = "delete from clipboard")
    public abstract void deleteAll();
    
    @androidx.room.Query(value = "SELECT COUNT(*) FROM clipboard")
    public abstract int getCount();
    
    @androidx.room.Query(value = "DELETE FROM clipboard WHERE content IN ( SELECT content FROM clipboard ORDER BY time ASC LIMIT :overflow)")
    public abstract void deleteOldest(int overflow);
    
    @androidx.room.Query(value = "DELETE FROM clipboard WHERE isKeep = 0")
    public abstract void deleteAllExceptKeep();
}
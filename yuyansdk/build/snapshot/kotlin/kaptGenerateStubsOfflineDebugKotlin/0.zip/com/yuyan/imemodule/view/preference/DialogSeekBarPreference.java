package com.yuyan.imemodule.view.preference;

/**
 * Custom preference which represents a seek bar which shows the current value in the summary. The
 * value can be changed by clicking on the preference, which brings up a dialog which a seek bar.
 * This implementation also allows for a min / max step value, while being backwards compatible.
 *
 * @property min The minimum value of the seek bar. Must not be greater or equal than [max].
 * @property max The maximum value of the seek bar. Must not be lesser or equal than [min].
 * @property step The step in which the seek bar increases per move. If the provided value is less
 * than 1, 1 will be used as step.
 * @property unit The unit to show after the value. Set to an empty string to disable this feature.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0010\u000e\n\u0002\b\u0014\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\t\b\u0017\u0018\u00002\u00020\u0001:\u00016B%\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bJ\b\u0010$\u001a\u00020%H\u0014J\u0018\u0010&\u001a\u00020\'2\u0006\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020\u0007H\u0014J\u0012\u0010+\u001a\u00020%2\b\u0010,\u001a\u0004\u0018\u00010\'H\u0014J\u0010\u0010-\u001a\u00020.2\u0006\u0010#\u001a\u00020\u0007H\u0014J\u0010\u0010/\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0007H\u0002J\u0012\u00100\u001a\u00020%2\b\u0010,\u001a\u0004\u0018\u00010\'H\u0016J\u0010\u00101\u001a\u00020%2\u0006\u0010#\u001a\u00020\u0007H\u0002J\b\u00102\u001a\u00020%H\u0002J\u0012\u00103\u001a\u00020\u00102\b\b\u0002\u0010#\u001a\u00020\u0007H\u0002J\u0010\u00104\u001a\u00020\u00072\u0006\u00105\u001a\u00020\u0007H\u0002R\u001e\u0010\t\u001a\u0004\u0018\u00010\u0007X\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010\u000e\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u001c\u0010\u000f\u001a\u0004\u0018\u00010\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0015\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u001a\u0010\u001a\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u0017\"\u0004\b\u001c\u0010\u0019R\u001a\u0010\u001d\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u0017\"\u0004\b\u001f\u0010\u0019R\u001a\u0010 \u001a\u00020\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\u0012\"\u0004\b\"\u0010\u0014R\u000e\u0010#\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00067"}, d2 = {"Lcom/yuyan/imemodule/view/preference/DialogSeekBarPreference;", "Landroidx/preference/DialogPreference;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyleAttr", "", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "default", "getDefault", "()Ljava/lang/Integer;", "setDefault", "(Ljava/lang/Integer;)V", "Ljava/lang/Integer;", "defaultLabel", "", "getDefaultLabel", "()Ljava/lang/String;", "setDefaultLabel", "(Ljava/lang/String;)V", "max", "getMax", "()I", "setMax", "(I)V", "min", "getMin", "setMin", "step", "getStep", "setStep", "unit", "getUnit", "setUnit", "value", "onClick", "", "onGetDefaultValue", "", "a", "Landroid/content/res/TypedArray;", "index", "onSetInitialValue", "defaultValue", "persistInt", "", "progressForValue", "setDefaultValue", "setValue", "showSeekBarDialog", "textForValue", "valueForProgress", "progress", "SimpleSummaryProvider", "yuyansdk_offlineDebug"})
public class DialogSeekBarPreference extends androidx.preference.DialogPreference {
    private int value = 0;
    private int min;
    private int max;
    private int step;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String unit;
    @org.jetbrains.annotations.Nullable()
    private java.lang.String defaultLabel;
    
    @kotlin.jvm.JvmOverloads()
    public DialogSeekBarPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null, null, 0, 0);
    }
    
    @kotlin.jvm.JvmOverloads()
    public DialogSeekBarPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null, null, 0, 0);
    }
    
    @kotlin.jvm.JvmOverloads()
    public DialogSeekBarPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs, int defStyleAttr) {
        super(null, null, 0, 0);
    }
    
    public final int getMin() {
        return 0;
    }
    
    public final void setMin(int p0) {
    }
    
    public final int getMax() {
        return 0;
    }
    
    public final void setMax(int p0) {
    }
    
    public final int getStep() {
        return 0;
    }
    
    public final void setStep(int p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getUnit() {
        return null;
    }
    
    public final void setUnit(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer getDefault() {
        return null;
    }
    
    public final void setDefault(@org.jetbrains.annotations.Nullable()
    java.lang.Integer p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getDefaultLabel() {
        return null;
    }
    
    public final void setDefaultLabel(@org.jetbrains.annotations.Nullable()
    java.lang.String p0) {
    }
    
    @java.lang.Override()
    protected boolean persistInt(int value) {
        return false;
    }
    
    @java.lang.Override()
    public void setDefaultValue(@org.jetbrains.annotations.Nullable()
    java.lang.Object defaultValue) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    protected java.lang.Object onGetDefaultValue(@org.jetbrains.annotations.NotNull()
    android.content.res.TypedArray a, int index) {
        return null;
    }
    
    @java.lang.Override()
    protected void onSetInitialValue(@org.jetbrains.annotations.Nullable()
    java.lang.Object defaultValue) {
    }
    
    @java.lang.Override()
    protected void onClick() {
    }
    
    /**
     * Shows the seek bar dialog.
     */
    private final void showSeekBarDialog() {
    }
    
    private final void setValue(int value) {
    }
    
    /**
     * Converts the actual value to a progress value which the Android SeekBar implementation can
     * handle. (Android's SeekBar step is fixed at 1 and min at 0)
     *
     * @param value The actual value.
     * @return the internal value which is used to allow different min and step values.
     */
    private final int progressForValue(int value) {
        return 0;
    }
    
    /**
     * Converts the Android SeekBar value to the actual value.
     *
     * @param progress The progress value of the SeekBar.
     * @return the actual value which is ready to use.
     */
    private final int valueForProgress(int progress) {
        return 0;
    }
    
    private final java.lang.String textForValue(int value) {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\r\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0002H\u0016\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/view/preference/DialogSeekBarPreference$SimpleSummaryProvider;", "Landroidx/preference/Preference$SummaryProvider;", "Lcom/yuyan/imemodule/view/preference/DialogSeekBarPreference;", "()V", "provideSummary", "", "preference", "yuyansdk_offlineDebug"})
    public static final class SimpleSummaryProvider implements androidx.preference.Preference.SummaryProvider<com.yuyan.imemodule.view.preference.DialogSeekBarPreference> {
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.view.preference.DialogSeekBarPreference.SimpleSummaryProvider INSTANCE = null;
        
        private SimpleSummaryProvider() {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.CharSequence provideSummary(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.view.preference.DialogSeekBarPreference preference) {
            return null;
        }
    }
}
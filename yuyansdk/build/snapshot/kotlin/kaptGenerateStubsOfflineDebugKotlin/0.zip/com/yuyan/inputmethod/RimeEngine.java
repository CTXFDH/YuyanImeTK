package com.yuyan.inputmethod;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000f\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u001c\u001a\u00020\u001dJ\u0016\u0010\u001e\u001a\u00020\u000b2\f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013H\u0002J\u0006\u0010 \u001a\u00020\u000bJ\u0011\u0010!\u001a\b\u0012\u0004\u0012\u00020\u00140\n\u00a2\u0006\u0002\u0010\"J\u0011\u0010#\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u00a2\u0006\u0002\u0010$J\u0006\u0010%\u001a\u00020\u001dJ\u0006\u0010&\u001a\u00020\'J\u0006\u0010(\u001a\u00020\u001dJ\u000e\u0010)\u001a\u00020\u001d2\u0006\u0010*\u001a\u00020+J\u000e\u0010,\u001a\u00020\u001d2\u0006\u0010-\u001a\u00020\u000bJ\u0006\u0010.\u001a\u00020\u001dJ\u000e\u0010/\u001a\u00020\u001d2\u0006\u00100\u001a\u00020\u0004J\u0010\u00101\u001a\u0004\u0018\u00010\u000b2\u0006\u00100\u001a\u00020\u0004J\u000e\u00102\u001a\u00020\u001d2\u0006\u00100\u001a\u00020\u0004J\u000e\u00103\u001a\u00020\'2\u0006\u00104\u001a\u00020\u000bJ\u000e\u00105\u001a\u00020\u001d2\u0006\u0010\u0005\u001a\u00020\u0004J\u0016\u00106\u001a\u00020\u001d2\u0006\u00107\u001a\u00020\u000b2\u0006\u00108\u001a\u00020\'J\n\u00109\u001a\u0004\u0018\u00010\u000bH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\fR\u001a\u0010\r\u001a\u00020\u000bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R \u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00140\u0013X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R\u001a\u0010\u0019\u001a\u00020\u000bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u000f\"\u0004\b\u001b\u0010\u0011\u00a8\u0006:"}, d2 = {"Lcom/yuyan/inputmethod/RimeEngine;", "", "()V", "MASK_CASE_LOWER", "", "charCase", "customPhraseSize", "keyRecordStack", "Lcom/yuyan/inputmethod/data/KeyRecordStack;", "pinyins", "", "", "[Ljava/lang/String;", "preCommitText", "getPreCommitText", "()Ljava/lang/String;", "setPreCommitText", "(Ljava/lang/String;)V", "showCandidates", "", "Lcom/yuyan/inputmethod/core/CandidateListItem;", "getShowCandidates", "()Ljava/util/List;", "setShowCandidates", "(Ljava/util/List;)V", "showComposition", "getShowComposition", "setShowComposition", "destroy", "", "getCurrentComposition", "candidates", "getCurrentRimeSchema", "getNextPageCandidates", "()[Lcom/yuyan/inputmethod/core/CandidateListItem;", "getPrefixs", "()[Ljava/lang/String;", "init", "isFinish", "", "onDeleteKey", "onNormalKey", "event", "Landroid/view/KeyEvent;", "predictAssociationWords", "text", "reset", "selectAssociation", "index", "selectCandidate", "selectPinyin", "selectSchema", "mod", "setCharCase", "setImeOption", "option", "value", "updateCandidatesOrCommitText", "yuyansdk_offlineDebug"})
public final class RimeEngine {
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.inputmethod.data.KeyRecordStack keyRecordStack = null;
    @org.jetbrains.annotations.NotNull()
    private static java.lang.String[] pinyins = {};
    @org.jetbrains.annotations.NotNull()
    private static java.util.List<com.yuyan.inputmethod.core.CandidateListItem> showCandidates;
    @org.jetbrains.annotations.NotNull()
    private static java.lang.String showComposition = "";
    @org.jetbrains.annotations.NotNull()
    private static java.lang.String preCommitText = "";
    private static int customPhraseSize = 0;
    public static final int MASK_CASE_LOWER = 0;
    private static int charCase = 0;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.RimeEngine INSTANCE = null;
    
    private RimeEngine() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.inputmethod.core.CandidateListItem> getShowCandidates() {
        return null;
    }
    
    public final void setShowCandidates(@org.jetbrains.annotations.NotNull()
    java.util.List<com.yuyan.inputmethod.core.CandidateListItem> p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getShowComposition() {
        return null;
    }
    
    public final void setShowComposition(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getPreCommitText() {
        return null;
    }
    
    public final void setPreCommitText(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    public final void init() {
    }
    
    public final boolean selectSchema(@org.jetbrains.annotations.NotNull()
    java.lang.String mod) {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getCurrentRimeSchema() {
        return null;
    }
    
    /**
     * 是否输入完毕
     */
    public final boolean isFinish() {
        return false;
    }
    
    public final void onNormalKey(@org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
    }
    
    public final void onDeleteKey() {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String selectCandidate(int index) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.inputmethod.core.CandidateListItem[] getNextPageCandidates() {
        return null;
    }
    
    public final void selectPinyin(int index) {
    }
    
    public final void predictAssociationWords(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
    }
    
    public final void selectAssociation(int index) {
    }
    
    public final void reset() {
    }
    
    public final void destroy() {
    }
    
    private final java.lang.String updateCandidatesOrCommitText() {
        return null;
    }
    
    /**
     * 拿到候选词拼音组合
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[] getPrefixs() {
        return null;
    }
    
    private final java.lang.String getCurrentComposition(java.util.List<com.yuyan.inputmethod.core.CandidateListItem> candidates) {
        return null;
    }
    
    /**
     * 设置输入法搜索参数
     */
    public final void setImeOption(@org.jetbrains.annotations.NotNull()
    java.lang.String option, boolean value) {
    }
    
    public final void setCharCase(int charCase) {
    }
}
package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0006\u001a\u00020\u0007J\u0006\u0010\b\u001a\u00020\u0007J\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\rR\u0010\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u00020\u00048\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/utils/InputMethodUtil;", "", "()V", "componentName", "", "serviceName", "isEnabled", "", "isSelected", "showPicker", "", "startSettingsActivity", "context", "Landroid/content/Context;", "yuyansdk_offlineDebug"})
public final class InputMethodUtil {
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String serviceName = null;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String componentName = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.InputMethodUtil INSTANCE = null;
    
    private InputMethodUtil() {
        super();
    }
    
    public final boolean isEnabled() {
        return false;
    }
    
    public final boolean isSelected() {
        return false;
    }
    
    /**
     * 智能尝试直达手机系统的【管理键盘 / 输入法管理】（Available Virtual Keyboards）页面，
     * 优先匹配小米 MIUI/HyperOS、华为、OPPO、vivo、三星等 ROM 的显式键盘管理入口类。
     */
    public final void startSettingsActivity(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    public final void showPicker() {
    }
}
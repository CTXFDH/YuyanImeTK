package com.yuyan.imemodule.callback;

/**
 * 候选词视图监听器接口
 * @ClassName CandidateViewListener
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0003H&J\b\u0010\u0007\u001a\u00020\u0003H&J\u0010\u0010\b\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\nH&J\u0010\u0010\u000b\u001a\u00020\u00032\u0006\u0010\f\u001a\u00020\u0005H&\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/callback/CandidateViewListener;", "", "onClickChoice", "", "choiceId", "", "onClickClearCandidate", "onClickClearClipBoard", "onClickMenu", "skbMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "onClickMore", "level", "yuyansdk_offlineDebug"})
public abstract interface CandidateViewListener {
    
    public abstract void onClickChoice(int choiceId);
    
    public abstract void onClickMore(int level);
    
    public abstract void onClickMenu(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode);
    
    public abstract void onClickClearCandidate();
    
    public abstract void onClickClearClipBoard();
}
package com.yuyan.imemodule.adapter;

/**
 * 剪切板界面适配器 (去卡片化平铺设计：单行显示，底部分割线隔开，超紧凑布局)
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001.B\u001b\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0002\u0010\bJ\f\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006J\b\u0010&\u001a\u00020\u000bH\u0016J\u001c\u0010\'\u001a\u00020\u00162\n\u0010(\u001a\u00060\u0002R\u00020\u00002\u0006\u0010)\u001a\u00020\u000bH\u0016J\u001c\u0010*\u001a\u00060\u0002R\u00020\u00002\u0006\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020\u000bH\u0016R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R$\u0010\u000e\u001a\u00020\r2\u0006\u0010\f\u001a\u00020\r@FX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u000e\u0010\u0012\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R(\u0010\u0014\u001a\u0010\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u0016\u0018\u00010\u0015X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR.\u0010\u001b\u001a\u0016\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\u0016\u0018\u00010\u001cX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u0017\u0010!\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010#R\u000e\u0010$\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006/"}, d2 = {"Lcom/yuyan/imemodule/adapter/ClipBoardAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/adapter/ClipBoardAdapter$SymbolHolder;", "context", "Landroid/content/Context;", "datas", "", "Lcom/yuyan/imemodule/database/entry/Clipboard;", "(Landroid/content/Context;Ljava/util/List;)V", "expandedSet", "Ljava/util/HashSet;", "", "value", "", "isMultiSelectMode", "()Z", "setMultiSelectMode", "(Z)V", "mContext", "mDatas", "onItemClickListener", "Lkotlin/Function1;", "", "getOnItemClickListener", "()Lkotlin/jvm/functions/Function1;", "setOnItemClickListener", "(Lkotlin/jvm/functions/Function1;)V", "onMultiSelectModeChanged", "Lkotlin/Function2;", "getOnMultiSelectModeChanged", "()Lkotlin/jvm/functions/Function2;", "setOnMultiSelectModeChanged", "(Lkotlin/jvm/functions/Function2;)V", "selectedPositions", "getSelectedPositions", "()Ljava/util/HashSet;", "textColor", "getDatas", "getItemCount", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "SymbolHolder", "yuyansdk_offlineDebug"})
public final class ClipBoardAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.adapter.ClipBoardAdapter.SymbolHolder> {
    @org.jetbrains.annotations.NotNull()
    private java.util.List<com.yuyan.imemodule.database.entry.Clipboard> mDatas;
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context mContext = null;
    private int textColor;
    @org.jetbrains.annotations.NotNull()
    private final java.util.HashSet<java.lang.Integer> expandedSet = null;
    private boolean isMultiSelectMode = false;
    @org.jetbrains.annotations.NotNull()
    private final java.util.HashSet<java.lang.Integer> selectedPositions = null;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function2<? super java.lang.Boolean, ? super java.lang.Integer, kotlin.Unit> onMultiSelectModeChanged;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onItemClickListener;
    
    public ClipBoardAdapter(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    java.util.List<com.yuyan.imemodule.database.entry.Clipboard> datas) {
        super();
    }
    
    public final boolean isMultiSelectMode() {
        return false;
    }
    
    public final void setMultiSelectMode(boolean value) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.HashSet<java.lang.Integer> getSelectedPositions() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final kotlin.jvm.functions.Function2<java.lang.Boolean, java.lang.Integer, kotlin.Unit> getOnMultiSelectModeChanged() {
        return null;
    }
    
    public final void setOnMultiSelectModeChanged(@org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function2<? super java.lang.Boolean, ? super java.lang.Integer, kotlin.Unit> p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final kotlin.jvm.functions.Function1<java.lang.Integer, kotlin.Unit> getOnItemClickListener() {
        return null;
    }
    
    public final void setOnItemClickListener(@org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> p0) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.adapter.ClipBoardAdapter.SymbolHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.adapter.ClipBoardAdapter.SymbolHolder holder, int position) {
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.database.entry.Clipboard> getDatas() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0007R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u001a\u0010\u000b\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\t\"\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/adapter/ClipBoardAdapter$SymbolHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/widget/RelativeLayout;", "circleCheck", "Landroid/widget/ImageView;", "ivExpand", "(Lcom/yuyan/imemodule/adapter/ClipBoardAdapter;Landroid/widget/RelativeLayout;Landroid/widget/ImageView;Landroid/widget/ImageView;)V", "getCircleCheck", "()Landroid/widget/ImageView;", "getIvExpand", "ivTopTips", "getIvTopTips", "setIvTopTips", "(Landroid/widget/ImageView;)V", "textView", "Landroid/widget/TextView;", "getTextView", "()Landroid/widget/TextView;", "setTextView", "(Landroid/widget/TextView;)V", "yuyansdk_offlineDebug"})
    public final class SymbolHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.NotNull()
        private final android.widget.ImageView circleCheck = null;
        @org.jetbrains.annotations.NotNull()
        private final android.widget.ImageView ivExpand = null;
        @org.jetbrains.annotations.NotNull()
        private android.widget.TextView textView;
        @org.jetbrains.annotations.NotNull()
        private android.widget.ImageView ivTopTips;
        
        public SymbolHolder(@org.jetbrains.annotations.NotNull()
        android.widget.RelativeLayout view, @org.jetbrains.annotations.NotNull()
        android.widget.ImageView circleCheck, @org.jetbrains.annotations.NotNull()
        android.widget.ImageView ivExpand) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.ImageView getCircleCheck() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.ImageView getIvExpand() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.TextView getTextView() {
            return null;
        }
        
        public final void setTextView(@org.jetbrains.annotations.NotNull()
        android.widget.TextView p0) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.ImageView getIvTopTips() {
            return null;
        }
        
        public final void setIvTopTips(@org.jetbrains.annotations.NotNull()
        android.widget.ImageView p0) {
        }
    }
}
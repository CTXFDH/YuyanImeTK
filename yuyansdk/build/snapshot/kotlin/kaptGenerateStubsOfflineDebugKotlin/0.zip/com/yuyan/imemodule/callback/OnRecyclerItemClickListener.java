package com.yuyan.imemodule.callback;

/**
 * RecyclerView条目点击响应事件监听
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J(\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\tH&\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/imemodule/callback/OnRecyclerItemClickListener;", "", "onItemClick", "", "parent", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "v", "Landroid/view/View;", "position", "", "yuyansdk_offlineDebug"})
public abstract interface OnRecyclerItemClickListener {
    
    public abstract void onItemClick(@org.jetbrains.annotations.Nullable()
    androidx.recyclerview.widget.RecyclerView.Adapter<?> parent, @org.jetbrains.annotations.Nullable()
    android.view.View v, int position);
}
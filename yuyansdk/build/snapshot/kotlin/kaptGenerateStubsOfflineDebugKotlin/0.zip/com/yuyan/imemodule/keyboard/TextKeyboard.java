package com.yuyan.imemodule.keyboard;

/**
 * 软件盘视图
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0084\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b1\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0017\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0002\u0010\u0004J\b\u00106\u001a\u000207H\u0016J\u001a\u00108\u001a\u00020\b2\u0006\u00109\u001a\u00020\b2\b\b\u0002\u0010:\u001a\u00020;H\u0002J\u001e\u0010<\u001a\u0002072\u0006\u0010=\u001a\u00020\u001b2\f\u0010>\u001a\b\u0012\u0004\u0012\u00020/0?H\u0002J8\u0010@\u001a\u0002072\u0006\u0010=\u001a\u00020\u001b2\u0006\u0010A\u001a\u00020;2\u0006\u0010B\u001a\u00020;2\u0006\u0010C\u001a\u00020;2\u0006\u0010D\u001a\u00020;2\u0006\u00109\u001a\u00020\bH\u0002J0\u0010E\u001a\u0002072\u0006\u0010=\u001a\u00020\u001b2\u0006\u0010A\u001a\u00020;2\u0006\u0010B\u001a\u00020;2\u0006\u0010F\u001a\u00020\f2\u0006\u00109\u001a\u00020\bH\u0002J@\u0010G\u001a\u0002072\u0006\u0010=\u001a\u00020\u001b2\u0006\u0010A\u001a\u00020;2\u0006\u0010B\u001a\u00020;2\u0006\u0010H\u001a\u00020;2\u0006\u0010I\u001a\u00020;2\u0006\u0010J\u001a\u00020;2\u0006\u0010K\u001a\u00020(H\u0002J(\u0010L\u001a\u0002072\u0006\u0010=\u001a\u00020\u001b2\u0006\u0010M\u001a\u00020/2\u0006\u0010N\u001a\u00020\b2\u0006\u0010O\u001a\u00020\bH\u0002J(\u0010P\u001a\u0002072\u0006\u0010=\u001a\u00020\u001b2\u0006\u0010M\u001a\u00020/2\u0006\u0010N\u001a\u00020\b2\u0006\u0010O\u001a\u00020\bH\u0002J\u001a\u0010Q\u001a\u0004\u0018\u00010/2\u0006\u0010R\u001a\u00020\b2\u0006\u0010S\u001a\u00020\bH\u0016J\u0016\u0010T\u001a\b\u0012\u0004\u0012\u00020/0?2\u0006\u0010U\u001a\u00020/H\u0002J\b\u0010V\u001a\u000207H\u0002J\u0010\u0010W\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010X\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010Y\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010Z\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010[\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010\\\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010]\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010^\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010_\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0010\u0010`\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\u0012\u0010a\u001a\u00020\f2\b\u0010b\u001a\u0004\u0018\u00010/H\u0014J\u0010\u0010c\u001a\u00020\f2\u0006\u0010M\u001a\u00020/H\u0002J\b\u0010d\u001a\u000207H\u0016J\b\u0010e\u001a\u000207H\u0016J\u0010\u0010f\u001a\u0002072\u0006\u0010=\u001a\u00020\u001bH\u0014J\u0018\u0010g\u001a\u0002072\u0006\u0010h\u001a\u00020\b2\u0006\u0010i\u001a\u00020\bH\u0014J(\u0010j\u001a\u0002072\u0006\u0010k\u001a\u00020\b2\u0006\u0010l\u001a\u00020\b2\u0006\u0010m\u001a\u00020\b2\u0006\u0010n\u001a\u00020\bH\u0016J\u0010\u0010o\u001a\u0002072\u0006\u0010p\u001a\u00020qH\u0016J\u0010\u0010r\u001a\u0002072\u0006\u0010s\u001a\u00020\u0013H\u0016J\u0006\u0010t\u001a\u000207R\u001d\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0012\u001a\u00020\u0013X\u0084.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u0010\u0010\u0018\u001a\u0004\u0018\u00010\u0019X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u001bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u001c\u001a\u00020\u001dX\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u000e\u0010\"\u001a\u00020#X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\'\u001a\u00020(X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010)\u001a\u00020\fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b*\u0010+\"\u0004\b,\u0010-R\u001c\u0010.\u001a\u0004\u0018\u00010/X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b0\u00101\"\u0004\b2\u00103R\u000e\u00104\u001a\u000205X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006u"}, d2 = {"Lcom/yuyan/imemodule/keyboard/TextKeyboard;", "Lcom/yuyan/imemodule/keyboard/BaseKeyboardView;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "customKeyColorMap", "", "", "", "getCustomKeyColorMap", "()Ljava/util/Map;", "isKeyBorder", "", "isKeyShadow", "keyRadius", "keyboardFontBold", "keyboardMnemonic", "keyboardSymbol", "mActiveTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "getMActiveTheme", "()Lcom/yuyan/imemodule/data/theme/Theme;", "setMActiveTheme", "(Lcom/yuyan/imemodule/data/theme/Theme;)V", "mBuffer", "Landroid/graphics/Bitmap;", "mCanvas", "Landroid/graphics/Canvas;", "mDirtyRect", "Landroid/graphics/Rect;", "getMDirtyRect", "()Landroid/graphics/Rect;", "setMDirtyRect", "(Landroid/graphics/Rect;)V", "mFmi", "Landroid/graphics/Paint$FontMetricsInt;", "mKeyboardChanged", "mNormalKeyTextSize", "mNormalKeyTextSizeSmall", "mPaint", "Landroid/graphics/Paint;", "selectSingleMode", "getSelectSingleMode", "()Z", "setSelectSingleMode", "(Z)V", "selectedKey", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "getSelectedKey", "()Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "setSelectedKey", "(Lcom/yuyan/imemodule/entity/keyboard/SoftKey;)V", "skbStyleMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbStyleMode;", "closing", "", "darkenColor", "color", "factor", "", "drawBlackAndWhiteMarqueeBox", "canvas", "keys", "", "drawChevronArrow", "cx", "cy", "size", "angleDegree", "drawJumpArrow", "isStart", "drawRingSectorHighlight", "innerR", "outerR", "startAngle", "fillPaint", "drawSoftKey", "softKey", "keyXMargin", "keyYMargin", "drawTextEditKey", "getKeyIndices", "x", "y", "getSelectedRegionKeys", "selected", "invalidateView", "isAlphaInputKey", "isAtKey", "isClearKey", "isDeleteKey", "isDotKey", "isEnterKey", "isNumberKey", "isReturnKey", "isShiftKey", "isSideSymbolKey", "isSpaceKey", "key", "isSymbolKey", "onBufferDraw", "onDetachedFromWindow", "onDraw", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "onSizeChanged", "w", "h", "oldw", "oldh", "setSoftKeyboard", "softSkb", "Lcom/yuyan/imemodule/entity/keyboard/SoftKeyboard;", "setTheme", "theme", "updateStates", "yuyansdk_offlineDebug"})
@kotlin.Suppress(names = {"ALL"})
public class TextKeyboard extends com.yuyan.imemodule.keyboard.BaseKeyboardView {
    private boolean mKeyboardChanged = false;
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Bitmap mBuffer;
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Canvas mCanvas;
    private int mNormalKeyTextSize = 0;
    private int mNormalKeyTextSizeSmall = 0;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Paint mPaint = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Paint.FontMetricsInt mFmi = null;
    private boolean isKeyBorder = false;
    private boolean isKeyShadow = false;
    protected com.yuyan.imemodule.data.theme.Theme mActiveTheme;
    private int keyRadius = 0;
    private boolean keyboardFontBold = false;
    private boolean keyboardSymbol = false;
    private boolean keyboardMnemonic = false;
    @org.jetbrains.annotations.NotNull()
    private android.graphics.Rect mDirtyRect;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.prefs.behavior.SkbStyleMode skbStyleMode;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.entity.keyboard.SoftKey selectedKey;
    private boolean selectSingleMode = false;
    @org.jetbrains.annotations.NotNull()
    private final java.util.Map<java.lang.String, java.lang.Integer> customKeyColorMap = null;
    
    public TextKeyboard(@org.jetbrains.annotations.Nullable()
    android.content.Context context) {
        super(null);
    }
    
    @org.jetbrains.annotations.NotNull()
    protected final com.yuyan.imemodule.data.theme.Theme getMActiveTheme() {
        return null;
    }
    
    protected final void setMActiveTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    protected final android.graphics.Rect getMDirtyRect() {
        return null;
    }
    
    protected final void setMDirtyRect(@org.jetbrains.annotations.NotNull()
    android.graphics.Rect p0) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.Nullable()
    public com.yuyan.imemodule.entity.keyboard.SoftKey getKeyIndices(int x, int y) {
        return null;
    }
    
    /**
     * 设置键盘实体
     *
     * @param softSkb 键盘
     */
    @java.lang.Override()
    public void setSoftKeyboard(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.keyboard.SoftKeyboard softSkb) {
    }
    
    /**
     * 刷新按键状态
     */
    public final void updateStates() {
    }
    
    /**
     * 重置主题并清空离屏缓存，确保按键背景色与高亮色毫秒级实时重绘刷新
     */
    public void setTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    private final void invalidateView() {
    }
    
    @java.lang.Override()
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
    }
    
    @java.lang.Override()
    protected void onDraw(@org.jetbrains.annotations.NotNull()
    android.graphics.Canvas canvas) {
    }
    
    @java.lang.Override()
    public void onBufferDraw() {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.entity.keyboard.SoftKey getSelectedKey() {
        return null;
    }
    
    public final void setSelectedKey(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.keyboard.SoftKey p0) {
    }
    
    public final boolean getSelectSingleMode() {
        return false;
    }
    
    public final void setSelectSingleMode(boolean p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.String, java.lang.Integer> getCustomKeyColorMap() {
        return null;
    }
    
    private final boolean isEnterKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    @java.lang.Override()
    protected boolean isSpaceKey(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.keyboard.SoftKey key) {
        return false;
    }
    
    private final boolean isDeleteKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isSymbolKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isNumberKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isShiftKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isClearKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isReturnKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isAtKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isDotKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isSideSymbolKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final boolean isAlphaInputKey(com.yuyan.imemodule.entity.keyboard.SoftKey softKey) {
        return false;
    }
    
    private final int darkenColor(int color, float factor) {
        return 0;
    }
    
    private final void drawSoftKey(android.graphics.Canvas canvas, com.yuyan.imemodule.entity.keyboard.SoftKey softKey, int keyXMargin, int keyYMargin) {
    }
    
    private final void drawChevronArrow(android.graphics.Canvas canvas, float cx, float cy, float size, float angleDegree, int color) {
    }
    
    private final void drawJumpArrow(android.graphics.Canvas canvas, float cx, float cy, boolean isStart, int color) {
    }
    
    private final void drawRingSectorHighlight(android.graphics.Canvas canvas, float cx, float cy, float innerR, float outerR, float startAngle, android.graphics.Paint fillPaint) {
    }
    
    private final void drawTextEditKey(android.graphics.Canvas canvas, com.yuyan.imemodule.entity.keyboard.SoftKey softKey, int keyXMargin, int keyYMargin) {
    }
    
    private final java.util.List<com.yuyan.imemodule.entity.keyboard.SoftKey> getSelectedRegionKeys(com.yuyan.imemodule.entity.keyboard.SoftKey selected) {
        return null;
    }
    
    private final void drawBlackAndWhiteMarqueeBox(android.graphics.Canvas canvas, java.util.List<? extends com.yuyan.imemodule.entity.keyboard.SoftKey> keys) {
    }
    
    @java.lang.Override()
    public void onDetachedFromWindow() {
    }
    
    @java.lang.Override()
    public void closing() {
    }
}
package com.yuyan.imemodule.view.popup;

/**
 * @param theme [Theme]
 * @param bounds bound [Rect] of popup trigger view. Used to calculate free space of both sides and
 * determine column order. See [focusColumn].
 * @param onDismissSelf callback when popup keyboard wants to close
 * @param radius popup keyboard and key radius
 * @param keyWidth key width in popup keyboard
 * trigger view to popup keyboard view. See [offsetX] and [offsetY].
 * @param keys character to commit when triggered
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u00015BF\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0019\b\u0002\u0010\u0004\u001a\u0013\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0002\b\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r\u00a2\u0006\u0002\u0010\u000fJ\u0010\u0010)\u001a\u00020\u00062\u0006\u0010*\u001a\u00020\u000bH\u0002J\u0010\u0010+\u001a\u00020\u00062\u0006\u0010*\u001a\u00020\u000bH\u0002J\u0018\u0010,\u001a\u00020-2\u0006\u0010.\u001a\u00020\t2\u0006\u0010/\u001a\u00020\tH\u0016J\u0010\u00100\u001a\u00020\u00062\u0006\u00101\u001a\u00020\tH\u0016J\u0014\u00102\u001a\u000e\u0012\u0004\u0012\u000204\u0012\u0004\u0012\u00020\u000e03H\u0016R\u000e\u0010\u0010\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00120\rX\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u001aR\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rX\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u001eR\u000e\u0010\u001f\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010!\u001a\u00020\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010#R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010$\u001a\u00020%X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010\'R\u000e\u0010(\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u00066"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupKeyboardUi;", "Lcom/yuyan/imemodule/view/popup/PopupContainerUi;", "bounds", "Landroid/graphics/Rect;", "onDismissSelf", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "radius", "", "keyWidth", "", "keys", "", "", "(Landroid/graphics/Rect;Lkotlin/jvm/functions/Function1;FI[Ljava/lang/String;)V", "columnCount", "columnOrder", "", "focusBackground", "Landroid/graphics/drawable/GradientDrawable;", "focusColumn", "focusRow", "focusedIndex", "inactiveBackground", "keyOrders", "[[I", "keyUis", "", "Lcom/yuyan/imemodule/view/popup/PopupKeyboardUi$PopupKeyUi;", "[Ljava/lang/String;", "lastX", "lastY", "offsetY", "getOffsetY", "()I", "root", "Landroid/widget/LinearLayout;", "getRoot", "()Landroid/widget/LinearLayout;", "rowCount", "markFocus", "index", "markInactive", "onChangeFocus", "", "x", "y", "onGestureEvent", "distanceX", "onTrigger", "Lkotlin/Pair;", "Lcom/yuyan/imemodule/prefs/behavior/PopupMenuMode;", "PopupKeyUi", "yuyansdk_offlineDebug"})
public final class PopupKeyboardUi extends com.yuyan.imemodule.view.popup.PopupContainerUi {
    private final float radius = 0.0F;
    private final int keyWidth = 0;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String[] keys = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.drawable.GradientDrawable inactiveBackground = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.drawable.GradientDrawable focusBackground = null;
    private final int rowCount = 0;
    private final int columnCount = 0;
    private float lastX;
    private float lastY;
    private final int focusRow = 0;
    private final int focusColumn = 0;
    
    /**
     * Offset on X axis made up of 2 parts:
     * 1. from trigger view bounds left to popup entry view left
     * 2. from left-most column to initial focused column
     *
     * Offset on Y axis made up of 2 parts as well:
     * 1. from trigger view top to popup entry view top
     * 2. from top-most row to initial focused row (bottom row)
     *
     * ```
     *                   c───┬───┬───┐
     *                   │   │ 4 │ 5 │
     *                ┌─ ├───p───┼───┤ ─┐
     *  popupKeyHeight│  │ 3 │ 1 │ 2 │  │
     *                └─ └───┼───┼───┘  │
     *                       │   │      │popupHeight
     *                ┌───── │o─┐│      │
     * bounds.height()│      ││a││      │
     *                └───── └┴─┴┘ ─────┘
     * ```
     * o: trigger view top-left origin
     *
     * p: popup preview ([PopupEntryUi]) top-left origin
     *
     * c: container view top-left origin
     *
     * Applying only `1.` parts of both X and Y offset, the origin should transform from `o` to `p`.
     * `2.` parts of both offset transform it from `p` to `c`.
     */
    private final int offsetY = 0;
    @org.jetbrains.annotations.NotNull()
    private final int[] columnOrder = null;
    
    /**
     * row with smaller index displays at bottom.
     * for example, keyOrders array:
     * ```
     * [[2, 0, 1, 3], [6, 4, 5, 7]]
     * ```
     * displays as
     * ```
     * | 6 | 4 | 5 | 7 |
     * | 2 | 0 | 1 | 3 |
     * ```
     * in which `0` indicates default focus
     */
    @org.jetbrains.annotations.NotNull()
    private final int[][] keyOrders = null;
    private int focusedIndex;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.view.popup.PopupKeyboardUi.PopupKeyUi> keyUis = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.LinearLayout root = null;
    
    public PopupKeyboardUi(@org.jetbrains.annotations.NotNull()
    android.graphics.Rect bounds, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.view.popup.PopupContainerUi, kotlin.Unit> onDismissSelf, float radius, int keyWidth, @org.jetbrains.annotations.NotNull()
    java.lang.String[] keys) {
        super(null, null, null);
    }
    
    /**
     * Offset on X axis made up of 2 parts:
     * 1. from trigger view bounds left to popup entry view left
     * 2. from left-most column to initial focused column
     *
     * Offset on Y axis made up of 2 parts as well:
     * 1. from trigger view top to popup entry view top
     * 2. from top-most row to initial focused row (bottom row)
     *
     * ```
     *                   c───┬───┬───┐
     *                   │   │ 4 │ 5 │
     *                ┌─ ├───p───┼───┤ ─┐
     *  popupKeyHeight│  │ 3 │ 1 │ 2 │  │
     *                └─ └───┼───┼───┘  │
     *                       │   │      │popupHeight
     *                ┌───── │o─┐│      │
     * bounds.height()│      ││a││      │
     *                └───── └┴─┴┘ ─────┘
     * ```
     * o: trigger view top-left origin
     *
     * p: popup preview ([PopupEntryUi]) top-left origin
     *
     * c: container view top-left origin
     *
     * Applying only `1.` parts of both X and Y offset, the origin should transform from `o` to `p`.
     * `2.` parts of both offset transform it from `p` to `c`.
     */
    @java.lang.Override()
    public int getOffsetY() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.widget.LinearLayout getRoot() {
        return null;
    }
    
    private final void markFocus(int index) {
    }
    
    private final void markInactive(int index) {
    }
    
    @java.lang.Override()
    public void onGestureEvent(float distanceX) {
    }
    
    @java.lang.Override()
    public boolean onChangeFocus(float x, float y) {
        return false;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public kotlin.Pair<com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> onTrigger() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0007\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bR\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0014\u0010\u000b\u001a\u00020\fX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0011\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0014R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018\u00a8\u0006\u0019"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupKeyboardUi$PopupKeyUi;", "Lsplitties/views/dsl/core/Ui;", "ctx", "Landroid/content/Context;", "theme", "Lcom/yuyan/imemodule/data/theme/Theme;", "text", "", "(Landroid/content/Context;Lcom/yuyan/imemodule/data/theme/Theme;Ljava/lang/String;)V", "getCtx", "()Landroid/content/Context;", "root", "Landroid/widget/FrameLayout;", "getRoot", "()Landroid/widget/FrameLayout;", "getText", "()Ljava/lang/String;", "textView", "Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "getTextView", "()Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "textViewSdb", "getTextViewSdb", "getTheme", "()Lcom/yuyan/imemodule/data/theme/Theme;", "yuyansdk_offlineDebug"})
    public static final class PopupKeyUi implements splitties.views.dsl.core.Ui {
        @org.jetbrains.annotations.NotNull()
        private final android.content.Context ctx = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.data.theme.Theme theme = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String text = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.popup.AutoScaleTextView textView = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.popup.AutoScaleTextView textViewSdb = null;
        @org.jetbrains.annotations.NotNull()
        private final android.widget.FrameLayout root = null;
        
        public PopupKeyUi(@org.jetbrains.annotations.NotNull()
        android.content.Context ctx, @org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.data.theme.Theme theme, @org.jetbrains.annotations.NotNull()
        java.lang.String text) {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public android.content.Context getCtx() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.data.theme.Theme getTheme() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getText() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.popup.AutoScaleTextView getTextView() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.popup.AutoScaleTextView getTextViewSdb() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public android.widget.FrameLayout getRoot() {
            return null;
        }
    }
}
package com.yuyan.imemodule.view.preference;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\u0015\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J\b\u0010\u0014\u001a\u00020\u0015H\u0016J\u0010\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0018H\u0016J\b\u0010\u0019\u001a\u00020\u0015H\u0014J\b\u0010\u001a\u001a\u00020\u0015H\u0002R\u001c\u0010\b\u001a\n \n*\u0004\u0018\u00010\t0\t8BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\r\u001a\u00020\u000eX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\u000eX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u000f\"\u0004\b\u0013\u0010\u0011\u00a8\u0006\u001b"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ThemeSelectPreference;", "Landroidx/preference/Preference;", "Lcom/yuyan/imemodule/utils/ICardPreferenceItem;", "context", "Landroid/content/Context;", "defaultTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "(Landroid/content/Context;Lcom/yuyan/imemodule/data/theme/Theme;)V", "currentThemeName", "", "kotlin.jvm.PlatformType", "getCurrentThemeName", "()Ljava/lang/String;", "isFirstInGroup", "", "()Z", "setFirstInGroup", "(Z)V", "isLastInGroup", "setLastInGroup", "onAttached", "", "onBindViewHolder", "holder", "Landroidx/preference/PreferenceViewHolder;", "onClick", "updateSummary", "yuyansdk_offlineDebug"})
public final class ThemeSelectPreference extends androidx.preference.Preference implements com.yuyan.imemodule.utils.ICardPreferenceItem {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.Theme defaultTheme = null;
    private boolean isFirstInGroup = false;
    private boolean isLastInGroup = false;
    
    public ThemeSelectPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme defaultTheme) {
        super(null, null, 0, 0);
    }
    
    @java.lang.Override()
    public boolean isFirstInGroup() {
        return false;
    }
    
    @java.lang.Override()
    public void setFirstInGroup(boolean p0) {
    }
    
    @java.lang.Override()
    public boolean isLastInGroup() {
        return false;
    }
    
    @java.lang.Override()
    public void setLastInGroup(boolean p0) {
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceViewHolder holder) {
    }
    
    private final java.lang.String getCurrentThemeName() {
        return null;
    }
    
    private final void updateSummary() {
    }
    
    @java.lang.Override()
    public void onAttached() {
    }
    
    @java.lang.Override()
    protected void onClick() {
    }
    
    @java.lang.Override()
    public void bindCardViewHolder(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceViewHolder holder, @org.jetbrains.annotations.NotNull()
    androidx.preference.Preference pref) {
    }
}
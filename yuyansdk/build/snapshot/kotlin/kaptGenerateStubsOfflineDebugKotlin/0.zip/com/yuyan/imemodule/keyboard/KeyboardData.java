package com.yuyan.imemodule.keyboard;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0011\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R9\u0010\u0003\u001a*\u0012\u0004\u0012\u00020\u0005\u0012 \u0012\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00070\u0006j\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007`\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR9\u0010\f\u001a*\u0012\u0004\u0012\u00020\u0005\u0012 \u0012\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00070\u0006j\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007`\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000bR9\u0010\u000e\u001a*\u0012\u0004\u0012\u00020\u0005\u0012 \u0012\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00070\u0006j\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007`\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000bR9\u0010\u0010\u001a*\u0012\u0004\u0012\u00020\u0005\u0012 \u0012\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00070\u0006j\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007`\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000bR9\u0010\u0012\u001a*\u0012\u0004\u0012\u00020\u0005\u0012 \u0012\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00070\u0006j\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007`\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000bR9\u0010\u0014\u001a*\u0012\u0004\u0012\u00020\u0005\u0012 \u0012\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00070\u0006j\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007`\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u000bR9\u0010\u0016\u001a*\u0012\u0004\u0012\u00020\u0005\u0012 \u0012\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00070\u0006j\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007`\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u000bR9\u0010\u0018\u001a*\u0012\u0004\u0012\u00020\u0005\u0012 \u0012\u001e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u00070\u0006j\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007`\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u000b\u00a8\u0006\u001a"}, d2 = {"Lcom/yuyan/imemodule/keyboard/KeyboardData;", "", "()V", "layoutLX17Cn", "", "Lcom/yuyan/imemodule/prefs/behavior/SkbStyleMode;", "Ljava/util/ArrayList;", "", "", "Lkotlin/collections/ArrayList;", "getLayoutLX17Cn", "()Ljava/util/Map;", "layoutLX17CnWithLeftPrefix", "getLayoutLX17CnWithLeftPrefix", "layoutQwertyCn", "getLayoutQwertyCn", "layoutQwertyEn", "getLayoutQwertyEn", "layoutStrokeCn", "getLayoutStrokeCn", "layoutT9Cn", "getLayoutT9Cn", "layoutT9Number", "getLayoutT9Number", "layoutTextEdit", "getLayoutTextEdit", "yuyansdk_offlineDebug"})
public final class KeyboardData {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> layoutQwertyCn = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> layoutT9Cn = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> layoutStrokeCn = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> layoutLX17Cn = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> layoutLX17CnWithLeftPrefix = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> layoutQwertyEn = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> layoutT9Number = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> layoutTextEdit = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.keyboard.KeyboardData INSTANCE = null;
    
    private KeyboardData() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> getLayoutQwertyCn() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> getLayoutT9Cn() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> getLayoutStrokeCn() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> getLayoutLX17Cn() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> getLayoutLX17CnWithLeftPrefix() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> getLayoutQwertyEn() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> getLayoutT9Number() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<com.yuyan.imemodule.prefs.behavior.SkbStyleMode, java.util.ArrayList<java.lang.Integer[]>> getLayoutTextEdit() {
        return null;
    }
}
package com.yuyan.imemodule.keyboard;

/**
 * 遵循 LiquidGlass 架构的分层高斯模糊与互动预览组件 (底层模糊、字母图标保持 100% 锐利)
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u009a\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u001b\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001:\u0001[B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0010\u00107\u001a\u00020$2\b\b\u0002\u00108\u001a\u00020\u0011J\u0006\u00109\u001a\u00020$J\b\u0010:\u001a\u00020$H\u0002J\u0010\u0010;\u001a\u00020<2\u0006\u0010=\u001a\u00020\u000fH\u0002J\u0010\u0010>\u001a\u00020$2\u0006\u0010?\u001a\u00020\u0015H\u0002J\b\u0010@\u001a\u00020$H\u0002J\b\u0010A\u001a\u00020$H\u0002J\b\u0010B\u001a\u00020$H\u0014J\b\u0010C\u001a\u00020$H\u0014J\b\u0010D\u001a\u00020$H\u0002J\u0012\u0010E\u001a\u00020$2\n\b\u0002\u0010=\u001a\u0004\u0018\u00010\u000fJ\u0006\u0010F\u001a\u00020$J\u000e\u0010G\u001a\u00020$2\u0006\u0010H\u001a\u00020\u0011J\u0016\u0010I\u001a\u00020$2\u0006\u0010J\u001a\u00020\u000b2\u0006\u0010K\u001a\u00020\u0011J\u000e\u0010L\u001a\u00020$2\u0006\u0010M\u001a\u00020\rJ\u000e\u0010N\u001a\u00020$2\u0006\u0010O\u001a\u00020\u001cJ\u0010\u0010P\u001a\u00020$2\b\u0010?\u001a\u0004\u0018\u00010\u0015J\u000e\u0010Q\u001a\u00020$2\u0006\u0010R\u001a\u00020\u0011J\u000e\u0010S\u001a\u00020$2\u0006\u0010=\u001a\u00020\u000fJ\u0016\u0010S\u001a\u00020$2\u0006\u0010=\u001a\u00020\u000f2\u0006\u0010T\u001a\u00020<J\u0018\u0010U\u001a\u00020$2\u0006\u0010V\u001a\u0002062\u0006\u0010W\u001a\u00020XH\u0002J\u0018\u0010Y\u001a\u00020$2\u0006\u0010?\u001a\u00020\u00152\u0006\u0010=\u001a\u00020\u000fH\u0002J\b\u0010Z\u001a\u00020$H\u0002R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\u0012R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u001b\u001a\u00020\u001cX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001d\"\u0004\b\u001e\u0010\u001fR\u0010\u0010 \u001a\u0004\u0018\u00010!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R(\u0010\"\u001a\u0010\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020$\u0018\u00010#X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b%\u0010&\"\u0004\b\'\u0010(R\"\u0010)\u001a\n\u0012\u0004\u0012\u00020$\u0018\u00010*X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b+\u0010,\"\u0004\b-\u0010.R\u0010\u0010/\u001a\u0004\u0018\u000100X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u00101\u001a\b\u0012\u0004\u0012\u00020302X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u00104\u001a\u0004\u0018\u00010\u0001X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u00105\u001a\u0004\u0018\u000106X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\\"}, d2 = {"Lcom/yuyan/imemodule/keyboard/KeyboardPreviewView;", "Landroid/widget/RelativeLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "backgroundLayer", "Landroid/view/View;", "candidatesBarView", "Lcom/yuyan/imemodule/view/CandidatesBar;", "checkeredLayer", "composingPinyin", "", "currentMode", "Lcom/yuyan/imemodule/keyboard/KeyboardPreviewView$PreviewMode;", "currentTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "customSkbLayoutMode", "", "Ljava/lang/Integer;", "dimOverlayView", "downSoftKey", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "downX", "", "downY", "handler", "Landroid/os/Handler;", "isInteractiveMode", "", "()Z", "setInteractiveMode", "(Z)V", "longPressRunnable", "Ljava/lang/Runnable;", "onKeySelectedListener", "Lkotlin/Function1;", "", "getOnKeySelectedListener", "()Lkotlin/jvm/functions/Function1;", "setOnKeySelectedListener", "(Lkotlin/jvm/functions/Function1;)V", "onToolbarSelectedListener", "Lkotlin/Function0;", "getOnToolbarSelectedListener", "()Lkotlin/jvm/functions/Function0;", "setOnToolbarSelectedListener", "(Lkotlin/jvm/functions/Function0;)V", "popupWindowView", "Landroid/widget/FrameLayout;", "prefChangeListener", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "", "previewContainer", "textKeyboard", "Lcom/yuyan/imemodule/keyboard/TextKeyboard;", "applyWindowTopCornerRadius", "radiusDp", "clearCandidatesBarSelection", "clearComposing", "getScaledBackgroundDrawable", "Landroid/graphics/drawable/Drawable;", "theme", "handleKeyTyping", "key", "hidePopupPreview", "initView", "onAttachedToWindow", "onDetachedFromWindow", "refreshPreviewLayout", "reloadKeyboardLayout", "selectToolbarArea", "setBrightness", "brightness", "setCustomKeyColor", "keyLabelOrCode", "color", "setPreviewState", "mode", "setSelectSingleMode", "singleMode", "setSelectedKey", "setSkbLayout", "layoutMode", "setTheme", "backgroundDrawable", "setupTouchInteraction", "keyboardView", "softKeyboard", "Lcom/yuyan/imemodule/entity/keyboard/SoftKeyboard;", "showPopupPreview", "updateComposingViewDisplay", "PreviewMode", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
public final class KeyboardPreviewView extends android.widget.RelativeLayout {
    private boolean isInteractiveMode = true;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.entity.keyboard.SoftKey, kotlin.Unit> onKeySelectedListener;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function0<kotlin.Unit> onToolbarSelectedListener;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.keyboard.KeyboardPreviewView.PreviewMode currentMode = com.yuyan.imemodule.keyboard.KeyboardPreviewView.PreviewMode.MAIN_ZH;
    @org.jetbrains.annotations.Nullable()
    private java.lang.Integer customSkbLayoutMode;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.keyboard.TextKeyboard textKeyboard;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.view.CandidatesBar candidatesBarView;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.data.theme.Theme currentTheme;
    @org.jetbrains.annotations.Nullable()
    private android.view.View checkeredLayer;
    @org.jetbrains.annotations.Nullable()
    private android.view.View backgroundLayer;
    @org.jetbrains.annotations.Nullable()
    private android.widget.RelativeLayout previewContainer;
    @org.jetbrains.annotations.Nullable()
    private android.widget.FrameLayout popupWindowView;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String composingPinyin = "";
    private float downX = 0.0F;
    private float downY = 0.0F;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.entity.keyboard.SoftKey downSoftKey;
    @org.jetbrains.annotations.NotNull()
    private final android.os.Handler handler = null;
    @org.jetbrains.annotations.Nullable()
    private java.lang.Runnable longPressRunnable;
    @org.jetbrains.annotations.Nullable()
    private android.view.View dimOverlayView;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<java.lang.Object> prefChangeListener = null;
    
    public KeyboardPreviewView(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null);
    }
    
    public final boolean isInteractiveMode() {
        return false;
    }
    
    public final void setInteractiveMode(boolean p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final kotlin.jvm.functions.Function1<com.yuyan.imemodule.entity.keyboard.SoftKey, kotlin.Unit> getOnKeySelectedListener() {
        return null;
    }
    
    public final void setOnKeySelectedListener(@org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.entity.keyboard.SoftKey, kotlin.Unit> p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final kotlin.jvm.functions.Function0<kotlin.Unit> getOnToolbarSelectedListener() {
        return null;
    }
    
    public final void setOnToolbarSelectedListener(@org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> p0) {
    }
    
    public final void clearCandidatesBarSelection() {
    }
    
    private final void initView() {
    }
    
    public final void setBrightness(int brightness) {
    }
    
    public final void reloadKeyboardLayout(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    public final void setTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme, @org.jetbrains.annotations.NotNull()
    android.graphics.drawable.Drawable backgroundDrawable) {
    }
    
    public final void setTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    public final void applyWindowTopCornerRadius(int radiusDp) {
    }
    
    private final android.graphics.drawable.Drawable getScaledBackgroundDrawable(com.yuyan.imemodule.data.theme.Theme theme) {
        return null;
    }
    
    public final void setSkbLayout(int layoutMode) {
    }
    
    public final void setPreviewState(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.KeyboardPreviewView.PreviewMode mode) {
    }
    
    public final void setCustomKeyColor(@org.jetbrains.annotations.NotNull()
    java.lang.String keyLabelOrCode, int color) {
    }
    
    public final void setSelectSingleMode(boolean singleMode) {
    }
    
    private final void refreshPreviewLayout() {
    }
    
    public final void setSelectedKey(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.keyboard.SoftKey key) {
    }
    
    public final void selectToolbarArea() {
    }
    
    private final void handleKeyTyping(com.yuyan.imemodule.entity.keyboard.SoftKey key) {
    }
    
    private final void clearComposing() {
    }
    
    private final void updateComposingViewDisplay() {
    }
    
    private final void setupTouchInteraction(com.yuyan.imemodule.keyboard.TextKeyboard keyboardView, com.yuyan.imemodule.entity.keyboard.SoftKeyboard softKeyboard) {
    }
    
    private final void showPopupPreview(com.yuyan.imemodule.entity.keyboard.SoftKey key, com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    private final void hidePopupPreview() {
    }
    
    @java.lang.Override()
    protected void onAttachedToWindow() {
    }
    
    @java.lang.Override()
    protected void onDetachedFromWindow() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/keyboard/KeyboardPreviewView$PreviewMode;", "", "(Ljava/lang/String;I)V", "MAIN_ZH", "MAIN_EN", "SYMBOL", "NUMBER", "yuyansdk_offlineDebug"})
    public static enum PreviewMode {
        /*public static final*/ MAIN_ZH /* = new MAIN_ZH() */,
        /*public static final*/ MAIN_EN /* = new MAIN_EN() */,
        /*public static final*/ SYMBOL /* = new SYMBOL() */,
        /*public static final*/ NUMBER /* = new NUMBER() */;
        
        PreviewMode() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.keyboard.KeyboardPreviewView.PreviewMode> getEntries() {
            return null;
        }
    }
}
package com.yuyan.imemodule.libs.cropper;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\b\n\u0000\n\u0002\u0010\b\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0080T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0002"}, d2 = {"DEGREES_360", "", "yuyansdk_offlineDebug"})
public final class CropImageOptionsKt {
    public static final int DEGREES_360 = 360;
}
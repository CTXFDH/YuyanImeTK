package com.yuyan.imemodule.libs.expression.tokenizer;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0019\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\f\n\u0002\b\u000e\b\u0007\u0018\u0000 (2\u00020\u0001:\u0001(BQ\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0014\u0010\u0004\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005\u0012\u0014\u0010\u0007\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\b\u0018\u00010\u0005\u0012\u000e\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\n\u0012\u0006\u0010\u000b\u001a\u00020\f\u00a2\u0006\u0002\u0010\rJ\u0012\u0010\u0014\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0015\u001a\u00020\u0003H\u0002J\u0012\u0010\u0016\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0017\u001a\u00020\u0003H\u0002J\t\u0010\u0018\u001a\u00020\fH\u0086\u0002J\u0010\u0010\u0019\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\u001bH\u0002J\u0010\u0010\u001c\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\u001bH\u0002J\u0010\u0010\u001d\u001a\u00020\f2\u0006\u0010\u001e\u001a\u00020\u0010H\u0002J\u0010\u0010\u001f\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\u001bH\u0002J\u0006\u0010 \u001a\u00020\u0012J\b\u0010!\u001a\u00020\u0012H\u0002J\b\u0010\"\u001a\u00020\u0012H\u0002J\u0010\u0010#\u001a\u00020\u00122\u0006\u0010$\u001a\u00020\u001bH\u0002J\u0010\u0010%\u001a\u00020\u00122\u0006\u0010$\u001a\u00020\u001bH\u0002J\u0010\u0010&\u001a\u00020\u00122\u0006\u0010\'\u001a\u00020\fH\u0002R\u000e\u0010\u0002\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0004\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0006\u0018\u00010\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0007\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\b\u0018\u00010\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006)"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/Tokenizer;", "", "expression", "", "userFunctions", "", "Lcom/yuyan/imemodule/libs/expression/function/Function;", "userOperators", "Lcom/yuyan/imemodule/libs/expression/operator/Operator;", "variableNames", "", "implicitMultiplication", "", "(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Z)V", "", "expressionLength", "", "lastToken", "Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "pos", "getFunction", "name", "getOperator", "symbol", "hasNext", "isArgumentSeparator", "ch", "", "isCloseParentheses", "isEndOfExpression", "offset", "isOpenParentheses", "nextToken", "parseArgumentSeparatorToken", "parseFunctionOrVariable", "parseNumberToken", "firstChar", "parseOperatorToken", "parseParentheses", "open", "Companion", "yuyansdk_offlineDebug"})
public final class Tokenizer {
    @org.jetbrains.annotations.Nullable()
    private final java.util.Map<java.lang.String, com.yuyan.imemodule.libs.expression.function.Function> userFunctions = null;
    @org.jetbrains.annotations.Nullable()
    private final java.util.Map<java.lang.String, com.yuyan.imemodule.libs.expression.operator.Operator> userOperators = null;
    @org.jetbrains.annotations.Nullable()
    private final java.util.Set<java.lang.String> variableNames = null;
    private final boolean implicitMultiplication = false;
    @org.jetbrains.annotations.NotNull()
    private final char[] expression = null;
    private final int expressionLength = 0;
    private int pos = 0;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.expression.tokenizer.Token lastToken;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.expression.tokenizer.Tokenizer.Companion Companion = null;
    
    public Tokenizer(@org.jetbrains.annotations.NotNull()
    java.lang.String expression, @org.jetbrains.annotations.Nullable()
    java.util.Map<java.lang.String, ? extends com.yuyan.imemodule.libs.expression.function.Function> userFunctions, @org.jetbrains.annotations.Nullable()
    java.util.Map<java.lang.String, ? extends com.yuyan.imemodule.libs.expression.operator.Operator> userOperators, @org.jetbrains.annotations.Nullable()
    java.util.Set<java.lang.String> variableNames, boolean implicitMultiplication) {
        super();
    }
    
    public final boolean hasNext() {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.expression.tokenizer.Token nextToken() {
        return null;
    }
    
    private final com.yuyan.imemodule.libs.expression.tokenizer.Token parseArgumentSeparatorToken() {
        return null;
    }
    
    private final boolean isArgumentSeparator(char ch) {
        return false;
    }
    
    private final com.yuyan.imemodule.libs.expression.tokenizer.Token parseParentheses(boolean open) {
        return null;
    }
    
    private final boolean isOpenParentheses(char ch) {
        return false;
    }
    
    private final boolean isCloseParentheses(char ch) {
        return false;
    }
    
    private final com.yuyan.imemodule.libs.expression.tokenizer.Token parseFunctionOrVariable() {
        return null;
    }
    
    private final com.yuyan.imemodule.libs.expression.function.Function getFunction(java.lang.String name) {
        return null;
    }
    
    private final com.yuyan.imemodule.libs.expression.tokenizer.Token parseOperatorToken(char firstChar) {
        return null;
    }
    
    private final com.yuyan.imemodule.libs.expression.operator.Operator getOperator(java.lang.String symbol) {
        return null;
    }
    
    private final com.yuyan.imemodule.libs.expression.tokenizer.Token parseNumberToken(char firstChar) {
        return null;
    }
    
    private final boolean isEndOfExpression(int offset) {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\f\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u0018\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0004H\u0002J\u000e\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006\u00a8\u0006\f"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/Tokenizer$Companion;", "", "()V", "isAlphabetic", "", "codePoint", "", "isNumeric", "ch", "", "lastCharE", "isVariableOrFunctionCharacter", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        private final boolean isNumeric(char ch, boolean lastCharE) {
            return false;
        }
        
        public final boolean isAlphabetic(int codePoint) {
            return false;
        }
        
        public final boolean isVariableOrFunctionCharacter(int codePoint) {
            return false;
        }
    }
}
package com.yuyan.imemodule.ui.fragment;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001:\u0001\u0010B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\b\u001a\u00020\tH\u0002J\u0012\u0010\n\u001a\u00020\t2\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016J\u001c\u0010\r\u001a\u00020\t2\b\u0010\u000b\u001a\u0004\u0018\u00010\f2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0005H\u0016J\b\u0010\u000f\u001a\u00020\tH\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/VoiceSettingsFragment;", "Landroidx/preference/PreferenceFragmentCompat;", "()V", "importModelLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "", "progressPreference", "Lcom/yuyan/imemodule/ui/fragment/VoiceSettingsFragment$InlineProgressBarPreference;", "checkAndRequestMicPermission", "", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onCreatePreferences", "rootKey", "onResume", "InlineProgressBarPreference", "yuyansdk_offlineDebug"})
public final class VoiceSettingsFragment extends androidx.preference.PreferenceFragmentCompat {
    private androidx.activity.result.ActivityResultLauncher<java.lang.String> importModelLauncher;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.ui.fragment.VoiceSettingsFragment.InlineProgressBarPreference progressPreference;
    
    public VoiceSettingsFragment() {
        super();
    }
    
    @java.lang.Override()
    public void onCreate(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
    }
    
    @java.lang.Override()
    public void onResume() {
    }
    
    private final void checkAndRequestMicPermission() {
    }
    
    @java.lang.Override()
    public void onCreatePreferences(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState, @org.jetbrains.annotations.Nullable()
    java.lang.String rootKey) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016R$\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0006@FX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000b\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/VoiceSettingsFragment$InlineProgressBarPreference;", "Landroidx/preference/Preference;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "value", "", "statusText", "getStatusText", "()Ljava/lang/String;", "setStatusText", "(Ljava/lang/String;)V", "onBindViewHolder", "", "holder", "Landroidx/preference/PreferenceViewHolder;", "yuyansdk_offlineDebug"})
    public static final class InlineProgressBarPreference extends androidx.preference.Preference {
        @org.jetbrains.annotations.NotNull()
        private java.lang.String statusText = "\u6b63\u5728\u89e3\u538b\u5e76\u5bfc\u5165\u8bed\u97f3\u6a21\u578b\u6587\u4ef6\uff0c\u8bf7\u7a0d\u5019...";
        
        public InlineProgressBarPreference(@org.jetbrains.annotations.NotNull()
        android.content.Context context) {
            super(null, null, 0, 0);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getStatusText() {
            return null;
        }
        
        public final void setStatusText(@org.jetbrains.annotations.NotNull()
        java.lang.String value) {
        }
        
        @java.lang.Override()
        public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
        androidx.preference.PreferenceViewHolder holder) {
        }
    }
}
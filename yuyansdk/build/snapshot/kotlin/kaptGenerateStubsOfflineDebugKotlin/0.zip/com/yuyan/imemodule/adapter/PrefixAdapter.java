package com.yuyan.imemodule.adapter;

/**
 * 拼音选择
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u0017B\u001d\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0002\u0010\bJ\b\u0010\u000e\u001a\u00020\rH\u0016J\u001c\u0010\u000f\u001a\u00020\u00102\n\u0010\u0011\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0012\u001a\u00020\rH\u0016J\u001c\u0010\u0013\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\rH\u0016R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u000bR\u000e\u0010\f\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0018"}, d2 = {"Lcom/yuyan/imemodule/adapter/PrefixAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/adapter/PrefixAdapter$SymbolTypeHolder;", "context", "Landroid/content/Context;", "mDatas", "", "", "(Landroid/content/Context;[Ljava/lang/String;)V", "inflater", "Landroid/view/LayoutInflater;", "[Ljava/lang/String;", "textColor", "", "getItemCount", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "SymbolTypeHolder", "yuyansdk_offlineDebug"})
public final class PrefixAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.adapter.PrefixAdapter.SymbolTypeHolder> {
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String[] mDatas = null;
    @org.jetbrains.annotations.NotNull()
    private final android.view.LayoutInflater inflater = null;
    private final int textColor = 0;
    
    public PrefixAdapter(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    java.lang.String[] mDatas) {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.adapter.PrefixAdapter.SymbolTypeHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.adapter.PrefixAdapter.SymbolTypeHolder holder, int position) {
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/adapter/PrefixAdapter$SymbolTypeHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "(Lcom/yuyan/imemodule/adapter/PrefixAdapter;Landroid/view/View;)V", "tvSymbolType", "Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "getTvSymbolType", "()Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "setTvSymbolType", "(Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;)V", "yuyansdk_offlineDebug"})
    public final class SymbolTypeHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.NotNull()
        private com.yuyan.imemodule.view.popup.AutoScaleTextView tvSymbolType;
        
        public SymbolTypeHolder(@org.jetbrains.annotations.NotNull()
        android.view.View view) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.popup.AutoScaleTextView getTvSymbolType() {
            return null;
        }
        
        public final void setTvSymbolType(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.view.popup.AutoScaleTextView p0) {
        }
    }
}
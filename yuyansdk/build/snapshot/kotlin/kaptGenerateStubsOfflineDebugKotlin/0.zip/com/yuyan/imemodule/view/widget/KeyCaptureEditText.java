package com.yuyan.imemodule.view.widget;

/**
 * 专门用于【输入码】捕获的 EditText
 * 处于焦点时，通过 privateImeOptions = "com.yuyan.KEY_CAPTURE" 告知 IME
 * 拦截 Pinyin 拼音输入，直接捕获当前键盘点击的物理/软键盘键值。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u001b\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/view/widget/KeyCaptureEditText;", "Lcom/yuyan/imemodule/view/widget/ImeEditText;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "yuyansdk_offlineDebug"})
public final class KeyCaptureEditText extends com.yuyan.imemodule.view.widget.ImeEditText {
    
    @kotlin.jvm.JvmOverloads()
    public KeyCaptureEditText(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null, null);
    }
    
    @kotlin.jvm.JvmOverloads()
    public KeyCaptureEditText(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null, null);
    }
}
package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0017\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\b\u0012\u0004\u0012\u00020\u00040\u0003:\u0001\u001eB\u0013\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0006\u00a2\u0006\u0002\u0010\u0007J\b\u0010\u0012\u001a\u00020\tH\u0016J\u0018\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u00042\u0006\u0010\u0016\u001a\u00020\tH\u0016J\u0015\u0010\u0017\u001a\u00020\u00142\u0006\u0010\u0018\u001a\u00028\u0000H\u0016\u00a2\u0006\u0002\u0010\u0019J\u0018\u0010\u001a\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\tH\u0016R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R$\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\t@FX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u0013\u0010\u000f\u001a\u0004\u0018\u00018\u00008F\u00a2\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011\u00a8\u0006\u001f"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/SimpleThemeListAdapter;", "T", "Lcom/yuyan/imemodule/data/theme/Theme;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/ui/fragment/theme/SimpleThemeListAdapter$ViewHolder;", "entries", "", "(Ljava/util/List;)V", "value", "", "selected", "getSelected", "()I", "setSelected", "(I)V", "selectedTheme", "getSelectedTheme", "()Lcom/yuyan/imemodule/data/theme/Theme;", "getItemCount", "onBindViewHolder", "", "holder", "position", "onClick", "theme", "(Lcom/yuyan/imemodule/data/theme/Theme;)V", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "ViewHolder", "yuyansdk_offlineDebug"})
public class SimpleThemeListAdapter<T extends com.yuyan.imemodule.data.theme.Theme> extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.ui.fragment.theme.SimpleThemeListAdapter.ViewHolder> {
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<T> entries = null;
    private int selected = -1;
    
    public SimpleThemeListAdapter(@org.jetbrains.annotations.NotNull()
    java.util.List<? extends T> entries) {
        super();
    }
    
    public final int getSelected() {
        return 0;
    }
    
    public final void setSelected(int value) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final T getSelectedTheme() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.ui.fragment.theme.SimpleThemeListAdapter.ViewHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.ui.fragment.theme.SimpleThemeListAdapter.ViewHolder holder, int position) {
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    public void onClick(@org.jetbrains.annotations.NotNull()
    T theme) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/SimpleThemeListAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "ui", "Lsplitties/views/dsl/core/Ui;", "(Lsplitties/views/dsl/core/Ui;)V", "getUi", "()Lsplitties/views/dsl/core/Ui;", "yuyansdk_offlineDebug"})
    public static final class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.NotNull()
        private final splitties.views.dsl.core.Ui ui = null;
        
        public ViewHolder(@org.jetbrains.annotations.NotNull()
        splitties.views.dsl.core.Ui ui) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final splitties.views.dsl.core.Ui getUi() {
            return null;
        }
    }
}
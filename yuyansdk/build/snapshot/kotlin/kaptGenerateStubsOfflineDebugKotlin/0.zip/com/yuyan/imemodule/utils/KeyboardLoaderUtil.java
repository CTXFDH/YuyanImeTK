package com.yuyan.imemodule.utils;

/**
 * 键盘加载类  包括中文9键  中文26键 英文26键
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010!\n\u0002\b\u0003\b\u0007\u0018\u0000 )2\u00020\u0001:\u0001)B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\r\u001a\u00020\fJ\u0010\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0004H\u0002J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0010\u001a\u00020\u0004H\u0002J+\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00142\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00040\u00142\b\b\u0002\u0010\u0016\u001a\u00020\u0017H\u0002\u00a2\u0006\u0002\u0010\u0018J!\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00142\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00040\u0014H\u0002\u00a2\u0006\u0002\u0010\u001aJ!\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00142\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00040\u0014H\u0002\u00a2\u0006\u0002\u0010\u001aJ!\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00142\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00040\u0014H\u0002\u00a2\u0006\u0002\u0010\u001aJ!\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00142\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00040\u0014H\u0002\u00a2\u0006\u0002\u0010\u001aJ!\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00142\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00040\u0014H\u0002\u00a2\u0006\u0002\u0010\u001aJ!\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u000f0\u00142\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00040\u0014H\u0002\u00a2\u0006\u0002\u0010\u001aJ\u000e\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020\u0004J$\u0010 \u001a\u00020!2\u0012\u0010#\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0$0$2\u0006\u0010%\u001a\u00020\u0006H\u0002J\u0016\u0010&\u001a\b\u0012\u0004\u0012\u00020\u000f0\'2\u0006\u0010\"\u001a\u00020\u0004H\u0002J\u0010\u0010(\u001a\u00020!2\u0006\u0010\"\u001a\u00020\u0004H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006*"}, d2 = {"Lcom/yuyan/imemodule/utils/KeyboardLoaderUtil;", "", "()V", "mSkbValue", "", "numberLine", "", "rimeValue", "", "skbStyleMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbStyleMode;", "changeSKBNumberRow", "", "clearKeyboardMap", "createHandwritingKey", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "code", "createKeyToggle", "Lcom/yuyan/imemodule/entity/keyboard/SoftKeyToggle;", "createLX17Keys", "", "codes", "width", "", "([Ljava/lang/Integer;F)[Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "createNumberLineKeys", "([Ljava/lang/Integer;)[Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "createQwertyKeys", "createQwertyPYKeys", "createT9Keys", "createT9NumberKeys", "createTextEditKeys", "getSoftKeyboard", "Lcom/yuyan/imemodule/entity/keyboard/SoftKeyboard;", "skbValue", "rows", "", "isNumberRow", "lastRows", "", "loadBaseSkb", "Companion", "yuyansdk_offlineDebug"})
public final class KeyboardLoaderUtil {
    @org.jetbrains.annotations.Nullable()
    private java.lang.String rimeValue;
    private int mSkbValue = 0;
    private boolean numberLine = false;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.prefs.behavior.SkbStyleMode skbStyleMode = com.yuyan.imemodule.prefs.behavior.SkbStyleMode.Yuyan;
    @org.jetbrains.annotations.Nullable()
    private static com.yuyan.imemodule.utils.KeyboardLoaderUtil mInstance;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.HashMap<java.lang.Integer, com.yuyan.imemodule.entity.keyboard.SoftKeyboard> mSoftKeyboardMap = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.KeyboardLoaderUtil.Companion Companion = null;
    
    private KeyboardLoaderUtil() {
        super();
    }
    
    public final void clearKeyboardMap() {
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKeyboard loadBaseSkb(int skbValue) {
        return null;
    }
    
    private final java.util.List<com.yuyan.imemodule.entity.keyboard.SoftKey> lastRows(int skbValue) {
        return null;
    }
    
    public final void changeSKBNumberRow() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.keyboard.SoftKeyboard getSoftKeyboard(int skbValue) {
        return null;
    }
    
    /**
     * 生成键盘布局，主要用于计算键盘边界
     */
    private final com.yuyan.imemodule.entity.keyboard.SoftKeyboard getSoftKeyboard(java.util.List<? extends java.util.List<? extends com.yuyan.imemodule.entity.keyboard.SoftKey>> rows, boolean isNumberRow) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKey[] createT9Keys(java.lang.Integer[] codes) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKey[] createT9NumberKeys(java.lang.Integer[] codes) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKey[] createQwertyPYKeys(java.lang.Integer[] codes) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKey[] createQwertyKeys(java.lang.Integer[] codes) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKey createHandwritingKey(int code) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKey[] createNumberLineKeys(java.lang.Integer[] codes) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKey[] createLX17Keys(java.lang.Integer[] codes, float width) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKey[] createTextEditKeys(java.lang.Integer[] codes) {
        return null;
    }
    
    private final com.yuyan.imemodule.entity.keyboard.SoftKeyToggle createKeyToggle(int code) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.KeyboardLoaderUtil getInstance() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u001a\u0010\u0003\u001a\u00020\u00048FX\u0087\u0004\u00a2\u0006\f\u0012\u0004\b\u0005\u0010\u0002\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\b\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/utils/KeyboardLoaderUtil$Companion;", "", "()V", "instance", "Lcom/yuyan/imemodule/utils/KeyboardLoaderUtil;", "getInstance$annotations", "getInstance", "()Lcom/yuyan/imemodule/utils/KeyboardLoaderUtil;", "mInstance", "mSoftKeyboardMap", "Ljava/util/HashMap;", "", "Lcom/yuyan/imemodule/entity/keyboard/SoftKeyboard;", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @kotlin.jvm.JvmStatic()
        @java.lang.Deprecated()
        public static void getInstance$annotations() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.utils.KeyboardLoaderUtil getInstance() {
            return null;
        }
    }
}
package com.yuyan.imemodule.speech;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0005\n\u0002\u0010\u0012\n\u0002\b\u0012\b\u0007\u0018\u0000 92\u00020\u0001:\u00029:B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010%\u001a\u00020\bJ\n\u0010&\u001a\u0004\u0018\u00010\u001aH\u0003J\u0010\u0010\'\u001a\u00020\u00102\u0006\u0010(\u001a\u00020)H\u0002J\b\u0010*\u001a\u00020\u0010H\u0002J\u0006\u0010+\u001a\u00020\bJ\u0084\u0001\u0010,\u001a\u00020\b2\u0012\u0010-\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\b0\u00062\u0012\u0010.\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\b0\u00062\u0012\u0010/\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\b0\u00062\u0018\u00100\u001a\u0014\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\b0\u000e2\u0012\u00101\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u00062\u0012\u00102\u001a\u000e\u0012\u0004\u0012\u00020#\u0012\u0004\u0012\u00020\b0\u0006J\u0010\u00103\u001a\u00020\b2\u0006\u00104\u001a\u00020\fH\u0002J\u0006\u00105\u001a\u00020\bJ\b\u00106\u001a\u00020\bH\u0007J\b\u00107\u001a\u00020\bH\u0002J\u0006\u00108\u001a\u00020\bR\u001c\u0010\u0005\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\"\u0010\r\u001a\u0016\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\b\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0016\u001a\u0010\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\b\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001d\u001a\b\u0018\u00010\u001eR\u00020\u0000X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u001f\u001a\u0010\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\b\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\"\u001a\u0010\u0012\u0004\u0012\u00020#\u0012\u0004\u0012\u00020\b\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010$\u001a\u0010\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\b\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006;"}, d2 = {"Lcom/yuyan/imemodule/speech/SpeechRecognitionManager;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "amplitudeCallback", "Lkotlin/Function1;", "", "", "backend", "Lcom/yuyan/imemodule/speech/AsrBackend;", "currentState", "Lcom/yuyan/imemodule/speech/RecognitionState;", "errorCallback", "Lkotlin/Function2;", "", "", "isPreloading", "loadingCancelled", "loadingInProgress", "mainHandler", "Landroid/os/Handler;", "partialResultCallback", "preStartTimeoutRunnable", "Ljava/lang/Runnable;", "preStartedRecord", "Landroid/media/AudioRecord;", "preloadLock", "Ljava/lang/Object;", "recordingThread", "Lcom/yuyan/imemodule/speech/SpeechRecognitionManager$RecordingThread;", "resultCallback", "sessionId", "", "spectrumCallback", "", "stateCallback", "cancelPreStart", "createAudioRecord", "isSpeech", "data", "", "preload", "release", "setCallbacks", "onResult", "onPartialResult", "onStateChange", "onError", "onAmplitude", "onSpectrum", "setState", "state", "startPreStart", "startRecognition", "startRecording", "stopRecognition", "Companion", "RecordingThread", "yuyansdk_offlineDebug"})
public final class SpeechRecognitionManager {
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context context = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String TAG = "SpeechRecognitionManager";
    private static final int SAMPLE_RATE = 16000;
    private static final int CHANNEL_CONFIG = android.media.AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = android.media.AudioFormat.ENCODING_PCM_16BIT;
    private static final float BUFFER_SIZE_SECONDS = 0.1F;
    private static final int SPEECH_THRESHOLD = 25;
    private static final long JOIN_TIMEOUT_MS = 5000L;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.speech.AsrBackend backend;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.speech.SpeechRecognitionManager.RecordingThread recordingThread;
    @org.jetbrains.annotations.NotNull()
    private final android.os.Handler mainHandler = null;
    private int sessionId = 0;
    @kotlin.jvm.Volatile()
    private volatile boolean loadingInProgress = false;
    @kotlin.jvm.Volatile()
    private volatile boolean loadingCancelled = false;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> resultCallback;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> partialResultCallback;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.speech.RecognitionState, kotlin.Unit> stateCallback;
    @kotlin.jvm.Volatile()
    @org.jetbrains.annotations.NotNull()
    private volatile com.yuyan.imemodule.speech.RecognitionState currentState = com.yuyan.imemodule.speech.RecognitionState.IDLE;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function2<? super java.lang.String, ? super java.lang.Boolean, kotlin.Unit> errorCallback;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function1<? super java.lang.Float, kotlin.Unit> amplitudeCallback;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function1<? super float[], kotlin.Unit> spectrumCallback;
    @org.jetbrains.annotations.Nullable()
    private android.media.AudioRecord preStartedRecord;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.Runnable preStartTimeoutRunnable = null;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.Object preloadLock = null;
    private boolean isPreloading = false;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.speech.SpeechRecognitionManager.Companion Companion = null;
    
    public SpeechRecognitionManager(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super();
    }
    
    public final void setCallbacks(@org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onResult, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onPartialResult, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.speech.RecognitionState, kotlin.Unit> onStateChange, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function2<? super java.lang.String, ? super java.lang.Boolean, kotlin.Unit> onError, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.lang.Float, kotlin.Unit> onAmplitude, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super float[], kotlin.Unit> onSpectrum) {
    }
    
    @androidx.annotation.RequiresPermission(value = "android.permission.RECORD_AUDIO")
    public final void startRecognition() {
    }
    
    private final void startRecording() {
    }
    
    public final void stopRecognition() {
    }
    
    public final void release() {
    }
    
    private final void setState(com.yuyan.imemodule.speech.RecognitionState state) {
    }
    
    public final void startPreStart() {
    }
    
    public final void cancelPreStart() {
    }
    
    private final boolean preload() {
        return false;
    }
    
    private final boolean isSpeech(byte[] data) {
        return false;
    }
    
    @android.annotation.SuppressLint(value = {"MissingPermission"})
    private final android.media.AudioRecord createAudioRecord() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/speech/SpeechRecognitionManager$Companion;", "", "()V", "AUDIO_FORMAT", "", "BUFFER_SIZE_SECONDS", "", "CHANNEL_CONFIG", "JOIN_TIMEOUT_MS", "", "SAMPLE_RATE", "SPEECH_THRESHOLD", "TAG", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006J\b\u0010\u0016\u001a\u00020\u000bH\u0016JB\u0010\u0017\u001a\u00020\u000b2\u0012\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\t2\u0012\u0010\u0019\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\t2\u0012\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\tR\u0010\u0010\u0007\u001a\u0004\u0018\u00010\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0004\u001a\u0004\u0018\u00010\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\b\u001a\u0010\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\f\u001a\u0010\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\r\u001a\u0010\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0010\u001a\u00020\u0011X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015\u00a8\u0006\u001b"}, d2 = {"Lcom/yuyan/imemodule/speech/SpeechRecognitionManager$RecordingThread;", "Ljava/lang/Thread;", "currentBackend", "Lcom/yuyan/imemodule/speech/AsrBackend;", "preStarted", "Landroid/media/AudioRecord;", "(Lcom/yuyan/imemodule/speech/SpeechRecognitionManager;Lcom/yuyan/imemodule/speech/AsrBackend;Landroid/media/AudioRecord;)V", "audioRecord", "resErrorCallback", "Lkotlin/Function1;", "", "", "resPartialCallback", "resResultCallback", "spectrumAnalyzer", "Lcom/yuyan/imemodule/speech/SpectrumAnalyzer;", "stopRequested", "", "getStopRequested", "()Z", "setStopRequested", "(Z)V", "run", "setCallbacks", "onResult", "onPartialResult", "onError", "yuyansdk_offlineDebug"})
    final class RecordingThread extends java.lang.Thread {
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.speech.AsrBackend currentBackend = null;
        @org.jetbrains.annotations.Nullable()
        private final android.media.AudioRecord preStarted = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.speech.SpectrumAnalyzer spectrumAnalyzer = null;
        @kotlin.jvm.Volatile()
        private volatile boolean stopRequested = false;
        @kotlin.jvm.Volatile()
        @org.jetbrains.annotations.Nullable()
        private volatile android.media.AudioRecord audioRecord;
        @org.jetbrains.annotations.Nullable()
        private kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> resResultCallback;
        @org.jetbrains.annotations.Nullable()
        private kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> resPartialCallback;
        @org.jetbrains.annotations.Nullable()
        private kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> resErrorCallback;
        
        public RecordingThread(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.speech.AsrBackend currentBackend, @org.jetbrains.annotations.Nullable()
        android.media.AudioRecord preStarted) {
            super();
        }
        
        public final boolean getStopRequested() {
            return false;
        }
        
        public final void setStopRequested(boolean p0) {
        }
        
        public final void setCallbacks(@org.jetbrains.annotations.NotNull()
        kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onResult, @org.jetbrains.annotations.NotNull()
        kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onPartialResult, @org.jetbrains.annotations.NotNull()
        kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onError) {
        }
        
        @java.lang.Override()
        public void run() {
        }
    }
}
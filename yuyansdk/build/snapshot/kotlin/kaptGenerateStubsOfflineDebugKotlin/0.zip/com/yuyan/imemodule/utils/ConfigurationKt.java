package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u00a8\u0006\u0003"}, d2 = {"isDarkMode", "", "Landroid/content/res/Configuration;", "yuyansdk_offlineDebug"})
public final class ConfigurationKt {
    
    public static final boolean isDarkMode(@org.jetbrains.annotations.NotNull()
    android.content.res.Configuration $this$isDarkMode) {
        return false;
    }
}
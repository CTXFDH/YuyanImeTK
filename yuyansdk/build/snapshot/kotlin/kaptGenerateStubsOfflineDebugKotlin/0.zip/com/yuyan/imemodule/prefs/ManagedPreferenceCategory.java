package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\b\'\u0018\u00002\u00020\u0001B\u0017\u0012\b\b\u0001\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J$\u0010\u000b\u001a\u00020\f2\b\b\u0001\u0010\u0002\u001a\u00020\u00032\u0010\b\u0002\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eH\u0004J\u0010\u0010\u0010\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u0012H\u0016Jm\u0010\u0013\u001a\u00020\u00142\b\b\u0001\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00032\b\b\u0002\u0010\u0018\u001a\u00020\u00032\b\b\u0002\u0010\u0019\u001a\u00020\u00032\b\b\u0002\u0010\u001a\u001a\u00020\u00162\b\b\u0002\u0010\u001b\u001a\u00020\u00032\n\b\u0003\u0010\u001c\u001a\u0004\u0018\u00010\u00032\u0010\b\u0002\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eH\u0004\u00a2\u0006\u0002\u0010\u001dJu\u0010\u001e\u001a\b\u0012\u0004\u0012\u0002H 0\u001f\"\b\b\u0000\u0010 *\u00020!2\b\b\u0001\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u0002H 2\f\u0010\"\u001a\b\u0012\u0004\u0012\u0002H 0#2\f\u0010$\u001a\b\u0012\u0004\u0012\u0002H 0%2\u000e\b\u0001\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00030%2\u0010\b\u0002\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eH\u0004\u00a2\u0006\u0002\u0010\'JE\u0010(\u001a\u00020)2\b\b\u0001\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u000f2\n\b\u0003\u0010*\u001a\u0004\u0018\u00010\u00032\u0010\b\u0002\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eH\u0004\u00a2\u0006\u0002\u0010+J\u0099\u0001\u0010,\u001a\u000e\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u00140-2\b\b\u0001\u0010\u0002\u001a\u00020\u00032\b\b\u0001\u0010.\u001a\u00020\u00032\u0006\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00032\b\b\u0001\u0010/\u001a\u00020\u00032\u0006\u00100\u001a\u00020\u00162\u0006\u00101\u001a\u00020\u00032\u0006\u0010\u0018\u001a\u00020\u00032\u0006\u0010\u0019\u001a\u00020\u00032\b\b\u0002\u0010\u001a\u001a\u00020\u00162\b\b\u0002\u0010\u001b\u001a\u00020\u00032\n\b\u0003\u0010\u001c\u001a\u0004\u0018\u00010\u00032\u0010\b\u0002\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eH\u0004\u00a2\u0006\u0002\u00102R\u0014\u0010\u0004\u001a\u00020\u0005X\u0084\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n\u00a8\u00063"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceCategory;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "title", "", "sharedPreferences", "Landroid/content/SharedPreferences;", "(ILandroid/content/SharedPreferences;)V", "getSharedPreferences", "()Landroid/content/SharedPreferences;", "getTitle", "()I", "category", "", "enableUiOn", "Lkotlin/Function0;", "", "createUi", "screen", "Landroidx/preference/PreferenceScreen;", "int", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "key", "", "defaultValue", "min", "max", "unit", "step", "defaultLabel", "(ILjava/lang/String;IIILjava/lang/String;ILjava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "list", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "T", "", "codec", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "entryValues", "", "entryLabels", "(ILjava/lang/String;Ljava/lang/Object;Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;Ljava/util/List;Ljava/util/List;Lkotlin/jvm/functions/Function0;)Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "switch", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "summary", "(ILjava/lang/String;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "twinInt", "Lkotlin/Pair;", "label", "secondaryLabel", "secondaryKey", "secondaryDefaultValue", "(IILjava/lang/String;IILjava/lang/String;IIILjava/lang/String;ILjava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lkotlin/Pair;", "yuyansdk_offlineDebug"})
public abstract class ManagedPreferenceCategory extends com.yuyan.imemodule.prefs.ManagedPreferenceProvider {
    private final int title = 0;
    @org.jetbrains.annotations.NotNull()
    private final android.content.SharedPreferences sharedPreferences = null;
    
    public ManagedPreferenceCategory(@androidx.annotation.StringRes()
    int title, @org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences sharedPreferences) {
        super();
    }
    
    public final int getTitle() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    protected final android.content.SharedPreferences getSharedPreferences() {
        return null;
    }
    
    protected final void category(@androidx.annotation.StringRes()
    int title, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
    }
    
    @org.jetbrains.annotations.NotNull()
    protected final <T extends java.lang.Object>com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<T> list(@androidx.annotation.StringRes()
    int title, @org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    T defaultValue, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<T> codec, @org.jetbrains.annotations.NotNull()
    java.util.List<? extends T> entryValues, @androidx.annotation.StringRes()
    @org.jetbrains.annotations.NotNull()
    java.util.List<java.lang.Integer> entryLabels, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    protected final kotlin.Pair<com.yuyan.imemodule.view.preference.ManagedPreference.PInt, com.yuyan.imemodule.view.preference.ManagedPreference.PInt> twinInt(@androidx.annotation.StringRes()
    int title, @androidx.annotation.StringRes()
    int label, @org.jetbrains.annotations.NotNull()
    java.lang.String key, int defaultValue, @androidx.annotation.StringRes()
    int secondaryLabel, @org.jetbrains.annotations.NotNull()
    java.lang.String secondaryKey, int secondaryDefaultValue, int min, int max, @org.jetbrains.annotations.NotNull()
    java.lang.String unit, int step, @androidx.annotation.StringRes()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer defaultLabel, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
        return null;
    }
    
    @java.lang.Override()
    public void createUi(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceScreen screen) {
    }
}
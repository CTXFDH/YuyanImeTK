package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\t\b\'\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\u00020\u0003:\u0006\u0011\u0012\u0013\u0014\u0015\u0016B\u001f\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0010\b\u0002\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007\u00a2\u0006\u0002\u0010\tJ\u0015\u0010\f\u001a\u00028\u00002\u0006\u0010\r\u001a\u00020\u000eH&\u00a2\u0006\u0002\u0010\u000fJ\u0006\u0010\u0010\u001a\u00020\bR\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b\u00a8\u0006\u0017"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "T", "Landroidx/preference/Preference;", "", "key", "", "enableUiOn", "Lkotlin/Function0;", "", "(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V", "getKey", "()Ljava/lang/String;", "createUi", "context", "Landroid/content/Context;", "(Landroid/content/Context;)Landroidx/preference/Preference;", "isEnabled", "Category", "EditTextInt", "SeekBarInt", "StringList", "Switch", "TwinSeekBarInt", "yuyansdk_offlineDebug"})
public abstract class ManagedPreferenceUi<T extends androidx.preference.Preference> {
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String key = null;
    @org.jetbrains.annotations.Nullable()
    private final kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn = null;
    
    public ManagedPreferenceUi(@org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getKey() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public abstract T createUi(@org.jetbrains.annotations.NotNull()
    android.content.Context context);
    
    public final boolean isEnabled() {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B!\u0012\b\b\u0001\u0010\u0003\u001a\u00020\u0004\u0012\u0010\b\u0002\u0010\u0005\u001a\n\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u0006\u00a2\u0006\u0002\u0010\bJ\u0010\u0010\u000b\u001a\u00020\u00022\u0006\u0010\f\u001a\u00020\rH\u0016R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi$Category;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "Landroidx/preference/PreferenceCategory;", "title", "", "enableUiOn", "Lkotlin/Function0;", "", "(ILkotlin/jvm/functions/Function0;)V", "getTitle", "()I", "createUi", "context", "Landroid/content/Context;", "yuyansdk_offlineDebug"})
    public static final class Category extends com.yuyan.imemodule.prefs.ManagedPreferenceUi<androidx.preference.PreferenceCategory> {
        private final int title = 0;
        
        public Category(@androidx.annotation.StringRes()
        int title, @org.jetbrains.annotations.Nullable()
        kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
            super(null, null);
        }
        
        public final int getTitle() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public androidx.preference.PreferenceCategory createUi(@org.jetbrains.annotations.NotNull()
        android.content.Context context) {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001BK\u0012\b\b\u0001\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0004\u0012\u0006\u0010\b\u001a\u00020\u0004\u0012\u0006\u0010\t\u001a\u00020\u0004\u0012\b\b\u0002\u0010\n\u001a\u00020\u0006\u0012\u0010\b\u0002\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\f\u00a2\u0006\u0002\u0010\u000eJ\u0010\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0019H\u0016R\u0011\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\t\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0011\u0010\b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0010R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0011\u0010\n\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015\u00a8\u0006\u001a"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi$EditTextInt;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "Landroidx/preference/EditTextPreference;", "title", "", "key", "", "defaultValue", "min", "max", "unit", "enableUiOn", "Lkotlin/Function0;", "", "(ILjava/lang/String;IIILjava/lang/String;Lkotlin/jvm/functions/Function0;)V", "getDefaultValue", "()I", "getMax", "getMin", "getTitle", "getUnit", "()Ljava/lang/String;", "createUi", "Lcom/yuyan/imemodule/utils/CardEditTextIntPreference;", "context", "Landroid/content/Context;", "yuyansdk_offlineDebug"})
    public static final class EditTextInt extends com.yuyan.imemodule.prefs.ManagedPreferenceUi<androidx.preference.EditTextPreference> {
        private final int title = 0;
        private final int defaultValue = 0;
        private final int min = 0;
        private final int max = 0;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String unit = null;
        
        public EditTextInt(@androidx.annotation.StringRes()
        int title, @org.jetbrains.annotations.NotNull()
        java.lang.String key, int defaultValue, int min, int max, @org.jetbrains.annotations.NotNull()
        java.lang.String unit, @org.jetbrains.annotations.Nullable()
        kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
            super(null, null);
        }
        
        public final int getTitle() {
            return 0;
        }
        
        public final int getDefaultValue() {
            return 0;
        }
        
        public final int getMin() {
            return 0;
        }
        
        public final int getMax() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getUnit() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.utils.CardEditTextIntPreference createUi(@org.jetbrains.annotations.NotNull()
        android.content.Context context) {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\r\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001Ba\u0012\b\b\u0001\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0004\u0012\u0006\u0010\b\u001a\u00020\u0004\u0012\u0006\u0010\t\u001a\u00020\u0004\u0012\b\b\u0002\u0010\n\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0004\u0012\n\b\u0003\u0010\f\u001a\u0004\u0018\u00010\u0004\u0012\u0010\b\u0002\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000e\u00a2\u0006\u0002\u0010\u0010J\u0010\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001fH\u0016R\u0015\u0010\f\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\n\n\u0002\u0010\u0013\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\t\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0015R\u0011\u0010\b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0015R\u0011\u0010\u000b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0015R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0015R\u0011\u0010\n\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001b\u00a8\u0006 "}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi$SeekBarInt;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "Lcom/yuyan/imemodule/view/preference/DialogSeekBarPreference;", "title", "", "key", "", "defaultValue", "min", "max", "unit", "step", "defaultLabel", "enableUiOn", "Lkotlin/Function0;", "", "(ILjava/lang/String;IIILjava/lang/String;ILjava/lang/Integer;Lkotlin/jvm/functions/Function0;)V", "getDefaultLabel", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getDefaultValue", "()I", "getMax", "getMin", "getStep", "getTitle", "getUnit", "()Ljava/lang/String;", "createUi", "Lcom/yuyan/imemodule/utils/CardDialogSeekBarPreference;", "context", "Landroid/content/Context;", "yuyansdk_offlineDebug"})
    public static final class SeekBarInt extends com.yuyan.imemodule.prefs.ManagedPreferenceUi<com.yuyan.imemodule.view.preference.DialogSeekBarPreference> {
        private final int title = 0;
        private final int defaultValue = 0;
        private final int min = 0;
        private final int max = 0;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String unit = null;
        private final int step = 0;
        @org.jetbrains.annotations.Nullable()
        private final java.lang.Integer defaultLabel = null;
        
        public SeekBarInt(@androidx.annotation.StringRes()
        int title, @org.jetbrains.annotations.NotNull()
        java.lang.String key, int defaultValue, int min, int max, @org.jetbrains.annotations.NotNull()
        java.lang.String unit, int step, @androidx.annotation.StringRes()
        @org.jetbrains.annotations.Nullable()
        java.lang.Integer defaultLabel, @org.jetbrains.annotations.Nullable()
        kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
            super(null, null);
        }
        
        public final int getTitle() {
            return 0;
        }
        
        public final int getDefaultValue() {
            return 0;
        }
        
        public final int getMin() {
            return 0;
        }
        
        public final int getMax() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getUnit() {
            return null;
        }
        
        public final int getStep() {
            return 0;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.Integer getDefaultLabel() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.utils.CardDialogSeekBarPreference createUi(@org.jetbrains.annotations.NotNull()
        android.content.Context context) {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u0000*\b\b\u0001\u0010\u0001*\u00020\u00022\b\u0012\u0004\u0012\u00020\u00040\u0003B]\u0012\b\b\u0001\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00028\u0001\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00010\u000b\u0012\f\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00010\r\u0012\u000e\b\u0001\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00060\r\u0012\u0010\b\u0002\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0011\u0018\u00010\u0010\u00a2\u0006\u0002\u0010\u0012J\u0010\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 H\u0016R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00010\u000b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0013\u0010\t\u001a\u00028\u0001\u00a2\u0006\n\n\u0002\u0010\u0017\u001a\u0004\b\u0015\u0010\u0016R\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00060\r\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0017\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00010\r\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001c\u00a8\u0006!"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi$StringList;", "T", "", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "Landroidx/preference/ListPreference;", "title", "", "key", "", "defaultValue", "codec", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "entryValues", "", "entryLabels", "enableUiOn", "Lkotlin/Function0;", "", "(ILjava/lang/String;Ljava/lang/Object;Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;Ljava/util/List;Ljava/util/List;Lkotlin/jvm/functions/Function0;)V", "getCodec", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "getDefaultValue", "()Ljava/lang/Object;", "Ljava/lang/Object;", "getEntryLabels", "()Ljava/util/List;", "getEntryValues", "getTitle", "()I", "createUi", "Lcom/yuyan/imemodule/utils/CardListPreference;", "context", "Landroid/content/Context;", "yuyansdk_offlineDebug"})
    public static final class StringList<T extends java.lang.Object> extends com.yuyan.imemodule.prefs.ManagedPreferenceUi<androidx.preference.ListPreference> {
        private final int title = 0;
        @org.jetbrains.annotations.NotNull()
        private final T defaultValue = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<T> codec = null;
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<T> entryValues = null;
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<java.lang.Integer> entryLabels = null;
        
        public StringList(@androidx.annotation.StringRes()
        int title, @org.jetbrains.annotations.NotNull()
        java.lang.String key, @org.jetbrains.annotations.NotNull()
        T defaultValue, @org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<T> codec, @org.jetbrains.annotations.NotNull()
        java.util.List<? extends T> entryValues, @androidx.annotation.StringRes()
        @org.jetbrains.annotations.NotNull()
        java.util.List<java.lang.Integer> entryLabels, @org.jetbrains.annotations.Nullable()
        kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
            super(null, null);
        }
        
        public final int getTitle() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final T getDefaultValue() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<T> getCodec() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<T> getEntryValues() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<java.lang.Integer> getEntryLabels() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.utils.CardListPreference createUi(@org.jetbrains.annotations.NotNull()
        android.content.Context context) {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001BI\u0012\b\b\u0001\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\n\b\u0003\u0010\t\u001a\u0004\u0018\u00010\u0004\u0012\u0010\b\u0002\u0010\n\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u000b\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\r\u00a2\u0006\u0002\u0010\u000eJ\u0010\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u001bH\u0016R\u0011\u0010\u0007\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0013\u0010\f\u001a\u0004\u0018\u00010\r\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0015\u0010\t\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\n\n\u0002\u0010\u0015\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017\u00a8\u0006\u001c"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi$Switch;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "Lcom/yuyan/imemodule/view/preference/ImeSwitchPreference;", "title", "", "key", "", "defaultValue", "", "summary", "enableUiOn", "Lkotlin/Function0;", "pref", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "(ILjava/lang/String;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function0;Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;)V", "getDefaultValue", "()Z", "getPref", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "getSummary", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getTitle", "()I", "createUi", "Lcom/yuyan/imemodule/utils/CardSwitchPreference;", "context", "Landroid/content/Context;", "yuyansdk_offlineDebug"})
    public static final class Switch extends com.yuyan.imemodule.prefs.ManagedPreferenceUi<com.yuyan.imemodule.view.preference.ImeSwitchPreference> {
        private final int title = 0;
        private final boolean defaultValue = false;
        @org.jetbrains.annotations.Nullable()
        private final java.lang.Integer summary = null;
        @org.jetbrains.annotations.Nullable()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool pref = null;
        
        public Switch(@androidx.annotation.StringRes()
        int title, @org.jetbrains.annotations.NotNull()
        java.lang.String key, boolean defaultValue, @androidx.annotation.StringRes()
        @org.jetbrains.annotations.Nullable()
        java.lang.Integer summary, @org.jetbrains.annotations.Nullable()
        kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn, @org.jetbrains.annotations.Nullable()
        com.yuyan.imemodule.view.preference.ManagedPreference.PBool pref) {
            super(null, null);
        }
        
        public final int getTitle() {
            return 0;
        }
        
        public final boolean getDefaultValue() {
            return false;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.Integer getSummary() {
            return null;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getPref() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.utils.CardSwitchPreference createUi(@org.jetbrains.annotations.NotNull()
        android.content.Context context) {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0085\u0001\u0012\b\b\u0001\u0010\u0003\u001a\u00020\u0004\u0012\b\b\u0001\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0004\u0012\b\b\u0001\u0010\t\u001a\u00020\u0004\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\u0006\u0010\u000b\u001a\u00020\u0004\u0012\u0006\u0010\f\u001a\u00020\u0004\u0012\u0006\u0010\r\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0004\u0012\n\b\u0003\u0010\u0010\u001a\u0004\u0018\u00010\u0004\u0012\u0010\b\u0002\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u0012\u00a2\u0006\u0002\u0010\u0014J\u0010\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020\'H\u0016R\u0015\u0010\u0010\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\n\n\u0002\u0010\u0017\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u0005\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\r\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0019R\u0011\u0010\f\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0019R\u0011\u0010\u000b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0019R\u0011\u0010\n\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0011\u0010\t\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u0019R\u0011\u0010\u000f\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0019R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0019R\u0011\u0010\u000e\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u001f\u00a8\u0006("}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi$TwinSeekBarInt;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "Lcom/yuyan/imemodule/view/preference/TwinSeekBarPreference;", "title", "", "label", "key", "", "defaultValue", "secondaryLabel", "secondaryKey", "secondaryDefaultValue", "min", "max", "unit", "step", "defaultLabel", "enableUiOn", "Lkotlin/Function0;", "", "(IILjava/lang/String;IILjava/lang/String;IIILjava/lang/String;ILjava/lang/Integer;Lkotlin/jvm/functions/Function0;)V", "getDefaultLabel", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getDefaultValue", "()I", "getLabel", "getMax", "getMin", "getSecondaryDefaultValue", "getSecondaryKey", "()Ljava/lang/String;", "getSecondaryLabel", "getStep", "getTitle", "getUnit", "createUi", "Lcom/yuyan/imemodule/utils/CardTwinSeekBarPreference;", "context", "Landroid/content/Context;", "yuyansdk_offlineDebug"})
    public static final class TwinSeekBarInt extends com.yuyan.imemodule.prefs.ManagedPreferenceUi<com.yuyan.imemodule.view.preference.TwinSeekBarPreference> {
        private final int title = 0;
        private final int label = 0;
        private final int defaultValue = 0;
        private final int secondaryLabel = 0;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String secondaryKey = null;
        private final int secondaryDefaultValue = 0;
        private final int min = 0;
        private final int max = 0;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String unit = null;
        private final int step = 0;
        @org.jetbrains.annotations.Nullable()
        private final java.lang.Integer defaultLabel = null;
        
        public TwinSeekBarInt(@androidx.annotation.StringRes()
        int title, @androidx.annotation.StringRes()
        int label, @org.jetbrains.annotations.NotNull()
        java.lang.String key, int defaultValue, @androidx.annotation.StringRes()
        int secondaryLabel, @org.jetbrains.annotations.NotNull()
        java.lang.String secondaryKey, int secondaryDefaultValue, int min, int max, @org.jetbrains.annotations.NotNull()
        java.lang.String unit, int step, @androidx.annotation.StringRes()
        @org.jetbrains.annotations.Nullable()
        java.lang.Integer defaultLabel, @org.jetbrains.annotations.Nullable()
        kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
            super(null, null);
        }
        
        public final int getTitle() {
            return 0;
        }
        
        public final int getLabel() {
            return 0;
        }
        
        public final int getDefaultValue() {
            return 0;
        }
        
        public final int getSecondaryLabel() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getSecondaryKey() {
            return null;
        }
        
        public final int getSecondaryDefaultValue() {
            return 0;
        }
        
        public final int getMin() {
            return 0;
        }
        
        public final int getMax() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getUnit() {
            return null;
        }
        
        public final int getStep() {
            return 0;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.Integer getDefaultLabel() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.utils.CardTwinSeekBarPreference createUi(@org.jetbrains.annotations.NotNull()
        android.content.Context context) {
            return null;
        }
    }
}
package com.yuyan.imemodule.utils.thread;

/**
 * @author yueban
 * @date 2019-07-18
 * @email fbzhh007@gmail.com
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0019\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0010\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/utils/thread/NamingThreadFactory;", "Ljava/util/concurrent/ThreadFactory;", "poolName", "", "daemon", "", "(Ljava/lang/String;Z)V", "group", "Ljava/lang/ThreadGroup;", "namePrefix", "threadNumber", "Ljava/util/concurrent/atomic/AtomicInteger;", "newThread", "Ljava/lang/Thread;", "r", "Ljava/lang/Runnable;", "yuyansdk_offlineDebug"})
public final class NamingThreadFactory implements java.util.concurrent.ThreadFactory {
    @org.jetbrains.annotations.Nullable()
    private final java.lang.ThreadGroup group = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.concurrent.atomic.AtomicInteger threadNumber = null;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String namePrefix = null;
    private final boolean daemon = false;
    
    @kotlin.jvm.JvmOverloads()
    public NamingThreadFactory(@org.jetbrains.annotations.NotNull()
    java.lang.String poolName) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public NamingThreadFactory(@org.jetbrains.annotations.NotNull()
    java.lang.String poolName, boolean daemon) {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.Thread newThread(@org.jetbrains.annotations.NotNull()
    java.lang.Runnable r) {
        return null;
    }
}
package com.yuyan.imemodule.view.popup;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u000e\b\u0007\u0018\u00002\u00020\u0001:\u00019BT\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0019\b\u0002\u0010\u0004\u001a\u0013\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0002\b\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00110\u000f\u00a2\u0006\u0002\u0010\u0012J\u0010\u00100\u001a\u00020\u00062\u0006\u00101\u001a\u00020\u000bH\u0002J\b\u00102\u001a\u00020\u0006H\u0002J\u0018\u00103\u001a\u00020\r2\u0006\u00104\u001a\u00020\t2\u0006\u00105\u001a\u00020\tH\u0016J\u0010\u00106\u001a\u00020\u00062\u0006\u00107\u001a\u00020\tH\u0016J\u0014\u00108\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00110\u000fH\u0016R\u000e\u0010\u0013\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00150\u001eX\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u001fR\u0014\u0010 \u001a\b\u0012\u0004\u0012\u00020\"0!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010#\u001a\b\u0012\u0004\u0012\u00020\u00110\u001eX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010$R\u000e\u0010%\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\'\u001a\u00020\u000bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010)R\u000e\u0010*\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00110\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010+\u001a\u00020,X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b-\u0010.R\u000e\u0010/\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006:"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupKeyboardMenuUi;", "Lcom/yuyan/imemodule/view/popup/PopupContainerUi;", "bounds", "Landroid/graphics/Rect;", "onDismissSelf", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "radius", "", "keyWidth", "", "isSelect", "", "popupMenuPair", "Lkotlin/Pair;", "Lcom/yuyan/imemodule/prefs/behavior/PopupMenuMode;", "", "(Landroid/graphics/Rect;Lkotlin/jvm/functions/Function1;FIZLkotlin/Pair;)V", "columnCount", "columnOrder", "", "focusBackground", "Landroid/graphics/drawable/GradientDrawable;", "focusBackgroundClear", "focusColumn", "focusRow", "focusedIndex", "inactiveBackground", "keyOrders", "", "[[I", "keyUis", "", "Lcom/yuyan/imemodule/view/popup/PopupKeyboardMenuUi$PopupKeyUi;", "keys", "[Ljava/lang/String;", "lastX", "lastY", "offsetY", "getOffsetY", "()I", "popupMenuMode", "root", "Landroid/widget/LinearLayout;", "getRoot", "()Landroid/widget/LinearLayout;", "rowCount", "markFocus", "index", "markInactive", "onChangeFocus", "x", "y", "onGestureEvent", "distance", "onTrigger", "PopupKeyUi", "yuyansdk_offlineDebug"})
public final class PopupKeyboardMenuUi extends com.yuyan.imemodule.view.popup.PopupContainerUi {
    private final float radius = 0.0F;
    private final int keyWidth = 0;
    private boolean isSelect;
    @org.jetbrains.annotations.NotNull()
    private kotlin.Pair<? extends com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> popupMenuPair;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.drawable.GradientDrawable inactiveBackground = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.drawable.GradientDrawable focusBackground = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.drawable.GradientDrawable focusBackgroundClear = null;
    private final int rowCount = 0;
    private final int columnCount = 0;
    private float lastX;
    private float lastY;
    private final int focusRow = 0;
    private final int focusColumn = 0;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.prefs.behavior.PopupMenuMode popupMenuMode = com.yuyan.imemodule.prefs.behavior.PopupMenuMode.None;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String[] keys;
    private final int offsetY = 0;
    @org.jetbrains.annotations.NotNull()
    private final int[] columnOrder = null;
    @org.jetbrains.annotations.NotNull()
    private final int[][] keyOrders = null;
    private int focusedIndex;
    @org.jetbrains.annotations.NotNull()
    private java.util.List<com.yuyan.imemodule.view.popup.PopupKeyboardMenuUi.PopupKeyUi> keyUis;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.LinearLayout root = null;
    
    public PopupKeyboardMenuUi(@org.jetbrains.annotations.NotNull()
    android.graphics.Rect bounds, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.view.popup.PopupContainerUi, kotlin.Unit> onDismissSelf, float radius, int keyWidth, boolean isSelect, @org.jetbrains.annotations.NotNull()
    kotlin.Pair<? extends com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> popupMenuPair) {
        super(null, null, null);
    }
    
    @java.lang.Override()
    public int getOffsetY() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.widget.LinearLayout getRoot() {
        return null;
    }
    
    private final void markFocus(int index) {
    }
    
    private final void markInactive() {
    }
    
    @java.lang.Override()
    public void onGestureEvent(float distance) {
    }
    
    @java.lang.Override()
    public boolean onChangeFocus(float x, float y) {
        return false;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public kotlin.Pair<com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> onTrigger() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\t\u001a\u00020\nX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u000f\u001a\u00020\u0010\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012\u00a8\u0006\u0013"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupKeyboardMenuUi$PopupKeyUi;", "Lsplitties/views/dsl/core/Ui;", "ctx", "Landroid/content/Context;", "text", "", "(Landroid/content/Context;Ljava/lang/String;)V", "getCtx", "()Landroid/content/Context;", "root", "Landroid/widget/FrameLayout;", "getRoot", "()Landroid/widget/FrameLayout;", "getText", "()Ljava/lang/String;", "textView", "Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "getTextView", "()Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "yuyansdk_offlineDebug"})
    public static final class PopupKeyUi implements splitties.views.dsl.core.Ui {
        @org.jetbrains.annotations.NotNull()
        private final android.content.Context ctx = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String text = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.popup.AutoScaleTextView textView = null;
        @org.jetbrains.annotations.NotNull()
        private final android.widget.FrameLayout root = null;
        
        public PopupKeyUi(@org.jetbrains.annotations.NotNull()
        android.content.Context ctx, @org.jetbrains.annotations.NotNull()
        java.lang.String text) {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public android.content.Context getCtx() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getText() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.popup.AutoScaleTextView getTextView() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public android.widget.FrameLayout getRoot() {
            return null;
        }
    }
}
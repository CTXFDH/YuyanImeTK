package com.yuyan.imemodule.keyboard.container;

/**
 * 设置键盘容器
 *
 * 设置键盘、切换键盘界面容器。使用RecyclerView + GridLayoutManager。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u000e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u000fJ\u0010\u0010\u001a\u001a\u00020\u00182\u0006\u0010\u0002\u001a\u00020\u0003H\u0002J\u0010\u0010\u001b\u001a\u00020\u00182\u0006\u0010\u001c\u001a\u00020\u000bH\u0002J\u0006\u0010\u001d\u001a\u00020\u0018J\u0006\u0010\u001e\u001a\u00020\u0018R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/SettingsContainer;", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "adapter", "Lcom/yuyan/imemodule/adapter/MenuAdapter;", "funItems", "", "Lcom/yuyan/imemodule/entity/SkbFunItem;", "getFunItems", "()Ljava/util/List;", "isSelectModeView", "", "()Z", "setSelectModeView", "(Z)V", "mRVMenuLayout", "Landroidx/recyclerview/widget/RecyclerView;", "mTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "enableDragItem", "", "enable", "initView", "onKeyboardMenuClick", "data", "showSettingsView", "showSkbSelelctModeView", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class SettingsContainer extends com.yuyan.imemodule.keyboard.container.BaseContainer {
    @org.jetbrains.annotations.Nullable()
    private androidx.recyclerview.widget.RecyclerView mRVMenuLayout;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.data.theme.Theme mTheme;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.adapter.MenuAdapter adapter;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> funItems = null;
    private boolean isSelectModeView = false;
    
    public SettingsContainer(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> getFunItems() {
        return null;
    }
    
    private final void initView(android.content.Context context) {
    }
    
    public final boolean isSelectModeView() {
        return false;
    }
    
    public final void setSelectModeView(boolean p0) {
    }
    
    /**
     * 弹出键盘设置界面
     */
    public final void showSettingsView() {
    }
    
    public final void enableDragItem(boolean enable) {
    }
    
    /**
     * 弹出键盘界面
     */
    public final void showSkbSelelctModeView() {
    }
    
    private final void onKeyboardMenuClick(com.yuyan.imemodule.entity.SkbFunItem data) {
    }
}
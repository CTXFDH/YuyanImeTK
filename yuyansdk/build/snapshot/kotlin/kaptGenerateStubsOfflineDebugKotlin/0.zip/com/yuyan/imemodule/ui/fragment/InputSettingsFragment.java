package com.yuyan.imemodule.ui.fragment;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\r\u001a\u00020\u000eH\u0016J\b\u0010\u000f\u001a\u00020\u000eH\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00070\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/InputSettingsFragment;", "Lcom/yuyan/imemodule/ui/fragment/base/ManagedPreferenceFragment;", "()V", "chineseFanTi", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "doublePYSchemaMode", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "Lcom/yuyan/imemodule/prefs/behavior/DoublePinyinSchemaMode;", "emojiInput", "schemaModeListener", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "switchKeyListener", "", "onStart", "", "onStop", "yuyansdk_offlineDebug"})
public final class InputSettingsFragment extends com.yuyan.imemodule.ui.fragment.base.ManagedPreferenceFragment {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool chineseFanTi = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool emojiInput = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.DoublePinyinSchemaMode> doublePYSchemaMode = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<java.lang.Boolean> switchKeyListener = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<com.yuyan.imemodule.prefs.behavior.DoublePinyinSchemaMode> schemaModeListener = null;
    
    public InputSettingsFragment() {
        super(null);
    }
    
    @java.lang.Override()
    public void onStart() {
    }
    
    @java.lang.Override()
    public void onStop() {
    }
}
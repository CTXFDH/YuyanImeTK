package com.yuyan.imemodule.service;

/**
 * 词库解码操作对象
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0010\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J#\u0010,\u001a\u00020-2\f\u0010.\u001a\b\u0012\u0004\u0012\u00020\u00100)2\b\b\u0002\u0010/\u001a\u00020\u001e\u00a2\u0006\u0002\u00100J\u000e\u00101\u001a\u00020\u00182\u0006\u00102\u001a\u00020\u0004J\u0006\u00103\u001a\u00020-J\u000e\u00104\u001a\u00020-2\u0006\u0010.\u001a\u00020\u0018J\u0010\u00105\u001a\u0004\u0018\u00010\u00102\u0006\u00102\u001a\u00020\u0004J\u0006\u00106\u001a\u00020-J\u0006\u00107\u001a\u00020-J\u000e\u00108\u001a\u00020-2\u0006\u00109\u001a\u00020\u0004J\u0016\u0010:\u001a\u00020-2\f\u0010;\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fH\u0002J\u0006\u0010<\u001a\u00020-R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR\u0011\u0010\f\u001a\u00020\u00048F\u00a2\u0006\u0006\u001a\u0004\b\r\u0010\u0006R\u0017\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f8F\u00a2\u0006\u0006\u001a\u0004\b\u0011\u0010\u0012R\u001d\u0010\u0013\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00100\u000f0\u0014\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\u0017\u001a\u00020\u00188F\u00a2\u0006\u0006\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u001b\u001a\u00020\u00188F\u00a2\u0006\u0006\u001a\u0004\b\u001c\u0010\u001aR\u001a\u0010\u001d\u001a\u00020\u001eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u001f\"\u0004\b \u0010!R\u0011\u0010\"\u001a\u00020\u001e8F\u00a2\u0006\u0006\u001a\u0004\b\"\u0010\u001fR\u001a\u0010#\u001a\u00020\u001eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b$\u0010\u001f\"\u0004\b%\u0010!R\u0011\u0010&\u001a\u00020\u00048F\u00a2\u0006\u0006\u001a\u0004\b\'\u0010\u0006R\u0017\u0010(\u001a\b\u0012\u0004\u0012\u00020\u00180)8F\u00a2\u0006\u0006\u001a\u0004\b*\u0010+\u00a8\u0006="}, d2 = {"Lcom/yuyan/imemodule/service/DictDecoder;", "", "()V", "activeCandidate", "", "getActiveCandidate", "()I", "setActiveCandidate", "(I)V", "activeCandidateBar", "getActiveCandidateBar", "setActiveCandidateBar", "candidateSize", "getCandidateSize", "candidates", "", "Lcom/yuyan/inputmethod/core/CandidateListItem;", "getCandidates", "()Ljava/util/List;", "candidatesLiveData", "Landroidx/lifecycle/MutableLiveData;", "getCandidatesLiveData", "()Landroidx/lifecycle/MutableLiveData;", "composingStrForCommit", "", "getComposingStrForCommit", "()Ljava/lang/String;", "composingStrForDisplay", "getComposingStrForDisplay", "isAssociate", "", "()Z", "setAssociate", "(Z)V", "isCandidatesEmpty", "justCommittedAssociateWord", "getJustCommittedAssociateWord", "setJustCommittedAssociateWord", "nextPageCandidates", "getNextPageCandidates", "prefixs", "", "getPrefixs", "()[Ljava/lang/String;", "cacheCandidates", "", "words", "associate", "([Lcom/yuyan/inputmethod/core/CandidateListItem;Z)V", "chooseDecodingCandidate", "candId", "deleteAction", "getAssociateWord", "getCandidate", "inputAction", "reset", "selectPrefix", "position", "updateCandidatesValue", "list", "updateDecodingCandidate", "yuyansdk_offlineDebug"})
public final class DictDecoder {
    private static int activeCandidate = 0;
    private static int activeCandidateBar = 0;
    @org.jetbrains.annotations.NotNull()
    private static final androidx.lifecycle.MutableLiveData<java.util.List<com.yuyan.inputmethod.core.CandidateListItem>> candidatesLiveData = null;
    private static boolean isAssociate = false;
    private static boolean justCommittedAssociateWord = false;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.service.DictDecoder INSTANCE = null;
    
    private DictDecoder() {
        super();
    }
    
    public final int getActiveCandidate() {
        return 0;
    }
    
    public final void setActiveCandidate(int p0) {
    }
    
    public final int getActiveCandidateBar() {
        return 0;
    }
    
    public final void setActiveCandidateBar(int p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final androidx.lifecycle.MutableLiveData<java.util.List<com.yuyan.inputmethod.core.CandidateListItem>> getCandidatesLiveData() {
        return null;
    }
    
    public final boolean isAssociate() {
        return false;
    }
    
    public final void setAssociate(boolean p0) {
    }
    
    public final boolean getJustCommittedAssociateWord() {
        return false;
    }
    
    public final void setJustCommittedAssociateWord(boolean p0) {
    }
    
    private final void updateCandidatesValue(java.util.List<com.yuyan.inputmethod.core.CandidateListItem> list) {
    }
    
    /**
     * 重置候选词
     */
    public final void reset() {
    }
    
    public final boolean isCandidatesEmpty() {
        return false;
    }
    
    public final int getCandidateSize() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.inputmethod.core.CandidateListItem> getCandidates() {
        return null;
    }
    
    public final void inputAction() {
    }
    
    /**
     * 选择拼音
     * @param position 选择的position
     */
    public final void selectPrefix(int position) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[] getPrefixs() {
        return null;
    }
    
    /**
     * 删除
     */
    public final void deleteAction() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getComposingStrForDisplay() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getComposingStrForCommit() {
        return null;
    }
    
    public final int getNextPageCandidates() {
        return 0;
    }
    
    /**
     * 选择一个候选词，且重新获取候选词列表
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String chooseDecodingCandidate(int candId) {
        return null;
    }
    
    /**
     * 对输入的拼音进行查询。
     */
    public final void updateDecodingCandidate() {
    }
    
    /**
     * 获得指定的候选词
     */
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.inputmethod.core.CandidateListItem getCandidate(int candId) {
        return null;
    }
    
    public final void cacheCandidates(@org.jetbrains.annotations.NotNull()
    com.yuyan.inputmethod.core.CandidateListItem[] words, boolean associate) {
    }
    
    /**
     * 根据输入的字符查询候选词
     */
    public final void getAssociateWord(@org.jetbrains.annotations.NotNull()
    java.lang.String words) {
    }
}
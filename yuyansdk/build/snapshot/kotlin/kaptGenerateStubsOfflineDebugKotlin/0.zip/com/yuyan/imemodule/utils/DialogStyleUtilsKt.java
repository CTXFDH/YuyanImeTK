package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u00a8\u0006\u0003"}, d2 = {"showStyled", "Landroidx/appcompat/app/AlertDialog;", "Landroidx/appcompat/app/AlertDialog$Builder;", "yuyansdk_offlineDebug"})
public final class DialogStyleUtilsKt {
    
    /**
     * 扩展方法：快捷为 AlertDialog.Builder 构建的对话框应用主题卡片样式并显示
     */
    @org.jetbrains.annotations.NotNull()
    public static final androidx.appcompat.app.AlertDialog showStyled(@org.jetbrains.annotations.NotNull()
    androidx.appcompat.app.AlertDialog.Builder $this$showStyled) {
        return null;
    }
}
package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0011\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0017\u0018\u00002\u00020\u00012\u00020\u0002B%\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u00a2\u0006\u0002\u0010\tJ\u0010\u0010\'\u001a\u00020(2\u0006\u0010)\u001a\u00020*H\u0016J\b\u0010+\u001a\u00020(H\u0014R$\u0010\f\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\u000b8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0010\u001a\u00020\u000bX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\r\"\u0004\b\u0011\u0010\u000fR\u001a\u0010\u0012\u001a\u00020\u000bX\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\r\"\u0004\b\u0013\u0010\u000fR\u001a\u0010\u0014\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R\u001a\u0010\u0019\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0016\"\u0004\b\u001b\u0010\u0018R\u0014\u0010\u001c\u001a\u00020\u001d8BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\u001e\u0010\u001fR\u001a\u0010 \u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\u0016\"\u0004\b\"\u0010\u0018R\u001a\u0010#\u001a\u00020\u001dX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b$\u0010\u001f\"\u0004\b%\u0010&\u00a8\u0006,"}, d2 = {"Lcom/yuyan/imemodule/utils/CardDialogSeekBarPreference;", "Lcom/yuyan/imemodule/view/preference/DialogSeekBarPreference;", "Lcom/yuyan/imemodule/utils/ICardPreferenceItem;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyleAttr", "", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "value", "", "isExpanded", "()Z", "setExpanded", "(Z)V", "isFirstInGroup", "setFirstInGroup", "isLastInGroup", "setLastInGroup", "maxVal", "getMaxVal", "()I", "setMaxVal", "(I)V", "minVal", "getMinVal", "setMinVal", "prefKey", "", "getPrefKey", "()Ljava/lang/String;", "stepVal", "getStepVal", "setStepVal", "unitVal", "getUnitVal", "setUnitVal", "(Ljava/lang/String;)V", "onBindViewHolder", "", "holder", "Landroidx/preference/PreferenceViewHolder;", "onClick", "yuyansdk_offlineDebug"})
public class CardDialogSeekBarPreference extends com.yuyan.imemodule.view.preference.DialogSeekBarPreference implements com.yuyan.imemodule.utils.ICardPreferenceItem {
    private boolean isFirstInGroup = false;
    private boolean isLastInGroup = false;
    private int minVal = 0;
    private int maxVal = 100;
    private int stepVal = 1;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String unitVal = "";
    
    @kotlin.jvm.JvmOverloads()
    public CardDialogSeekBarPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null, null, 0);
    }
    
    @kotlin.jvm.JvmOverloads()
    public CardDialogSeekBarPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null, null, 0);
    }
    
    @kotlin.jvm.JvmOverloads()
    public CardDialogSeekBarPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs, int defStyleAttr) {
        super(null, null, 0);
    }
    
    @java.lang.Override()
    public boolean isFirstInGroup() {
        return false;
    }
    
    @java.lang.Override()
    public void setFirstInGroup(boolean p0) {
    }
    
    @java.lang.Override()
    public boolean isLastInGroup() {
        return false;
    }
    
    @java.lang.Override()
    public void setLastInGroup(boolean p0) {
    }
    
    public final int getMinVal() {
        return 0;
    }
    
    public final void setMinVal(int p0) {
    }
    
    public final int getMaxVal() {
        return 0;
    }
    
    public final void setMaxVal(int p0) {
    }
    
    public final int getStepVal() {
        return 0;
    }
    
    public final void setStepVal(int p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getUnitVal() {
        return null;
    }
    
    public final void setUnitVal(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    private final java.lang.String getPrefKey() {
        return null;
    }
    
    public final boolean isExpanded() {
        return false;
    }
    
    public final void setExpanded(boolean value) {
    }
    
    @java.lang.Override()
    protected void onClick() {
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceViewHolder holder) {
    }
    
    @java.lang.Override()
    @android.annotation.SuppressLint(value = {"RestrictedApi"})
    public void bindCardViewHolder(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceViewHolder holder, @org.jetbrains.annotations.NotNull()
    androidx.preference.Preference pref) {
    }
}
package com.yuyan.imemodule.libs.cropper;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u0000 \u00072\u00060\u0001j\u0002`\u0002:\u0004\u0006\u0007\b\tB\u000f\b\u0004\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0002\u0010\u0005\u0082\u0001\u0003\n\u000b\f\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "message", "", "(Ljava/lang/String;)V", "Cancellation", "Companion", "FailedToDecodeImage", "FailedToLoadBitmap", "Lcom/yuyan/imemodule/libs/cropper/CropException$Cancellation;", "Lcom/yuyan/imemodule/libs/cropper/CropException$FailedToDecodeImage;", "Lcom/yuyan/imemodule/libs/cropper/CropException$FailedToLoadBitmap;", "yuyansdk_offlineDebug"})
public abstract class CropException extends java.lang.Exception {
    private static final long serialVersionUID = 4933890872862969613L;
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String EXCEPTION_PREFIX = "crop:";
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.cropper.CropException.Companion Companion = null;
    
    private CropException(java.lang.String message) {
        super();
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 \u00032\u00020\u0001:\u0001\u0003B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0004"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropException$Cancellation;", "Lcom/yuyan/imemodule/libs/cropper/CropException;", "()V", "Companion", "yuyansdk_offlineDebug"})
    public static final class Cancellation extends com.yuyan.imemodule.libs.cropper.CropException {
        private static final long serialVersionUID = -6896269134508601990L;
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.libs.cropper.CropException.Cancellation.Companion Companion = null;
        
        public Cancellation() {
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropException$Cancellation$Companion;", "", "()V", "serialVersionUID", "", "yuyansdk_offlineDebug"})
        public static final class Companion {
            
            private Companion() {
                super();
            }
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0000\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropException$Companion;", "", "()V", "EXCEPTION_PREFIX", "", "serialVersionUID", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 \u00052\u00020\u0001:\u0001\u0005B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropException$FailedToDecodeImage;", "Lcom/yuyan/imemodule/libs/cropper/CropException;", "uri", "Landroid/net/Uri;", "(Landroid/net/Uri;)V", "Companion", "yuyansdk_offlineDebug"})
    public static final class FailedToDecodeImage extends com.yuyan.imemodule.libs.cropper.CropException {
        private static final long serialVersionUID = 3516154387706407275L;
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.libs.cropper.CropException.FailedToDecodeImage.Companion Companion = null;
        
        public FailedToDecodeImage(@org.jetbrains.annotations.NotNull()
        android.net.Uri uri) {
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropException$FailedToDecodeImage$Companion;", "", "()V", "serialVersionUID", "", "yuyansdk_offlineDebug"})
        public static final class Companion {
            
            private Companion() {
                super();
            }
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0007\u0018\u0000 \u00072\u00020\u0001:\u0001\u0007B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropException$FailedToLoadBitmap;", "Lcom/yuyan/imemodule/libs/cropper/CropException;", "uri", "Landroid/net/Uri;", "message", "", "(Landroid/net/Uri;Ljava/lang/String;)V", "Companion", "yuyansdk_offlineDebug"})
    public static final class FailedToLoadBitmap extends com.yuyan.imemodule.libs.cropper.CropException {
        private static final long serialVersionUID = 7791142932960927332L;
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.libs.cropper.CropException.FailedToLoadBitmap.Companion Companion = null;
        
        public FailedToLoadBitmap(@org.jetbrains.annotations.NotNull()
        android.net.Uri uri, @org.jetbrains.annotations.Nullable()
        java.lang.String message) {
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropException$FailedToLoadBitmap$Companion;", "", "()V", "serialVersionUID", "", "yuyansdk_offlineDebug"})
        public static final class Companion {
            
            private Companion() {
                super();
            }
        }
    }
}
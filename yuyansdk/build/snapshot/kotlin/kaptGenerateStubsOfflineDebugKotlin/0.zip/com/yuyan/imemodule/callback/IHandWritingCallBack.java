package com.yuyan.imemodule.callback;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J\u001b\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H&\u00a2\u0006\u0002\u0010\u0007\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/callback/IHandWritingCallBack;", "", "onSucess", "", "item", "", "Lcom/yuyan/inputmethod/core/CandidateListItem;", "([Lcom/yuyan/inputmethod/core/CandidateListItem;)V", "yuyansdk_offlineDebug"})
public abstract interface IHandWritingCallBack {
    
    public abstract void onSucess(@org.jetbrains.annotations.NotNull()
    com.yuyan.inputmethod.core.CandidateListItem[] item);
}
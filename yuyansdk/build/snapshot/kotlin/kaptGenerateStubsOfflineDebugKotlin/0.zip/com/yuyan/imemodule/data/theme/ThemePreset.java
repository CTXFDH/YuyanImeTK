package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b5\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0011\u0010\t\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0006R\u0011\u0010\u000b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u0006R\u0011\u0010\r\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0006R\u0011\u0010\u000f\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0006R\u0011\u0010\u0011\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0006R\u0011\u0010\u0013\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0006R\u0011\u0010\u0015\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0006R\u0011\u0010\u0017\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0006R\u0011\u0010\u0019\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0006R\u0011\u0010\u001b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0006R\u0011\u0010\u001d\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0006R\u0011\u0010\u001f\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u0006R\u0011\u0010!\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0006R\u0011\u0010#\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0006R\u0011\u0010%\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010\u0006R\u0011\u0010\'\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010\u0006R\u0011\u0010)\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010\u0006R\u0011\u0010+\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b,\u0010\u0006R\u0011\u0010-\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b.\u0010\u0006R\u0011\u0010/\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u0010\u0006R\u0011\u00101\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u0010\u0006R\u0011\u00103\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b4\u0010\u0006R\u0011\u00105\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b6\u0010\u0006R\u0011\u00107\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b8\u0010\u0006\u00a8\u00069"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ThemePreset;", "", "()V", "AMOLEDBlack", "Lcom/yuyan/imemodule/data/theme/Theme$Builtin;", "getAMOLEDBlack", "()Lcom/yuyan/imemodule/data/theme/Theme$Builtin;", "AbyssalOcean", "getAbyssalOcean", "BlackGoldLuxury", "getBlackGoldLuxury", "CosmicPurple", "getCosmicPurple", "CustomBlue", "getCustomBlue", "CustomCrimson", "getCustomCrimson", "CustomPink", "getCustomPink", "CustomPurple", "getCustomPurple", "CustomRed", "getCustomRed", "CustomYellow", "getCustomYellow", "MaterialDark", "getMaterialDark", "MaterialLight", "getMaterialLight", "MintSummer", "getMintSummer", "MonochromeGraphite", "getMonochromeGraphite", "Monokai", "getMonokai", "NightAurora", "getNightAurora", "NordDark", "getNordDark", "NordLight", "getNordLight", "PixelDark", "getPixelDark", "PixelLight", "getPixelLight", "QuietVanilla", "getQuietVanilla", "SeaSaltCheese", "getSeaSaltCheese", "SunsetGlow", "getSunsetGlow", "TransparentDark", "getTransparentDark", "TransparentLight", "getTransparentLight", "VioletHyacinth", "getVioletHyacinth", "yuyansdk_offlineDebug"})
public final class ThemePreset {
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin MaterialLight = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin MaterialDark = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin PixelLight = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin PixelDark = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin AMOLEDBlack = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin NordLight = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin NordDark = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin Monokai = null;
    
    /**
     * transparent background with semi-transparent white keys
     */
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin TransparentDark = null;
    
    /**
     * transparent background with semi-transparent black keys
     */
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin TransparentLight = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin CustomRed = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin CustomPink = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin CustomYellow = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin CustomCrimson = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin CustomPurple = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin CustomBlue = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin MintSummer = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin SunsetGlow = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin SeaSaltCheese = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin QuietVanilla = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin VioletHyacinth = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin NightAurora = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin BlackGoldLuxury = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin CosmicPurple = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin MonochromeGraphite = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin AbyssalOcean = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.theme.ThemePreset INSTANCE = null;
    
    private ThemePreset() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getMaterialLight() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getMaterialDark() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getPixelLight() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getPixelDark() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getAMOLEDBlack() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getNordLight() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getNordDark() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getMonokai() {
        return null;
    }
    
    /**
     * transparent background with semi-transparent white keys
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getTransparentDark() {
        return null;
    }
    
    /**
     * transparent background with semi-transparent black keys
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getTransparentLight() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getCustomRed() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getCustomPink() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getCustomYellow() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getCustomCrimson() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getCustomPurple() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getCustomBlue() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getMintSummer() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getSunsetGlow() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getSeaSaltCheese() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getQuietVanilla() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getVioletHyacinth() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getNightAurora() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getBlackGoldLuxury() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getCosmicPurple() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getMonochromeGraphite() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getAbyssalOcean() {
        return null;
    }
}
package com.yuyan.inputmethod;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0010\n\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u001e\u0010\u0005\u001a\u00020\u00062\u000e\u0010\u0007\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\t0\b2\u0006\u0010\n\u001a\u00020\u000bR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2 = {"Lcom/yuyan/inputmethod/HWEngine;", "", "()V", "mHanyuPinyinOutputFormat", "Lcom/yuyan/imemodule/libs/pinyin4j/format/HanyuPinyinOutputFormat;", "recognitionData", "", "strokes", "", "", "recogResult", "Lcom/yuyan/imemodule/callback/IHandWritingCallBack;", "yuyansdk_offlineDebug"})
public final class HWEngine {
    @org.jetbrains.annotations.NotNull()
    private static com.yuyan.imemodule.libs.pinyin4j.format.HanyuPinyinOutputFormat mHanyuPinyinOutputFormat;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.HWEngine INSTANCE = null;
    
    private HWEngine() {
        super();
    }
    
    public final void recognitionData(@org.jetbrains.annotations.NotNull()
    java.util.List<java.lang.Short> strokes, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.callback.IHandWritingCallBack recogResult) {
    }
}
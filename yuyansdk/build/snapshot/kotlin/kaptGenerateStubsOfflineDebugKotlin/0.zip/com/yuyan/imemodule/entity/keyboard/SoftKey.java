package com.yuyan.imemodule.entity.keyboard;

/**
 * 按键的属性
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b%\n\u0002\u0010\u0002\n\u0002\b\u000f\b\u0017\u0018\u00002\u00020\u0001B-\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\bJ\u0010\u0010H\u001a\u00020I2\u0006\u0010J\u001a\u00020\u0014H\u0016J\u0006\u0010K\u001a\u00020\u0005J\u0006\u0010L\u001a\u00020\u0005J\u0006\u0010M\u001a\u00020\u0003J\u0006\u0010N\u001a\u00020IJ\u0006\u0010O\u001a\u00020IJ\u0006\u0010P\u001a\u00020\u0014J\u0016\u0010Q\u001a\u00020I2\u0006\u0010R\u001a\u00020\u000e2\u0006\u0010S\u001a\u00020\u000eJ\u001e\u0010Q\u001a\u00020I2\u0006\u0010R\u001a\u00020\u000e2\u0006\u0010S\u001a\u00020\u000e2\u0006\u0010M\u001a\u00020\u000eJ\u0016\u0010T\u001a\u00020I2\u0006\u0010U\u001a\u00020\u00032\u0006\u0010V\u001a\u00020\u0003J\u0006\u0010W\u001a\u00020\u0003R\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001a\u0010\r\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0013\u001a\u00020\u00148F\u00a2\u0006\u0006\u001a\u0004\b\u0013\u0010\u0015R\u0011\u0010\u0016\u001a\u00020\u00148F\u00a2\u0006\u0006\u001a\u0004\b\u0016\u0010\u0015R\u0011\u0010\u0017\u001a\u00020\u00148F\u00a2\u0006\u0006\u001a\u0004\b\u0017\u0010\u0015R\u0016\u0010\u0018\u001a\u0004\u0018\u00010\u00198VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u001a\u0010\u001bR\u0014\u0010\u001c\u001a\u00020\u00058VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u001d\u0010\u001eR\u001a\u0010\u0007\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u001e\"\u0004\b \u0010!R\u001a\u0010\"\u001a\u00020#X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b$\u0010%\"\u0004\b&\u0010\'R\u001a\u0010\u0004\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b(\u0010\u001e\"\u0004\b)\u0010!R\u001a\u0010\u0006\u001a\u00020\u0005X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b*\u0010\u001e\"\u0004\b+\u0010!R\u001a\u0010,\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b-\u0010\n\"\u0004\b.\u0010\fR\u001a\u0010/\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b0\u0010\n\"\u0004\b1\u0010\fR\u001a\u00102\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b3\u0010\u0010\"\u0004\b4\u0010\u0012R\u001a\u00105\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b6\u0010\n\"\u0004\b7\u0010\fR\u001a\u00108\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b9\u0010\n\"\u0004\b:\u0010\fR\u001a\u0010;\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b<\u0010\u0010\"\u0004\b=\u0010\u0012R\u001a\u0010>\u001a\u00020\u0014X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b?\u0010\u0015\"\u0004\b@\u0010AR\u001a\u0010B\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bC\u0010\n\"\u0004\bD\u0010\fR\u001a\u0010E\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bF\u0010\u0010\"\u0004\bG\u0010\u0012\u00a8\u0006X"}, d2 = {"Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "", "code", "", "label", "", "labelSmall", "keyMnemonic", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getCode", "()I", "setCode", "(I)V", "heightF", "", "getHeightF", "()F", "setHeightF", "(F)V", "isKeyCodeKey", "", "()Z", "isUniStrKey", "isUserDefKey", "keyIcon", "Landroid/graphics/drawable/Drawable;", "getKeyIcon", "()Landroid/graphics/drawable/Drawable;", "keyLabel", "getKeyLabel", "()Ljava/lang/String;", "getKeyMnemonic", "setKeyMnemonic", "(Ljava/lang/String;)V", "keyType", "Lcom/yuyan/imemodule/entity/keyboard/KeyType;", "getKeyType", "()Lcom/yuyan/imemodule/entity/keyboard/KeyType;", "setKeyType", "(Lcom/yuyan/imemodule/entity/keyboard/KeyType;)V", "getLabel", "setLabel", "getLabelSmall", "setLabelSmall", "mBottom", "getMBottom", "setMBottom", "mLeft", "getMLeft", "setMLeft", "mLeftF", "getMLeftF", "setMLeftF", "mRight", "getMRight", "setMRight", "mTop", "getMTop", "setMTop", "mTopF", "getMTopF", "setMTopF", "pressed", "getPressed", "setPressed", "(Z)V", "stateId", "getStateId", "setStateId", "widthF", "getWidthF", "setWidthF", "changeCase", "", "upperCase", "getkeyLabel", "getmKeyLabelSmall", "height", "onPressed", "onReleased", "repeatable", "setKeyDimensions", "left", "top", "setSkbCoreSize", "skbWidth", "skbHeight", "width", "yuyansdk_offlineDebug"})
public class SoftKey {
    private int code;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String label;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String labelSmall;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String keyMnemonic;
    
    /**
     * 键盘上下左右位置百分比 ，mLeft = (int) (mLeftF * skbWidth);
     */
    private float mLeftF = -1.0F;
    private float mTopF = -1.0F;
    private float widthF = 0.0F;
    private float heightF = 0.25F;
    
    /**
     * 键盘上下左右位置坐标边界;
     */
    private int mLeft = 0;
    private int mRight = 0;
    private int mTop = 0;
    private int mBottom = 0;
    private int stateId = 0;
    private boolean pressed = false;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.entity.keyboard.KeyType keyType = com.yuyan.imemodule.entity.keyboard.KeyType.Normal;
    
    public SoftKey(int code, @org.jetbrains.annotations.NotNull()
    java.lang.String label, @org.jetbrains.annotations.NotNull()
    java.lang.String labelSmall, @org.jetbrains.annotations.NotNull()
    java.lang.String keyMnemonic) {
        super();
    }
    
    public final int getCode() {
        return 0;
    }
    
    public final void setCode(int p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getLabel() {
        return null;
    }
    
    public final void setLabel(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getLabelSmall() {
        return null;
    }
    
    public final void setLabelSmall(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getKeyMnemonic() {
        return null;
    }
    
    public final void setKeyMnemonic(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    /**
     * 键盘上下左右位置百分比 ，mLeft = (int) (mLeftF * skbWidth);
     */
    public final float getMLeftF() {
        return 0.0F;
    }
    
    /**
     * 键盘上下左右位置百分比 ，mLeft = (int) (mLeftF * skbWidth);
     */
    public final void setMLeftF(float p0) {
    }
    
    public final float getMTopF() {
        return 0.0F;
    }
    
    public final void setMTopF(float p0) {
    }
    
    public final float getWidthF() {
        return 0.0F;
    }
    
    public final void setWidthF(float p0) {
    }
    
    public final float getHeightF() {
        return 0.0F;
    }
    
    public final void setHeightF(float p0) {
    }
    
    /**
     * 键盘上下左右位置坐标边界;
     */
    public final int getMLeft() {
        return 0;
    }
    
    /**
     * 键盘上下左右位置坐标边界;
     */
    public final void setMLeft(int p0) {
    }
    
    public final int getMRight() {
        return 0;
    }
    
    public final void setMRight(int p0) {
    }
    
    public final int getMTop() {
        return 0;
    }
    
    public final void setMTop(int p0) {
    }
    
    public final int getMBottom() {
        return 0;
    }
    
    public final void setMBottom(int p0) {
    }
    
    public final int getStateId() {
        return 0;
    }
    
    public final void setStateId(int p0) {
    }
    
    public final boolean getPressed() {
        return false;
    }
    
    public final void setPressed(boolean p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.keyboard.KeyType getKeyType() {
        return null;
    }
    
    public final void setKeyType(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.keyboard.KeyType p0) {
    }
    
    public final void onPressed() {
    }
    
    public final void onReleased() {
    }
    
    public final void setKeyDimensions(float left, float top) {
    }
    
    public final void setKeyDimensions(float left, float top, float height) {
    }
    
    /**
     * 设置按键的区域
     */
    public final void setSkbCoreSize(int skbWidth, int skbHeight) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public android.graphics.drawable.Drawable getKeyIcon() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public java.lang.String getKeyLabel() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getmKeyLabelSmall() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getkeyLabel() {
        return null;
    }
    
    public void changeCase(boolean upperCase) {
    }
    
    public final boolean isKeyCodeKey() {
        return false;
    }
    
    public final boolean isUserDefKey() {
        return false;
    }
    
    public final boolean isUniStrKey() {
        return false;
    }
    
    public final boolean repeatable() {
        return false;
    }
    
    public final int width() {
        return 0;
    }
    
    public final int height() {
        return 0;
    }
    
    public SoftKey() {
        super();
    }
}
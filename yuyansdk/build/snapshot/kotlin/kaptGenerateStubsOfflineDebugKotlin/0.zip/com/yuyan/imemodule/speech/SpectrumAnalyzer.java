package com.yuyan.imemodule.speech;

/**
 * 轻量 FFT 频谱分析器：把一帧 PCM 采样拆成 [bandCount] 个对数频段，
 * 每个频段输出 0~1 的归一化能量，供频谱可视化使用。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0004\n\u0002\u0010\u0017\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B#\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0006J\u0016\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0003J \u0010\u0011\u001a\u00020\u00122\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0013\u001a\u00020\u0003H\u0002R\u000e\u0010\u0005\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0014"}, d2 = {"Lcom/yuyan/imemodule/speech/SpectrumAnalyzer;", "", "fftSize", "", "sampleRate", "bandCount", "(III)V", "bandEdges", "", "hannWindow", "", "im", "re", "analyze", "samples", "", "length", "fft", "", "n", "yuyansdk_offlineDebug"})
public final class SpectrumAnalyzer {
    private final int fftSize = 0;
    private final int sampleRate = 0;
    private final int bandCount = 0;
    @org.jetbrains.annotations.NotNull()
    private final int[] bandEdges = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] re = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] im = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] hannWindow = null;
    
    public SpectrumAnalyzer(int fftSize, int sampleRate, int bandCount) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final float[] analyze(@org.jetbrains.annotations.NotNull()
    short[] samples, int length) {
        return null;
    }
    
    private final void fft(float[] re, float[] im, int n) {
    }
    
    public SpectrumAnalyzer() {
        super();
    }
}
package com.yuyan.imemodule.libs.expression.function;

/**
 * A class representing a Function which can be used in an expression
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u0013\n\u0002\b\u0002\b\'\u0018\u0000 \u000f2\u00020\u0001:\u0001\u000fB\u0019\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0014\u0010\u000b\u001a\u00020\f2\n\u0010\r\u001a\u00020\u000e\"\u00020\fH&R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/function/Function;", "", "name", "", "numArguments", "", "(Ljava/lang/String;I)V", "getName", "()Ljava/lang/String;", "getNumArguments", "()I", "apply", "", "args", "", "Companion", "yuyansdk_offlineDebug"})
public abstract class Function {
    
    /**
     * Get the name of the Function
     *
     * @return the name
     */
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String name = null;
    
    /**
     * Get the number of arguments for this function
     *
     * @return the number of arguments
     */
    private final int numArguments = 0;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.expression.function.Function.Companion Companion = null;
    
    @kotlin.jvm.JvmOverloads()
    public Function(@org.jetbrains.annotations.NotNull()
    java.lang.String name) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public Function(@org.jetbrains.annotations.NotNull()
    java.lang.String name, int numArguments) {
        super();
    }
    
    /**
     * Get the name of the Function
     *
     * @return the name
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getName() {
        return null;
    }
    
    /**
     * Get the number of arguments for this function
     *
     * @return the number of arguments
     */
    public final int getNumArguments() {
        return 0;
    }
    
    /**
     * Method that does the actual calculation of the function value given the arguments
     *
     * @param args the set of arguments used for calculating the function
     * @return the result of the function evaluation
     */
    public abstract double apply(@org.jetbrains.annotations.NotNull()
    double... args);
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/function/Function$Companion;", "", "()V", "isValidFunctionName", "", "name", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        public final boolean isValidFunctionName(@org.jetbrains.annotations.Nullable()
        java.lang.String name) {
            return false;
        }
    }
}
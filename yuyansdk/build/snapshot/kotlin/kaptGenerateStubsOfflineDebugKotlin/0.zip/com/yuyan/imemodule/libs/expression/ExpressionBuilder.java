package com.yuyan.imemodule.libs.expression;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010#\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\u000e\u001a\u00020\u000fR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082D\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u000b0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00030\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/ExpressionBuilder;", "", "expression", "", "(Ljava/lang/String;)V", "implicitMultiplication", "", "userFunctions", "", "Lcom/yuyan/imemodule/libs/expression/function/Function;", "userOperators", "Lcom/yuyan/imemodule/libs/expression/operator/Operator;", "variableNames", "", "build", "Lcom/yuyan/imemodule/libs/expression/Expression;", "yuyansdk_offlineDebug"})
public final class ExpressionBuilder {
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String expression = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.Map<java.lang.String, com.yuyan.imemodule.libs.expression.function.Function> userFunctions = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.Map<java.lang.String, com.yuyan.imemodule.libs.expression.operator.Operator> userOperators = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.Set<java.lang.String> variableNames = null;
    private final boolean implicitMultiplication = true;
    
    public ExpressionBuilder(@org.jetbrains.annotations.Nullable()
    java.lang.String expression) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.expression.Expression build() {
        return null;
    }
}
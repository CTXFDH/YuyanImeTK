package com.yuyan.imemodule.entity.handwriting;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\r\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0012\u001a\u00020\n2\u0006\u0010\u0013\u001a\u00020\u0000J\u0016\u0010\u0014\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000f\u001a\u00020\nJ\u000e\u0010\u0015\u001a\u00020\n2\u0006\u0010\u0016\u001a\u00020\u0000R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\f\"\u0004\b\u0011\u0010\u000e\u00a8\u0006\u0017"}, d2 = {"Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;", "", "()V", "timestamp", "", "getTimestamp", "()J", "setTimestamp", "(J)V", "x", "", "getX", "()F", "setX", "(F)V", "y", "getY", "setY", "distanceTo", "point", "set", "velocityFrom", "start", "yuyansdk_offlineDebug"})
public final class TimedPoint {
    private float x = 0.0F;
    private float y = 0.0F;
    private long timestamp = 0L;
    
    public TimedPoint() {
        super();
    }
    
    public final float getX() {
        return 0.0F;
    }
    
    public final void setX(float p0) {
    }
    
    public final float getY() {
        return 0.0F;
    }
    
    public final void setY(float p0) {
    }
    
    public final long getTimestamp() {
        return 0L;
    }
    
    public final void setTimestamp(long p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.handwriting.TimedPoint set(float x, float y) {
        return null;
    }
    
    public final float velocityFrom(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint start) {
        return 0.0F;
    }
    
    public final float distanceTo(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint point) {
        return 0.0F;
    }
}
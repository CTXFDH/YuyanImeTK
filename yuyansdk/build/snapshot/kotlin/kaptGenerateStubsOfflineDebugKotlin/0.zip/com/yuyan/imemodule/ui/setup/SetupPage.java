package com.yuyan.imemodule.ui.setup;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\r\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\u0081\u0002\u0018\u0000 \u000f2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000fB\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u0006J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u0006J\u0006\u0010\u000b\u001a\u00020\fj\u0002\b\rj\u0002\b\u000e\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/ui/setup/SetupPage;", "", "(Ljava/lang/String;I)V", "getButtonAction", "", "context", "Landroid/content/Context;", "getButtonText", "", "getHintText", "Landroid/text/Spanned;", "isDone", "", "Enable", "Select", "Companion", "yuyansdk_offlineDebug"})
public enum SetupPage {
    /*public static final*/ Enable /* = new Enable() */,
    /*public static final*/ Select /* = new Select() */;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.ui.setup.SetupPage.Companion Companion = null;
    
    SetupPage() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.text.Spanned getHintText(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.CharSequence getButtonText(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        return null;
    }
    
    public final void getButtonAction(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    public final boolean isDone() {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static kotlin.enums.EnumEntries<com.yuyan.imemodule.ui.setup.SetupPage> getEntries() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004J\u0006\u0010\u0005\u001a\u00020\u0006J\u000e\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\tJ\n\u0010\n\u001a\u00020\u0006*\u00020\u0004J\n\u0010\n\u001a\u00020\u0006*\u00020\t\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/ui/setup/SetupPage$Companion;", "", "()V", "firstUndonePage", "Lcom/yuyan/imemodule/ui/setup/SetupPage;", "hasUndonePage", "", "valueOf", "value", "", "isLastPage", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.ui.setup.SetupPage valueOf(int value) {
            return null;
        }
        
        public final boolean isLastPage(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.ui.setup.SetupPage $this$isLastPage) {
            return false;
        }
        
        public final boolean isLastPage(int $this$isLastPage) {
            return false;
        }
        
        public final boolean hasUndonePage() {
            return false;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final com.yuyan.imemodule.ui.setup.SetupPage firstUndonePage() {
            return null;
        }
    }
}
package com.yuyan.imemodule.prefs.behavior;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b&\b\u0086\u0081\u0002\u0018\u0000 &2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001&B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018j\u0002\b\u0019j\u0002\b\u001aj\u0002\b\u001bj\u0002\b\u001cj\u0002\b\u001dj\u0002\b\u001ej\u0002\b\u001fj\u0002\b j\u0002\b!j\u0002\b\"j\u0002\b#j\u0002\b$j\u0002\b%\u00a8\u0006\'"}, d2 = {"Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "", "(Ljava/lang/String;I)V", "SwitchKeyboard", "KeyboardHeight", "DarkTheme", "Feedback", "NumberRow", "JianFan", "LockEnglish", "SymbolShow", "CandidatesMore", "Mnemonic", "FlowerTypeface", "EmojiInput", "Handwriting", "Custom", "Theme", "SettingsMenu", "Settings", "FloatKeyboard", "OneHanded", "PinyinT9", "Pinyin26Jian", "PinyinLx17", "PinyinHandWriting", "Pinyin26Double", "PinyinStroke", "ClipBoard", "ClearClipBoard", "Phrases", "AddPhrases", "CloseSKB", "Emojicon", "Emoticon", "LockClipBoard", "TextEdit", "SwitchIME", "Companion", "yuyansdk_offlineDebug"})
public enum SkbMenuMode {
    /*public static final*/ SwitchKeyboard /* = new SwitchKeyboard() */,
    /*public static final*/ KeyboardHeight /* = new KeyboardHeight() */,
    /*public static final*/ DarkTheme /* = new DarkTheme() */,
    /*public static final*/ Feedback /* = new Feedback() */,
    /*public static final*/ NumberRow /* = new NumberRow() */,
    /*public static final*/ JianFan /* = new JianFan() */,
    /*public static final*/ LockEnglish /* = new LockEnglish() */,
    /*public static final*/ SymbolShow /* = new SymbolShow() */,
    /*public static final*/ CandidatesMore /* = new CandidatesMore() */,
    /*public static final*/ Mnemonic /* = new Mnemonic() */,
    /*public static final*/ FlowerTypeface /* = new FlowerTypeface() */,
    /*public static final*/ EmojiInput /* = new EmojiInput() */,
    /*public static final*/ Handwriting /* = new Handwriting() */,
    /*public static final*/ Custom /* = new Custom() */,
    /*public static final*/ Theme /* = new Theme() */,
    /*public static final*/ SettingsMenu /* = new SettingsMenu() */,
    /*public static final*/ Settings /* = new Settings() */,
    /*public static final*/ FloatKeyboard /* = new FloatKeyboard() */,
    /*public static final*/ OneHanded /* = new OneHanded() */,
    /*public static final*/ PinyinT9 /* = new PinyinT9() */,
    /*public static final*/ Pinyin26Jian /* = new Pinyin26Jian() */,
    /*public static final*/ PinyinLx17 /* = new PinyinLx17() */,
    /*public static final*/ PinyinHandWriting /* = new PinyinHandWriting() */,
    /*public static final*/ Pinyin26Double /* = new Pinyin26Double() */,
    /*public static final*/ PinyinStroke /* = new PinyinStroke() */,
    /*public static final*/ ClipBoard /* = new ClipBoard() */,
    /*public static final*/ ClearClipBoard /* = new ClearClipBoard() */,
    /*public static final*/ Phrases /* = new Phrases() */,
    /*public static final*/ AddPhrases /* = new AddPhrases() */,
    /*public static final*/ CloseSKB /* = new CloseSKB() */,
    /*public static final*/ Emojicon /* = new Emojicon() */,
    /*public static final*/ Emoticon /* = new Emoticon() */,
    /*public static final*/ LockClipBoard /* = new LockClipBoard() */,
    /*public static final*/ TextEdit /* = new TextEdit() */,
    /*public static final*/ SwitchIME /* = new SwitchIME() */;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.prefs.behavior.SkbMenuMode.Companion Companion = null;
    
    SkbMenuMode() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public static kotlin.enums.EnumEntries<com.yuyan.imemodule.prefs.behavior.SkbMenuMode> getEntries() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0006H\u0016\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode$Companion;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "()V", "decode", "raw", "", "yuyansdk_offlineDebug"})
    public static final class Companion implements com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<com.yuyan.imemodule.prefs.behavior.SkbMenuMode> {
        
        private Companion() {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.prefs.behavior.SkbMenuMode decode(@org.jetbrains.annotations.NotNull()
        java.lang.String raw) {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String encode(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.prefs.behavior.SkbMenuMode x) {
            return null;
        }
    }
}
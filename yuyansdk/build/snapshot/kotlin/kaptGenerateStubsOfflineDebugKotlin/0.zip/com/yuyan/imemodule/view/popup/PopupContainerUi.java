package com.yuyan.imemodule.view.popup;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\b\'\u0018\u0000 /2\u00020\u0001:\u0001/B.\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0017\u0010\u0006\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\b0\u0007\u00a2\u0006\u0002\b\t\u00a2\u0006\u0002\u0010\nJ\u001e\u0010\u001d\u001a\u00020\u00102\u0006\u0010\u001e\u001a\u00020\u00102\u0006\u0010\u001f\u001a\u00020\u00102\u0006\u0010\u0004\u001a\u00020\u0005J\u0016\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020#J\u0016\u0010%\u001a\u00020&2\u0006\u0010\u001e\u001a\u00020\u00102\u0006\u0010\'\u001a\u00020\u0010J\u0018\u0010(\u001a\u00020!2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020#H&J\u0010\u0010)\u001a\u00020\b2\u0006\u0010*\u001a\u00020#H&J\u0014\u0010+\u001a\u000e\u0012\u0004\u0012\u00020-\u0012\u0004\u0012\u00020.0,H&R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u0012\u0010\u0015\u001a\u00020\u0010X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0016\u0010\u0012R\"\u0010\u0006\u001a\u0013\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\b0\u0007\u00a2\u0006\u0002\b\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0012\u0010\u0019\u001a\u00020\u001aX\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b\u001b\u0010\u001c\u00a8\u00060"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupContainerUi;", "Lsplitties/views/dsl/core/Ui;", "ctx", "Landroid/content/Context;", "bounds", "Landroid/graphics/Rect;", "onDismissSelf", "Lkotlin/Function1;", "", "Lkotlin/ExtensionFunctionType;", "(Landroid/content/Context;Landroid/graphics/Rect;Lkotlin/jvm/functions/Function1;)V", "getBounds", "()Landroid/graphics/Rect;", "getCtx", "()Landroid/content/Context;", "offsetX", "", "getOffsetX", "()I", "setOffsetX", "(I)V", "offsetY", "getOffsetY", "getOnDismissSelf", "()Lkotlin/jvm/functions/Function1;", "root", "Landroid/view/View;", "getRoot", "()Landroid/view/View;", "calcInitialFocusedColumn", "columnCount", "columnWidth", "changeFocus", "", "x", "", "y", "createColumnOrder", "", "initialFocus", "onChangeFocus", "onGestureEvent", "distance", "onTrigger", "Lkotlin/Pair;", "Lcom/yuyan/imemodule/prefs/behavior/PopupMenuMode;", "", "Companion", "yuyansdk_offlineDebug"})
public abstract class PopupContainerUi implements splitties.views.dsl.core.Ui {
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context ctx = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Rect bounds = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function1<com.yuyan.imemodule.view.popup.PopupContainerUi, kotlin.Unit> onDismissSelf = null;
    
    /**
     * Offset on X axis to put this [PopupKeyboardUi] relative to popup trigger view [bounds]
     */
    private int offsetX = 0;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.view.popup.PopupContainerUi.Companion Companion = null;
    
    public PopupContainerUi(@org.jetbrains.annotations.NotNull()
    android.content.Context ctx, @org.jetbrains.annotations.NotNull()
    android.graphics.Rect bounds, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.view.popup.PopupContainerUi, kotlin.Unit> onDismissSelf) {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.content.Context getCtx() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.Rect getBounds() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlin.jvm.functions.Function1<com.yuyan.imemodule.view.popup.PopupContainerUi, kotlin.Unit> getOnDismissSelf() {
        return null;
    }
    
    /**
     * Popup container view
     */
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public abstract android.view.View getRoot();
    
    /**
     * Offset on X axis to put this [PopupKeyboardUi] relative to popup trigger view [bounds]
     */
    public final int getOffsetX() {
        return 0;
    }
    
    /**
     * Offset on X axis to put this [PopupKeyboardUi] relative to popup trigger view [bounds]
     */
    public final void setOffsetX(int p0) {
    }
    
    /**
     * Offset on Y axis to put this [PopupKeyboardUi] relative to popup trigger view [bounds]
     */
    public abstract int getOffsetY();
    
    public final int calcInitialFocusedColumn(int columnCount, int columnWidth, @org.jetbrains.annotations.NotNull()
    android.graphics.Rect bounds) {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final int[] createColumnOrder(int columnCount, int initialFocus) {
        return null;
    }
    
    public final boolean changeFocus(float x, float y) {
        return false;
    }
    
    public abstract boolean onChangeFocus(float x, float y);
    
    public abstract void onGestureEvent(float distance);
    
    @org.jetbrains.annotations.NotNull()
    public abstract kotlin.Pair<com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> onTrigger();
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0016\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupContainerUi$Companion;", "", "()V", "limitIndex", "", "i", "limit", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        public final int limitIndex(int i, int limit) {
            return 0;
        }
    }
}
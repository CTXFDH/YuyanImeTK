package com.yuyan.imemodule.libs.cropper;

/**
 * Custom view that provides cropping capabilities to an image.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u00e2\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\"\b\u0007\u0018\u0000 \u00a5\u00012\u00020\u00012\u00020\u0002:\u0018\u00a5\u0001\u00a6\u0001\u00a7\u0001\u00a8\u0001\u00a9\u0001\u00aa\u0001\u00ab\u0001\u00ac\u0001\u00ad\u0001\u00ae\u0001\u00af\u0001\u00b0\u0001B\u001b\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\u0002\u0010\u0007J(\u0010g\u001a\u00020h2\u0006\u0010i\u001a\u0002082\u0006\u0010j\u001a\u0002082\u0006\u0010k\u001a\u00020.2\u0006\u0010l\u001a\u00020.H\u0002J\b\u0010m\u001a\u00020hH\u0002JD\u0010n\u001a\u00020h2\b\b\u0002\u0010o\u001a\u00020p2\b\b\u0002\u0010q\u001a\u00020!2\b\b\u0002\u0010r\u001a\u00020!2\b\b\u0002\u0010s\u001a\u00020!2\b\b\u0002\u0010t\u001a\u00020u2\n\b\u0002\u0010\u001e\u001a\u0004\u0018\u00010\u001fJ\u0006\u0010v\u001a\u00020hJ\u0006\u0010w\u001a\u00020hJ(\u0010x\u001a\u0004\u0018\u00010\u00192\b\b\u0002\u0010r\u001a\u00020!2\b\b\u0002\u0010s\u001a\u00020!2\b\b\u0002\u0010t\u001a\u00020uH\u0007J\u0018\u0010y\u001a\u00020h2\u0006\u0010z\u001a\u00020.2\u0006\u0010l\u001a\u00020.H\u0002J\b\u0010{\u001a\u00020hH\u0002J\u0010\u0010|\u001a\u00020h2\u0006\u0010z\u001a\u00020.H\u0016J\u0016\u0010}\u001a\u00020h2\u0006\u0010~\u001a\u00020\u007fH\u0000\u00a2\u0006\u0003\b\u0080\u0001J6\u0010\u0081\u0001\u001a\u00020h2\u0007\u0010\u0082\u0001\u001a\u00020.2\u0007\u0010\u0083\u0001\u001a\u00020!2\u0007\u0010\u0084\u0001\u001a\u00020!2\u0007\u0010\u0085\u0001\u001a\u00020!2\u0007\u0010\u0086\u0001\u001a\u00020!H\u0014J\u001b\u0010\u0087\u0001\u001a\u00020h2\u0007\u0010\u0088\u0001\u001a\u00020!2\u0007\u0010\u0089\u0001\u001a\u00020!H\u0014J\u0013\u0010\u008a\u0001\u001a\u00020h2\b\u0010\u008b\u0001\u001a\u00030\u008c\u0001H\u0016J\f\u0010\u008d\u0001\u001a\u0005\u0018\u00010\u008c\u0001H\u0016J\u0018\u0010\u008e\u0001\u001a\u00020h2\u0007\u0010~\u001a\u00030\u008f\u0001H\u0000\u00a2\u0006\u0003\b\u0090\u0001J-\u0010\u0091\u0001\u001a\u00020h2\u0007\u0010\u0092\u0001\u001a\u00020!2\u0007\u0010\u0093\u0001\u001a\u00020!2\u0007\u0010\u0094\u0001\u001a\u00020!2\u0007\u0010\u0095\u0001\u001a\u00020!H\u0014J\u000f\u0010\u0096\u0001\u001a\u00020h2\u0006\u0010a\u001a\u00020!J8\u0010\u0097\u0001\u001a\u00020h2\t\u0010\u0098\u0001\u001a\u0004\u0018\u00010\u00192\u0006\u0010\"\u001a\u00020!2\b\u0010(\u001a\u0004\u0018\u00010\u001f2\u0007\u0010\u0099\u0001\u001a\u00020!2\u0007\u0010\u009a\u0001\u001a\u00020!H\u0002J\t\u0010\u009b\u0001\u001a\u00020hH\u0002J\u0012\u0010\u009c\u0001\u001a\u00020h2\t\u0010\u009d\u0001\u001a\u0004\u0018\u00010\u001fJ\u0012\u0010\u009e\u0001\u001a\u00020h2\t\u0010\u009f\u0001\u001a\u0004\u0018\u00010HJ\u0012\u0010\u00a0\u0001\u001a\u00020h2\t\u0010\u009f\u0001\u001a\u0004\u0018\u00010PJ\t\u0010\u00a1\u0001\u001a\u00020hH\u0002J;\u0010\u00a2\u0001\u001a\u00020h2\u0006\u0010r\u001a\u00020!2\u0006\u0010s\u001a\u00020!2\u0006\u0010t\u001a\u00020u2\u0006\u0010o\u001a\u00020p2\u0006\u0010q\u001a\u00020!2\b\u0010\u001e\u001a\u0004\u0018\u00010\u001fH\u0002J\u0012\u0010\u00a3\u0001\u001a\u00020h2\u0007\u0010\u00a4\u0001\u001a\u00020.H\u0002R\u0016\u0010\b\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\r\u001a\u00020\u000e8F\u00a2\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010R(\u0010\u0013\u001a\u0004\u0018\u00010\u00122\b\u0010\u0011\u001a\u0004\u0018\u00010\u00128F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u001c\u0010\u0018\u001a\u0004\u0018\u00010\u00198GX\u0087\u0004\u00a2\u0006\f\u0012\u0004\b\u001a\u0010\u001b\u001a\u0004\b\u001c\u0010\u001dR\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R$\u0010\"\u001a\u00020!2\u0006\u0010 \u001a\u00020!8B@BX\u0082\u000e\u00a2\u0006\f\u001a\u0004\b#\u0010$\"\u0004\b%\u0010&R\"\u0010(\u001a\u0004\u0018\u00010\u001f2\b\u0010\'\u001a\u0004\u0018\u00010\u001f@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010*R\u000e\u0010+\u001a\u00020,X\u0082\u0004\u00a2\u0006\u0002\n\u0000R$\u0010-\u001a\u00020.8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0014\n\u0000\u0012\u0004\b/\u0010\u001b\u001a\u0004\b-\u00100\"\u0004\b1\u00102R\u000e\u00103\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u00104\u001a\u0004\u0018\u000105X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00107\u001a\u000208X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u00109\u001a\u0004\u0018\u00010:X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010<\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020?X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010@\u001a\u00020?X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010A\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010B\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010D\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010E\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010F\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010G\u001a\u0004\u0018\u00010HX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010I\u001a\u0004\u0018\u00010JX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010K\u001a\u0004\u0018\u00010LX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010M\u001a\u0004\u0018\u00010NX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010O\u001a\u0004\u0018\u00010PX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010Q\u001a\u00020RX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010S\u001a\u0004\u0018\u00010TX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010U\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010V\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010W\u001a\u00020XX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010Y\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010Z\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010[\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\\\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010]\u001a\u000208X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010^\u001a\u000208X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010_\u001a\u000208X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010`\u001a\u0004\u0018\u00010\u0019X\u0082\u000e\u00a2\u0006\u0002\n\u0000R$\u0010b\u001a\u00020!2\u0006\u0010a\u001a\u00020!8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\bc\u0010$\"\u0004\bd\u0010&R\u0013\u0010e\u001a\u0004\u0018\u00010\u00128F\u00a2\u0006\u0006\u001a\u0004\bf\u0010\u0015\u00a8\u0006\u00b1\u0001"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView;", "Landroid/widget/FrameLayout;", "Lcom/yuyan/imemodule/libs/cropper/CropOverlayView$CropWindowChangeListener;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "bitmapCroppingWorkerJob", "Ljava/lang/ref/WeakReference;", "Lcom/yuyan/imemodule/libs/cropper/BitmapCroppingWorkerJob;", "bitmapLoadingWorkerJob", "Lcom/yuyan/imemodule/libs/cropper/BitmapLoadingWorkerJob;", "cropPoints", "", "getCropPoints", "()[F", "rect", "Landroid/graphics/Rect;", "cropRect", "getCropRect", "()Landroid/graphics/Rect;", "setCropRect", "(Landroid/graphics/Rect;)V", "croppedImage", "Landroid/graphics/Bitmap;", "-croppedImage$annotations", "()V", "-croppedImage", "()Landroid/graphics/Bitmap;", "customOutputUri", "Landroid/net/Uri;", "resId", "", "imageResource", "getImageResource", "()I", "setImageResource", "(I)V", "<set-?>", "imageUri", "getImageUri", "()Landroid/net/Uri;", "imageView", "Landroid/widget/ImageView;", "isSaveBitmapToInstanceState", "", "isSaveBitmapToInstanceState$annotations", "()Z", "setSaveBitmapToInstanceState", "(Z)V", "loadedSampleSize", "mAnimation", "Lcom/yuyan/imemodule/libs/cropper/CropImageAnimation;", "mAutoZoomEnabled", "mCropLabelTextSize", "", "mCropOverlayView", "Lcom/yuyan/imemodule/libs/cropper/CropOverlayView;", "mDegreesRotated", "mFlipHorizontally", "mFlipVertically", "mImageInverseMatrix", "Landroid/graphics/Matrix;", "mImageMatrix", "mImagePoints", "mImageResource", "mInitialDegreesRotated", "mLayoutHeight", "mLayoutWidth", "mMaxZoom", "mOnCropImageCompleteListener", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnCropImageCompleteListener;", "mOnCropOverlayReleasedListener", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetCropOverlayReleasedListener;", "mOnSetCropOverlayMovedListener", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetCropOverlayMovedListener;", "mOnSetCropWindowChangeListener", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetCropWindowChangeListener;", "mOnSetImageUriCompleteListener", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetImageUriCompleteListener;", "mProgressBar", "Landroid/widget/ProgressBar;", "mRestoreCropWindowRect", "Landroid/graphics/RectF;", "mRestoreDegreesRotated", "mScaleImagePoints", "mScaleType", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$ScaleType;", "mShowCropLabel", "mShowCropOverlay", "mShowProgressBar", "mSizeChanged", "mZoom", "mZoomOffsetX", "mZoomOffsetY", "originalBitmap", "degrees", "rotatedDegrees", "getRotatedDegrees", "setRotatedDegrees", "wholeImageRect", "getWholeImageRect", "applyImageMatrix", "", "width", "height", "center", "animate", "clearImageInt", "croppedImageAsync", "saveCompressFormat", "Landroid/graphics/Bitmap$CompressFormat;", "saveCompressQuality", "reqWidth", "reqHeight", "options", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$RequestSizeOptions;", "flipImageHorizontally", "flipImageVertically", "getCroppedImage", "handleCropWindowChanged", "inProgress", "mapImagePointsByImageMatrix", "onCropWindowChanged", "onImageCroppingAsyncComplete", "result", "Lcom/yuyan/imemodule/libs/cropper/BitmapCroppingWorkerJob$Result;", "onImageCroppingAsyncComplete$yuyansdk_offlineDebug", "onLayout", "changed", "l", "t", "r", "b", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "onRestoreInstanceState", "state", "Landroid/os/Parcelable;", "onSaveInstanceState", "onSetImageUriAsyncComplete", "Lcom/yuyan/imemodule/libs/cropper/BitmapLoadingWorkerJob$Result;", "onSetImageUriAsyncComplete$yuyansdk_offlineDebug", "onSizeChanged", "w", "h", "oldw", "oldh", "rotateImage", "setBitmap", "bitmap", "loadSampleSize", "degreesRotated", "setCropOverlayVisibility", "setImageUriAsync", "uri", "setOnCropImageCompleteListener", "listener", "setOnSetImageUriCompleteListener", "setProgressBarVisibility", "startCropWorkerTask", "updateImageBounds", "clear", "Companion", "CropCornerShape", "CropResult", "CropShape", "Guidelines", "OnCropImageCompleteListener", "OnSetCropOverlayMovedListener", "OnSetCropOverlayReleasedListener", "OnSetCropWindowChangeListener", "OnSetImageUriCompleteListener", "RequestSizeOptions", "ScaleType", "yuyansdk_offlineDebug"})
public final class CropImageView extends android.widget.FrameLayout implements com.yuyan.imemodule.libs.cropper.CropOverlayView.CropWindowChangeListener {
    
    /**
     * Image view widget used to show the image for cropping.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ImageView imageView = null;
    
    /**
     * Overlay over the image view to show cropping UI.
     */
    @org.jetbrains.annotations.Nullable()
    private final com.yuyan.imemodule.libs.cropper.CropOverlayView mCropOverlayView = null;
    
    /**
     * The matrix used to transform the cropping image in the image view
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Matrix mImageMatrix = null;
    
    /**
     * Reusing matrix instance for reverse matrix calculations.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Matrix mImageInverseMatrix = null;
    
    /**
     * Progress bar widget to show progress bar on async image loading and cropping.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ProgressBar mProgressBar = null;
    
    /**
     * Rectangle used in image matrix transformation calculation (reusing rect instance)
     */
    @org.jetbrains.annotations.NotNull()
    private final float[] mImagePoints = null;
    
    /**
     * Rectangle used in image matrix transformation for scale calculation (reusing rect instance)
     */
    @org.jetbrains.annotations.NotNull()
    private final float[] mScaleImagePoints = null;
    
    /**
     * Animation class to smooth animate zoom-in/out
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageAnimation mAnimation;
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Bitmap originalBitmap;
    
    /**
     * The image rotation value used during loading of the image, so we can reset to it
     */
    private int mInitialDegreesRotated = 0;
    
    /**
     * How much the image is rotated from original clockwise
     */
    private int mDegreesRotated = 0;
    
    /**
     * If the image flipped horizontally
     */
    private boolean mFlipHorizontally;
    
    /**
     * If the image flipped vertically
     */
    private boolean mFlipVertically;
    private int mLayoutWidth = 0;
    private int mLayoutHeight = 0;
    private int mImageResource = 0;
    
    /**
     * The initial scale type of the image in the crop image view
     */
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType mScaleType;
    
    /**
     * if to save bitmap on save instance state.<br></br>
     * It is best to avoid it by using URI in setting image for cropping.<br></br>
     * If false the bitmap is not saved and if restore is required to view will be empty, storing the
     * bitmap requires saving it to file which can be expensive. default: false.
     */
    @java.lang.Deprecated()
    private boolean isSaveBitmapToInstanceState = false;
    
    /**
     * if to show crop overlay UI what contains the crop window UI surrounded by background over the
     * cropping image.<br></br>
     * default: true, may disable for animation or frame transition.
     */
    private boolean mShowCropOverlay = true;
    
    /**
     * If true, shows a helper text label over crop overlay UI
     * default: false
     */
    private boolean mShowCropLabel = false;
    
    /**
     * Text size for text label over crop overlay UI
     * default: 20sp
     */
    private float mCropLabelTextSize = 20.0F;
    
    /**
     * if to show progress bar when image async loading/cropping is in progress.<br></br>
     * default: true, disable to provide custom progress bar UI.
     */
    private boolean mShowProgressBar = true;
    
    /**
     * if auto-zoom functionality is enabled.<br></br>
     * default: true.
     */
    private boolean mAutoZoomEnabled = true;
    
    /**
     * The max zoom allowed during cropping
     */
    private int mMaxZoom;
    
    /**
     * Callback to be invoked when crop overlay is released.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView.OnSetCropOverlayReleasedListener mOnCropOverlayReleasedListener;
    
    /**
     * Callback to be invoked when crop overlay is moved.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView.OnSetCropOverlayMovedListener mOnSetCropOverlayMovedListener;
    
    /**
     * Callback to be invoked when crop window is changed.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView.OnSetCropWindowChangeListener mOnSetCropWindowChangeListener;
    
    /**
     * Callback to be invoked when image async loading is complete.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView.OnSetImageUriCompleteListener mOnSetImageUriCompleteListener;
    
    /**
     * Callback to be invoked when image async cropping is complete.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView.OnCropImageCompleteListener mOnCropImageCompleteListener;
    
    /**
     * The URI that the image was loaded from (if loaded from URI)
     */
    @org.jetbrains.annotations.Nullable()
    private android.net.Uri imageUri;
    
    /**
     * The sample size the image was loaded by if was loaded by URI
     */
    private int loadedSampleSize = 1;
    
    /**
     * The current zoom level to scale the cropping image
     */
    private float mZoom = 1.0F;
    
    /**
     * The X offset that the cropping image was translated after zooming
     */
    private float mZoomOffsetX = 0.0F;
    
    /**
     * The Y offset that the cropping image was translated after zooming
     */
    private float mZoomOffsetY = 0.0F;
    
    /**
     * Used to restore the cropping windows rectangle after state restore
     */
    @org.jetbrains.annotations.Nullable()
    private android.graphics.RectF mRestoreCropWindowRect;
    
    /**
     * Used to restore image rotation after state restore
     */
    private int mRestoreDegreesRotated = 0;
    
    /**
     * Used to detect size change to handle auto-zoom using [handleCropWindowChanged] in layout.
     */
    private boolean mSizeChanged = false;
    
    /**
     * Task used to load bitmap async from UI thread
     */
    @org.jetbrains.annotations.Nullable()
    private java.lang.ref.WeakReference<com.yuyan.imemodule.libs.cropper.BitmapLoadingWorkerJob> bitmapLoadingWorkerJob;
    
    /**
     * Task used to crop bitmap async from UI thread
     */
    @org.jetbrains.annotations.Nullable()
    private java.lang.ref.WeakReference<com.yuyan.imemodule.libs.cropper.BitmapCroppingWorkerJob> bitmapCroppingWorkerJob;
    
    /**
     * The Android Uri to save the cropped image to
     */
    @org.jetbrains.annotations.Nullable()
    private android.net.Uri customOutputUri;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.cropper.CropImageView.Companion Companion = null;
    
    @kotlin.jvm.JvmOverloads()
    public CropImageView(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null);
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageView(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null);
    }
    
    /**
     * if to save bitmap on save instance state.<br></br>
     * It is best to avoid it by using URI in setting image for cropping.<br></br>
     * If false the bitmap is not saved and if restore is required to view will be empty, storing the
     * bitmap requires saving it to file which can be expensive. default: false.
     */
    @java.lang.Deprecated()
    public final boolean isSaveBitmapToInstanceState() {
        return false;
    }
    
    /**
     * if to save bitmap on save instance state.<br></br>
     * It is best to avoid it by using URI in setting image for cropping.<br></br>
     * If false the bitmap is not saved and if restore is required to view will be empty, storing the
     * bitmap requires saving it to file which can be expensive. default: false.
     */
    @java.lang.Deprecated()
    public static void isSaveBitmapToInstanceState$annotations() {
    }
    
    /**
     * if to save bitmap on save instance state.<br></br>
     * It is best to avoid it by using URI in setting image for cropping.<br></br>
     * If false the bitmap is not saved and if restore is required to view will be empty, storing the
     * bitmap requires saving it to file which can be expensive. default: false.
     */
    @java.lang.Deprecated()
    public final void setSaveBitmapToInstanceState(boolean p0) {
    }
    
    /**
     * The URI that the image was loaded from (if loaded from URI)
     */
    @org.jetbrains.annotations.Nullable()
    public final android.net.Uri getImageUri() {
        return null;
    }
    
    public final int getRotatedDegrees() {
        return 0;
    }
    
    public final void setRotatedDegrees(int degrees) {
    }
    
    private final int getImageResource() {
        return 0;
    }
    
    private final void setImageResource(int resId) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final android.graphics.Rect getWholeImageRect() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final android.graphics.Rect getCropRect() {
        return null;
    }
    
    public final void setCropRect(@org.jetbrains.annotations.Nullable()
    android.graphics.Rect rect) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final float[] getCropPoints() {
        return null;
    }
    
    /**
     * Gets the cropped image based on the current crop window.
     *
     * [reqWidth] the width to resize the cropped image
     * [reqHeight] the height to resize the cropped image
     * [options] the resize method to use
     * @return a new Bitmap representing the cropped image
     */
    @kotlin.jvm.JvmOverloads()
    @org.jetbrains.annotations.Nullable()
    public final android.graphics.Bitmap getCroppedImage() {
        return null;
    }
    
    /**
     * Gets the cropped image based on the current crop window.
     *
     * [reqWidth] the width to resize the cropped image
     * [reqHeight] the height to resize the cropped image
     * [options] the resize method to use
     * @return a new Bitmap representing the cropped image
     */
    @kotlin.jvm.JvmOverloads()
    @org.jetbrains.annotations.Nullable()
    public final android.graphics.Bitmap getCroppedImage(int reqWidth) {
        return null;
    }
    
    /**
     * Gets the cropped image based on the current crop window.
     *
     * [reqWidth] the width to resize the cropped image
     * [reqHeight] the height to resize the cropped image
     * [options] the resize method to use
     * @return a new Bitmap representing the cropped image
     */
    @kotlin.jvm.JvmOverloads()
    @org.jetbrains.annotations.Nullable()
    public final android.graphics.Bitmap getCroppedImage(int reqWidth, int reqHeight) {
        return null;
    }
    
    /**
     * Gets the cropped image based on the current crop window.
     *
     * [reqWidth] the width to resize the cropped image
     * [reqHeight] the height to resize the cropped image
     * [options] the resize method to use
     * @return a new Bitmap representing the cropped image
     */
    @kotlin.jvm.JvmOverloads()
    @org.jetbrains.annotations.Nullable()
    public final android.graphics.Bitmap getCroppedImage(int reqWidth, int reqHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions options) {
        return null;
    }
    
    /**
     * Cropped image based on the current crop window to the given uri.
     * The result will be invoked to listener set by [setOnCropImageCompleteListener].
     *
     * [saveCompressFormat] the compression format to use when writing the image
     * [saveCompressQuality] the quality (if applicable) to use when writing the image (0 - 100)
     * [reqWidth] the width to resize the cropped image
     * [reqHeight] the height to resize the cropped image
     * [options] the resize method to use, see its documentation
     */
    public final void croppedImageAsync(@org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat saveCompressFormat, int saveCompressQuality, int reqWidth, int reqHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions options, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri) {
    }
    
    /**
     * Set the callback to be invoked when image async loading [setImageUriAsync] is
     * complete (successful or failed).
     */
    public final void setOnSetImageUriCompleteListener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.libs.cropper.CropImageView.OnSetImageUriCompleteListener listener) {
    }
    
    /**
     * Set the callback to be invoked when image async cropping image [croppedImageAsync]
     * or [croppedImage] is complete (successful or failed).
     */
    public final void setOnCropImageCompleteListener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.libs.cropper.CropImageView.OnCropImageCompleteListener listener) {
    }
    
    /**
     * Sets a bitmap loaded from the given Android URI as the content of the CropImageView.<br></br>
     * Can be used with URI from gallery or camera source.<br></br>
     * Will rotate the image by exif data.<br></br>
     *
     * [uri] the URI to load the image from
     */
    public final void setImageUriAsync(@org.jetbrains.annotations.Nullable()
    android.net.Uri uri) {
    }
    
    /**
     * Rotates image by the specified number of degrees clockwise.<br></br>
     * Negative values represent counter-clockwise rotations.
     *
     * [degrees] Integer specifying the number of degrees to rotate.
     */
    public final void rotateImage(int degrees) {
    }
    
    /**
     * Flips the image horizontally.
     */
    public final void flipImageHorizontally() {
    }
    
    /**
     * Flips the image vertically.
     */
    public final void flipImageVertically() {
    }
    
    /**
     * On complete of the async bitmap loading by [setImageUriAsync] set the result to the
     * widget if still relevant and call listener if set.
     *
     * [result] the result of bitmap loading
     */
    public final void onSetImageUriAsyncComplete$yuyansdk_offlineDebug(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.BitmapLoadingWorkerJob.Result result) {
    }
    
    /**
     * On complete of the async bitmap cropping by [croppedImageAsync] call listener if
     * set.
     *
     * [result] the result of bitmap cropping
     */
    public final void onImageCroppingAsyncComplete$yuyansdk_offlineDebug(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.BitmapCroppingWorkerJob.Result result) {
    }
    
    /**
     * Set the given bitmap to be used in for cropping<br></br>
     * Optionally clear full if the bitmap is new, or partial clear if the bitmap has been
     * manipulated.
     */
    private final void setBitmap(android.graphics.Bitmap bitmap, int imageResource, android.net.Uri imageUri, int loadSampleSize, int degreesRotated) {
    }
    
    /**
     * Clear the current image set for cropping.<br></br>
     * Full clear will also clear the data of the set image like Uri or Resource id while partial
     * clear will only clear the bitmap and recycle if required.
     */
    private final void clearImageInt() {
    }
    
    /**
     * Gets the cropped image based on the current crop window.
     * If (reqWidth,reqHeight) is given AND image is loaded from URI cropping will try to use sample
     * size to fit in the requested width and height down-sampling if possible - optimization to get
     * best size to quality.
     * The result will be invoked to listener set by [setOnCropImageCompleteListener].
     *
     * [reqWidth] the width to resize the cropped image
     * [reqHeight] the height to resize the cropped image
     * [options] the resize method to use on the cropped bitmap
     * [saveCompressFormat] if saveUri is given, the given compression will be used for saving
     * the image
     * [saveCompressQuality] if saveUri is given, the given quality will be used for the
     * compression.
     */
    private final void startCropWorkerTask(int reqWidth, int reqHeight, com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions options, android.graphics.Bitmap.CompressFormat saveCompressFormat, int saveCompressQuality, android.net.Uri customOutputUri) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.Nullable()
    public android.os.Parcelable onSaveInstanceState() {
        return null;
    }
    
    @java.lang.Override()
    public void onRestoreInstanceState(@org.jetbrains.annotations.NotNull()
    android.os.Parcelable state) {
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    @java.lang.Override()
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
    }
    
    /**
     * Detect size change to handle auto-zoom using [handleCropWindowChanged] in layout.
     */
    @java.lang.Override()
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    }
    
    /**
     * Handle crop window change to:<br></br>
     * 1. Execute auto-zoom-in/out depending on the area covered of cropping window relative to the
     * available view area.<br></br>
     * 2. Slide the zoomed sub-area if the cropping window is outside the visible view sub-area.
     * <br></br>
     *
     * [inProgress] is the crop window change is still in progress by the user
     * [animate] if to animate the change to the image matrix, or set it directly
     */
    private final void handleCropWindowChanged(boolean inProgress, boolean animate) {
    }
    
    /**
     * Apply matrix to handle the image inside the image view.
     *
     * [width] the width of the image view
     * [height] the height of the image view
     */
    private final void applyImageMatrix(float width, float height, boolean center, boolean animate) {
    }
    
    /**
     * Adjust the given image rectangle by image transformation matrix to know the final rectangle of
     * the image.<br></br>
     * To get the proper rectangle it must be first reset to original image rectangle.
     */
    private final void mapImagePointsByImageMatrix() {
    }
    
    /**
     * Set visibility of crop overlay to hide it when there is no image or specifically set by client.
     */
    private final void setCropOverlayVisibility() {
    }
    
    /**
     * Set visibility of progress bar when async loading/cropping is in process and show is enabled.
     */
    private final void setProgressBarVisibility() {
    }
    
    /**
     * Update the scale factor between the actual image bitmap and the shown image.<br></br>
     */
    private final void updateImageBounds(boolean clear) {
    }
    
    @java.lang.Override()
    public void onCropWindowChanged(boolean inProgress) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J%\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0004H\u0000\u00a2\u0006\u0002\b\b\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$Companion;", "", "()V", "getOnMeasureSpec", "", "measureSpecMode", "measureSpecSize", "desiredSize", "getOnMeasureSpec$yuyansdk_offlineDebug", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        /**
         * Determines the specs for the onMeasure function. Calculates the width or height depending on
         * the mode.
         *
         * [measureSpecMode] The mode of the measured width or height.
         * [measureSpecSize] The size of the measured width or height.
         * [desiredSize] The desired size of the measured width or height.
         * @return The final size of the width or height.
         */
        public final int getOnMeasureSpec$yuyansdk_offlineDebug(int measureSpecMode, int measureSpecSize, int desiredSize) {
            return 0;
        }
    }
    
    /**
     * Possible crop corner shape
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropCornerShape;", "", "(Ljava/lang/String;I)V", "RECTANGLE", "OVAL", "yuyansdk_offlineDebug"})
    public static enum CropCornerShape {
        /*public static final*/ RECTANGLE /* = new RECTANGLE() */,
        /*public static final*/ OVAL /* = new OVAL() */;
        
        CropCornerShape() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape> getEntries() {
            return null;
        }
    }
    
    /**
     * Result data of crop image.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0017\u0018\u00002\u00020\u0001Ba\b\u0000\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\u000e\u0010\u0007\u001a\n\u0018\u00010\bj\u0004\u0018\u0001`\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\b\u0010\f\u001a\u0004\u0018\u00010\r\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\r\u0012\u0006\u0010\u000f\u001a\u00020\u0010\u0012\u0006\u0010\u0011\u001a\u00020\u0010\u00a2\u0006\u0002\u0010\u0012J\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u00052\u0006\u0010%\u001a\u00020&J\u001c\u0010\'\u001a\u0004\u0018\u00010(2\u0006\u0010%\u001a\u00020&2\b\b\u0002\u0010)\u001a\u00020\u001cH\u0002R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\n\u001a\u00020\u000b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0013\u0010\f\u001a\u0004\u0018\u00010\r\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0019\u0010\u0007\u001a\n\u0018\u00010\bj\u0004\u0018\u0001`\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u001b\u001a\u00020\u001c8F\u00a2\u0006\u0006\u001a\u0004\b\u001b\u0010\u001dR\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0011\u0010\u000f\u001a\u00020\u0010\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0011\u0010\u0011\u001a\u00020\u0010\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010!R\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u001fR\u0013\u0010\u000e\u001a\u0004\u0018\u00010\r\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010\u0018\u00a8\u0006*"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropResult;", "", "originalUri", "Landroid/net/Uri;", "bitmap", "Landroid/graphics/Bitmap;", "uriContent", "error", "Ljava/lang/Exception;", "Lkotlin/Exception;", "cropPoints", "", "cropRect", "Landroid/graphics/Rect;", "wholeImageRect", "rotation", "", "sampleSize", "(Landroid/net/Uri;Landroid/graphics/Bitmap;Landroid/net/Uri;Ljava/lang/Exception;[FLandroid/graphics/Rect;Landroid/graphics/Rect;II)V", "getBitmap", "()Landroid/graphics/Bitmap;", "getCropPoints", "()[F", "getCropRect", "()Landroid/graphics/Rect;", "getError", "()Ljava/lang/Exception;", "isSuccessful", "", "()Z", "getOriginalUri", "()Landroid/net/Uri;", "getRotation", "()I", "getSampleSize", "getUriContent", "getWholeImageRect", "context", "Landroid/content/Context;", "getUriFilePath", "", "uniqueName", "yuyansdk_offlineDebug"})
    public static class CropResult {
        
        /**
         * The Android uri of the original image loaded for cropping.<br></br>
         * Null if bitmap was used to load image.
         */
        @org.jetbrains.annotations.Nullable()
        private final android.net.Uri originalUri = null;
        
        /**
         * The cropped image bitmap result.<br></br>
         * Null if save cropped image was executed, no output requested or failure.
         */
        @org.jetbrains.annotations.Nullable()
        private final android.graphics.Bitmap bitmap = null;
        
        /**
         * The Android uri of the saved cropped image result.<br></br>
         * Null if get cropped image was executed, no output requested or failure.
         *
         * This is NOT the file path, please use [getUriFilePath]
         */
        @org.jetbrains.annotations.Nullable()
        private final android.net.Uri uriContent = null;
        
        /**
         * The error that failed the loading/cropping (null if successful).
         */
        @org.jetbrains.annotations.Nullable()
        private final java.lang.Exception error = null;
        
        /**
         * The 4 points of the cropping window in the source image.
         */
        @org.jetbrains.annotations.NotNull()
        private final float[] cropPoints = null;
        
        /**
         * The rectangle of the cropping window in the source image.
         */
        @org.jetbrains.annotations.Nullable()
        private final android.graphics.Rect cropRect = null;
        
        /**
         * The rectangle of the source image dimensions.
         */
        @org.jetbrains.annotations.Nullable()
        private final android.graphics.Rect wholeImageRect = null;
        
        /**
         * The final rotation of the cropped image relative to source.
         */
        private final int rotation = 0;
        
        /**
         * Sample size used creating the crop bitmap to lower its size.
         */
        private final int sampleSize = 0;
        
        public CropResult(@org.jetbrains.annotations.Nullable()
        android.net.Uri originalUri, @org.jetbrains.annotations.Nullable()
        android.graphics.Bitmap bitmap, @org.jetbrains.annotations.Nullable()
        android.net.Uri uriContent, @org.jetbrains.annotations.Nullable()
        java.lang.Exception error, @org.jetbrains.annotations.NotNull()
        float[] cropPoints, @org.jetbrains.annotations.Nullable()
        android.graphics.Rect cropRect, @org.jetbrains.annotations.Nullable()
        android.graphics.Rect wholeImageRect, int rotation, int sampleSize) {
            super();
        }
        
        /**
         * The Android uri of the original image loaded for cropping.<br></br>
         * Null if bitmap was used to load image.
         */
        @org.jetbrains.annotations.Nullable()
        public final android.net.Uri getOriginalUri() {
            return null;
        }
        
        /**
         * The cropped image bitmap result.<br></br>
         * Null if save cropped image was executed, no output requested or failure.
         */
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Bitmap getBitmap() {
            return null;
        }
        
        /**
         * The Android uri of the saved cropped image result.<br></br>
         * Null if get cropped image was executed, no output requested or failure.
         *
         * This is NOT the file path, please use [getUriFilePath]
         */
        @org.jetbrains.annotations.Nullable()
        public final android.net.Uri getUriContent() {
            return null;
        }
        
        /**
         * The error that failed the loading/cropping (null if successful).
         */
        @org.jetbrains.annotations.Nullable()
        public final java.lang.Exception getError() {
            return null;
        }
        
        /**
         * The 4 points of the cropping window in the source image.
         */
        @org.jetbrains.annotations.NotNull()
        public final float[] getCropPoints() {
            return null;
        }
        
        /**
         * The rectangle of the cropping window in the source image.
         */
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Rect getCropRect() {
            return null;
        }
        
        /**
         * The rectangle of the source image dimensions.
         */
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Rect getWholeImageRect() {
            return null;
        }
        
        /**
         * The final rotation of the cropped image relative to source.
         */
        public final int getRotation() {
            return 0;
        }
        
        /**
         * Sample size used creating the crop bitmap to lower its size.
         */
        public final int getSampleSize() {
            return 0;
        }
        
        public final boolean isSuccessful() {
            return false;
        }
        
        /**
         * The cropped image bitmap result.<br></br>
         * Null if save cropped image was executed, no output requested or failure.
         *
         * [context] used to retrieve the bitmap in case you need from activity result
         */
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Bitmap getBitmap(@org.jetbrains.annotations.NotNull()
        android.content.Context context) {
            return null;
        }
        
        /**
         * The file path of the image to load
         * Null if you get cropped image was executed, no output requested or failure.
         *
         * [context] used to access Android APIs, like content resolve, it is your activity/fragment/widget.
         * [uniqueName] If true, make each image cropped have a different file name, this could
         * cause memory issues, use wisely.
         */
        private final java.lang.String getUriFilePath(android.content.Context context, boolean uniqueName) {
            return null;
        }
    }
    
    /**
     * The possible cropping area shape.<br></br>
     * To set square/circle crop shape set aspect ratio to 1:1.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropShape;", "", "(Ljava/lang/String;I)V", "RECTANGLE", "OVAL", "RECTANGLE_VERTICAL_ONLY", "RECTANGLE_HORIZONTAL_ONLY", "yuyansdk_offlineDebug"})
    public static enum CropShape {
        /*public static final*/ RECTANGLE /* = new RECTANGLE() */,
        /*public static final*/ OVAL /* = new OVAL() */,
        /*public static final*/ RECTANGLE_VERTICAL_ONLY /* = new RECTANGLE_VERTICAL_ONLY() */,
        /*public static final*/ RECTANGLE_HORIZONTAL_ONLY /* = new RECTANGLE_HORIZONTAL_ONLY() */;
        
        CropShape() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.libs.cropper.CropImageView.CropShape> getEntries() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$Guidelines;", "", "(Ljava/lang/String;I)V", "OFF", "ON_TOUCH", "ON", "yuyansdk_offlineDebug"})
    public static enum Guidelines {
        /*public static final*/ OFF /* = new OFF() */,
        /*public static final*/ ON_TOUCH /* = new ON_TOUCH() */,
        /*public static final*/ ON /* = new ON() */;
        
        Guidelines() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines> getEntries() {
            return null;
        }
    }
    
    /**
     * Interface definition for a callback to be invoked when image async crop is complete.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007H&\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnCropImageCompleteListener;", "", "onCropImageComplete", "", "view", "Lcom/yuyan/imemodule/libs/cropper/CropImageView;", "result", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropResult;", "yuyansdk_offlineDebug"})
    public static abstract interface OnCropImageCompleteListener {
        
        /**
         * Called when a crop image view has completed cropping image.<br></br>
         * Result object contains the cropped bitmap, saved cropped image uri, crop points data or the
         * error occurred during cropping.
         *
         * [view] The crop image view that cropping of image was complete.
         * [result] the crop image result data (with cropped image or error)
         */
        public abstract void onCropImageComplete(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.libs.cropper.CropImageView view, @org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.libs.cropper.CropImageView.CropResult result);
    }
    
    /**
     * Interface definition for a callback to be invoked when the crop overlay is released.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J\u0012\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H&\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetCropOverlayMovedListener;", "", "onCropOverlayMoved", "", "rect", "Landroid/graphics/Rect;", "yuyansdk_offlineDebug"})
    public static abstract interface OnSetCropOverlayMovedListener {
        
        /**
         * Called when the crop overlay is moved
         *
         * [rect] The rect coordinates of the cropped overlay
         */
        public abstract void onCropOverlayMoved(@org.jetbrains.annotations.Nullable()
        android.graphics.Rect rect);
    }
    
    /**
     * Interface definition for a callback to be invoked when the crop overlay is released.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J\u0012\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005H&\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetCropOverlayReleasedListener;", "", "onCropOverlayReleased", "", "rect", "Landroid/graphics/Rect;", "yuyansdk_offlineDebug"})
    public static abstract interface OnSetCropOverlayReleasedListener {
        
        /**
         * Called when the crop overlay changed listener is called and inProgress is false.
         *
         * [rect] The rect coordinates of the cropped overlay
         */
        public abstract void onCropOverlayReleased(@org.jetbrains.annotations.Nullable()
        android.graphics.Rect rect);
    }
    
    /**
     * Interface definition for a callback to be invoked when the crop overlay is released.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&\u00a8\u0006\u0004"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetCropWindowChangeListener;", "", "onCropWindowChanged", "", "yuyansdk_offlineDebug"})
    public static abstract interface OnSetCropWindowChangeListener {
        
        /**
         * Called when the crop window is changed
         */
        public abstract void onCropWindowChanged();
    }
    
    /**
     * Interface definition for a callback to be invoked when image async loading is complete.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J(\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u000e\u0010\b\u001a\n\u0018\u00010\tj\u0004\u0018\u0001`\nH&\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetImageUriCompleteListener;", "", "onSetImageUriComplete", "", "view", "Lcom/yuyan/imemodule/libs/cropper/CropImageView;", "uri", "Landroid/net/Uri;", "error", "Ljava/lang/Exception;", "Lkotlin/Exception;", "yuyansdk_offlineDebug"})
    public static abstract interface OnSetImageUriCompleteListener {
        
        /**
         * Called when a crop image view has completed loading image for cropping.<br></br>
         * If loading failed error parameter will contain the error.
         *
         * [view] The crop image view that loading of image was complete.
         * [uri] the URI of the image that was loading
         * [error] if error occurred during loading will contain the error, otherwise null.
         */
        public abstract void onSetImageUriComplete(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.libs.cropper.CropImageView view, @org.jetbrains.annotations.NotNull()
        android.net.Uri uri, @org.jetbrains.annotations.Nullable()
        java.lang.Exception error);
    }
    
    /**
     * Possible options for handling requested width/height for cropping.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$RequestSizeOptions;", "", "(Ljava/lang/String;I)V", "NONE", "SAMPLING", "RESIZE_INSIDE", "RESIZE_FIT", "RESIZE_EXACT", "yuyansdk_offlineDebug"})
    public static enum RequestSizeOptions {
        /*public static final*/ NONE /* = new NONE() */,
        /*public static final*/ SAMPLING /* = new SAMPLING() */,
        /*public static final*/ RESIZE_INSIDE /* = new RESIZE_INSIDE() */,
        /*public static final*/ RESIZE_FIT /* = new RESIZE_FIT() */,
        /*public static final*/ RESIZE_EXACT /* = new RESIZE_EXACT() */;
        
        RequestSizeOptions() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions> getEntries() {
            return null;
        }
    }
    
    /**
     * Options for scaling the bounds of cropping image to the bounds of Crop Image View.<br></br>
     * Note: Some options are affected by auto-zoom, if enabled.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageView$ScaleType;", "", "(Ljava/lang/String;I)V", "FIT_CENTER", "CENTER", "CENTER_CROP", "CENTER_INSIDE", "yuyansdk_offlineDebug"})
    public static enum ScaleType {
        /*public static final*/ FIT_CENTER /* = new FIT_CENTER() */,
        /*public static final*/ CENTER /* = new CENTER() */,
        /*public static final*/ CENTER_CROP /* = new CENTER_CROP() */,
        /*public static final*/ CENTER_INSIDE /* = new CENTER_INSIDE() */;
        
        ScaleType() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType> getEntries() {
            return null;
        }
    }
}
package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\u001a\u0010\u0010\u0000\u001a\u00020\u00012\b\b\u0001\u0010\u0002\u001a\u00020\u0003\u00a8\u0006\u0004"}, d2 = {"rippleDrawable", "Landroid/graphics/drawable/RippleDrawable;", "color", "", "yuyansdk_offlineDebug"})
public final class DrawableKt {
    
    @org.jetbrains.annotations.NotNull()
    public static final android.graphics.drawable.RippleDrawable rippleDrawable(@androidx.annotation.ColorInt()
    int color) {
        return null;
    }
}
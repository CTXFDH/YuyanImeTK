package com.yuyan.imemodule.keyboard;

/**
 * 键盘显示管理类
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0004\b\u0007\u0018\u0000 \u001f2\u00020\u0001:\u0002\u001f B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0013\u001a\u00020\u0014J\u000e\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\rJ\u0016\u0010\u0017\u001a\u00020\u00142\u0006\u0010\u0018\u001a\u00020\u00122\u0006\u0010\u0019\u001a\u00020\u0010J\u000e\u0010\u001a\u001a\u00020\u00142\u0006\u0010\u001b\u001a\u00020\rJ\u0010\u0010\u001a\u001a\u00020\u00142\b\b\u0002\u0010\u001c\u001a\u00020\u001dJ\u0006\u0010\u001e\u001a\u00020\u0014R\"\u0010\u0005\u001a\u0004\u0018\u00010\u00042\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\t8F\u00a2\u0006\u0006\u001a\u0004\b\b\u0010\nR\u001c\u0010\u000b\u001a\u0010\u0012\u0004\u0012\u00020\r\u0012\u0006\u0012\u0004\u0018\u00010\u00040\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\rX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006!"}, d2 = {"Lcom/yuyan/imemodule/keyboard/KeyboardManager;", "", "()V", "<set-?>", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "currentContainer", "getCurrentContainer", "()Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "isInputKeyboard", "", "()Z", "keyboards", "Ljava/util/HashMap;", "Lcom/yuyan/imemodule/keyboard/KeyboardManager$KeyboardType;", "mCurrentKeyboardName", "mInputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "mKeyboardRootView", "Lcom/yuyan/imemodule/keyboard/container/InputViewParent;", "clearKeyboard", "", "clearNonMainKeyboards", "keepType", "setData", "keyboardRootView", "inputView", "switchKeyboard", "keyboardName", "layout", "", "switchKeyboardToMain", "Companion", "KeyboardType", "yuyansdk_offlineDebug"})
public final class KeyboardManager {
    private com.yuyan.imemodule.keyboard.InputView mInputView;
    private com.yuyan.imemodule.keyboard.container.InputViewParent mKeyboardRootView;
    @org.jetbrains.annotations.NotNull()
    private final java.util.HashMap<com.yuyan.imemodule.keyboard.KeyboardManager.KeyboardType, com.yuyan.imemodule.keyboard.container.BaseContainer> keyboards = null;
    private com.yuyan.imemodule.keyboard.KeyboardManager.KeyboardType mCurrentKeyboardName;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.keyboard.container.BaseContainer currentContainer;
    @org.jetbrains.annotations.Nullable()
    private static com.yuyan.imemodule.keyboard.KeyboardManager mInstance;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.keyboard.KeyboardManager.Companion Companion = null;
    
    public KeyboardManager() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.keyboard.container.BaseContainer getCurrentContainer() {
        return null;
    }
    
    public final void setData(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.container.InputViewParent keyboardRootView, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
    }
    
    public final void clearKeyboard() {
    }
    
    public final void clearNonMainKeyboards(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.KeyboardManager.KeyboardType keepType) {
    }
    
    public final void switchKeyboardToMain() {
    }
    
    public final void switchKeyboard(int layout) {
    }
    
    public final void switchKeyboard(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.KeyboardManager.KeyboardType keyboardName) {
    }
    
    public final boolean isInputKeyboard() {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.keyboard.KeyboardManager getInstance() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u001a\u0010\u0003\u001a\u00020\u00048FX\u0087\u0004\u00a2\u0006\f\u0012\u0004\b\u0005\u0010\u0002\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\b\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/keyboard/KeyboardManager$Companion;", "", "()V", "instance", "Lcom/yuyan/imemodule/keyboard/KeyboardManager;", "getInstance$annotations", "getInstance", "()Lcom/yuyan/imemodule/keyboard/KeyboardManager;", "mInstance", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @kotlin.jvm.JvmStatic()
        @java.lang.Deprecated()
        public static void getInstance$annotations() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.keyboard.KeyboardManager getInstance() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\r\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000bj\u0002\b\fj\u0002\b\r\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/keyboard/KeyboardManager$KeyboardType;", "", "(Ljava/lang/String;I)V", "T9", "QWERTY", "LX17", "QWERTYABC", "NUMBER", "SYMBOL", "SETTINGS", "HANDWRITING", "CANDIDATES", "ClipBoard", "TEXTEDIT", "yuyansdk_offlineDebug"})
    public static enum KeyboardType {
        /*public static final*/ T9 /* = new T9() */,
        /*public static final*/ QWERTY /* = new QWERTY() */,
        /*public static final*/ LX17 /* = new LX17() */,
        /*public static final*/ QWERTYABC /* = new QWERTYABC() */,
        /*public static final*/ NUMBER /* = new NUMBER() */,
        /*public static final*/ SYMBOL /* = new SYMBOL() */,
        /*public static final*/ SETTINGS /* = new SETTINGS() */,
        /*public static final*/ HANDWRITING /* = new HANDWRITING() */,
        /*public static final*/ CANDIDATES /* = new CANDIDATES() */,
        /*public static final*/ ClipBoard /* = new ClipBoard() */,
        /*public static final*/ TEXTEDIT /* = new TEXTEDIT() */;
        
        KeyboardType() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.keyboard.KeyboardManager.KeyboardType> getEntries() {
            return null;
        }
    }
}
package com.yuyan.inputmethod.core;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0007\u0018\u0000 \u00052\u00020\u0001:\u0001\u0005B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/inputmethod/core/Rime;", "", "fullCheck", "", "(Z)V", "Companion", "yuyansdk_offlineDebug"})
public final class Rime {
    @org.jetbrains.annotations.Nullable()
    private static com.yuyan.inputmethod.core.Rime instance;
    @org.jetbrains.annotations.Nullable()
    private static com.yuyan.inputmethod.core.RimeContext mContext;
    @org.jetbrains.annotations.Nullable()
    private static com.yuyan.inputmethod.core.RimeStatus mStatus;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.core.Rime.Companion Companion = null;
    
    public Rime(boolean fullCheck) {
        super();
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.core.Rime getInstance(boolean fullCheck) {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final void destroy() {
    }
    
    public static final boolean isComposing() {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final boolean hasMenu() {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final boolean hasRight() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public static final com.yuyan.inputmethod.core.RimeComposition getComposition() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String getCompositionText() {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final boolean processKey(int keycode, int mask) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final boolean replaceKey(int caretPos, int length, @org.jetbrains.annotations.NotNull()
    java.lang.String key) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final void clearComposition() {
    }
    
    @kotlin.jvm.JvmStatic()
    public static final boolean selectCandidate(int index) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final void setOption(@org.jetbrains.annotations.NotNull()
    java.lang.String option, boolean value) {
    }
    
    @kotlin.jvm.JvmStatic()
    public static final boolean selectSchema(@org.jetbrains.annotations.NotNull()
    java.lang.String schemaId) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native void startupRime(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    java.lang.String sharedDir, @org.jetbrains.annotations.NotNull()
    java.lang.String userDir, boolean fullCheck) {
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native void exitRime() {
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native void setRimePageSize(int pageSize) {
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native boolean processRimeKey(int keycode, int mask) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native boolean replaceRimeKey(int caretPos, int length, @org.jetbrains.annotations.Nullable()
    java.lang.String key) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native void clearRimeComposition() {
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.Nullable()
    public static final native com.yuyan.inputmethod.core.RimeCommit getRimeCommit() {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.Nullable()
    public static final native com.yuyan.inputmethod.core.RimeContext getRimeContext() {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.Nullable()
    public static final native com.yuyan.inputmethod.core.RimeStatus getRimeStatus() {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native void setRimeOption(@org.jetbrains.annotations.NotNull()
    java.lang.String option, boolean value) {
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.NotNull()
    public static final native java.lang.String getCurrentRimeSchema() {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native boolean selectRimeSchema(@org.jetbrains.annotations.NotNull()
    java.lang.String schemaId) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native boolean selectRimeCandidate(int index) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native int getRimeKeycodeByName(@org.jetbrains.annotations.NotNull()
    java.lang.String name) {
        return 0;
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.NotNull()
    public static final native java.lang.String[] getRimeAssociateList(@org.jetbrains.annotations.Nullable()
    java.lang.String key) {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final native boolean selectRimeAssociate(int index) {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u001c\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0017\u001a\u00020\u00102\u0006\u0010\u0018\u001a\u00020\u0019J\b\u0010\u001a\u001a\u00020\u001bH\u0007J\t\u0010\u001c\u001a\u00020\u001bH\u0087 J\b\u0010\u001d\u001a\u00020\u001bH\u0007J\t\u0010\u001e\u001a\u00020\u001bH\u0087 J\u001d\u0010\u001f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\t0 2\b\u0010!\u001a\u0004\u0018\u00010\t\u00a2\u0006\u0002\u0010\"J\t\u0010#\u001a\u00020\tH\u0087 J\u0012\u0010$\u001a\u00020\u000e2\b\b\u0002\u0010%\u001a\u00020\u0010H\u0007J\u001b\u0010&\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\t0 2\b\u0010!\u001a\u0004\u0018\u00010\tH\u0087 J\u000b\u0010\'\u001a\u0004\u0018\u00010(H\u0087 J\u000b\u0010)\u001a\u0004\u0018\u00010\u0014H\u0087 J\u0011\u0010*\u001a\u00020\u00192\u0006\u0010+\u001a\u00020\tH\u0087 J\u000b\u0010,\u001a\u0004\u0018\u00010\u0016H\u0087 J\b\u0010-\u001a\u00020\u0010H\u0007J\b\u0010.\u001a\u00020\u0010H\u0007J\u0018\u0010/\u001a\u00020\u00102\u0006\u00100\u001a\u00020\u00192\u0006\u00101\u001a\u00020\u0019H\u0007J\u0019\u00102\u001a\u00020\u00102\u0006\u00100\u001a\u00020\u00192\u0006\u00101\u001a\u00020\u0019H\u0087 J \u00103\u001a\u00020\u00102\u0006\u00104\u001a\u00020\u00192\u0006\u00105\u001a\u00020\u00192\u0006\u0010!\u001a\u00020\tH\u0007J#\u00106\u001a\u00020\u00102\u0006\u00104\u001a\u00020\u00192\u0006\u00105\u001a\u00020\u00192\b\u0010!\u001a\u0004\u0018\u00010\tH\u0087 J\u0010\u00107\u001a\u00020\u00102\u0006\u0010\u0018\u001a\u00020\u0019H\u0007J\u0011\u00108\u001a\u00020\u00102\u0006\u0010\u0018\u001a\u00020\u0019H\u0087 J\u0011\u00109\u001a\u00020\u00102\u0006\u0010\u0018\u001a\u00020\u0019H\u0087 J\u0011\u0010:\u001a\u00020\u00102\u0006\u0010;\u001a\u00020\tH\u0087 J\u0010\u0010<\u001a\u00020\u00102\u0006\u0010;\u001a\u00020\tH\u0007J\u0018\u0010=\u001a\u00020\u001b2\u0006\u0010>\u001a\u00020\t2\u0006\u0010?\u001a\u00020\u0010H\u0007J\u0019\u0010@\u001a\u00020\u001b2\u0006\u0010>\u001a\u00020\t2\u0006\u0010?\u001a\u00020\u0010H\u0087 J\u0011\u0010A\u001a\u00020\u001b2\u0006\u0010B\u001a\u00020\u0019H\u0087 J\u0016\u0010C\u001a\u00020\u001b2\u0006\u0010D\u001a\u00020E2\u0006\u0010%\u001a\u00020\u0010J)\u0010F\u001a\u00020\u001b2\u0006\u0010D\u001a\u00020E2\u0006\u0010G\u001a\u00020\t2\u0006\u0010H\u001a\u00020\t2\u0006\u0010%\u001a\u00020\u0010H\u0087 J\u0006\u0010I\u001a\u00020\u001bJ\u0006\u0010J\u001a\u00020\u001bR\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00048FX\u0087\u0004\u00a2\u0006\f\u0012\u0004\b\u0005\u0010\u0002\u001a\u0004\b\u0006\u0010\u0007R\u001a\u0010\b\u001a\u00020\t8FX\u0087\u0004\u00a2\u0006\f\u0012\u0004\b\n\u0010\u0002\u001a\u0004\b\u000b\u0010\fR\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000f\u001a\u00020\u00108FX\u0087\u0004\u00a2\u0006\f\u0012\u0004\b\u0011\u0010\u0002\u001a\u0004\b\u000f\u0010\u0012R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006K"}, d2 = {"Lcom/yuyan/inputmethod/core/Rime$Companion;", "", "()V", "composition", "Lcom/yuyan/inputmethod/core/RimeComposition;", "getComposition$annotations", "getComposition", "()Lcom/yuyan/inputmethod/core/RimeComposition;", "compositionText", "", "getCompositionText$annotations", "getCompositionText", "()Ljava/lang/String;", "instance", "Lcom/yuyan/inputmethod/core/Rime;", "isComposing", "", "isComposing$annotations", "()Z", "mContext", "Lcom/yuyan/inputmethod/core/RimeContext;", "mStatus", "Lcom/yuyan/inputmethod/core/RimeStatus;", "chooseAssociate", "index", "", "clearComposition", "", "clearRimeComposition", "destroy", "exitRime", "getAssociateList", "", "key", "(Ljava/lang/String;)[Ljava/lang/String;", "getCurrentRimeSchema", "getInstance", "fullCheck", "getRimeAssociateList", "getRimeCommit", "Lcom/yuyan/inputmethod/core/RimeCommit;", "getRimeContext", "getRimeKeycodeByName", "name", "getRimeStatus", "hasMenu", "hasRight", "processKey", "keycode", "mask", "processRimeKey", "replaceKey", "caretPos", "length", "replaceRimeKey", "selectCandidate", "selectRimeAssociate", "selectRimeCandidate", "selectRimeSchema", "schemaId", "selectSchema", "setOption", "option", "value", "setRimeOption", "setRimePageSize", "pageSize", "startup", "context", "Landroid/content/Context;", "startupRime", "sharedDir", "userDir", "updateContext", "updateStatus", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @kotlin.jvm.JvmStatic()
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.inputmethod.core.Rime getInstance(boolean fullCheck) {
            return null;
        }
        
        public final void startup(@org.jetbrains.annotations.NotNull()
        android.content.Context context, boolean fullCheck) {
        }
        
        @kotlin.jvm.JvmStatic()
        public final void destroy() {
        }
        
        public final void updateStatus() {
        }
        
        public final void updateContext() {
        }
        
        @kotlin.jvm.JvmStatic()
        @java.lang.Deprecated()
        public static void isComposing$annotations() {
        }
        
        public final boolean isComposing() {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean hasMenu() {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean hasRight() {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        @java.lang.Deprecated()
        public static void getComposition$annotations() {
        }
        
        @org.jetbrains.annotations.Nullable()
        public final com.yuyan.inputmethod.core.RimeComposition getComposition() {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        @java.lang.Deprecated()
        public static void getCompositionText$annotations() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getCompositionText() {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean processKey(int keycode, int mask) {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean replaceKey(int caretPos, int length, @org.jetbrains.annotations.NotNull()
        java.lang.String key) {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final void clearComposition() {
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean selectCandidate(int index) {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final void setOption(@org.jetbrains.annotations.NotNull()
        java.lang.String option, boolean value) {
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean selectSchema(@org.jetbrains.annotations.NotNull()
        java.lang.String schemaId) {
            return false;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String[] getAssociateList(@org.jetbrains.annotations.Nullable()
        java.lang.String key) {
            return null;
        }
        
        public final boolean chooseAssociate(int index) {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final void startupRime(@org.jetbrains.annotations.NotNull()
        android.content.Context context, @org.jetbrains.annotations.NotNull()
        java.lang.String sharedDir, @org.jetbrains.annotations.NotNull()
        java.lang.String userDir, boolean fullCheck) {
        }
        
        @kotlin.jvm.JvmStatic()
        public final void exitRime() {
        }
        
        @kotlin.jvm.JvmStatic()
        public final void setRimePageSize(int pageSize) {
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean processRimeKey(int keycode, int mask) {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean replaceRimeKey(int caretPos, int length, @org.jetbrains.annotations.Nullable()
        java.lang.String key) {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final void clearRimeComposition() {
        }
        
        @kotlin.jvm.JvmStatic()
        @org.jetbrains.annotations.Nullable()
        public final com.yuyan.inputmethod.core.RimeCommit getRimeCommit() {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        @org.jetbrains.annotations.Nullable()
        public final com.yuyan.inputmethod.core.RimeContext getRimeContext() {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        @org.jetbrains.annotations.Nullable()
        public final com.yuyan.inputmethod.core.RimeStatus getRimeStatus() {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        public final void setRimeOption(@org.jetbrains.annotations.NotNull()
        java.lang.String option, boolean value) {
        }
        
        @kotlin.jvm.JvmStatic()
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getCurrentRimeSchema() {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean selectRimeSchema(@org.jetbrains.annotations.NotNull()
        java.lang.String schemaId) {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean selectRimeCandidate(int index) {
            return false;
        }
        
        @kotlin.jvm.JvmStatic()
        public final int getRimeKeycodeByName(@org.jetbrains.annotations.NotNull()
        java.lang.String name) {
            return 0;
        }
        
        @kotlin.jvm.JvmStatic()
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String[] getRimeAssociateList(@org.jetbrains.annotations.Nullable()
        java.lang.String key) {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        public final boolean selectRimeAssociate(int index) {
            return false;
        }
    }
}
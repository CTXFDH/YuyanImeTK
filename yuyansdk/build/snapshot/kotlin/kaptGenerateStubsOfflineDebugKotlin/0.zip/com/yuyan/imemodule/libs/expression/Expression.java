package com.yuyan.imemodule.libs.expression;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0006\n\u0002\b\u0003\b\u0007\u0018\u0000 \f2\u00020\u0001:\u0001\fB\u0015\b\u0000\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0002\u0010\u0005J\u0006\u0010\u000b\u001a\u00020\nR\u0016\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u0006R\u001a\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\n0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/Expression;", "", "tokens", "", "Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "([Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;)V", "[Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "variables", "", "", "", "evaluate", "Companion", "yuyansdk_offlineDebug"})
public final class Expression {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.libs.expression.tokenizer.Token[] tokens = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.Map<java.lang.String, java.lang.Double> variables = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.expression.Expression.Companion Companion = null;
    
    public Expression(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.expression.tokenizer.Token[] tokens) {
        super();
    }
    
    public final double evaluate() {
        return 0.0;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0006\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0014\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004H\u0002\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/Expression$Companion;", "", "()V", "createDefaultVariables", "", "", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        private final java.util.Map<java.lang.String, java.lang.Double> createDefaultVariables() {
            return null;
        }
    }
}
package com.yuyan.imemodule.libs.expression.tokenizer;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u0010\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/FunctionToken;", "Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "function", "Lcom/yuyan/imemodule/libs/expression/function/Function;", "(Lcom/yuyan/imemodule/libs/expression/function/Function;)V", "yuyansdk_offlineDebug"})
public final class FunctionToken extends com.yuyan.imemodule.libs.expression.tokenizer.Token {
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.expression.function.Function function = null;
    
    public FunctionToken(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.expression.function.Function function) {
        super(0);
    }
}
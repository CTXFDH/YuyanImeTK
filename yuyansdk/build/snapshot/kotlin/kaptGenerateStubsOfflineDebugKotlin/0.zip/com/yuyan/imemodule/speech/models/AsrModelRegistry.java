package com.yuyan.imemodule.speech.models;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u000b\u001a\u0004\u0018\u00010\u00042\u0006\u0010\f\u001a\u00020\rJ\u000e\u0010\u000e\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\rR\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00040\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n\u00a8\u0006\u000f"}, d2 = {"Lcom/yuyan/imemodule/speech/models/AsrModelRegistry;", "", "()V", "default", "Lcom/yuyan/imemodule/speech/models/AsrModelProfile;", "getDefault", "()Lcom/yuyan/imemodule/speech/models/AsrModelProfile;", "profiles", "", "getProfiles", "()Ljava/util/List;", "findById", "id", "", "profileOrDefault", "yuyansdk_offlineDebug"})
public final class AsrModelRegistry {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.List<com.yuyan.imemodule.speech.models.AsrModelProfile> profiles = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.speech.models.AsrModelRegistry INSTANCE = null;
    
    private AsrModelRegistry() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.speech.models.AsrModelProfile> getProfiles() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.speech.models.AsrModelProfile getDefault() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.speech.models.AsrModelProfile findById(@org.jetbrains.annotations.NotNull()
    java.lang.String id) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.speech.models.AsrModelProfile profileOrDefault(@org.jetbrains.annotations.NotNull()
    java.lang.String id) {
        return null;
    }
}
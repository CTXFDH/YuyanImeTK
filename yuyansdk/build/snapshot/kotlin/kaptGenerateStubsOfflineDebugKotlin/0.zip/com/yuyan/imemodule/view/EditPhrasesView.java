package com.yuyan.imemodule.view;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\u000b\u001a\u00020\fJ\u0006\u0010\r\u001a\u00020\fJ\u000e\u0010\u000e\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\u0010J\u0006\u0010\u0011\u001a\u00020\fJ\u000e\u0010\u0012\u001a\u00020\f2\u0006\u0010\u0013\u001a\u00020\u0014J\u000e\u0010\u0015\u001a\u00020\f2\u0006\u0010\u0016\u001a\u00020\u0017J\u000e\u0010\u0018\u001a\u00020\f2\u0006\u0010\u0019\u001a\u00020\u001aR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001b"}, d2 = {"Lcom/yuyan/imemodule/view/EditPhrasesView;", "Landroid/widget/LinearLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "mEtPhrases", "Lcom/yuyan/imemodule/view/widget/ImeEditText;", "mEtPhrasesQuickCode", "Lcom/yuyan/imemodule/view/widget/KeyCaptureEditText;", "mEtPhrasesTips", "Landroid/widget/TextView;", "addPhrasesHandle", "", "clearPhrasesContent", "commitText", "text", "", "handleAddPhrasesView", "sendKeyEvent", "keyCode", "", "setExtraData", "extra", "Lcom/yuyan/imemodule/database/entry/QuickPhrase;", "updateTheme", "theme", "Lcom/yuyan/imemodule/data/theme/Theme;", "yuyansdk_offlineDebug"})
public final class EditPhrasesView extends android.widget.LinearLayout {
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.view.widget.ImeEditText mEtPhrases;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.view.widget.KeyCaptureEditText mEtPhrasesQuickCode;
    @org.jetbrains.annotations.NotNull()
    private android.widget.TextView mEtPhrasesTips;
    
    public EditPhrasesView(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null);
    }
    
    public final void handleAddPhrasesView() {
    }
    
    public final void clearPhrasesContent() {
    }
    
    public final void addPhrasesHandle() {
    }
    
    public final void setExtraData(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.database.entry.QuickPhrase extra) {
    }
    
    public final void commitText(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
    }
    
    public final void sendKeyEvent(int keyCode) {
    }
    
    public final void updateTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
}
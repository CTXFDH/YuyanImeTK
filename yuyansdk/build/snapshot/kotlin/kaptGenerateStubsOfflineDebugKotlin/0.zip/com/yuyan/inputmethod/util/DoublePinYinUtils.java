package com.yuyan.inputmethod.util;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\f\n\u0002\b\u000f\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u001e\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u00052\u0006\u0010\u0014\u001a\u00020\u0005R)\u0010\u0003\u001a\u001a\u0012\u0004\u0012\u00020\u0005\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00050\u00040\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u001d\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\bR\u001d\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\bR\u001d\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\bR\u001d\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\b\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/inputmethod/util/DoublePinYinUtils;", "", "()V", "doublePinyinMap", "", "", "", "getDoublePinyinMap", "()Ljava/util/Map;", "double_pinyin", "getDouble_pinyin", "double_pinyin_abc", "getDouble_pinyin_abc", "double_pinyin_ls17", "getDouble_pinyin_ls17", "double_pinyin_ziguang", "getDouble_pinyin_ziguang", "getDoublePinYinComposition", "rimeSchema", "composition", "comment", "yuyansdk_offlineDebug"})
public final class DoublePinYinUtils {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Character, java.lang.String> double_pinyin_abc = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Character, java.lang.String> double_pinyin_ziguang = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Character, java.lang.String> double_pinyin_ls17 = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Character, java.lang.String> double_pinyin = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.String, java.util.Map<java.lang.Character, java.lang.String>> doublePinyinMap = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.util.DoublePinYinUtils INSTANCE = null;
    
    private DoublePinYinUtils() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.Character, java.lang.String> getDouble_pinyin_abc() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.Character, java.lang.String> getDouble_pinyin_ziguang() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.Character, java.lang.String> getDouble_pinyin_ls17() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.Character, java.lang.String> getDouble_pinyin() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.String, java.util.Map<java.lang.Character, java.lang.String>> getDoublePinyinMap() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getDoublePinYinComposition(@org.jetbrains.annotations.NotNull()
    java.lang.String rimeSchema, @org.jetbrains.annotations.NotNull()
    java.lang.String composition, @org.jetbrains.annotations.NotNull()
    java.lang.String comment) {
        return null;
    }
}
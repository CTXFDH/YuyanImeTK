package com.yuyan.imemodule.database.dao;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\b\u0004\bg\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u0018\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\'J\u000e\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00020\nH\'J\u000e\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00020\nH\'J\u000e\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00020\nH\'J\u0010\u0010\r\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u0006H\'\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/database/dao/UsedSymbolDao;", "Lcom/yuyan/imemodule/database/BaseDao;", "Lcom/yuyan/imemodule/database/entry/UsedSymbol;", "deleteOldest", "", "type", "", "overflow", "", "getAllEmoticon", "", "getAllSymbolEmoji", "getAllUsedSymbol", "getCount", "yuyansdk_offlineDebug"})
@androidx.room.Dao()
public abstract interface UsedSymbolDao extends com.yuyan.imemodule.database.BaseDao<com.yuyan.imemodule.database.entry.UsedSymbol> {
    
    @androidx.room.Query(value = "select * from usedSymbol where type = \'symbol\' ORDER BY time DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.UsedSymbol> getAllUsedSymbol();
    
    @androidx.room.Query(value = "select * from usedSymbol where type = \'emoji\' ORDER BY time DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.UsedSymbol> getAllSymbolEmoji();
    
    @androidx.room.Query(value = "select * from usedSymbol where type = \'emoticon\' ORDER BY time DESC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.UsedSymbol> getAllEmoticon();
    
    @androidx.room.Query(value = "SELECT COUNT(*) FROM usedSymbol where type = :type")
    public abstract int getCount(@org.jetbrains.annotations.NotNull()
    java.lang.String type);
    
    @androidx.room.Query(value = "DELETE FROM usedSymbol WHERE symbol IN ( SELECT symbol FROM usedSymbol WHERE type = :type ORDER BY time ASC LIMIT :overflow)")
    public abstract void deleteOldest(@org.jetbrains.annotations.NotNull()
    java.lang.String type, int overflow);
}
package com.yuyan.imemodule.libs.cropper.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u001a\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\u001a\u0018\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\u0000\u001a\f\u0010\u0006\u001a\u00020\u0007*\u00020\u0003H\u0000\u00a8\u0006\b"}, d2 = {"getUriForFile", "Landroid/net/Uri;", "context", "Landroid/content/Context;", "file", "Ljava/io/File;", "authority", "", "yuyansdk_offlineDebug"})
public final class GetUriForFileKt {
    
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String authority(@org.jetbrains.annotations.NotNull()
    android.content.Context $this$authority) {
        return null;
    }
    
    /**
     * This class exist because of two issues. One is related to the new Scope Storage for OS 10+
     * Where we should not access external storage anymore. Because of this we cannot get an external uri
     *
     * Using FileProvider to retrieve the path can return a value that is not the real one for some devices
     * This happens in specific devices and OSs. Because of this is needed to do a lot of if/else and
     * try/catch to just use the latest cases when needed.
     *
     * This code is not good, but work. I don't suggest anyone to reproduce it.
     *
     * Most of the devices will work fine, but if you worry about memory usage, please remember to clean
     * the cache from time to time,
     */
    @org.jetbrains.annotations.NotNull()
    public static final android.net.Uri getUriForFile(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    java.io.File file) {
        return null;
    }
}
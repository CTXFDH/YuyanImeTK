package com.yuyan.imemodule.keyboard.container;

/**
 * 软键盘View集装箱
 * 所有软键盘（输入、符号、设置等）父容器View。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0017\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u001b\u001a\u00020\b2\u0006\u0010\u001c\u001a\u00020\bH\u0014J\u0018\u0010\u001d\u001a\u00020\r2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!H\u0002J\u0012\u0010\"\u001a\u00020\r2\b\u0010 \u001a\u0004\u0018\u00010!H\u0002J\b\u0010#\u001a\u00020\u001aH\u0007J\b\u0010$\u001a\u00020\u001aH\u0016R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0004\u001a\u00020\u00058\u0004@\u0004X\u0085\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\f\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\u000e\"\u0004\b\u000f\u0010\u0010R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082.\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0002\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0014X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006%"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "Landroidx/constraintlayout/widget/ConstraintLayout;", "mContext", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "bottomPaddingValue", "", "initialTouchX", "", "initialTouchY", "isHandling", "", "()Z", "setHandling", "(Z)V", "lastY", "", "mBottomPaddingKey", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "mRightPaddingKey", "mSkbRootHeight", "mSkbRootWidth", "rightPaddingValue", "onMeasure", "", "widthMeasureSpec", "heightMeasureSpec", "onModifyKeyboardHeightEvent", "v12", "Landroid/view/View;", "event", "Landroid/view/MotionEvent;", "onMoveKeyboardEvent", "setKeyboardHeight", "updateSkbLayout", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public class BaseContainer extends androidx.constraintlayout.widget.ConstraintLayout {
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public android.content.Context mContext;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    protected com.yuyan.imemodule.keyboard.InputView inputView;
    private com.yuyan.imemodule.view.preference.ManagedPreference.PInt mRightPaddingKey;
    private com.yuyan.imemodule.view.preference.ManagedPreference.PInt mBottomPaddingKey;
    @org.jetbrains.annotations.NotNull()
    private final float[] lastY = {0.0F};
    private boolean isHandling = false;
    private float initialTouchX = 0.0F;
    private float initialTouchY = 0.0F;
    private int rightPaddingValue = 0;
    private int bottomPaddingValue = 0;
    private int mSkbRootHeight = 0;
    private int mSkbRootWidth = 0;
    
    public BaseContainer(@org.jetbrains.annotations.NotNull()
    android.content.Context mContext, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null);
    }
    
    /**
     * 更新软键盘布局
     */
    public void updateSkbLayout() {
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    /**
     * 设置键盘高度
     */
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public final void setKeyboardHeight() {
    }
    
    public final boolean isHandling() {
        return false;
    }
    
    public final void setHandling(boolean p0) {
    }
    
    private final boolean onModifyKeyboardHeightEvent(android.view.View v12, android.view.MotionEvent event) {
        return false;
    }
    
    private final boolean onMoveKeyboardEvent(android.view.MotionEvent event) {
        return false;
    }
}
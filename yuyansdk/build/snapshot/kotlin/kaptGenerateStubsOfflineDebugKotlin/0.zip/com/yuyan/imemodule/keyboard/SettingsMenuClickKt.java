package com.yuyan.imemodule.keyboard;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0016\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005\u00a8\u0006\u0006"}, d2 = {"onSettingsMenuClick", "", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "skbMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "yuyansdk_offlineDebug"})
public final class SettingsMenuClickKt {
    
    public static final void onSettingsMenuClick(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode) {
    }
}
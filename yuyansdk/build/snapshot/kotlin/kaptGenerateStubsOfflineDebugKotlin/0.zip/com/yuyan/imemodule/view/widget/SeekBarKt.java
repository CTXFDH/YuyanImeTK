package com.yuyan.imemodule.view.widget;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\"\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u001a8\u0010\u0000\u001a\u00020\u0001*\u00020\u00022,\u0010\u0003\u001a(\u0012\u0004\u0012\u00020\u0002\u0012\u0013\u0012\u00110\u0005\u00a2\u0006\f\b\u0006\u0012\b\b\u0007\u0012\u0004\b\b(\b\u0012\u0004\u0012\u00020\u00010\u0004\u00a2\u0006\u0002\b\t\u00a8\u0006\n"}, d2 = {"setOnChangeListener", "", "Landroid/widget/SeekBar;", "listener", "Lkotlin/Function2;", "", "Lkotlin/ParameterName;", "name", "progress", "Lkotlin/ExtensionFunctionType;", "yuyansdk_offlineDebug"})
public final class SeekBarKt {
    
    public static final void setOnChangeListener(@org.jetbrains.annotations.NotNull()
    android.widget.SeekBar $this$setOnChangeListener, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function2<? super android.widget.SeekBar, ? super java.lang.Integer, kotlin.Unit> listener) {
    }
}
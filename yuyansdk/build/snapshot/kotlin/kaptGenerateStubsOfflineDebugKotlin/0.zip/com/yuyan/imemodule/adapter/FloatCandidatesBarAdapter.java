package com.yuyan.imemodule.adapter;

/**
 * 候选词界面适配器
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001!B\u000f\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\u0002\u0010\u0005J\u0018\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00022\u0006\u0010\u0013\u001a\u00020\u0007H\u0002J\b\u0010\u0014\u001a\u00020\u0007H\u0016J\u0006\u0010\u0015\u001a\u00020\u0011J\u0018\u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00022\u0006\u0010\u0013\u001a\u00020\u0007H\u0016J\u0018\u0010\u0017\u001a\u00020\u00022\u0006\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0007H\u0016J\u0010\u0010\u001b\u001a\u00020\u00112\b\u0010\u001c\u001a\u0004\u0018\u00010\u000fJ\u0016\u0010\u001d\u001a\u00020\u00112\u0006\u0010\u000b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\u001e\u001a\u00020\u00112\u0006\u0010\u001f\u001a\u00020 R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\u00020\u00078BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\t\u0010\nR\u000e\u0010\u000b\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\""}, d2 = {"Lcom/yuyan/imemodule/adapter/FloatCandidatesBarAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/adapter/FloatCandidatesBarAdapter$SymbolHolder;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "activeCandidatePosition", "", "displayedActivePosition", "getDisplayedActivePosition", "()I", "firstVisiblePosition", "inflater", "Landroid/view/LayoutInflater;", "mOnItemClickListener", "Lcom/yuyan/imemodule/callback/OnRecyclerItemClickListener;", "bindCandidateAppearance", "", "holder", "position", "getItemCount", "notifyChanged", "onBindViewHolder", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setOnItemClickLitener", "mOnItemClickLitener", "updateCandidateState", "updateVisibleIndices", "recyclerView", "Landroidx/recyclerview/widget/RecyclerView;", "SymbolHolder", "yuyansdk_offlineDebug"})
public final class FloatCandidatesBarAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.adapter.FloatCandidatesBarAdapter.SymbolHolder> {
    @org.jetbrains.annotations.NotNull()
    private final android.view.LayoutInflater inflater = null;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.callback.OnRecyclerItemClickListener mOnItemClickListener;
    private int activeCandidatePosition = androidx.recyclerview.widget.RecyclerView.NO_POSITION;
    private int firstVisiblePosition = 0;
    
    public FloatCandidatesBarAdapter(@org.jetbrains.annotations.Nullable()
    android.content.Context context) {
        super();
    }
    
    public final void setOnItemClickLitener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.callback.OnRecyclerItemClickListener mOnItemClickLitener) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.adapter.FloatCandidatesBarAdapter.SymbolHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.adapter.FloatCandidatesBarAdapter.SymbolHolder holder, int position) {
    }
    
    public final void updateVisibleIndices(@org.jetbrains.annotations.NotNull()
    androidx.recyclerview.widget.RecyclerView recyclerView) {
    }
    
    private final void bindCandidateAppearance(com.yuyan.imemodule.adapter.FloatCandidatesBarAdapter.SymbolHolder holder, int position) {
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    public final void updateCandidateState(int firstVisiblePosition, int activeCandidatePosition) {
    }
    
    private final int getDisplayedActivePosition() {
        return 0;
    }
    
    public final void notifyChanged() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/adapter/FloatCandidatesBarAdapter$SymbolHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "(Landroid/view/View;)V", "textViewCandidate", "Landroidx/emoji2/widget/EmojiTextView;", "getTextViewCandidate", "()Landroidx/emoji2/widget/EmojiTextView;", "setTextViewCandidate", "(Landroidx/emoji2/widget/EmojiTextView;)V", "textViewIndex", "Landroid/widget/TextView;", "getTextViewIndex", "()Landroid/widget/TextView;", "setTextViewIndex", "(Landroid/widget/TextView;)V", "yuyansdk_offlineDebug"})
    public static final class SymbolHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.NotNull()
        private android.widget.TextView textViewIndex;
        @org.jetbrains.annotations.NotNull()
        private androidx.emoji2.widget.EmojiTextView textViewCandidate;
        
        public SymbolHolder(@org.jetbrains.annotations.NotNull()
        android.view.View view) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.TextView getTextViewIndex() {
            return null;
        }
        
        public final void setTextViewIndex(@org.jetbrains.annotations.NotNull()
        android.widget.TextView p0) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final androidx.emoji2.widget.EmojiTextView getTextViewCandidate() {
            return null;
        }
        
        public final void setTextViewCandidate(@org.jetbrains.annotations.NotNull()
        androidx.emoji2.widget.EmojiTextView p0) {
        }
    }
}
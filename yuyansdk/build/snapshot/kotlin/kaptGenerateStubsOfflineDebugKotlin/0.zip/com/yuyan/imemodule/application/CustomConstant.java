package com.yuyan.imemodule.application;

/**
 * 用户自定义常量类
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0006\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000bR\u000e\u0010\f\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\t\"\u0004\b\u0010\u0010\u000bR\u000e\u0010\u0011\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0019\u001a\u00020\u001aX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR$\u0010!\u001a\u00020 2\u0006\u0010\u001f\u001a\u00020 8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\"\u0010#\"\u0004\b$\u0010%\u00a8\u0006&"}, d2 = {"Lcom/yuyan/imemodule/application/CustomConstant;", "", "()V", "CURRENT_RIME_DICT_DATA_VERSIOM", "", "FEEDBACK_TXC_REPO", "", "HW_DICT_PATH", "getHW_DICT_PATH", "()Ljava/lang/String;", "setHW_DICT_PATH", "(Ljava/lang/String;)V", "LICENSE_URL", "ORIGINAL_YUYAN_REPO", "RIME_DICT_PATH", "getRIME_DICT_PATH", "setRIME_DICT_PATH", "SCHEMA_EN", "SCHEMA_ZH_DOUBLE_FLYPY", "SCHEMA_ZH_DOUBLE_LX17", "SCHEMA_ZH_HANDWRITING", "SCHEMA_ZH_QWERTY", "SCHEMA_ZH_STROKE", "SCHEMA_ZH_T9", "YUYAN_IME_REPO", "flowerTypeface", "Lcom/yuyan/imemodule/data/flower/FlowerTypefaceMode;", "getFlowerTypeface", "()Lcom/yuyan/imemodule/data/flower/FlowerTypefaceMode;", "setFlowerTypeface", "(Lcom/yuyan/imemodule/data/flower/FlowerTypefaceMode;)V", "value", "", "lockClipBoardEnable", "getLockClipBoardEnable", "()Z", "setLockClipBoardEnable", "(Z)V", "yuyansdk_offlineDebug"})
public final class CustomConstant {
    @org.jetbrains.annotations.NotNull()
    private static java.lang.String RIME_DICT_PATH;
    @org.jetbrains.annotations.NotNull()
    private static java.lang.String HW_DICT_PATH;
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String SCHEMA_ZH_T9 = "t9_pinyin";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String SCHEMA_ZH_QWERTY = "pinyin";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String SCHEMA_EN = "english";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String SCHEMA_ZH_HANDWRITING = "handwriting";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String SCHEMA_ZH_DOUBLE_FLYPY = "double_pinyin_";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String SCHEMA_ZH_DOUBLE_LX17 = "double_pinyin_ls17";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String SCHEMA_ZH_STROKE = "stroke";
    public static final int CURRENT_RIME_DICT_DATA_VERSIOM = 20261102;
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String YUYAN_IME_REPO = "https://github.com/kuangru52/YuyanImeK";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String ORIGINAL_YUYAN_REPO = "https://github.com/gurecn/YuyanIme";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String LICENSE_URL = "https://www.gnu.org/licenses/gpl-3.0.html";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String FEEDBACK_TXC_REPO = "https://github.com/kuangru52/YuyanImeK/issues";
    @org.jetbrains.annotations.NotNull()
    private static com.yuyan.imemodule.data.flower.FlowerTypefaceMode flowerTypeface = com.yuyan.imemodule.data.flower.FlowerTypefaceMode.Disabled;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.application.CustomConstant INSTANCE = null;
    
    private CustomConstant() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getRIME_DICT_PATH() {
        return null;
    }
    
    public final void setRIME_DICT_PATH(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getHW_DICT_PATH() {
        return null;
    }
    
    public final void setHW_DICT_PATH(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.flower.FlowerTypefaceMode getFlowerTypeface() {
        return null;
    }
    
    public final void setFlowerTypeface(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.flower.FlowerTypefaceMode p0) {
    }
    
    public final boolean getLockClipBoardEnable() {
        return false;
    }
    
    public final void setLockClipBoardEnable(boolean value) {
    }
}
package com.yuyan.imemodule.adapter;

/**
 * 候选词界面适配器
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u0000 #2\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0002#$B\u000f\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\u0002\u0010\u0005J\u000e\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0010J\b\u0010\u0017\u001a\u00020\u0010H\u0016J\u0010\u0010\u0018\u001a\u00020\u00102\u0006\u0010\u0019\u001a\u00020\u0010H\u0016J\u0006\u0010\u001a\u001a\u00020\u0015J\u001c\u0010\u001b\u001a\u00020\u00152\n\u0010\u001c\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0019\u001a\u00020\u0010H\u0016J\u001c\u0010\u001d\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0010H\u0016J\u0010\u0010!\u001a\u00020\u00152\b\u0010\"\u001a\u0004\u0018\u00010\u0012R$\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u00078F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006%"}, d2 = {"Lcom/yuyan/imemodule/adapter/CandidatesBarAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/adapter/CandidatesBarAdapter$SymbolHolder;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "value", "Lcom/yuyan/imemodule/data/theme/Theme;", "activeTheme", "getActiveTheme", "()Lcom/yuyan/imemodule/data/theme/Theme;", "setActiveTheme", "(Lcom/yuyan/imemodule/data/theme/Theme;)V", "inflater", "Landroid/view/LayoutInflater;", "mActiveCandNo", "", "mOnItemClickListener", "Lcom/yuyan/imemodule/callback/OnRecyclerItemClickListener;", "overrideTheme", "activeCandidates", "", "activeCandNo", "getItemCount", "getItemViewType", "position", "notifyChanged", "onBindViewHolder", "holder", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setOnItemClickLitener", "mOnItemClickLitener", "Companion", "SymbolHolder", "yuyansdk_offlineDebug"})
public final class CandidatesBarAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.adapter.CandidatesBarAdapter.SymbolHolder> {
    @org.jetbrains.annotations.NotNull()
    private final android.view.LayoutInflater inflater = null;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.callback.OnRecyclerItemClickListener mOnItemClickListener;
    private int mActiveCandNo = 0;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.data.theme.Theme overrideTheme;
    private static final int VIEW_TYPE_FIRST = 0;
    private static final int VIEW_TYPE_NORMAL = 1;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.adapter.CandidatesBarAdapter.Companion Companion = null;
    
    public CandidatesBarAdapter(@org.jetbrains.annotations.Nullable()
    android.content.Context context) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme getActiveTheme() {
        return null;
    }
    
    public final void setActiveTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme value) {
    }
    
    public final void setOnItemClickLitener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.callback.OnRecyclerItemClickListener mOnItemClickLitener) {
    }
    
    @java.lang.Override()
    public int getItemViewType(int position) {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.adapter.CandidatesBarAdapter.SymbolHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.adapter.CandidatesBarAdapter.SymbolHolder holder, int position) {
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    public final void activeCandidates(int activeCandNo) {
    }
    
    public final void notifyChanged() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/adapter/CandidatesBarAdapter$Companion;", "", "()V", "VIEW_TYPE_FIRST", "", "VIEW_TYPE_NORMAL", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/adapter/CandidatesBarAdapter$SymbolHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "(Lcom/yuyan/imemodule/adapter/CandidatesBarAdapter;Landroid/view/View;)V", "textView", "Landroidx/emoji2/widget/EmojiTextView;", "getTextView", "()Landroidx/emoji2/widget/EmojiTextView;", "setTextView", "(Landroidx/emoji2/widget/EmojiTextView;)V", "yuyansdk_offlineDebug"})
    public final class SymbolHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.NotNull()
        private androidx.emoji2.widget.EmojiTextView textView;
        
        public SymbolHolder(@org.jetbrains.annotations.NotNull()
        android.view.View view) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final androidx.emoji2.widget.EmojiTextView getTextView() {
            return null;
        }
        
        public final void setTextView(@org.jetbrains.annotations.NotNull()
        androidx.emoji2.widget.EmojiTextView p0) {
        }
    }
}
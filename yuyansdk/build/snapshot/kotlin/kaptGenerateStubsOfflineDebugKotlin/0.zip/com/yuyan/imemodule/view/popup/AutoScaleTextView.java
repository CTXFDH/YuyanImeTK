package com.yuyan.imemodule.view.popup;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\r\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u00018B\u001d\b\u0007\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u001eH\u0002J\b\u0010 \u001a\u00020!H\u0016J\b\u0010\"\u001a\u00020\u0017H\u0016J \u0010#\u001a\u00020\u001e2\u0006\u0010$\u001a\u00020\u001e2\u0006\u0010%\u001a\u00020\u001e2\u0006\u0010&\u001a\u00020\u001eH\u0002J\b\u0010\'\u001a\u00020\u0015H\u0002J\u0010\u0010(\u001a\u00020\u001c2\u0006\u0010)\u001a\u00020*H\u0014J0\u0010+\u001a\u00020\u001c2\u0006\u0010,\u001a\u00020\n2\u0006\u0010-\u001a\u00020\u001e2\u0006\u0010.\u001a\u00020\u001e2\u0006\u0010/\u001a\u00020\u001e2\u0006\u00100\u001a\u00020\u001eH\u0014J\u0018\u00101\u001a\u00020\u001c2\u0006\u00102\u001a\u00020\u001e2\u0006\u00103\u001a\u00020\u001eH\u0014J\u001a\u00104\u001a\u00020\u001c2\b\u00105\u001a\u0004\u0018\u00010!2\u0006\u00106\u001a\u000207H\u0016R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\f\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00069"}, d2 = {"Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "Landroid/widget/TextView;", "context", "Landroid/content/Context;", "attributeSet", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "fontMetrics", "Landroid/graphics/Paint$FontMetrics;", "needsCalculateTransform", "", "needsMeasureText", "scaleMode", "Lcom/yuyan/imemodule/view/popup/AutoScaleTextView$Mode;", "getScaleMode", "()Lcom/yuyan/imemodule/view/popup/AutoScaleTextView$Mode;", "setScaleMode", "(Lcom/yuyan/imemodule/view/popup/AutoScaleTextView$Mode;)V", "text", "", "textBounds", "Landroid/graphics/Rect;", "textScaleX", "", "textScaleY", "translateX", "translateY", "calculateTransform", "", "viewWidth", "", "viewHeight", "getText", "", "getTextScaleX", "measure", "specMode", "specSize", "calculatedSize", "measureTextBounds", "onDraw", "canvas", "Landroid/graphics/Canvas;", "onLayout", "changed", "left", "top", "right", "bottom", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "setText", "charSequence", "bufferType", "Landroid/widget/TextView$BufferType;", "Mode", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"AppCompatCustomView"})
public final class AutoScaleTextView extends android.widget.TextView {
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.view.popup.AutoScaleTextView.Mode scaleMode = com.yuyan.imemodule.view.popup.AutoScaleTextView.Mode.None;
    private java.lang.String text;
    private boolean needsMeasureText = true;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Paint.FontMetrics fontMetrics = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Rect textBounds = null;
    private boolean needsCalculateTransform = true;
    private float translateY = 0.0F;
    private float translateX = 0.0F;
    private float textScaleX = 1.0F;
    private float textScaleY = 1.0F;
    
    @kotlin.jvm.JvmOverloads()
    public AutoScaleTextView(@org.jetbrains.annotations.Nullable()
    android.content.Context context) {
        super(null);
    }
    
    @kotlin.jvm.JvmOverloads()
    public AutoScaleTextView(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attributeSet) {
        super(null);
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.popup.AutoScaleTextView.Mode getScaleMode() {
        return null;
    }
    
    public final void setScaleMode(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.popup.AutoScaleTextView.Mode p0) {
    }
    
    @java.lang.Override()
    public void setText(@org.jetbrains.annotations.Nullable()
    java.lang.CharSequence charSequence, @org.jetbrains.annotations.NotNull()
    android.widget.TextView.BufferType bufferType) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.CharSequence getText() {
        return null;
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    private final int measure(int specMode, int specSize, int calculatedSize) {
        return 0;
    }
    
    private final android.graphics.Rect measureTextBounds() {
        return null;
    }
    
    @java.lang.Override()
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
    }
    
    private final void calculateTransform(int viewWidth, int viewHeight) {
    }
    
    @java.lang.Override()
    protected void onDraw(@org.jetbrains.annotations.NotNull()
    android.graphics.Canvas canvas) {
    }
    
    @java.lang.Override()
    public float getTextScaleX() {
        return 0.0F;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/view/popup/AutoScaleTextView$Mode;", "", "(Ljava/lang/String;I)V", "None", "Horizontal", "Proportional", "yuyansdk_offlineDebug"})
    public static enum Mode {
        /*public static final*/ None /* = new None() */,
        /*public static final*/ Horizontal /* = new Horizontal() */,
        /*public static final*/ Proportional /* = new Proportional() */;
        
        Mode() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.view.popup.AutoScaleTextView.Mode> getEntries() {
            return null;
        }
    }
}
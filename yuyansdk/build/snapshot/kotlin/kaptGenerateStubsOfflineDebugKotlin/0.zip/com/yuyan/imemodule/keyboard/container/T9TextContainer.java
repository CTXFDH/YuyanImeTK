package com.yuyan.imemodule.keyboard.container;

/**
 * 九宫格键盘容器
 *
 * 包含输入键盘键盘[TextKeyboard]及拼音选择界面两层。
 *
 * 其中：
 * 输入键盘占据全部空间，左上角由拼音选择栏占位按键[InputModeSwitcher.USER_KEYCODE_LEFT_SYMBOL]站位。
 *
 * 拼音选择栏（无拼音时显示中文符号）位于键盘左上角，拼音选择栏占位按键正上方。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0017\u0018\u00002\u00020\u0001B!\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bJ\b\u0010\u0011\u001a\u00020\u0012H\u0002J\b\u0010\u0013\u001a\u00020\u0012H\u0016J\u0006\u0010\u0014\u001a\u00020\u0012R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/T9TextContainer;", "Lcom/yuyan/imemodule/keyboard/container/InputBaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "skbValue", "", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;I)V", "mLlAddSymbol", "Landroid/widget/LinearLayout;", "mRVLeftPrefix", "Lcom/yuyan/imemodule/libs/recyclerview/SwipeRecyclerView;", "mSideSymbolsPinyin", "", "Lcom/yuyan/imemodule/database/entry/SideSymbol;", "mSkbValue", "updateKeyboardView", "", "updateSkbLayout", "updateSymbolListView", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public class T9TextContainer extends com.yuyan.imemodule.keyboard.container.InputBaseContainer {
    private int mSkbValue = 0;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> mSideSymbolsPinyin = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView mRVLeftPrefix = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.LinearLayout mLlAddSymbol = null;
    
    public T9TextContainer(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView, int skbValue) {
        super(null, null);
    }
    
    /**
     * 更新软键盘布局
     */
    @java.lang.Override()
    public void updateSkbLayout() {
    }
    
    private final void updateKeyboardView() {
    }
    
    public final void updateSymbolListView() {
    }
}
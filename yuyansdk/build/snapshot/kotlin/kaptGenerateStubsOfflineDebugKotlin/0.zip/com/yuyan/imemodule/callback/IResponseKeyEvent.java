package com.yuyan.imemodule.callback;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u001c\u0010\u0006\u001a\u00020\u00032\u0012\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\n0\bH&\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/callback/IResponseKeyEvent;", "", "responseKeyEvent", "", "sKey", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "responseLongKeyEvent", "result", "Lkotlin/Pair;", "Lcom/yuyan/imemodule/prefs/behavior/PopupMenuMode;", "", "yuyansdk_offlineDebug"})
public abstract interface IResponseKeyEvent {
    
    public abstract void responseKeyEvent(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.keyboard.SoftKey sKey);
    
    public abstract void responseLongKeyEvent(@org.jetbrains.annotations.NotNull()
    kotlin.Pair<? extends com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> result);
}
package com.yuyan.imemodule.callback;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\bf\u0018\u00002\u00020\u0001J\u001b\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005H&\u00a2\u0006\u0002\u0010\u0007J\u0010\u0010\b\u001a\u00020\u00032\u0006\u0010\t\u001a\u00020\nH&J\u001c\u0010\u000b\u001a\u00020\u00032\u0012\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\rH&\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/callback/IResponseKeyEvent;", "", "responseHandwritingResultEvent", "", "words", "", "Lcom/yuyan/inputmethod/core/CandidateListItem;", "([Lcom/yuyan/inputmethod/core/CandidateListItem;)V", "responseKeyEvent", "sKey", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "responseLongKeyEvent", "result", "Lkotlin/Pair;", "Lcom/yuyan/imemodule/prefs/behavior/PopupMenuMode;", "", "yuyansdk_offlineDebug"})
public abstract interface IResponseKeyEvent {
    
    public abstract void responseKeyEvent(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.keyboard.SoftKey sKey);
    
    public abstract void responseLongKeyEvent(@org.jetbrains.annotations.NotNull()
    kotlin.Pair<? extends com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> result);
    
    public abstract void responseHandwritingResultEvent(@org.jetbrains.annotations.NotNull()
    com.yuyan.inputmethod.core.CandidateListItem[] words);
}
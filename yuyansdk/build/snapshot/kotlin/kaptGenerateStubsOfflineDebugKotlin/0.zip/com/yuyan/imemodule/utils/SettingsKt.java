package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\u001a\u0012\u0010\u0000\u001a\u00020\u00012\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0003\u001a\u001e\u0010\u0004\u001a\u0002H\u0005\"\u0006\b\u0000\u0010\u0005\u0018\u00012\u0006\u0010\u0006\u001a\u00020\u0007H\u0086\b\u00a2\u0006\u0002\u0010\b\u00a8\u0006\t"}, d2 = {"errInvalidType", "", "cls", "Ljava/lang/Class;", "getGlobalSettings", "T", "name", "", "(Ljava/lang/String;)Ljava/lang/Object;", "yuyansdk_offlineDebug"})
public final class SettingsKt {
    
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.Void errInvalidType(@org.jetbrains.annotations.NotNull()
    java.lang.Class<?> cls) {
        return null;
    }
}
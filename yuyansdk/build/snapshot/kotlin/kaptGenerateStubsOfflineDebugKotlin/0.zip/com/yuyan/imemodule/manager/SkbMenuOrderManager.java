package com.yuyan.imemodule.manager;

/**
 * 键盘菜单顺序管理
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\b0\u0007J\u0006\u0010\u000e\u001a\u00020\u000fJ\u000e\u0010\u0010\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u000e\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\b0\u0007H\u0002J\u0014\u0010\u0012\u001a\u00020\u000f2\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\b0\u0014J\u001e\u0010\u0015\u001a\u00020\u000f2\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\f0\u00142\u0006\u0010\u0017\u001a\u00020\u0004H\u0002J\u0014\u0010\u0018\u001a\u00020\u000f2\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\b0\u0014J\u000e\u0010\u0019\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\u001c\u0010\u001a\u001a\u00020\u000f2\u0012\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\u000f0\u001cH\u0002J\u0016\u0010\u001e\u001a\u00020\u000f2\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\f0\u0014H\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0006\u001a\n\u0012\u0004\u0012\u00020\b\u0018\u00010\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"}, d2 = {"Lcom/yuyan/imemodule/manager/SkbMenuOrderManager;", "", "()V", "BAR_MENU", "", "SETTING_MENU", "barMenuCache", "", "Lcom/yuyan/imemodule/entity/SkbFunItem;", "addBarMenu", "", "skbMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "barMenus", "invalidate", "", "isInBarMenu", "loadBarMenus", "persistBarMenus", "menus", "", "persistOrder", "order", "isKeep", "persistSettingMenus", "removeBarMenu", "write", "block", "Lkotlin/Function1;", "Lcom/yuyan/imemodule/database/dao/SkbFunDao;", "writeBarOrder", "yuyansdk_offlineDebug"})
public final class SkbMenuOrderManager {
    private static final int BAR_MENU = 1;
    private static final int SETTING_MENU = 0;
    @kotlin.jvm.Volatile()
    @org.jetbrains.annotations.Nullable()
    private static volatile java.util.List<com.yuyan.imemodule.entity.SkbFunItem> barMenuCache;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.manager.SkbMenuOrderManager INSTANCE = null;
    
    private SkbMenuOrderManager() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> barMenus() {
        return null;
    }
    
    private final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> loadBarMenus() {
        return null;
    }
    
    public final void invalidate() {
    }
    
    public final boolean isInBarMenu(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode) {
        return false;
    }
    
    public final boolean addBarMenu(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode) {
        return false;
    }
    
    public final boolean removeBarMenu(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode) {
        return false;
    }
    
    public final void persistBarMenus(@org.jetbrains.annotations.NotNull()
    java.util.List<com.yuyan.imemodule.entity.SkbFunItem> menus) {
    }
    
    public final void persistSettingMenus(@org.jetbrains.annotations.NotNull()
    java.util.List<com.yuyan.imemodule.entity.SkbFunItem> menus) {
    }
    
    private final void writeBarOrder(java.util.List<? extends com.yuyan.imemodule.prefs.behavior.SkbMenuMode> order) {
    }
    
    private final void persistOrder(java.util.List<? extends com.yuyan.imemodule.prefs.behavior.SkbMenuMode> order, int isKeep) {
    }
    
    private final void write(kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.database.dao.SkbFunDao, kotlin.Unit> block) {
    }
}
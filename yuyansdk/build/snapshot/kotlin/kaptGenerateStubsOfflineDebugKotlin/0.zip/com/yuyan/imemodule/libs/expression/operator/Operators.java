package com.yuyan.imemodule.libs.expression.operator;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\f\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0018\u0010\u0011\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\bR\u0018\u0010\u0003\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u0004X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u0006R\u000e\u0010\u0007\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/operator/Operators;", "", "()V", "BUILT_IN_OPERATORS", "", "Lcom/yuyan/imemodule/libs/expression/operator/Operator;", "[Lcom/yuyan/imemodule/libs/expression/operator/Operator;", "INDEX_ADDITION", "", "INDEX_DIVISION", "INDEX_EQUAL", "INDEX_MODULO", "INDEX_MULTIPLICATION", "INDEX_POWER", "INDEX_SUBTRACTION", "INDEX_UNARY_MINUS", "INDEX_UNARY_PLUS", "getBuiltinOperator", "symbol", "", "numArguments", "yuyansdk_offlineDebug"})
public final class Operators {
    private static final int INDEX_EQUAL = 0;
    private static final int INDEX_ADDITION = 1;
    private static final int INDEX_SUBTRACTION = 2;
    private static final int INDEX_MULTIPLICATION = 3;
    private static final int INDEX_DIVISION = 4;
    private static final int INDEX_POWER = 5;
    private static final int INDEX_MODULO = 6;
    private static final int INDEX_UNARY_MINUS = 7;
    private static final int INDEX_UNARY_PLUS = 8;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.libs.expression.operator.Operator[] BUILT_IN_OPERATORS = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.expression.operator.Operators INSTANCE = null;
    
    private Operators() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.libs.expression.operator.Operator getBuiltinOperator(char symbol, int numArguments) {
        return null;
    }
}
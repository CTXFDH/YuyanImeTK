package com.yuyan.imemodule.keyboard.container;

/**
 * 表情与符号键盘容器 (顶部仅保留 Emoji 与 颜文字 两大选项卡，去除微信分类)
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\n\b\u0007\u0018\u0000 82\u00020\u0001:\u0003789B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0006\u0010.\u001a\u00020#J\b\u0010/\u001a\u000200H\u0014J\u0010\u00101\u001a\u0002002\u0006\u0010\f\u001a\u00020\u000bH\u0002J\b\u00102\u001a\u00020\rH\u0002J\u0018\u00103\u001a\u0002002\u0006\u00104\u001a\u00020#2\b\b\u0002\u00105\u001a\u00020\u001cJ\u0006\u00106\u001a\u000200R\u000e\u0010\u0007\u001a\u00020\bX\u0082.\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R$\u0010\u000e\u001a\u00020\r2\u0006\u0010\f\u001a\u00020\r8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R$\u0010\u0012\u001a\u00020\r2\u0006\u0010\f\u001a\u00020\r8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\u0012\u0010\u000f\"\u0004\b\u0013\u0010\u0011R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0015X\u0082.\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0019\u001a\b\u0018\u00010\u001aR\u00020\u0000X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001d\u001a\u0004\u0018\u00010\u001eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020 X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020#X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010$\u001a\b\u0018\u00010%R\u00020\u0000X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\'X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010(\u001a\b\u0012\u0004\u0012\u00020\u000b0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020*X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020-X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006:"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/SymbolContainer;", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "bottomControlBar", "Landroid/widget/RelativeLayout;", "emojiCategories", "", "", "value", "", "isLockExpression", "()Z", "setLockExpression", "(Z)V", "isLockSymbol", "setLockSymbol", "ivExprLock", "Landroid/widget/ImageView;", "ivExprSend", "ivSymbolLock", "kaomojiCategories", "mBottomTabAdapter", "Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$BottomTabAdapter;", "mExprSubTab", "", "mHandler", "Landroid/os/Handler;", "mRVBottomCategoryBar", "Landroidx/recyclerview/widget/RecyclerView;", "mRVLeftSideTabs", "mShowType", "Lcom/yuyan/imemodule/prefs/behavior/SymbolMode;", "mSideTabAdapter", "Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$SideTabAdapter;", "mVPSymbolsView", "Landroidx/viewpager2/widget/ViewPager2;", "symbolCategoryNames", "tabEmoji", "Landroid/widget/TextView;", "tabKaomoji", "topExprHeader", "Landroid/widget/LinearLayout;", "getMenuMode", "onAttachedToWindow", "", "onItemClickOperate", "repeatKey", "setEmojisView", "showType", "subTab", "setSymbolsView", "BottomTabAdapter", "Companion", "SideTabAdapter", "yuyansdk_offlineDebug"})
@kotlin.Suppress(names = {"DEPRECATION", "SetTextI18n", "RedundantSuppression", "UnusedImport", "MemberVisibilityCanBePrivate", "UnnecessaryVariable"})
@android.annotation.SuppressLint(value = {"ViewConstructor", "ClickableViewAccessibility"})
public final class SymbolContainer extends com.yuyan.imemodule.keyboard.container.BaseContainer {
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.prefs.behavior.SymbolMode mShowType = com.yuyan.imemodule.prefs.behavior.SymbolMode.Symbol;
    private int mExprSubTab = 0;
    @org.jetbrains.annotations.NotNull()
    private androidx.viewpager2.widget.ViewPager2 mVPSymbolsView;
    @org.jetbrains.annotations.NotNull()
    private androidx.recyclerview.widget.RecyclerView mRVLeftSideTabs;
    @org.jetbrains.annotations.NotNull()
    private androidx.recyclerview.widget.RecyclerView mRVBottomCategoryBar;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.keyboard.container.SymbolContainer.SideTabAdapter mSideTabAdapter;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.keyboard.container.SymbolContainer.BottomTabAdapter mBottomTabAdapter;
    @org.jetbrains.annotations.NotNull()
    private android.widget.LinearLayout topExprHeader;
    @org.jetbrains.annotations.NotNull()
    private android.widget.TextView tabEmoji;
    @org.jetbrains.annotations.NotNull()
    private android.widget.TextView tabKaomoji;
    private android.widget.ImageView ivExprLock;
    private android.widget.ImageView ivExprSend;
    private android.widget.ImageView ivSymbolLock;
    private android.widget.RelativeLayout bottomControlBar;
    @org.jetbrains.annotations.Nullable()
    private android.os.Handler mHandler;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<java.lang.String> symbolCategoryNames = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<java.lang.String> emojiCategories = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<java.lang.String> kaomojiCategories = null;
    private static final int MSG_REPEAT = 3;
    private static final long REPEAT_INTERVAL = 50L;
    private static final long REPEAT_START_DELAY = 400L;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.keyboard.container.SymbolContainer.Companion Companion = null;
    
    public SymbolContainer(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    public final boolean isLockSymbol() {
        return false;
    }
    
    public final void setLockSymbol(boolean value) {
    }
    
    public final boolean isLockExpression() {
        return false;
    }
    
    public final void setLockExpression(boolean value) {
    }
    
    @java.lang.Override()
    protected void onAttachedToWindow() {
    }
    
    private final boolean repeatKey() {
        return false;
    }
    
    private final void onItemClickOperate(java.lang.String value) {
    }
    
    /**
     * 切换显示界面 (符号模式)
     */
    public final void setSymbolsView() {
    }
    
    /**
     * 切换显示界面 (表情/颜文字模式)
     */
    public final void setEmojisView(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SymbolMode showType, int subTab) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.behavior.SymbolMode getMenuMode() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0016B\'\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0012\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\n0\b\u00a2\u0006\u0002\u0010\u000bJ\b\u0010\r\u001a\u00020\tH\u0016J \u0010\u000e\u001a\u00020\n2\u000e\u0010\u000f\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0010\u001a\u00020\tH\u0016J \u0010\u0011\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\tH\u0016J\u000e\u0010\u0015\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\tR\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\n0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0017"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$BottomTabAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$BottomTabAdapter$ViewHolder;", "Lcom/yuyan/imemodule/keyboard/container/SymbolContainer;", "categories", "", "", "onTabClick", "Lkotlin/Function1;", "", "", "(Lcom/yuyan/imemodule/keyboard/container/SymbolContainer;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "selectedIndex", "getItemCount", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setSelected", "ViewHolder", "yuyansdk_offlineDebug"})
    public final class BottomTabAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.keyboard.container.SymbolContainer.BottomTabAdapter.ViewHolder> {
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<java.lang.String> categories = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.jvm.functions.Function1<java.lang.Integer, kotlin.Unit> onTabClick = null;
        private int selectedIndex = 0;
        
        public BottomTabAdapter(@org.jetbrains.annotations.NotNull()
        java.util.List<java.lang.String> categories, @org.jetbrains.annotations.NotNull()
        kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onTabClick) {
            super();
        }
        
        public final void setSelected(int position) {
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.keyboard.container.SymbolContainer.BottomTabAdapter.ViewHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
        android.view.ViewGroup parent, int viewType) {
            return null;
        }
        
        @java.lang.Override()
        public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.keyboard.container.SymbolContainer.BottomTabAdapter.ViewHolder holder, int position) {
        }
        
        @java.lang.Override()
        public int getItemCount() {
            return 0;
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$BottomTabAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "text", "Landroid/widget/TextView;", "(Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$BottomTabAdapter;Landroid/view/View;Landroid/widget/TextView;)V", "getText", "()Landroid/widget/TextView;", "yuyansdk_offlineDebug"})
        public final class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            @org.jetbrains.annotations.NotNull()
            private final android.widget.TextView text = null;
            
            public ViewHolder(@org.jetbrains.annotations.NotNull()
            android.view.View view, @org.jetbrains.annotations.NotNull()
            android.widget.TextView text) {
                super(null);
            }
            
            @org.jetbrains.annotations.NotNull()
            public final android.widget.TextView getText() {
                return null;
            }
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$Companion;", "", "()V", "MSG_REPEAT", "", "REPEAT_INTERVAL", "", "REPEAT_START_DELAY", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0004\u0018\u00002\u0010\u0012\f\u0012\n0\u0002R\u00060\u0000R\u00020\u00030\u0001:\u0001\u0015B\'\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0012\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\t0\b\u00a2\u0006\u0002\u0010\nJ\b\u0010\f\u001a\u00020\u0006H\u0016J \u0010\r\u001a\u00020\t2\u000e\u0010\u000e\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u0006H\u0016J \u0010\u0010\u001a\n0\u0002R\u00060\u0000R\u00020\u00032\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0006H\u0016J\u000e\u0010\u0014\u001a\u00020\t2\u0006\u0010\u000f\u001a\u00020\u0006R\u001a\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$SideTabAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$SideTabAdapter$ViewHolder;", "Lcom/yuyan/imemodule/keyboard/container/SymbolContainer;", "tabIcons", "", "", "onTabClick", "Lkotlin/Function1;", "", "(Lcom/yuyan/imemodule/keyboard/container/SymbolContainer;Ljava/util/List;Lkotlin/jvm/functions/Function1;)V", "selectedIndex", "getItemCount", "onBindViewHolder", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setSelected", "ViewHolder", "yuyansdk_offlineDebug"})
    public final class SideTabAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.keyboard.container.SymbolContainer.SideTabAdapter.ViewHolder> {
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<java.lang.Integer> tabIcons = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.jvm.functions.Function1<java.lang.Integer, kotlin.Unit> onTabClick = null;
        private int selectedIndex = 0;
        
        public SideTabAdapter(@org.jetbrains.annotations.NotNull()
        java.util.List<java.lang.Integer> tabIcons, @org.jetbrains.annotations.NotNull()
        kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onTabClick) {
            super();
        }
        
        public final void setSelected(int position) {
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.keyboard.container.SymbolContainer.SideTabAdapter.ViewHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
        android.view.ViewGroup parent, int viewType) {
            return null;
        }
        
        @java.lang.Override()
        public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.keyboard.container.SymbolContainer.SideTabAdapter.ViewHolder holder, int position) {
        }
        
        @java.lang.Override()
        public int getItemCount() {
            return 0;
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$SideTabAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "tv", "Landroid/widget/TextView;", "(Lcom/yuyan/imemodule/keyboard/container/SymbolContainer$SideTabAdapter;Landroid/view/View;Landroid/widget/TextView;)V", "getTv", "()Landroid/widget/TextView;", "yuyansdk_offlineDebug"})
        public final class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            @org.jetbrains.annotations.NotNull()
            private final android.widget.TextView tv = null;
            
            public ViewHolder(@org.jetbrains.annotations.NotNull()
            android.view.View view, @org.jetbrains.annotations.NotNull()
            android.widget.TextView tv) {
                super(null);
            }
            
            @org.jetbrains.annotations.NotNull()
            public final android.widget.TextView getTv() {
                return null;
            }
        }
    }
}
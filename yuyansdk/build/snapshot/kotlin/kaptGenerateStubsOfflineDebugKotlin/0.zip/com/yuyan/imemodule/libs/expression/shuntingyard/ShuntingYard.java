package com.yuyan.imemodule.libs.expression.shuntingyard;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002JW\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010\u0006\u001a\u00020\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n0\t2\u0012\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\f0\t2\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00070\u000e2\u0006\u0010\u000f\u001a\u00020\u0010\u00a2\u0006\u0002\u0010\u0011\u00a8\u0006\u0012"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/shuntingyard/ShuntingYard;", "", "()V", "convertToRPN", "", "Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "expression", "", "userFunctions", "", "Lcom/yuyan/imemodule/libs/expression/function/Function;", "userOperators", "Lcom/yuyan/imemodule/libs/expression/operator/Operator;", "variableNames", "", "implicitMultiplication", "", "(Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;Ljava/util/Set;Z)[Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "yuyansdk_offlineDebug"})
public final class ShuntingYard {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.expression.shuntingyard.ShuntingYard INSTANCE = null;
    
    private ShuntingYard() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.expression.tokenizer.Token[] convertToRPN(@org.jetbrains.annotations.NotNull()
    java.lang.String expression, @org.jetbrains.annotations.NotNull()
    java.util.Map<java.lang.String, ? extends com.yuyan.imemodule.libs.expression.function.Function> userFunctions, @org.jetbrains.annotations.NotNull()
    java.util.Map<java.lang.String, ? extends com.yuyan.imemodule.libs.expression.operator.Operator> userOperators, @org.jetbrains.annotations.NotNull()
    java.util.Set<java.lang.String> variableNames, boolean implicitMultiplication) {
        return null;
    }
}
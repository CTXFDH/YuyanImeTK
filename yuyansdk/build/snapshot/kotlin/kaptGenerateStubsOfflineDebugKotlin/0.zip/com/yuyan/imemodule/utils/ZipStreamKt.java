package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0018\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0002\u00a8\u0006\u0005"}, d2 = {"extract", "", "Ljava/io/File;", "Ljava/util/zip/ZipInputStream;", "destDir", "yuyansdk_offlineDebug"})
public final class ZipStreamKt {
    
    /**
     * @return top-level files in zip file
     */
    @org.jetbrains.annotations.NotNull()
    public static final java.util.List<java.io.File> extract(@org.jetbrains.annotations.NotNull()
    java.util.zip.ZipInputStream $this$extract, @org.jetbrains.annotations.NotNull()
    java.io.File destDir) {
        return null;
    }
}
package com.yuyan.imemodule.libs.cropper;

/**
 * Providing a custom {@code FileProvider} prevents manifest {@code <provider>} name collisions.
 *
 * See https://developer.android.com/guide/topics/manifest/provider-element.html for details.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropFileProvider;", "Landroidx/core/content/FileProvider;", "()V", "yuyansdk_offlineDebug"})
public final class CropFileProvider extends androidx.core.content.FileProvider {
    
    public CropFileProvider() {
        super();
    }
}
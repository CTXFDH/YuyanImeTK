package com.yuyan.imemodule.entity.handwriting;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0007J\u0006\u0010\u0012\u001a\u00020\u0013J.\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\u0013R\u001a\u0010\u0004\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000bR\u001a\u0010\u0005\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\t\"\u0004\b\r\u0010\u000bR\u001a\u0010\u0006\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\t\"\u0004\b\u000f\u0010\u000bR\u001a\u0010\u0002\u001a\u00020\u0003X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\t\"\u0004\b\u0011\u0010\u000b\u00a8\u0006\u001b"}, d2 = {"Lcom/yuyan/imemodule/entity/handwriting/Bezier;", "", "startPoint", "Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;", "control1", "control2", "endPoint", "(Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;)V", "getControl1", "()Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;", "setControl1", "(Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;)V", "getControl2", "setControl2", "getEndPoint", "setEndPoint", "getStartPoint", "setStartPoint", "length", "", "point", "", "t", "start", "c1", "c2", "end", "yuyansdk_offlineDebug"})
public final class Bezier {
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.entity.handwriting.TimedPoint startPoint;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.entity.handwriting.TimedPoint control1;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.entity.handwriting.TimedPoint control2;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.entity.handwriting.TimedPoint endPoint;
    
    public Bezier(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint startPoint, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint control1, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint control2, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint endPoint) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.handwriting.TimedPoint getStartPoint() {
        return null;
    }
    
    public final void setStartPoint(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.handwriting.TimedPoint getControl1() {
        return null;
    }
    
    public final void setControl1(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.handwriting.TimedPoint getControl2() {
        return null;
    }
    
    public final void setControl2(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.handwriting.TimedPoint getEndPoint() {
        return null;
    }
    
    public final void setEndPoint(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.handwriting.TimedPoint p0) {
    }
    
    public final float length() {
        return 0.0F;
    }
    
    public final double point(float t, float start, float c1, float c2, float end) {
        return 0.0;
    }
}
package com.yuyan.imemodule.database;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\'\u0018\u0000 \u00112\u00020\u0001:\u0001\u0011B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H&J\b\u0010\u0005\u001a\u00020\u0006H&J\b\u0010\u0007\u001a\u00020\bH&J\b\u0010\t\u001a\u00020\nH&J\b\u0010\u000b\u001a\u00020\fH&J\b\u0010\r\u001a\u00020\u000eH&J\b\u0010\u000f\u001a\u00020\u0010H&\u00a8\u0006\u0012"}, d2 = {"Lcom/yuyan/imemodule/database/DataBaseKT;", "Landroidx/room/RoomDatabase;", "()V", "clipboardDao", "Lcom/yuyan/imemodule/database/dao/ClipboardDao;", "phraseDao", "Lcom/yuyan/imemodule/database/dao/PhraseDao;", "quickPhraseDao", "Lcom/yuyan/imemodule/database/dao/QuickPhraseDao;", "sideSymbolDao", "Lcom/yuyan/imemodule/database/dao/SideSymbolDao;", "skbFunDao", "Lcom/yuyan/imemodule/database/dao/SkbFunDao;", "usedSymbolDao", "Lcom/yuyan/imemodule/database/dao/UsedSymbolDao;", "userWordDao", "Lcom/yuyan/imemodule/database/dao/UserWordDao;", "Companion", "yuyansdk_offlineDebug"})
@androidx.room.Database(entities = {com.yuyan.imemodule.database.entry.SideSymbol.class, com.yuyan.imemodule.database.entry.Clipboard.class, com.yuyan.imemodule.database.entry.UsedSymbol.class, com.yuyan.imemodule.database.entry.Phrase.class, com.yuyan.imemodule.database.entry.SkbFun.class, com.yuyan.imemodule.database.entry.UserWord.class, com.yuyan.imemodule.database.entry.QuickPhrase.class}, version = 7, exportSchema = false)
public abstract class DataBaseKT extends androidx.room.RoomDatabase {
    @kotlin.jvm.Volatile()
    @org.jetbrains.annotations.Nullable()
    private static volatile java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> cachedSideSymbolsPinyin;
    @kotlin.jvm.Volatile()
    @org.jetbrains.annotations.Nullable()
    private static volatile java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> cachedSideSymbolsNumber;
    @org.jetbrains.annotations.NotNull()
    private static final androidx.room.migration.Migration MIGRATION_1_2 = null;
    @org.jetbrains.annotations.NotNull()
    private static final androidx.room.migration.Migration MIGRATION_2_3 = null;
    @org.jetbrains.annotations.NotNull()
    private static final androidx.room.migration.Migration MIGRATION_3_4 = null;
    @org.jetbrains.annotations.NotNull()
    private static final androidx.room.migration.Migration MIGRATION_4_5 = null;
    @org.jetbrains.annotations.NotNull()
    private static final androidx.room.migration.Migration MIGRATION_5_6 = null;
    @org.jetbrains.annotations.NotNull()
    private static final androidx.room.migration.Migration MIGRATION_6_7 = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.database.DataBaseKT instance = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.database.DataBaseKT.Companion Companion = null;
    
    public DataBaseKT() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public abstract com.yuyan.imemodule.database.dao.SideSymbolDao sideSymbolDao();
    
    @org.jetbrains.annotations.NotNull()
    public abstract com.yuyan.imemodule.database.dao.ClipboardDao clipboardDao();
    
    @org.jetbrains.annotations.NotNull()
    public abstract com.yuyan.imemodule.database.dao.UsedSymbolDao usedSymbolDao();
    
    @org.jetbrains.annotations.NotNull()
    public abstract com.yuyan.imemodule.database.dao.PhraseDao phraseDao();
    
    @org.jetbrains.annotations.NotNull()
    public abstract com.yuyan.imemodule.database.dao.SkbFunDao skbFunDao();
    
    @org.jetbrains.annotations.NotNull()
    public abstract com.yuyan.imemodule.database.dao.UserWordDao userWordDao();
    
    @org.jetbrains.annotations.NotNull()
    public abstract com.yuyan.imemodule.database.dao.QuickPhraseDao quickPhraseDao();
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\f0\u000bJ\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\f0\u000bJ\b\u0010\u0014\u001a\u00020\u0015H\u0002J\b\u0010\u0016\u001a\u00020\u0015H\u0002J\u0006\u0010\u0017\u001a\u00020\u0015R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\r\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011\u00a8\u0006\u0018"}, d2 = {"Lcom/yuyan/imemodule/database/DataBaseKT$Companion;", "", "()V", "MIGRATION_1_2", "Landroidx/room/migration/Migration;", "MIGRATION_2_3", "MIGRATION_3_4", "MIGRATION_4_5", "MIGRATION_5_6", "MIGRATION_6_7", "cachedSideSymbolsNumber", "", "Lcom/yuyan/imemodule/database/entry/SideSymbol;", "cachedSideSymbolsPinyin", "instance", "Lcom/yuyan/imemodule/database/DataBaseKT;", "getInstance", "()Lcom/yuyan/imemodule/database/DataBaseKT;", "getSideSymbolsNumber", "getSideSymbolsPinyin", "initDb", "", "initPhrasesDb", "invalidateSideSymbolsCache", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> getSideSymbolsPinyin() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> getSideSymbolsNumber() {
            return null;
        }
        
        public final void invalidateSideSymbolsCache() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.database.DataBaseKT getInstance() {
            return null;
        }
        
        private final void initDb() {
        }
        
        private final void initPhrasesDb() {
        }
    }
}
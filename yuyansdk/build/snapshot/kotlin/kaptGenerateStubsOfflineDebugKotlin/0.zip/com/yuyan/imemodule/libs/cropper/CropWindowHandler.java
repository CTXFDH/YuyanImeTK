package com.yuyan.imemodule.libs.cropper;

/**
 * Handler from crop window stuff, moving and knowing position.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\b\u0000\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J(\u0010\u0011\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u0007H\u0002J\b\u0010\u0016\u001a\u00020\u0017H\u0002J\u0006\u0010\u0018\u001a\u00020\u0007J\u0006\u0010\u0019\u001a\u00020\u0007J\u0006\u0010\u001a\u001a\u00020\u0007J\u0006\u0010\u001b\u001a\u00020\u0007J0\u0010\u001c\u001a\u0004\u0018\u00010\u001d2\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u00072\u0006\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u0017J\"\u0010$\u001a\u0004\u0018\u00010%2\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0017H\u0002J\u0006\u0010&\u001a\u00020\u0004J*\u0010\'\u001a\u0004\u0018\u00010%2\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0017H\u0002J*\u0010(\u001a\u0004\u0018\u00010%2\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0017H\u0002J*\u0010)\u001a\u0004\u0018\u00010%2\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0017H\u0002J\u0006\u0010*\u001a\u00020\u0007J\u0006\u0010+\u001a\u00020\u0007J8\u0010,\u001a\u00020\u00172\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010-\u001a\u00020\u00072\u0006\u0010.\u001a\u00020\u00072\u0006\u0010/\u001a\u00020\u00072\u0006\u00100\u001a\u00020\u0007H\u0002J0\u00101\u001a\u00020\u00172\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u00102\u001a\u00020\u00072\u0006\u00103\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u0007H\u0002J8\u00104\u001a\u00020\u00172\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u00105\u001a\u00020\u00072\u0006\u00106\u001a\u00020\u00072\u0006\u00103\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u0007H\u0002J8\u00107\u001a\u00020\u00172\u0006\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u00102\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u00072\u0006\u00109\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u0007H\u0002J&\u0010:\u001a\u00020;2\u0006\u0010<\u001a\u00020\u00072\u0006\u0010=\u001a\u00020\u00072\u0006\u0010>\u001a\u00020\u00072\u0006\u0010?\u001a\u00020\u0007J\u000e\u0010@\u001a\u00020;2\u0006\u0010A\u001a\u00020BJ\u0016\u0010C\u001a\u00020;2\u0006\u0010D\u001a\u00020E2\u0006\u0010F\u001a\u00020EJ\u0016\u0010G\u001a\u00020;2\u0006\u0010H\u001a\u00020E2\u0006\u0010I\u001a\u00020EJ\u000e\u0010J\u001a\u00020;2\u0006\u0010K\u001a\u00020\u0004J\u0006\u0010L\u001a\u00020\u0017R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006M"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropWindowHandler;", "", "()V", "mEdges", "Landroid/graphics/RectF;", "mGetEdges", "mMaxCropResultHeight", "", "mMaxCropResultWidth", "mMaxCropWindowHeight", "mMaxCropWindowWidth", "mMinCropResultHeight", "mMinCropResultWidth", "mMinCropWindowHeight", "mMinCropWindowWidth", "mScaleFactorHeight", "mScaleFactorWidth", "distance", "x1", "y1", "x2", "y2", "focusCenter", "", "getMaxCropHeight", "getMaxCropWidth", "getMinCropHeight", "getMinCropWidth", "getMoveHandler", "Lcom/yuyan/imemodule/libs/cropper/CropWindowMoveHandler;", "x", "y", "targetRadius", "cropShape", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropShape;", "isCenterMoveEnabled", "getOvalPressedMoveType", "Lcom/yuyan/imemodule/libs/cropper/CropWindowMoveHandler$Type;", "getRect", "getRectangleHorizontalOnlyPressedMoveType", "getRectanglePressedMoveType", "getRectangleVerticalOnlyPressedMoveType", "getScaleFactorHeight", "getScaleFactorWidth", "isInCenterTargetZone", "left", "top", "right", "bottom", "isInCornerTargetZone", "handleX", "handleY", "isInHorizontalTargetZone", "handleXStart", "handleXEnd", "isInVerticalTargetZone", "handleYStart", "handleYEnd", "setCropWindowLimits", "", "maxWidth", "maxHeight", "scaleFactorWidth", "scaleFactorHeight", "setInitialAttributeValues", "options", "Lcom/yuyan/imemodule/libs/cropper/CropImageOptions;", "setMaxCropResultSize", "maxCropResultWidth", "", "maxCropResultHeight", "setMinCropResultSize", "minCropResultWidth", "minCropResultHeight", "setRect", "rect", "showGuidelines", "yuyansdk_offlineDebug"})
public final class CropWindowHandler {
    
    /**
     * The 4 edges of the crop window defining its coordinates and size.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.RectF mEdges = null;
    
    /**
     * Rectangle used to return the edges rectangle without ability to change it and without creating
     * new all the time.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.RectF mGetEdges = null;
    
    /**
     * Minimum width in pixels that the crop window can get.
     */
    private float mMinCropWindowWidth = 0.0F;
    
    /**
     * Minimum height in pixels that the crop window can get.
     */
    private float mMinCropWindowHeight = 0.0F;
    
    /**
     * Maximum width in pixels that the crop window can CURRENTLY get.
     */
    private float mMaxCropWindowWidth = 0.0F;
    
    /**
     * Maximum height in pixels that the crop window can CURRENTLY get.
     */
    private float mMaxCropWindowHeight = 0.0F;
    
    /**
     * Minimum width in pixels that the result of cropping an image can get, affects crop window width
     * adjusted by width scale factor.
     */
    private float mMinCropResultWidth = 0.0F;
    
    /**
     * Minimum height in pixels that the result of cropping an image can get, affects crop window
     * height adjusted by height scale factor.
     */
    private float mMinCropResultHeight = 0.0F;
    
    /**
     * Maximum width in pixels that the result of cropping an image can get, affects crop window width
     * adjusted by width scale factor.
     */
    private float mMaxCropResultWidth = 0.0F;
    
    /**
     * Maximum height in pixels that the result of cropping an image can get, affects crop window
     * height adjusted by height scale factor.
     */
    private float mMaxCropResultHeight = 0.0F;
    
    /**
     * The width scale factor of shown image and actual image.
     */
    private float mScaleFactorWidth = 1.0F;
    
    /**
     * The height scale factor of shown image and actual image.
     */
    private float mScaleFactorHeight = 1.0F;
    
    public CropWindowHandler() {
        super();
    }
    
    /**
     * Get the left/top/right/bottom coordinates of the crop window.
     */
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.RectF getRect() {
        return null;
    }
    
    /**
     * Minimum width in pixels that the crop window can get.
     */
    public final float getMinCropWidth() {
        return 0.0F;
    }
    
    /**
     * Minimum height in pixels that the crop window can get.
     */
    public final float getMinCropHeight() {
        return 0.0F;
    }
    
    /**
     * Maximum width in pixels that the crop window can get.
     */
    public final float getMaxCropWidth() {
        return 0.0F;
    }
    
    /**
     * Maximum height in pixels that the crop window can get.
     */
    public final float getMaxCropHeight() {
        return 0.0F;
    }
    
    /**
     * Get the scale factor (on width) of the shown image to original image.
     */
    public final float getScaleFactorWidth() {
        return 0.0F;
    }
    
    /**
     * Get the scale factor (on height) of the shown image to original image.
     */
    public final float getScaleFactorHeight() {
        return 0.0F;
    }
    
    /**
     * the min size the resulting cropping image is allowed to be, affects the cropping window limits
     * (in pixels).<br></br>
     */
    public final void setMinCropResultSize(int minCropResultWidth, int minCropResultHeight) {
    }
    
    /**
     * the max size the resulting cropping image is allowed to be, affects the cropping window limits
     * (in pixels).<br></br>
     */
    public final void setMaxCropResultSize(int maxCropResultWidth, int maxCropResultHeight) {
    }
    
    /**
     * set the max width/height and scale factor of the shown image to original image to scale the
     * limits appropriately.
     */
    public final void setCropWindowLimits(float maxWidth, float maxHeight, float scaleFactorWidth, float scaleFactorHeight) {
    }
    
    /**
     * Set the variables to be used during crop window handling.
     */
    public final void setInitialAttributeValues(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageOptions options) {
    }
    
    /**
     * Set the left/top/right/bottom coordinates of the crop window.
     */
    public final void setRect(@org.jetbrains.annotations.NotNull()
    android.graphics.RectF rect) {
    }
    
    /**
     * Indicates whether the crop window is small enough that the guidelines should be shown. Public
     * because this function is also used to determine if the center handle should be focused.
     *
     * @return boolean Whether the guidelines should be shown or not
     */
    public final boolean showGuidelines() {
        return false;
    }
    
    /**
     * Determines which, if any, of the handles are pressed given the touch coordinates, the bounding
     * box, the touch radius, the crop shape and whether movement of the crop window is enabled.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [targetRadius] the target radius in pixels
     * [cropShape] the shape of the crop window
     * [isCenterMoveEnabled] whether movement of the crop window by dragging center is enabled
     * @return the Handle that was pressed; null if no Handle was pressed
     */
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler getMoveHandler(float x, float y, float targetRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, boolean isCenterMoveEnabled) {
        return null;
    }
    
    /**
     * Determines which, if any, of the handles are pressed given the touch coordinates, the bounding
     * box, and the touch radius.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [targetRadius] the target radius in pixels
     * [isCenterMoveEnabled] whether movement of the crop window by dragging center is enabled
     * @return the Handle that was pressed; null if no Handle was pressed
     */
    private final com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler.Type getRectanglePressedMoveType(float x, float y, float targetRadius, boolean isCenterMoveEnabled) {
        return null;
    }
    
    /**
     * Determines which, if any, of the handles are pressed given the touch coordinates, the bounding
     * box/oval, and the touch radius.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [isCenterMoveEnabled] whether movement of the crop window by dragging center is enabled
     * @return the Handle that was pressed; null if no Handle was pressed
     */
    private final com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler.Type getOvalPressedMoveType(float x, float y, boolean isCenterMoveEnabled) {
        return null;
    }
    
    /**
     * Determines which, if any, of the handles are pressed given the touch coordinates, the bounding
     * box, and the touch radius.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [targetRadius] the target radius in pixels
     * [isCenterMoveEnabled] whether movement of the crop window by dragging center is enabled
     * @return the Handle that was pressed; null if no Handle was pressed
     */
    private final com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler.Type getRectangleVerticalOnlyPressedMoveType(float x, float y, float targetRadius, boolean isCenterMoveEnabled) {
        return null;
    }
    
    /**
     * Determines which, if any, of the handles are pressed given the touch coordinates, the bounding
     * box, and the touch radius.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [targetRadius] the target radius in pixels
     * [isCenterMoveEnabled] whether movement of the crop window by dragging center is enabled
     * @return the Handle that was pressed; null if no Handle was pressed
     */
    private final com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler.Type getRectangleHorizontalOnlyPressedMoveType(float x, float y, float targetRadius, boolean isCenterMoveEnabled) {
        return null;
    }
    
    /**
     * Determines if the specified coordinate is in the target touch zone for a corner handle.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [handleX] the x-coordinate of the corner handle
     * [handleY] the y-coordinate of the corner handle
     * [targetRadius] the target radius in pixels
     * @return true if the touch point is in the target touch zone; false otherwise
     */
    private final boolean isInCornerTargetZone(float x, float y, float handleX, float handleY, float targetRadius) {
        return false;
    }
    
    /**
     * Get the distance between two points in the maximum norm.
     *
     * [x1] the x-coordinate of the first point
     * [y1] the y-coordinate of the first point
     * [x2] the x-coordinate of the second point
     * [y2] the y-coordinate of the second point
     * @return the distance between these points
     */
    private final float distance(float x1, float y1, float x2, float y2) {
        return 0.0F;
    }
    
    /**
     * Determines if the specified coordinate is in the target touch zone for a horizontal bar handle.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [handleXStart] the left x-coordinate of the horizontal bar handle
     * [handleXEnd] the right x-coordinate of the horizontal bar handle
     * [handleY] the y-coordinate of the horizontal bar handle
     * [targetRadius] the target radius in pixels
     * @return true if the touch point is in the target touch zone; false otherwise
     */
    private final boolean isInHorizontalTargetZone(float x, float y, float handleXStart, float handleXEnd, float handleY, float targetRadius) {
        return false;
    }
    
    /**
     * Determines if the specified coordinate is in the target touch zone for a vertical bar handle.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [handleX] the x-coordinate of the vertical bar handle
     * [handleYStart] the top y-coordinate of the vertical bar handle
     * [handleYEnd] the bottom y-coordinate of the vertical bar handle
     * [targetRadius] the target radius in pixels
     * @return true if the touch point is in the target touch zone; false otherwise
     */
    private final boolean isInVerticalTargetZone(float x, float y, float handleX, float handleYStart, float handleYEnd, float targetRadius) {
        return false;
    }
    
    /**
     * Determines if the specified coordinate falls anywhere inside the given bounds.
     *
     * [x] the x-coordinate of the touch point
     * [y] the y-coordinate of the touch point
     * [left] the x-coordinate of the left bound
     * [top] the y-coordinate of the top bound
     * [right] the x-coordinate of the right bound
     * [bottom] the y-coordinate of the bottom bound
     * @return true if the touch point is inside the bounding rectangle; false otherwise
     */
    private final boolean isInCenterTargetZone(float x, float y, float left, float top, float right, float bottom) {
        return false;
    }
    
    /**
     * Determines if the cropper should focus on the center handle or the side handles. If it is a
     * small image, focus on the center handle so the user can move it. If it is a large image, focus
     * on the side handles so user can grab them. Corresponds to the appearance of the
     * RuleOfThirdsGuidelines.
     *
     * @return true if it is small enough such that it should focus in the center; less than
     * show_guidelines limit
     */
    private final boolean focusCenter() {
        return false;
    }
}
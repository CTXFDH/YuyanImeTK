package com.yuyan.imemodule.candidate;

/**
 * 物理键盘输入界面。
 * 包含拼音显示、候选词栏、键盘界面等。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0080\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0010\u0014\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001:\u0001GB\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0010\u0010\u001a\u001a\u00020\u001b2\b\b\u0002\u0010\u001c\u001a\u00020\fJ\u0012\u0010\u001d\u001a\u00020\u001b2\b\u0010\u001e\u001a\u0004\u0018\u00010\u001fH\u0002J\b\u0010 \u001a\u00020!H\u0016J\u0010\u0010\"\u001a\u00020\u001b2\u0006\u0010\u0004\u001a\u00020\u0005H\u0002J\b\u0010#\u001a\u00020\u001bH\u0007J\b\u0010$\u001a\u00020\u001bH\u0016J\u0018\u0010%\u001a\u00020\u001b2\u0006\u0010&\u001a\u00020\'2\u0006\u0010(\u001a\u00020)H\u0016J0\u0010*\u001a\u00020\u001b2\u0006\u0010+\u001a\u00020\f2\u0006\u0010,\u001a\u00020\f2\u0006\u0010-\u001a\u00020\f2\u0006\u0010.\u001a\u00020\f2\u0006\u0010/\u001a\u00020\fH\u0016J\b\u00100\u001a\u00020\u001bH\u0016J\b\u00101\u001a\u00020\u001bH\u0016J\u0010\u00102\u001a\u00020)2\u0006\u00103\u001a\u000204H\u0002J\u0010\u00105\u001a\u00020)2\u0006\u00103\u001a\u000204H\u0002J\u0018\u00106\u001a\u00020)2\u0006\u00107\u001a\u00020\f2\u0006\u00103\u001a\u000204H\u0016J\u0010\u00108\u001a\u00020)2\u0006\u00103\u001a\u000204H\u0016J\u0006\u00109\u001a\u00020\u001bJ\u0010\u0010:\u001a\u00020\u001b2\u0006\u00107\u001a\u00020\fH\u0002J\u0010\u0010;\u001a\u00020\u001b2\u0006\u0010<\u001a\u00020=H\u0016J\u001b\u0010>\u001a\u00020\u001b2\f\u0010?\u001a\b\u0012\u0004\u0012\u00020\u001f0@H\u0016\u00a2\u0006\u0002\u0010AJ\b\u0010B\u001a\u00020\u001bH\u0002J\u0010\u0010C\u001a\u00020\u001b2\u0006\u0010D\u001a\u00020EH\u0016J\b\u0010F\u001a\u00020\u001bH\u0016R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0012\u0010\t\u001a\u00060\nR\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000e\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u0015X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u0017\"\u0004\b\u0018\u0010\u0019R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006H"}, d2 = {"Lcom/yuyan/imemodule/candidate/CandidateView;", "Lcom/yuyan/imemodule/callback/IKeyboardView;", "context", "Landroid/content/Context;", "service", "Lcom/yuyan/imemodule/service/ImeService;", "(Landroid/content/Context;Lcom/yuyan/imemodule/service/ImeService;)V", "appPrefs", "Lcom/yuyan/imemodule/prefs/AppPrefs;", "mChoiceNotifier", "Lcom/yuyan/imemodule/candidate/CandidateView$ChoiceNotifier;", "mFloatCandidateBarWidth", "", "mHorizontalCutoutWidth", "mSkbCandidatesBarView", "Lcom/yuyan/imemodule/candidate/FloatCandidateBar;", "getMSkbCandidatesBarView", "()Lcom/yuyan/imemodule/candidate/FloatCandidateBar;", "setMSkbCandidatesBarView", "(Lcom/yuyan/imemodule/candidate/FloatCandidateBar;)V", "mSkbRoot", "Landroid/widget/RelativeLayout;", "getMSkbRoot", "()Landroid/widget/RelativeLayout;", "setMSkbRoot", "(Landroid/widget/RelativeLayout;)V", "chooseAndUpdate", "", "candId", "commitDecInfoText", "resultText", "", "getKeyboardRect", "", "initDisplayCutout", "initView", "onCandidateChanged", "onStartInputView", "editorInfo", "Landroid/view/inputmethod/EditorInfo;", "restarting", "", "onUpdateSelection", "oldSelStart", "oldSelEnd", "newSelStart", "newSelEnd", "candidatesEnd", "onWindowHidden", "onWindowShown", "processFunctionKeys", "event", "Landroid/view/KeyEvent;", "processInput", "processKeyDown", "keyCode", "processKeyUp", "resetToIdleState", "sendKeyEvent", "setConfiguration", "newConfig", "Landroid/content/res/Configuration;", "showSymbols", "symbols", "", "([Ljava/lang/String;)V", "updateCandidate", "updatePosition", "anchor", "", "updateTheme", "ChoiceNotifier", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class CandidateView extends com.yuyan.imemodule.callback.IKeyboardView {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.service.ImeService service = null;
    private int mHorizontalCutoutWidth = 0;
    private int mFloatCandidateBarWidth = 0;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.AppPrefs appPrefs = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.candidate.CandidateView.ChoiceNotifier mChoiceNotifier = null;
    @org.jetbrains.annotations.NotNull()
    private android.widget.RelativeLayout mSkbRoot;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.candidate.FloatCandidateBar mSkbCandidatesBarView;
    
    public CandidateView(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.service.ImeService service) {
        super(null);
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.widget.RelativeLayout getMSkbRoot() {
        return null;
    }
    
    public final void setMSkbRoot(@org.jetbrains.annotations.NotNull()
    android.widget.RelativeLayout p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.candidate.FloatCandidateBar getMSkbCandidatesBarView() {
        return null;
    }
    
    public final void setMSkbCandidatesBarView(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.candidate.FloatCandidateBar p0) {
    }
    
    @java.lang.Override()
    public void onCandidateChanged() {
    }
    
    private final void initDisplayCutout(com.yuyan.imemodule.service.ImeService service) {
    }
    
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public final void initView() {
    }
    
    @java.lang.Override()
    public void updateTheme() {
    }
    
    @java.lang.Override()
    public void updatePosition(@org.jetbrains.annotations.NotNull()
    float[] anchor) {
    }
    
    @java.lang.Override()
    public boolean processKeyDown(int keyCode, @org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    @java.lang.Override()
    public boolean processKeyUp(@org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    private final boolean processFunctionKeys(android.view.KeyEvent event) {
        return false;
    }
    
    private final boolean processInput(android.view.KeyEvent event) {
        return false;
    }
    
    public final void resetToIdleState() {
    }
    
    public final void chooseAndUpdate(int candId) {
    }
    
    private final void updateCandidate() {
    }
    
    private final void sendKeyEvent(int keyCode) {
    }
    
    private final void commitDecInfoText(java.lang.String resultText) {
    }
    
    @java.lang.Override()
    public void onStartInputView(@org.jetbrains.annotations.NotNull()
    android.view.inputmethod.EditorInfo editorInfo, boolean restarting) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public int[] getKeyboardRect() {
        return null;
    }
    
    @java.lang.Override()
    public void showSymbols(@org.jetbrains.annotations.NotNull()
    java.lang.String[] symbols) {
    }
    
    @java.lang.Override()
    public void setConfiguration(@org.jetbrains.annotations.NotNull()
    android.content.res.Configuration newConfig) {
    }
    
    @java.lang.Override()
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candidatesEnd) {
    }
    
    @java.lang.Override()
    public void onWindowShown() {
    }
    
    @java.lang.Override()
    public void onWindowHidden() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0007\b\u0000\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\b\u0010\u0007\u001a\u00020\u0004H\u0016J\b\u0010\b\u001a\u00020\u0004H\u0016J\u0010\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u000bH\u0016J\u0010\u0010\f\u001a\u00020\u00042\u0006\u0010\r\u001a\u00020\u0006H\u0016\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/candidate/CandidateView$ChoiceNotifier;", "Lcom/yuyan/imemodule/callback/CandidateViewListener;", "(Lcom/yuyan/imemodule/candidate/CandidateView;)V", "onClickChoice", "", "choiceId", "", "onClickClearCandidate", "onClickClearClipBoard", "onClickMenu", "skbMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "onClickMore", "level", "yuyansdk_offlineDebug"})
    public final class ChoiceNotifier implements com.yuyan.imemodule.callback.CandidateViewListener {
        
        public ChoiceNotifier() {
            super();
        }
        
        @java.lang.Override()
        public void onClickChoice(int choiceId) {
        }
        
        @java.lang.Override()
        public void onClickMore(int level) {
        }
        
        @java.lang.Override()
        public void onClickMenu(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode) {
        }
        
        @java.lang.Override()
        public void onClickClearCandidate() {
        }
        
        @java.lang.Override()
        public void onClickClearClipBoard() {
        }
    }
}
package com.yuyan.inputmethod.util;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\f\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0006\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u001b\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00060\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\u0006\u00a2\u0006\u0002\u0010\fJ\u0010\u0010\r\u001a\u00020\u00062\b\u0010\u000b\u001a\u0004\u0018\u00010\u0006J\u000e\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u0005R\u001a\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/inputmethod/util/LX17PinYinUtils;", "", "()V", "lx17KeyMap", "", "", "", "lx17PinyinMap", "Ljava/util/HashMap;", "lx17KeyToPinyin", "", "sequence", "(Ljava/lang/String;)[Ljava/lang/String;", "pinyin2Key", "pinyin2Lx17Key", "pinyin", "yuyansdk_offlineDebug"})
public final class LX17PinYinUtils {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Character, java.lang.String> lx17KeyMap = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.HashMap<java.lang.String, java.lang.String> lx17PinyinMap = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.util.LX17PinYinUtils INSTANCE = null;
    
    private LX17PinYinUtils() {
        super();
    }
    
    /**
     * 获取键码对应的拼音组合
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[] lx17KeyToPinyin(@org.jetbrains.annotations.Nullable()
    java.lang.String sequence) {
        return null;
    }
    
    /**
     * 获取拼音拼音对应的键码
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String pinyin2Key(@org.jetbrains.annotations.Nullable()
    java.lang.String sequence) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String pinyin2Lx17Key(char pinyin) {
        return null;
    }
}
package com.yuyan.inputmethod;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\"\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0010!\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0013\u001a\u00020\u0014J#\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010\u0016\u001a\u00020\u00052\b\u0010\u0017\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0018J\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0016\u001a\u00020\u0005J\u0014\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00050\u001b2\u0006\u0010\u001c\u001a\u00020\u0005J\u0014\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00050\u001b2\u0006\u0010\u001c\u001a\u00020\u0005R\u0016\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u0006R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00050\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00050\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00050\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010\u000f\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00110\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010\u0012\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00110\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001e"}, d2 = {"Lcom/yuyan/inputmethod/CustomEngine;", "", "()V", "CALCULATOR_DEFAULT_OPERATORS", "", "", "[Ljava/lang/String;", "EXPRESSION_END_PATTERN", "Lkotlin/text/Regex;", "SUFFIXES_DATE", "", "SUFFIXES_DAYS", "SUFFIXES_EXCLAMATION", "SUFFIXES_QUESTION", "SUFFIXES_TIME", "phraseCache", "Ljava/util/concurrent/ConcurrentHashMap;", "", "userWordCache", "clearCache", "", "expressionCalculator", "input", "expression", "(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;", "parseExpressionAtEnd", "predictAssociationWordsChinese", "", "text", "processPhrase", "yuyansdk_offlineDebug"})
public final class CustomEngine {
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.text.Regex EXPRESSION_END_PATTERN = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String[] CALCULATOR_DEFAULT_OPERATORS = {"=", "+", "-", "*", "/", "%", ".", ",", "\'", "(", ")"};
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Set<java.lang.String> SUFFIXES_DAYS = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Set<java.lang.String> SUFFIXES_EXCLAMATION = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Set<java.lang.String> SUFFIXES_QUESTION = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Set<java.lang.String> SUFFIXES_DATE = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Set<java.lang.String> SUFFIXES_TIME = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.concurrent.ConcurrentHashMap<java.lang.String, java.util.List<java.lang.String>> phraseCache = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.concurrent.ConcurrentHashMap<java.lang.String, java.util.List<java.lang.String>> userWordCache = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.CustomEngine INSTANCE = null;
    
    private CustomEngine() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String parseExpressionAtEnd(@org.jetbrains.annotations.NotNull()
    java.lang.String input) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[] expressionCalculator(@org.jetbrains.annotations.NotNull()
    java.lang.String input, @org.jetbrains.annotations.Nullable()
    java.lang.String expression) {
        return null;
    }
    
    public final void clearCache() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<java.lang.String> predictAssociationWordsChinese(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<java.lang.String> processPhrase(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
        return null;
    }
}
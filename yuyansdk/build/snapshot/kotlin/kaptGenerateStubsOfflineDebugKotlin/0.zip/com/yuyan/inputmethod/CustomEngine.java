package com.yuyan.inputmethod;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010!\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J#\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u00042\u0006\u0010\u0006\u001a\u00020\u00052\b\u0010\u0007\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\bJ\u0010\u0010\t\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u0005J\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00050\u000b2\u0006\u0010\f\u001a\u00020\u0005J\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00050\u000b2\u0006\u0010\f\u001a\u00020\u0005\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/inputmethod/CustomEngine;", "", "()V", "expressionCalculator", "", "", "input", "expression", "(Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;", "parseExpressionAtEnd", "predictAssociationWordsChinese", "", "text", "processPhrase", "yuyansdk_offlineDebug"})
public final class CustomEngine {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.CustomEngine INSTANCE = null;
    
    private CustomEngine() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String parseExpressionAtEnd(@org.jetbrains.annotations.NotNull()
    java.lang.String input) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[] expressionCalculator(@org.jetbrains.annotations.NotNull()
    java.lang.String input, @org.jetbrains.annotations.Nullable()
    java.lang.String expression) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<java.lang.String> predictAssociationWordsChinese(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<java.lang.String> processPhrase(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
        return null;
    }
}
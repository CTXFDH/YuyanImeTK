package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u00c7\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u000e\u0010\u0010\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\u0002J\u0017\u0010\u0012\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0014\u001a\u00020\u0005H\u0002\u00a2\u0006\u0002\u0010\u0015J\u000e\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u0017\u001a\u00020\u0005J\u0010\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0019H\u0014J\u0010\u0010\u001b\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\u0019H\u0014J\f\u0010\u001c\u001a\u00020\u001d*\u00020\u001dH\u0002J\f\u0010\u001e\u001a\u00020\u0005*\u00020\u0005H\u0002J\f\u0010\u001f\u001a\u00020\u001d*\u00020\u001dH\u0002J\f\u0010 \u001a\u00020\u0005*\u00020\u0013H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u000e\u0010\n\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u001d\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\r0\f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f\u00a8\u0006!"}, d2 = {"Lcom/yuyan/imemodule/data/theme/CustomThemeSerializer;", "Lkotlinx/serialization/json/JsonTransformingSerializer;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "()V", "CURRENT_VERSION", "", "LenientJson", "Lkotlinx/serialization/json/Json;", "getLenientJson", "()Lkotlinx/serialization/json/Json;", "VERSION", "WithMigrationStatus", "Lcom/yuyan/imemodule/utils/NostalgicSerializer;", "", "getWithMigrationStatus", "()Lcom/yuyan/imemodule/utils/NostalgicSerializer;", "encodeToChineseAnnotatedHexJson", "theme", "parseColorString", "", "raw", "(Ljava/lang/String;)Ljava/lang/Integer;", "stripJsonComments", "jsonText", "transformDeserialize", "Lkotlinx/serialization/json/JsonElement;", "element", "transformSerialize", "addVersion", "Lkotlinx/serialization/json/JsonObject;", "escapeJson", "removeVersion", "toHexString", "yuyansdk_offlineDebug"})
public final class CustomThemeSerializer extends kotlinx.serialization.json.JsonTransformingSerializer<com.yuyan.imemodule.data.theme.Theme.Custom> {
    @org.jetbrains.annotations.NotNull()
    private static final kotlinx.serialization.json.Json LenientJson = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.utils.NostalgicSerializer<com.yuyan.imemodule.data.theme.Theme.Custom, java.lang.Boolean> WithMigrationStatus = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String VERSION = "version";
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String CURRENT_VERSION = "2.0";
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.theme.CustomThemeSerializer INSTANCE = null;
    
    private CustomThemeSerializer() {
        super(null);
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.serialization.json.Json getLenientJson() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.utils.NostalgicSerializer<com.yuyan.imemodule.data.theme.Theme.Custom, java.lang.Boolean> getWithMigrationStatus() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    protected kotlinx.serialization.json.JsonElement transformSerialize(@org.jetbrains.annotations.NotNull()
    kotlinx.serialization.json.JsonElement element) {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    protected kotlinx.serialization.json.JsonElement transformDeserialize(@org.jetbrains.annotations.NotNull()
    kotlinx.serialization.json.JsonElement element) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String stripJsonComments(@org.jetbrains.annotations.NotNull()
    java.lang.String jsonText) {
        return null;
    }
    
    private final java.lang.String toHexString(int $this$toHexString) {
        return null;
    }
    
    private final java.lang.String escapeJson(java.lang.String $this$escapeJson) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String encodeToChineseAnnotatedHexJson(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme.Custom theme) {
        return null;
    }
    
    private final java.lang.Integer parseColorString(java.lang.String raw) {
        return null;
    }
    
    private final kotlinx.serialization.json.JsonObject addVersion(kotlinx.serialization.json.JsonObject $this$addVersion) {
        return null;
    }
    
    private final kotlinx.serialization.json.JsonObject removeVersion(kotlinx.serialization.json.JsonObject $this$removeVersion) {
        return null;
    }
}
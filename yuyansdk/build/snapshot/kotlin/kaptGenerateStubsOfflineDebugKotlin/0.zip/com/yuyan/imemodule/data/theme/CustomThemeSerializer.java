package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\b\u00c7\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001$B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u000e\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u0002J\u0017\u0010\u0016\u001a\u0004\u0018\u00010\u00172\u0006\u0010\u0018\u001a\u00020\u0005H\u0002\u00a2\u0006\u0002\u0010\u0019J\u000e\u0010\u001a\u001a\u00020\u00052\u0006\u0010\u001b\u001a\u00020\u0005J\u0010\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001dH\u0014J\u0010\u0010\u001f\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001dH\u0014J\f\u0010 \u001a\u00020\b*\u00020\bH\u0002J\f\u0010!\u001a\u00020\u0005*\u00020\u0005H\u0002J\f\u0010\"\u001a\u00020\b*\u00020\bH\u0002J\f\u0010#\u001a\u00020\u0005*\u00020\u0017H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0082T\u00a2\u0006\u0002\n\u0000R\u001d\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\r0\f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00050\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00130\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006%"}, d2 = {"Lcom/yuyan/imemodule/data/theme/CustomThemeSerializer;", "Lkotlinx/serialization/json/JsonTransformingSerializer;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "()V", "CURRENT_VERSION", "", "EmptyTransform", "Lkotlin/Function1;", "Lkotlinx/serialization/json/JsonObject;", "FALLBACK_VERSION", "VERSION", "WithMigrationStatus", "Lcom/yuyan/imemodule/utils/NostalgicSerializer;", "", "getWithMigrationStatus", "()Lcom/yuyan/imemodule/utils/NostalgicSerializer;", "knownVersions", "", "strategies", "Lcom/yuyan/imemodule/data/theme/CustomThemeSerializer$MigrationStrategy;", "encodeToChineseAnnotatedHexJson", "theme", "parseColorString", "", "raw", "(Ljava/lang/String;)Ljava/lang/Integer;", "stripJsonComments", "jsonText", "transformDeserialize", "Lkotlinx/serialization/json/JsonElement;", "element", "transformSerialize", "addVersion", "escapeJson", "removeVersion", "toHexString", "MigrationStrategy", "yuyansdk_offlineDebug"})
public final class CustomThemeSerializer extends kotlinx.serialization.json.JsonTransformingSerializer<com.yuyan.imemodule.data.theme.Theme.Custom> {
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.utils.NostalgicSerializer<com.yuyan.imemodule.data.theme.Theme.Custom, java.lang.Boolean> WithMigrationStatus = null;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.jvm.functions.Function1<kotlinx.serialization.json.JsonObject, kotlinx.serialization.json.JsonObject> EmptyTransform = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.List<com.yuyan.imemodule.data.theme.CustomThemeSerializer.MigrationStrategy> strategies = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String VERSION = "version";
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String CURRENT_VERSION = "2.0";
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String FALLBACK_VERSION = "1.0";
    @org.jetbrains.annotations.NotNull()
    private static final java.util.List<java.lang.String> knownVersions = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.theme.CustomThemeSerializer INSTANCE = null;
    
    private CustomThemeSerializer() {
        super(null);
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.utils.NostalgicSerializer<com.yuyan.imemodule.data.theme.Theme.Custom, java.lang.Boolean> getWithMigrationStatus() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    protected kotlinx.serialization.json.JsonElement transformSerialize(@org.jetbrains.annotations.NotNull()
    kotlinx.serialization.json.JsonElement element) {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    protected kotlinx.serialization.json.JsonElement transformDeserialize(@org.jetbrains.annotations.NotNull()
    kotlinx.serialization.json.JsonElement element) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String stripJsonComments(@org.jetbrains.annotations.NotNull()
    java.lang.String jsonText) {
        return null;
    }
    
    private final java.lang.String toHexString(int $this$toHexString) {
        return null;
    }
    
    private final java.lang.String escapeJson(java.lang.String $this$escapeJson) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String encodeToChineseAnnotatedHexJson(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme.Custom theme) {
        return null;
    }
    
    private final java.lang.Integer parseColorString(java.lang.String raw) {
        return null;
    }
    
    private final kotlinx.serialization.json.JsonObject addVersion(kotlinx.serialization.json.JsonObject $this$addVersion) {
        return null;
    }
    
    private final kotlinx.serialization.json.JsonObject removeVersion(kotlinx.serialization.json.JsonObject $this$removeVersion) {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\u0002\u0010\u0007J\t\u0010\f\u001a\u00020\u0003H\u00c6\u0003J\u0015\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\u0005H\u00c6\u0003J)\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u0014\b\u0002\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\u0005H\u00c6\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0012\u001a\u00020\u0013H\u00d6\u0001J\t\u0010\u0014\u001a\u00020\u0003H\u00d6\u0001R\u001d\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/data/theme/CustomThemeSerializer$MigrationStrategy;", "", "version", "", "transformation", "Lkotlin/Function1;", "Lkotlinx/serialization/json/JsonObject;", "(Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V", "getTransformation", "()Lkotlin/jvm/functions/Function1;", "getVersion", "()Ljava/lang/String;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "yuyansdk_offlineDebug"})
    public static final class MigrationStrategy {
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String version = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.jvm.functions.Function1<kotlinx.serialization.json.JsonObject, kotlinx.serialization.json.JsonObject> transformation = null;
        
        public MigrationStrategy(@org.jetbrains.annotations.NotNull()
        java.lang.String version, @org.jetbrains.annotations.NotNull()
        kotlin.jvm.functions.Function1<? super kotlinx.serialization.json.JsonObject, kotlinx.serialization.json.JsonObject> transformation) {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getVersion() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.jvm.functions.Function1<kotlinx.serialization.json.JsonObject, kotlinx.serialization.json.JsonObject> getTransformation() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component1() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.jvm.functions.Function1<kotlinx.serialization.json.JsonObject, kotlinx.serialization.json.JsonObject> component2() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.data.theme.CustomThemeSerializer.MigrationStrategy copy(@org.jetbrains.annotations.NotNull()
        java.lang.String version, @org.jetbrains.annotations.NotNull()
        kotlin.jvm.functions.Function1<? super kotlinx.serialization.json.JsonObject, kotlinx.serialization.json.JsonObject> transformation) {
            return null;
        }
        
        @java.lang.Override()
        public boolean equals(@org.jetbrains.annotations.Nullable()
        java.lang.Object other) {
            return false;
        }
        
        @java.lang.Override()
        public int hashCode() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String toString() {
            return null;
        }
    }
}
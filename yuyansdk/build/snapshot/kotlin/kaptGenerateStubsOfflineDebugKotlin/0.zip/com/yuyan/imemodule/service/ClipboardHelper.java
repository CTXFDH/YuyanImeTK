package com.yuyan.imemodule.service;

/**
 * 剪切板监听
 * 移除使用广播监听方式，解决部分手机后台无法启动监听服务异常(API level 31)。
 * 增加后台线程异步 I/O 写入与重复记录去重逻辑，防止磁盘 I/O 阻塞 UI 主线程。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0005\u001a\u00020\u0006J\b\u0010\u0007\u001a\u00020\u0006H\u0016R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/service/ClipboardHelper;", "Landroid/content/ClipboardManager$OnPrimaryClipChangedListener;", "()V", "lastCopiedText", "", "init", "", "onPrimaryClipChanged", "yuyansdk_offlineDebug"})
public final class ClipboardHelper implements android.content.ClipboardManager.OnPrimaryClipChangedListener {
    @kotlin.jvm.Volatile()
    @org.jetbrains.annotations.Nullable()
    private static volatile java.lang.String lastCopiedText;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.service.ClipboardHelper INSTANCE = null;
    
    private ClipboardHelper() {
        super();
    }
    
    public final void init() {
    }
    
    @java.lang.Override()
    public void onPrimaryClipChanged() {
    }
}
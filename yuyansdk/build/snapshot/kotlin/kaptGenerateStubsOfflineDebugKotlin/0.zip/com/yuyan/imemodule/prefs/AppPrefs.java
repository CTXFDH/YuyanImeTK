package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\n\b\u0007\u0018\u0000 ,2\u00020\u0001:\u0007+,-./01B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J)\u0010\"\u001a\u0002H#\"\b\b\u0000\u0010#*\u00020!2\u0012\u0010$\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u0002H#0%\u00a2\u0006\u0002\u0010&J\b\u0010\'\u001a\u00020(H\u0007J\u001b\u0010)\u001a\u0002H#\"\b\b\u0000\u0010#*\u00020!*\u0002H#H\u0002\u00a2\u0006\u0002\u0010*R\u0015\u0010\u0005\u001a\u00060\u0006R\u00020\u0000\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0015\u0010\t\u001a\u00060\nR\u00020\u0000\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0015\u0010\r\u001a\u00060\u000eR\u00020\u0000\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0015\u0010\u0011\u001a\u00060\u0012R\u00020\u0000\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0015\u0010\u0015\u001a\u00060\u0016R\u00020\u0000\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0015\u0010\u001b\u001a\u00060\u001cR\u00020\u0000\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0014\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020!0 X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u00062"}, d2 = {"Lcom/yuyan/imemodule/prefs/AppPrefs;", "", "sharedPreferences", "Landroid/content/SharedPreferences;", "(Landroid/content/SharedPreferences;)V", "clipboard", "Lcom/yuyan/imemodule/prefs/AppPrefs$Clipboard;", "getClipboard", "()Lcom/yuyan/imemodule/prefs/AppPrefs$Clipboard;", "handwriting", "Lcom/yuyan/imemodule/prefs/AppPrefs$Handwriting;", "getHandwriting", "()Lcom/yuyan/imemodule/prefs/AppPrefs$Handwriting;", "input", "Lcom/yuyan/imemodule/prefs/AppPrefs$Input;", "getInput", "()Lcom/yuyan/imemodule/prefs/AppPrefs$Input;", "internal", "Lcom/yuyan/imemodule/prefs/AppPrefs$Internal;", "getInternal", "()Lcom/yuyan/imemodule/prefs/AppPrefs$Internal;", "keyboardSetting", "Lcom/yuyan/imemodule/prefs/AppPrefs$KeyboardSetting;", "getKeyboardSetting", "()Lcom/yuyan/imemodule/prefs/AppPrefs$KeyboardSetting;", "onSharedPreferenceChangeListener", "Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;", "other", "Lcom/yuyan/imemodule/prefs/AppPrefs$Other;", "getOther", "()Lcom/yuyan/imemodule/prefs/AppPrefs$Other;", "providers", "", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "registerProvider", "T", "providerF", "Lkotlin/Function1;", "(Lkotlin/jvm/functions/Function1;)Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "syncToDeviceEncryptedStorage", "", "register", "(Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;)Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "Clipboard", "Companion", "Handwriting", "Input", "Internal", "KeyboardSetting", "Other", "yuyansdk_offlineDebug"})
public final class AppPrefs {
    @org.jetbrains.annotations.NotNull()
    private final android.content.SharedPreferences sharedPreferences = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.prefs.ManagedPreferenceProvider> providers = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.AppPrefs.Internal internal = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.AppPrefs.Handwriting handwriting = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.AppPrefs.Input input = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.AppPrefs.Clipboard clipboard = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.AppPrefs.KeyboardSetting keyboardSetting = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.AppPrefs.Other other = null;
    @org.jetbrains.annotations.NotNull()
    private final android.content.SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener = null;
    @org.jetbrains.annotations.Nullable()
    private static com.yuyan.imemodule.prefs.AppPrefs instance;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.prefs.AppPrefs.Companion Companion = null;
    
    public AppPrefs(@org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences sharedPreferences) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final <T extends com.yuyan.imemodule.prefs.ManagedPreferenceProvider>T registerProvider(@org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super android.content.SharedPreferences, ? extends T> providerF) {
        return null;
    }
    
    private final <T extends com.yuyan.imemodule.prefs.ManagedPreferenceProvider>T register(T $this$register) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.AppPrefs.Internal getInternal() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.AppPrefs.Handwriting getHandwriting() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.AppPrefs.Input getInput() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.AppPrefs.Clipboard getClipboard() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.AppPrefs.KeyboardSetting getKeyboardSetting() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.AppPrefs.Other getOther() {
        return null;
    }
    
    @androidx.annotation.RequiresApi(value = android.os.Build.VERSION_CODES.N)
    public final void syncToDeviceEncryptedStorage() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0012\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011\u00a8\u0006\u0014"}, d2 = {"Lcom/yuyan/imemodule/prefs/AppPrefs$Clipboard;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceCategory;", "(Lcom/yuyan/imemodule/prefs/AppPrefs;)V", "clipboardHistoryLimit", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "getClipboardHistoryLimit", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "clipboardItemTimeout", "getClipboardItemTimeout", "clipboardLayoutCompact", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "Lcom/yuyan/imemodule/prefs/behavior/ClipboardLayoutMode;", "getClipboardLayoutCompact", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "clipboardListening", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "getClipboardListening", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "clipboardSuggestion", "getClipboardSuggestion", "yuyansdk_offlineDebug"})
    public final class Clipboard extends com.yuyan.imemodule.prefs.ManagedPreferenceCategory {
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool clipboardListening = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt clipboardHistoryLimit = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool clipboardSuggestion = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt clipboardItemTimeout = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.ClipboardLayoutMode> clipboardLayoutCompact = null;
        
        public Clipboard() {
            super(0, null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getClipboardListening() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getClipboardHistoryLimit() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getClipboardSuggestion() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getClipboardItemTimeout() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.ClipboardLayoutMode> getClipboardLayoutCompact() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0005\u001a\u00020\u0004J\u000e\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tR\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/imemodule/prefs/AppPrefs$Companion;", "", "()V", "instance", "Lcom/yuyan/imemodule/prefs/AppPrefs;", "getInstance", "init", "", "sharedPreferences", "Landroid/content/SharedPreferences;", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        /**
         * MUST call before use
         */
        public final void init(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences sharedPreferences) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.prefs.AppPrefs getInstance() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/prefs/AppPrefs$Handwriting;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceCategory;", "(Lcom/yuyan/imemodule/prefs/AppPrefs;)V", "handWritingSpeed", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "getHandWritingSpeed", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "handWritingWidth", "getHandWritingWidth", "yuyansdk_offlineDebug"})
    public final class Handwriting extends com.yuyan.imemodule.prefs.ManagedPreferenceCategory {
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt handWritingWidth = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt handWritingSpeed = null;
        
        public Handwriting() {
            super(0, null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getHandWritingWidth() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getHandWritingSpeed() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\n\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0011\u0010\t\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0006R\u0011\u0010\u000b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u0006R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0017\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00130\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0011R\u0011\u0010\u0015\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0006R\u0011\u0010\u0017\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0006R\u0013\u0010\u0019\u001a\u00020\u001a\u00a2\u0006\n\n\u0002\u0010\u001d\u001a\u0004\b\u001b\u0010\u001cR\u0013\u0010\u001e\u001a\u00020\u001a\u00a2\u0006\n\n\u0002\u0010\u001d\u001a\u0004\b\u001f\u0010\u001cR\u0013\u0010 \u001a\u00020\u001a\u00a2\u0006\n\n\u0002\u0010\u001d\u001a\u0004\b!\u0010\u001cR\u0013\u0010\"\u001a\u00020\u001a\u00a2\u0006\n\n\u0002\u0010\u001d\u001a\u0004\b#\u0010\u001c\u00a8\u0006$"}, d2 = {"Lcom/yuyan/imemodule/prefs/AppPrefs$Input;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceCategory;", "(Lcom/yuyan/imemodule/prefs/AppPrefs;)V", "abcSearchEnglishCell", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "getAbcSearchEnglishCell", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "abcSpaceAuto", "getAbcSpaceAuto", "chineseFanTi", "getChineseFanTi", "chinesePredictionDate", "getChinesePredictionDate", "chinesePredictionMode", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "Lcom/yuyan/imemodule/prefs/behavior/ChineseAssociationMode;", "getChinesePredictionMode", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "doublePYSchemaMode", "Lcom/yuyan/imemodule/prefs/behavior/DoublePinyinSchemaMode;", "getDoublePYSchemaMode", "emojiInput", "getEmojiInput", "symbolPairInput", "getSymbolPairInput", "titleChinese", "", "getTitleChinese", "()Lkotlin/Unit;", "Lkotlin/Unit;", "titleEmoji", "getTitleEmoji", "titleEnglish", "getTitleEnglish", "titleSymbol", "getTitleSymbol", "yuyansdk_offlineDebug"})
    public final class Input extends com.yuyan.imemodule.prefs.ManagedPreferenceCategory {
        @org.jetbrains.annotations.NotNull()
        private final kotlin.Unit titleChinese = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool chineseFanTi = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.DoublePinyinSchemaMode> doublePYSchemaMode = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.ChineseAssociationMode> chinesePredictionMode = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool chinesePredictionDate = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.Unit titleEnglish = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool abcSearchEnglishCell = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool abcSpaceAuto = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.Unit titleEmoji = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool emojiInput = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.Unit titleSymbol = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool symbolPairInput = null;
        
        public Input() {
            super(0, null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.Unit getTitleChinese() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getChineseFanTi() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.DoublePinyinSchemaMode> getDoublePYSchemaMode() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.ChineseAssociationMode> getChinesePredictionMode() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getChinesePredictionDate() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.Unit getTitleEnglish() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getAbcSearchEnglishCell() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getAbcSpaceAuto() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.Unit getTitleEmoji() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getEmojiInput() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.Unit getTitleSymbol() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getSymbolPairInput() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b9\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\u0006R\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\r\u001a\u00020\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0011\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0006R\u0011\u0010\u0017\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0006R\u0011\u0010\u0019\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0006R\u0011\u0010\u001b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0006R\u0011\u0010\u001d\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\fR\u0011\u0010\u001f\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\fR\u0011\u0010!\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\fR\u0011\u0010#\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010&R\u0011\u0010\'\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010\u0014R\u0011\u0010)\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010\u0014R\u0011\u0010+\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b,\u0010\u0014R\u0011\u0010-\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b.\u0010\u0014R\u0011\u0010/\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u0010\u0014R\u0011\u00101\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u0010\u0014R\u0011\u00103\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b4\u0010\u0006R\u0011\u00105\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b6\u0010\u0006R\u0011\u00107\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\b8\u0010&R\u0011\u00109\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\b:\u0010&R\u0011\u0010;\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b<\u0010\u0014R\u0011\u0010=\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b>\u0010\u0014R\u0011\u0010?\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b@\u0010\u0014R\u0011\u0010A\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\bB\u0010&R\u0011\u0010C\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\bD\u0010&R\u0011\u0010E\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\bF\u0010&R\u0011\u0010G\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\bH\u0010\fR\u0011\u0010I\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\bJ\u0010&R\u0011\u0010K\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\bL\u0010\fR\u0011\u0010M\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\bN\u0010\fR\u0011\u0010O\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\bP\u0010\fR\u0011\u0010Q\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\bR\u0010\fR\u0011\u0010S\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\bT\u0010\fR\u0011\u0010U\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\bV\u0010\u0014R\u0011\u0010W\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\bX\u0010\fR\u0011\u0010Y\u001a\u00020$\u00a2\u0006\b\n\u0000\u001a\u0004\bZ\u0010&R\u0011\u0010[\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\\\u0010\u0014\u00a8\u0006]"}, d2 = {"Lcom/yuyan/imemodule/prefs/AppPrefs$Internal;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceInternal;", "(Lcom/yuyan/imemodule/prefs/AppPrefs;)V", "candidatesHeightRatio", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PFloat;", "getCandidatesHeightRatio", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PFloat;", "candidatesHeightRatioLandscape", "getCandidatesHeightRatioLandscape", "clipboardUpdateContent", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PString;", "getClipboardUpdateContent", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PString;", "clipboardUpdateTime", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PLong;", "getClipboardUpdateTime", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PLong;", "dataDictVersion", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "getDataDictVersion", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "floatTranslationXLand", "getFloatTranslationXLand", "floatTranslationXPort", "getFloatTranslationXPort", "floatTranslationYLand", "getFloatTranslationYLand", "floatTranslationYPort", "getFloatTranslationYPort", "fullDisplayCenterMode", "getFullDisplayCenterMode", "fullDisplayKeyModeLeft", "getFullDisplayKeyModeLeft", "fullDisplayKeyModeRight", "getFullDisplayKeyModeRight", "fullDisplayKeyboardEnable", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "getFullDisplayKeyboardEnable", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "inputDefaultMode", "getInputDefaultMode", "inputMethodPinyinMode", "getInputMethodPinyinMode", "keyPressVolume", "getKeyPressVolume", "keyboardBottomPadding", "getKeyboardBottomPadding", "keyboardBottomPaddingFloat", "getKeyboardBottomPaddingFloat", "keyboardBottomPaddingLandscapeFloat", "getKeyboardBottomPaddingLandscapeFloat", "keyboardHeightRatio", "getKeyboardHeightRatio", "keyboardHeightRatioLandscape", "getKeyboardHeightRatioLandscape", "keyboardModeFloat", "getKeyboardModeFloat", "keyboardModeFloatLandscape", "getKeyboardModeFloatLandscape", "keyboardRightPadding", "getKeyboardRightPadding", "keyboardRightPaddingFloat", "getKeyboardRightPaddingFloat", "keyboardRightPaddingLandscapeFloat", "getKeyboardRightPaddingLandscapeFloat", "lockClipBoardEnable", "getLockClipBoardEnable", "lockExpressionEnable", "getLockExpressionEnable", "lockSymbolEnable", "getLockSymbolEnable", "pinyinModeRime", "getPinyinModeRime", "privacyPolicySure", "getPrivacyPolicySure", "soundEffectDelete", "getSoundEffectDelete", "soundEffectReturn", "getSoundEffectReturn", "soundEffectSpaceBar", "getSoundEffectSpaceBar", "soundEffectStandard", "getSoundEffectStandard", "soundEndTime", "getSoundEndTime", "soundOnKeyPress", "getSoundOnKeyPress", "soundStartTime", "getSoundStartTime", "soundTimeRangeEnable", "getSoundTimeRangeEnable", "vibrationAmplitude", "getVibrationAmplitude", "yuyansdk_offlineDebug"})
    public final class Internal extends com.yuyan.imemodule.prefs.ManagedPreferenceInternal {
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString pinyinModeRime = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt inputDefaultMode = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt inputMethodPinyinMode = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt dataDictVersion = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat keyboardHeightRatio = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat keyboardHeightRatioLandscape = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat candidatesHeightRatio = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat candidatesHeightRatioLandscape = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardModeFloat = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardModeFloatLandscape = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardBottomPaddingFloat = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardRightPaddingFloat = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardBottomPaddingLandscapeFloat = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardRightPaddingLandscapeFloat = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardBottomPadding = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardRightPadding = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PLong clipboardUpdateTime = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString clipboardUpdateContent = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool fullDisplayKeyboardEnable = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString fullDisplayKeyModeLeft = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString fullDisplayKeyModeRight = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString fullDisplayCenterMode = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt soundOnKeyPress = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyPressVolume = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt vibrationAmplitude = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool soundTimeRangeEnable = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundStartTime = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEndTime = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEffectStandard = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEffectSpaceBar = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEffectDelete = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEffectReturn = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool privacyPolicySure = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool lockSymbolEnable = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool lockExpressionEnable = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool lockClipBoardEnable = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat floatTranslationXPort = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat floatTranslationYPort = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat floatTranslationXLand = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat floatTranslationYLand = null;
        
        public Internal() {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getPinyinModeRime() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getInputDefaultMode() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getInputMethodPinyinMode() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getDataDictVersion() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat getKeyboardHeightRatio() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat getKeyboardHeightRatioLandscape() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat getCandidatesHeightRatio() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat getCandidatesHeightRatioLandscape() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardModeFloat() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardModeFloatLandscape() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardBottomPaddingFloat() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardRightPaddingFloat() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardBottomPaddingLandscapeFloat() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardRightPaddingLandscapeFloat() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardBottomPadding() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardRightPadding() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PLong getClipboardUpdateTime() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getClipboardUpdateContent() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getFullDisplayKeyboardEnable() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getFullDisplayKeyModeLeft() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getFullDisplayKeyModeRight() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getFullDisplayCenterMode() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getSoundOnKeyPress() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyPressVolume() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getVibrationAmplitude() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getSoundTimeRangeEnable() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getSoundStartTime() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getSoundEndTime() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getSoundEffectStandard() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getSoundEffectSpaceBar() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getSoundEffectDelete() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PString getSoundEffectReturn() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getPrivacyPolicySure() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getLockSymbolEnable() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getLockExpressionEnable() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getLockClipBoardEnable() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat getFloatTranslationXPort() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat getFloatTranslationYPort() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat getFloatTranslationXLand() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PFloat getFloatTranslationYLand() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\n\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0013\u0010\u000b\u001a\u00020\f\u00a2\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\r\u0010\u000eR\u0013\u0010\u0010\u001a\u00020\f\u00a2\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\u0011\u0010\u000eR\u0013\u0010\u0012\u001a\u00020\f\u00a2\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\u0013\u0010\u000eR\u0013\u0010\u0014\u001a\u00020\f\u00a2\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\u0015\u0010\u000eR\u0017\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00180\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u001b\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0006R\u0011\u0010\u001d\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0006R\u0011\u0010\u001f\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u0006R\u0011\u0010!\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010\u0006R\u0011\u0010#\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010\nR\u0011\u0010%\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010\u0006R\u0017\u0010\'\u001a\b\u0012\u0004\u0012\u00020(0\u0017\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010\u001aR\u0011\u0010*\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010\u0006R\u0011\u0010,\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b-\u0010\u0006R\u0011\u0010.\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u0010\u0006R\u0011\u00100\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u0010\n\u00a8\u00062"}, d2 = {"Lcom/yuyan/imemodule/prefs/AppPrefs$KeyboardSetting;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceCategory;", "(Lcom/yuyan/imemodule/prefs/AppPrefs;)V", "abcNumberLine", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "getAbcNumberLine", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "candidateTextSize", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "getCandidateTextSize", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "categoryKeys", "", "getCategoryKeys", "()Lkotlin/Unit;", "Lkotlin/Unit;", "categoryLayout", "getCategoryLayout", "categoryModes", "getCategoryModes", "categoryPeripherals", "getCategoryPeripherals", "halfWidthSymbolsMode", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "Lcom/yuyan/imemodule/prefs/behavior/HalfWidthSymbolsMode;", "getHalfWidthSymbolsMode", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "keyboardBalloonShow", "getKeyboardBalloonShow", "keyboardDoubleInputKey", "getKeyboardDoubleInputKey", "keyboardLockEnglish", "getKeyboardLockEnglish", "keyboardMnemonic", "getKeyboardMnemonic", "longPressTimeout", "getLongPressTimeout", "lx17WithLeftPrefix", "getLx17WithLeftPrefix", "oneHandedMod", "Lcom/yuyan/imemodule/prefs/behavior/KeyboardOneHandedMod;", "getOneHandedMod", "oneHandedModSwitch", "getOneHandedModSwitch", "showVirtualKeyboardOnPhysicalKeyboard", "getShowVirtualKeyboardOnPhysicalKeyboard", "spaceSwipeMoveCursor", "getSpaceSwipeMoveCursor", "spaceSwipeMoveCursorSpeed", "getSpaceSwipeMoveCursorSpeed", "yuyansdk_offlineDebug"})
    public final class KeyboardSetting extends com.yuyan.imemodule.prefs.ManagedPreferenceCategory {
        @org.jetbrains.annotations.NotNull()
        private final kotlin.Unit categoryLayout = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.KeyboardOneHandedMod> oneHandedMod = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool oneHandedModSwitch = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt candidateTextSize = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.Unit categoryKeys = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardBalloonShow = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt longPressTimeout = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool spaceSwipeMoveCursor = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt spaceSwipeMoveCursorSpeed = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.Unit categoryModes = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool abcNumberLine = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardLockEnglish = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardDoubleInputKey = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardMnemonic = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool lx17WithLeftPrefix = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlin.Unit categoryPeripherals = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.HalfWidthSymbolsMode> halfWidthSymbolsMode = null;
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool showVirtualKeyboardOnPhysicalKeyboard = null;
        
        public KeyboardSetting() {
            super(0, null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.Unit getCategoryLayout() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.KeyboardOneHandedMod> getOneHandedMod() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getOneHandedModSwitch() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getCandidateTextSize() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.Unit getCategoryKeys() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardBalloonShow() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getLongPressTimeout() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getSpaceSwipeMoveCursor() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getSpaceSwipeMoveCursorSpeed() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.Unit getCategoryModes() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getAbcNumberLine() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardLockEnglish() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardDoubleInputKey() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardMnemonic() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getLx17WithLeftPrefix() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlin.Unit getCategoryPeripherals() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.HalfWidthSymbolsMode> getHalfWidthSymbolsMode() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getShowVirtualKeyboardOnPhysicalKeyboard() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/prefs/AppPrefs$Other;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceCategory;", "(Lcom/yuyan/imemodule/prefs/AppPrefs;)V", "imeHideIcon", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "getImeHideIcon", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "yuyansdk_offlineDebug"})
    public final class Other extends com.yuyan.imemodule.prefs.ManagedPreferenceCategory {
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool imeHideIcon = null;
        
        public Other() {
            super(0, null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getImeHideIcon() {
            return null;
        }
    }
}
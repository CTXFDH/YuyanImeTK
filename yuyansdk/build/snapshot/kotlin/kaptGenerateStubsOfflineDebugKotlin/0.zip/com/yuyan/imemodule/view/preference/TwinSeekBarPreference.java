package com.yuyan.imemodule.view.preference;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b$\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0017\u0018\u00002\u00020\u0001:\u0001JB\u001b\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006J\b\u00103\u001a\u000204H\u0014J\u0012\u00105\u001a\u0002042\b\u00106\u001a\u0004\u0018\u000107H\u0014J\u0018\u00108\u001a\u0002042\u0006\u00109\u001a\u00020\b2\u0006\u0010:\u001a\u00020\bH\u0002J\u0010\u0010;\u001a\u00020\b2\u0006\u00101\u001a\u00020\bH\u0002J\u0012\u0010<\u001a\u0002042\b\u00106\u001a\u0004\u0018\u000107H\u0016J\u0018\u0010=\u001a\u0002042\u0006\u00109\u001a\u00020\b2\u0006\u0010:\u001a\u00020\bH\u0002J\b\u0010>\u001a\u000204H\u0002J!\u0010?\u001a\u00020\u000f2\u0006\u00101\u001a\u00020\b2\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0002\u00a2\u0006\u0002\u0010@J\u0010\u0010A\u001a\u00020\b2\u0006\u0010B\u001a\u00020\bH\u0002J9\u0010C\u001a\u00020D*\u00020E2\u0006\u0010\u0014\u001a\u00020\u000f2\u0006\u0010F\u001a\u00020\b2\n\b\u0002\u00106\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010G\u001a\u0004\u0018\u00010HH\u0002\u00a2\u0006\u0002\u0010IR\u001e\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010\r\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001c\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0014\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0011\"\u0004\b\u0016\u0010\u0013R\u001a\u0010\u0017\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u001a\u0010\u001c\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u0019\"\u0004\b\u001e\u0010\u001bR\u001e\u0010\u001f\u001a\u0004\u0018\u00010\bX\u0086\u000e\u00a2\u0006\u0010\n\u0002\u0010\r\u001a\u0004\b \u0010\n\"\u0004\b!\u0010\fR\u001a\u0010\"\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b#\u0010\u0011\"\u0004\b$\u0010\u0013R\u001a\u0010%\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b&\u0010\u0011\"\u0004\b\'\u0010\u0013R\u001e\u0010)\u001a\u00020\b2\u0006\u0010(\u001a\u00020\b@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010\u0019R\u001a\u0010+\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b,\u0010\u0019\"\u0004\b-\u0010\u001bR\u001a\u0010.\u001a\u00020\u000fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b/\u0010\u0011\"\u0004\b0\u0010\u0013R\u001e\u00101\u001a\u00020\b2\u0006\u0010(\u001a\u00020\b@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u0010\u0019\u00a8\u0006K"}, d2 = {"Lcom/yuyan/imemodule/view/preference/TwinSeekBarPreference;", "Landroidx/preference/DialogPreference;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "default", "", "getDefault", "()Ljava/lang/Integer;", "setDefault", "(Ljava/lang/Integer;)V", "Ljava/lang/Integer;", "defaultLabel", "", "getDefaultLabel", "()Ljava/lang/String;", "setDefaultLabel", "(Ljava/lang/String;)V", "label", "getLabel", "setLabel", "max", "getMax", "()I", "setMax", "(I)V", "min", "getMin", "setMin", "secondaryDefault", "getSecondaryDefault", "setSecondaryDefault", "secondaryKey", "getSecondaryKey", "setSecondaryKey", "secondaryLabel", "getSecondaryLabel", "setSecondaryLabel", "<set-?>", "secondaryValue", "getSecondaryValue", "step", "getStep", "setStep", "unit", "getUnit", "setUnit", "value", "getValue", "onClick", "", "onSetInitialValue", "defaultValue", "", "persistValues", "primary", "secondary", "progressForValue", "setDefaultValue", "setValue", "showDialog", "textForValue", "(ILjava/lang/Integer;)Ljava/lang/String;", "valueForProgress", "progress", "addSeekBar", "Landroid/widget/SeekBar;", "Landroidx/constraintlayout/widget/ConstraintLayout;", "initialValue", "belowView", "Landroid/view/View;", "(Landroidx/constraintlayout/widget/ConstraintLayout;Ljava/lang/String;ILjava/lang/Integer;Landroid/view/View;)Landroid/widget/SeekBar;", "SimpleSummaryProvider", "yuyansdk_offlineDebug"})
public class TwinSeekBarPreference extends androidx.preference.DialogPreference {
    private int min = 0;
    private int max = 100;
    private int step = 1;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String unit = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String label = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String secondaryKey = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String secondaryLabel = "";
    @org.jetbrains.annotations.Nullable()
    private java.lang.Integer secondaryDefault;
    @org.jetbrains.annotations.Nullable()
    private java.lang.String defaultLabel;
    private int value = 0;
    private int secondaryValue = 0;
    
    @kotlin.jvm.JvmOverloads()
    public TwinSeekBarPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null, null, 0, 0);
    }
    
    @kotlin.jvm.JvmOverloads()
    public TwinSeekBarPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null, null, 0, 0);
    }
    
    public final int getMin() {
        return 0;
    }
    
    public final void setMin(int p0) {
    }
    
    public final int getMax() {
        return 0;
    }
    
    public final void setMax(int p0) {
    }
    
    public final int getStep() {
        return 0;
    }
    
    public final void setStep(int p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getUnit() {
        return null;
    }
    
    public final void setUnit(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getLabel() {
        return null;
    }
    
    public final void setLabel(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getSecondaryKey() {
        return null;
    }
    
    public final void setSecondaryKey(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getSecondaryLabel() {
        return null;
    }
    
    public final void setSecondaryLabel(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer getDefault() {
        return null;
    }
    
    public final void setDefault(@org.jetbrains.annotations.Nullable()
    java.lang.Integer p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer getSecondaryDefault() {
        return null;
    }
    
    public final void setSecondaryDefault(@org.jetbrains.annotations.Nullable()
    java.lang.Integer p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getDefaultLabel() {
        return null;
    }
    
    public final void setDefaultLabel(@org.jetbrains.annotations.Nullable()
    java.lang.String p0) {
    }
    
    public final int getValue() {
        return 0;
    }
    
    public final int getSecondaryValue() {
        return 0;
    }
    
    @java.lang.Override()
    protected void onSetInitialValue(@org.jetbrains.annotations.Nullable()
    java.lang.Object defaultValue) {
    }
    
    @java.lang.Override()
    public void setDefaultValue(@org.jetbrains.annotations.Nullable()
    java.lang.Object defaultValue) {
    }
    
    private final void persistValues(int primary, int secondary) {
    }
    
    @java.lang.Override()
    protected void onClick() {
    }
    
    private final android.widget.SeekBar addSeekBar(androidx.constraintlayout.widget.ConstraintLayout $this$addSeekBar, java.lang.String label, int initialValue, java.lang.Integer defaultValue, android.view.View belowView) {
        return null;
    }
    
    private final void showDialog() {
    }
    
    private final void setValue(int primary, int secondary) {
    }
    
    private final int progressForValue(int value) {
        return 0;
    }
    
    private final int valueForProgress(int progress) {
        return 0;
    }
    
    private final java.lang.String textForValue(int value, java.lang.Integer p1_772401952) {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\r\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0002H\u0016\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/view/preference/TwinSeekBarPreference$SimpleSummaryProvider;", "Landroidx/preference/Preference$SummaryProvider;", "Lcom/yuyan/imemodule/view/preference/TwinSeekBarPreference;", "()V", "provideSummary", "", "preference", "yuyansdk_offlineDebug"})
    public static final class SimpleSummaryProvider implements androidx.preference.Preference.SummaryProvider<com.yuyan.imemodule.view.preference.TwinSeekBarPreference> {
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.view.preference.TwinSeekBarPreference.SimpleSummaryProvider INSTANCE = null;
        
        private SimpleSummaryProvider() {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.CharSequence provideSummary(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.view.preference.TwinSeekBarPreference preference) {
            return null;
        }
    }
}
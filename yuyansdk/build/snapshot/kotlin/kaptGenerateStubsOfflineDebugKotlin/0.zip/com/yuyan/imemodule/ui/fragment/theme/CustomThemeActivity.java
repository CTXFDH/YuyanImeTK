package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0094\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0019\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b.\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b>\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\n\b\u0007\u0018\u0000 \u00e1\u00022\u00020\u0001:\b\u00df\u0002\u00e0\u0002\u00e1\u0002\u00e2\u0002B\u0005\u00a2\u0006\u0002\u0010\u0002J\n\u0010\u0084\u0002\u001a\u00030\u0085\u0002H\u0002J)\u0010\u0086\u0002\u001a\u00030\u0085\u00022\b\u0010\u0087\u0002\u001a\u00030\u0088\u00022\b\u0010\u0089\u0002\u001a\u00030\u008a\u00022\t\b\u0002\u0010\u008b\u0002\u001a\u00020\u0011H\u0002J)\u0010\u008c\u0002\u001a\u00020\'2\u0007\u0010\u008d\u0002\u001a\u00020L2\u0015\u0010\u008e\u0002\u001a\u0010\u0012\u0004\u0012\u00020\u0004\u0012\u0005\u0012\u00030\u0085\u00020\u008f\u0002H\u0002JN\u0010\u0090\u0002\u001a\u00020\u00042\u0007\u0010\u0091\u0002\u001a\u00020L2\u000e\u0010\u0092\u0002\u001a\t\u0012\u0004\u0012\u00020\u00110\u0093\u00022\u0013\b\u0002\u0010\u0094\u0002\u001a\f\u0012\u0005\u0012\u00030\u0085\u0002\u0018\u00010\u0093\u00022\u0015\u0010\u0095\u0002\u001a\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0005\u0012\u00030\u0085\u00020\u008f\u0002H\u0002J9\u0010\u0090\u0002\u001a\u00020\u00042\u0007\u0010\u0091\u0002\u001a\u00020L2\u000e\u0010\u0092\u0002\u001a\t\u0012\u0004\u0012\u00020\u00110\u0093\u00022\u0015\u0010\u0095\u0002\u001a\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0005\u0012\u00030\u0085\u00020\u008f\u0002H\u0002J0\u0010\u0096\u0002\u001a\u00020\u00042\u000e\u0010\u0097\u0002\u001a\t\u0012\u0004\u0012\u00020\u00110\u0093\u00022\u0015\u0010\u0098\u0002\u001a\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0005\u0012\u00030\u0085\u00020\u008f\u0002H\u0002J)\u0010\u0099\u0002\u001a\u00020\'2\u0007\u0010\u008d\u0002\u001a\u00020L2\u0015\u0010\u008e\u0002\u001a\u0010\u0012\u0004\u0012\u00020\u0004\u0012\u0005\u0012\u00030\u0085\u00020\u008f\u0002H\u0002J\'\u0010\u009a\u0002\u001a\u00020\'2\u000b\b\u0003\u0010\u009b\u0002\u001a\u0004\u0018\u00010\u00112\t\b\u0002\u0010\u009c\u0002\u001a\u00020hH\u0002\u00a2\u0006\u0003\u0010\u009d\u0002J\n\u0010\u009e\u0002\u001a\u00030\u0085\u0002H\u0002J\n\u0010\u009f\u0002\u001a\u00030\u0085\u0002H\u0002J\t\u0010\u00a0\u0002\u001a\u00020LH\u0002J\n\u0010\u00a1\u0002\u001a\u00030\u00a2\u0002H\u0002J\t\u0010\u00a3\u0002\u001a\u00020\u0011H\u0002J\u0014\u0010\u00a4\u0002\u001a\u00030\u0085\u00022\b\u0010\u00a5\u0002\u001a\u00030\u00a6\u0002H\u0002J\n\u0010\u00a7\u0002\u001a\u00030\u0085\u0002H\u0002J\n\u0010\u00a8\u0002\u001a\u00030\u0085\u0002H\u0002J\u0013\u0010\u00a9\u0002\u001a\u00020h2\b\u0010\u00a5\u0002\u001a\u00030\u00a6\u0002H\u0002J\u0013\u0010\u00aa\u0002\u001a\u00020h2\b\u0010\u00a5\u0002\u001a\u00030\u00a6\u0002H\u0002J\u0016\u0010\u00ab\u0002\u001a\u00030\u0085\u00022\n\u0010\u00ac\u0002\u001a\u0005\u0018\u00010\u00ad\u0002H\u0014J\u0013\u0010\u00ae\u0002\u001a\u00020h2\b\u0010\u00af\u0002\u001a\u00030\u00b0\u0002H\u0016J\u0013\u0010\u00b1\u0002\u001a\u00020h2\b\u0010\u00b2\u0002\u001a\u00030\u00b3\u0002H\u0016J\n\u0010\u00b4\u0002\u001a\u00030\u0085\u0002H\u0002J\n\u0010\u00b5\u0002\u001a\u00030\u0085\u0002H\u0002J\n\u0010\u00b6\u0002\u001a\u00030\u0085\u0002H\u0002J-\u0010\u00b7\u0002\u001a\u00030\u0085\u00022\b\u0010\u00b8\u0002\u001a\u00030\u00b9\u00022\t\u0010\u00ba\u0002\u001a\u0004\u0018\u00010\u00042\f\b\u0002\u0010\u00bb\u0002\u001a\u0005\u0018\u00010\u00bc\u0002H\u0002J/\u0010\u00bd\u0002\u001a\u00030\u0085\u00022\u0007\u0010\u0091\u0002\u001a\u00020L2\u0014\u0010\u00be\u0002\u001a\u000b\u0012\u0006\b\u0001\u0012\u00020\u00040\u00bf\u0002\"\u00020\u0004H\u0002\u00a2\u0006\u0003\u0010\u00c0\u0002J\u001f\u0010\u00c1\u0002\u001a\u00030\u0085\u00022\n\u0010\u00c2\u0002\u001a\u0005\u0018\u00010\u00c3\u00022\u0007\u0010\u00c4\u0002\u001a\u00020hH\u0002J@\u0010\u00c5\u0002\u001a\u00030\u0085\u00022\u0007\u0010\u00c6\u0002\u001a\u00020\u00042\u000e\u0010\u00c7\u0002\u001a\t\u0012\u0004\u0012\u00020L0\u00bf\u00022\u0015\u0010\u00c8\u0002\u001a\u0010\u0012\u0004\u0012\u00020L\u0012\u0005\u0012\u00030\u0085\u00020\u008f\u0002H\u0002\u00a2\u0006\u0003\u0010\u00c9\u0002J3\u0010\u00ca\u0002\u001a\u00030\u0085\u00022\u0007\u0010\u0091\u0002\u001a\u00020L2\u0007\u0010\u00cb\u0002\u001a\u00020\u00112\u0015\u0010\u00cc\u0002\u001a\u0010\u0012\u0004\u0012\u00020\u0011\u0012\u0005\u0012\u00030\u0085\u00020\u008f\u0002H\u0002J\n\u0010\u00cd\u0002\u001a\u00030\u0085\u0002H\u0002J%\u0010\u00ce\u0002\u001a\u00030\u0085\u00022\u0007\u0010\u00cf\u0002\u001a\u00020\u00042\u0007\u0010\u00d0\u0002\u001a\u00020\u00112\u0007\u0010\u00d1\u0002\u001a\u00020hH\u0002J \u0010\u00d2\u0002\u001a\u00030\u0085\u00022\u0014\u0010\u00d3\u0002\u001a\u000f\u0012\u0004\u0012\u00020]\u0012\u0004\u0012\u00020]0\u008f\u0002H\u0002J\n\u0010\u00d4\u0002\u001a\u00030\u0085\u0002H\u0002J\n\u0010\u00d5\u0002\u001a\u00030\u0085\u0002H\u0003J1\u0010\u00d6\u0002\u001a\u00030\u0085\u00022$\u0010\u00d7\u0002\u001a\u001f\u0012\u0004\u0012\u00020\"\u0012\u0007\u0012\u0005\u0018\u00010\u00c3\u0002\u0012\u0005\u0012\u00030\u0085\u00020\u00d8\u0002\u00a2\u0006\u0003\b\u00d9\u0002H\u0082\bJ \u0010\u00da\u0002\u001a\u00030\u0085\u0002*\u00020\"2\u0007\u0010\u00db\u0002\u001a\u00020\u00112\u0007\u0010\u00dc\u0002\u001a\u00020\u0011H\u0002J\u0016\u0010\u00dd\u0002\u001a\u00020\u0011*\u00020\u00112\u0007\u0010\u00de\u0002\u001a\u00020\u0011H\u0002R\u001b\u0010\u0003\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0005\u0010\u0006R\u001b\u0010\t\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u000b\u0010\b\u001a\u0004\b\n\u0010\u0006R\u001b\u0010\f\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u000e\u0010\b\u001a\u0004\b\r\u0010\u0006R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001b\u0010\u0012\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0014\u0010\b\u001a\u0004\b\u0013\u0010\u0006R\u001b\u0010\u0015\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0017\u0010\b\u001a\u0004\b\u0016\u0010\u0006R\u001b\u0010\u0018\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u001a\u0010\b\u001a\u0004\b\u0019\u0010\u0006R\u001b\u0010\u001b\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u001d\u0010\b\u001a\u0004\b\u001c\u0010\u0006R\u001b\u0010\u001e\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b \u0010\b\u001a\u0004\b\u001f\u0010\u0006R\u001b\u0010!\u001a\u00020\"8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b%\u0010\b\u001a\u0004\b#\u0010$R\u001b\u0010&\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b*\u0010\b\u001a\u0004\b(\u0010)R\u001b\u0010+\u001a\u00020,8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b/\u0010\b\u001a\u0004\b-\u0010.R\u001b\u00100\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b2\u0010\b\u001a\u0004\b1\u0010)R\u001b\u00103\u001a\u00020,8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b5\u0010\b\u001a\u0004\b4\u0010.R\u001b\u00106\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b8\u0010\b\u001a\u0004\b7\u0010)R\u001b\u00109\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b;\u0010\b\u001a\u0004\b:\u0010)R\u001b\u0010<\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b>\u0010\b\u001a\u0004\b=\u0010)R\u001b\u0010?\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bA\u0010\b\u001a\u0004\b@\u0010)R\u001b\u0010B\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bD\u0010\b\u001a\u0004\bC\u0010\u0006R\u001b\u0010E\u001a\u00020F8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bI\u0010\b\u001a\u0004\bG\u0010HR\u001c\u0010J\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001b\u0010N\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bP\u0010\b\u001a\u0004\bO\u0010\u0006R\u001b\u0010Q\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bS\u0010\b\u001a\u0004\bR\u0010\u0006R\u001b\u0010T\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bV\u0010\b\u001a\u0004\bU\u0010\u0006R\u001b\u0010W\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bY\u0010\b\u001a\u0004\bX\u0010)R\u001c\u0010Z\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010[0[0KX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\\\u001a\u00020]X\u0082.\u00a2\u0006\u0002\n\u0000R\u001b\u0010^\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b`\u0010\b\u001a\u0004\b_\u0010\u0006R\u001b\u0010a\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bc\u0010\b\u001a\u0004\bb\u0010\u0006R\u001b\u0010d\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bf\u0010\b\u001a\u0004\be\u0010\u0006R\u000e\u0010g\u001a\u00020hX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001b\u0010i\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bk\u0010\b\u001a\u0004\bj\u0010\u0006R\u001b\u0010l\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bn\u0010\b\u001a\u0004\bm\u0010\u0006R\u001b\u0010o\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bq\u0010\b\u001a\u0004\bp\u0010\u0006R\u001b\u0010r\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bt\u0010\b\u001a\u0004\bs\u0010\u0006R\u001b\u0010u\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bw\u0010\b\u001a\u0004\bv\u0010\u0006R\u001b\u0010x\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bz\u0010\b\u001a\u0004\by\u0010)R\u000e\u0010{\u001a\u00020hX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001b\u0010|\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b~\u0010\b\u001a\u0004\b}\u0010\u0006R\u001d\u0010\u007f\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u0081\u0001\u0010\b\u001a\u0005\b\u0080\u0001\u0010\u0006R\u001e\u0010\u0082\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u0084\u0001\u0010\b\u001a\u0005\b\u0083\u0001\u0010\u0006R\u0011\u0010\u0085\u0001\u001a\u0004\u0018\u00010LX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0086\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u0088\u0001\u0010\b\u001a\u0005\b\u0087\u0001\u0010\u0006R\u001e\u0010\u0089\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u008b\u0001\u0010\b\u001a\u0005\b\u008a\u0001\u0010\u0006R\u001e\u0010\u008c\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u008e\u0001\u0010\b\u001a\u0005\b\u008d\u0001\u0010\u0006R\u001d\u0010\u008f\u0001\u001a\u0010\u0012\f\u0012\n M*\u0004\u0018\u00010L0L0KX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0090\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u0092\u0001\u0010\b\u001a\u0005\b\u0091\u0001\u0010\u0006R\u001e\u0010\u0093\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u0095\u0001\u0010\b\u001a\u0005\b\u0094\u0001\u0010\u0006R\u0010\u0010\u0096\u0001\u001a\u00030\u0097\u0001X\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0098\u0001\u001a\u00030\u0099\u0001X\u0082.\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u009a\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u009c\u0001\u0010\b\u001a\u0005\b\u009b\u0001\u0010\u0006R\u001e\u0010\u009d\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u009f\u0001\u0010\b\u001a\u0005\b\u009e\u0001\u0010\u0006R\u001e\u0010\u00a0\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00a2\u0001\u0010\b\u001a\u0005\b\u00a1\u0001\u0010\u0006R\u001e\u0010\u00a3\u0001\u001a\u00020F8BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00a5\u0001\u0010\b\u001a\u0005\b\u00a4\u0001\u0010HR\u001e\u0010\u00a6\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00a8\u0001\u0010\b\u001a\u0005\b\u00a7\u0001\u0010\u0006R\u001e\u0010\u00a9\u0001\u001a\u00020F8BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00ab\u0001\u0010\b\u001a\u0005\b\u00aa\u0001\u0010HR\u0011\u0010\u00ac\u0001\u001a\u0004\u0018\u00010LX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u00ad\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00af\u0001\u0010\b\u001a\u0005\b\u00ae\u0001\u0010\u0006R\u001e\u0010\u00b0\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00b2\u0001\u0010\b\u001a\u0005\b\u00b1\u0001\u0010\u0006R\u001e\u0010\u00b3\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00b5\u0001\u0010\b\u001a\u0005\b\u00b4\u0001\u0010\u0006R\u001e\u0010\u00b6\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00b8\u0001\u0010\b\u001a\u0005\b\u00b7\u0001\u0010\u0006R\u001e\u0010\u00b9\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00bb\u0001\u0010\b\u001a\u0005\b\u00ba\u0001\u0010\u0006R\u001e\u0010\u00bc\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00be\u0001\u0010\b\u001a\u0005\b\u00bd\u0001\u0010\u0006R\u001e\u0010\u00bf\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00c1\u0001\u0010\b\u001a\u0005\b\u00c0\u0001\u0010\u0006R\u001e\u0010\u00c2\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00c4\u0001\u0010\b\u001a\u0005\b\u00c3\u0001\u0010\u0006R\u001e\u0010\u00c5\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00c7\u0001\u0010\b\u001a\u0005\b\u00c6\u0001\u0010\u0006R\u001e\u0010\u00c8\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00ca\u0001\u0010\b\u001a\u0005\b\u00c9\u0001\u0010\u0006R\u001e\u0010\u00cb\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00cd\u0001\u0010\b\u001a\u0005\b\u00cc\u0001\u0010\u0006R\u001e\u0010\u00ce\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00d0\u0001\u0010\b\u001a\u0005\b\u00cf\u0001\u0010\u0006R\u001e\u0010\u00d1\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00d3\u0001\u0010\b\u001a\u0005\b\u00d2\u0001\u0010\u0006R\u0017\u0010\u00d4\u0001\u001a\u00020]8BX\u0082\u0004\u00a2\u0006\b\u001a\u0006\b\u00d5\u0001\u0010\u00d6\u0001R\u0016\u0010\u00d7\u0001\u001a\t\u0012\u0004\u0012\u00020]0\u00d8\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000R \u0010\u00d9\u0001\u001a\u00030\u00da\u00018BX\u0082\u0084\u0002\u00a2\u0006\u000f\n\u0005\b\u00dd\u0001\u0010\b\u001a\u0006\b\u00db\u0001\u0010\u00dc\u0001R \u0010\u00de\u0001\u001a\u00030\u00df\u00018BX\u0082\u0084\u0002\u00a2\u0006\u000f\n\u0005\b\u00e2\u0001\u0010\b\u001a\u0006\b\u00e0\u0001\u0010\u00e1\u0001R \u0010\u00e3\u0001\u001a\u00030\u00e4\u00018BX\u0082\u0084\u0002\u00a2\u0006\u000f\n\u0005\b\u00e7\u0001\u0010\b\u001a\u0006\b\u00e5\u0001\u0010\u00e6\u0001R\u001e\u0010\u00e8\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00ea\u0001\u0010\b\u001a\u0005\b\u00e9\u0001\u0010\u0006R\u001e\u0010\u00eb\u0001\u001a\u00020F8BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00ed\u0001\u0010\b\u001a\u0005\b\u00ec\u0001\u0010HR\u001e\u0010\u00ee\u0001\u001a\u00020\u00048BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00f0\u0001\u0010\b\u001a\u0005\b\u00ef\u0001\u0010\u0006R\u001e\u0010\u00f1\u0001\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00f3\u0001\u0010\b\u001a\u0005\b\u00f2\u0001\u0010)R \u0010\u00f4\u0001\u001a\u00030\u00f5\u00018BX\u0082\u0084\u0002\u00a2\u0006\u000f\n\u0005\b\u00f8\u0001\u0010\b\u001a\u0006\b\u00f6\u0001\u0010\u00f7\u0001R\u001e\u0010\u00f9\u0001\u001a\u00020\'8BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u00fb\u0001\u0010\b\u001a\u0005\b\u00fa\u0001\u0010)R \u0010\u00fc\u0001\u001a\u00030\u00fd\u00018BX\u0082\u0084\u0002\u00a2\u0006\u000f\n\u0005\b\u0080\u0002\u0010\b\u001a\u0006\b\u00fe\u0001\u0010\u00ff\u0001R\u001e\u0010\u0081\u0002\u001a\u00020F8BX\u0082\u0084\u0002\u00a2\u0006\u000e\n\u0005\b\u0083\u0002\u0010\b\u001a\u0005\b\u0082\u0002\u0010H\u00a8\u0006\u00e3\u0002"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "()V", "accentKeyBgColorRow", "Landroid/view/View;", "getAccentKeyBgColorRow", "()Landroid/view/View;", "accentKeyBgColorRow$delegate", "Lkotlin/Lazy;", "accentKeyPressColorRow", "getAccentKeyPressColorRow", "accentKeyPressColorRow$delegate", "accentKeyTextColorRow", "getAccentKeyTextColorRow", "accentKeyTextColorRow$delegate", "activeExpandRow", "activeThemeTabIndex", "", "arrowBgColorRow", "getArrowBgColorRow", "arrowBgColorRow$delegate", "arrowTextColorRow", "getArrowTextColorRow", "arrowTextColorRow$delegate", "atKeyBgColorRow", "getAtKeyBgColorRow", "atKeyBgColorRow$delegate", "atKeyPressColorRow", "getAtKeyPressColorRow", "atKeyPressColorRow$delegate", "atKeyTextColorRow", "getAtKeyTextColorRow", "atKeyTextColorRow$delegate", "backgroundStates", "Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundStates;", "getBackgroundStates", "()Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundStates;", "backgroundStates$delegate", "blurLabel", "Landroid/widget/TextView;", "getBlurLabel", "()Landroid/widget/TextView;", "blurLabel$delegate", "blurSeekBar", "Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar;", "getBlurSeekBar", "()Lcom/yuyan/imemodule/view/widget/seekbar/SignSeekBar;", "blurSeekBar$delegate", "brightnessLabel", "getBrightnessLabel", "brightnessLabel$delegate", "brightnessSeekBar", "getBrightnessSeekBar", "brightnessSeekBar$delegate", "brightnessValue", "getBrightnessValue", "brightnessValue$delegate", "btnKeyboardCapsule", "getBtnKeyboardCapsule", "btnKeyboardCapsule$delegate", "btnStateCapsule", "getBtnStateCapsule", "btnStateCapsule$delegate", "btnUndoCapsule", "getBtnUndoCapsule", "btnUndoCapsule$delegate", "candidateTextColorRow", "getCandidateTextColorRow", "candidateTextColorRow$delegate", "capsuleBarLayout", "Landroid/widget/LinearLayout;", "getCapsuleBarLayout", "()Landroid/widget/LinearLayout;", "capsuleBarLayout$delegate", "changeWallpaperImageLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "", "kotlin.jvm.PlatformType", "clearKeyBgColorRow", "getClearKeyBgColorRow", "clearKeyBgColorRow$delegate", "clearKeyPressColorRow", "getClearKeyPressColorRow", "clearKeyPressColorRow$delegate", "clearKeyTextColorRow", "getClearKeyTextColorRow", "clearKeyTextColorRow$delegate", "cropLabel", "getCropLabel", "cropLabel$delegate", "cropLogoLauncher", "Lcom/yuyan/imemodule/libs/cropper/CropImageContractOptions;", "customTheme", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "deleteKeyBgColorRow", "getDeleteKeyBgColorRow", "deleteKeyBgColorRow$delegate", "deleteKeyPressColorRow", "getDeleteKeyPressColorRow", "deleteKeyPressColorRow$delegate", "deleteKeyTextColorRow", "getDeleteKeyTextColorRow", "deleteKeyTextColorRow$delegate", "isToolbarLogoInitialized", "", "keyBgColorRow", "getKeyBgColorRow", "keyBgColorRow$delegate", "keyPressColorRow", "getKeyPressColorRow", "keyPressColorRow$delegate", "keySmallSymbolColorRow", "getKeySmallSymbolColorRow", "keySmallSymbolColorRow$delegate", "keyTextColorRow", "getKeyTextColorRow", "keyTextColorRow$delegate", "keyboardColorRow", "getKeyboardColorRow", "keyboardColorRow$delegate", "logoLabel", "getLogoLabel", "logoLabel$delegate", "newCreated", "numberKeyBgColorRow", "getNumberKeyBgColorRow", "numberKeyBgColorRow$delegate", "numberKeyPressColorRow", "getNumberKeyPressColorRow", "numberKeyPressColorRow$delegate", "numberKeyTextColorRow", "getNumberKeyTextColorRow", "numberKeyTextColorRow$delegate", "originThemeName", "periodKeyBgColorRow", "getPeriodKeyBgColorRow", "periodKeyBgColorRow$delegate", "periodKeyPressColorRow", "getPeriodKeyPressColorRow", "periodKeyPressColorRow$delegate", "periodKeyTextColorRow", "getPeriodKeyTextColorRow", "periodKeyTextColorRow$delegate", "pickLogoImageLauncher", "popupBgColorRow", "getPopupBgColorRow", "popupBgColorRow$delegate", "popupHighlightColorRow", "getPopupHighlightColorRow", "popupHighlightColorRow$delegate", "previewScaleContainer", "Landroid/widget/FrameLayout;", "previewUi", "Lcom/yuyan/imemodule/keyboard/KeyboardPreviewView;", "returnKeyBgColorRow", "getReturnKeyBgColorRow", "returnKeyBgColorRow$delegate", "returnKeyPressColorRow", "getReturnKeyPressColorRow", "returnKeyPressColorRow$delegate", "returnKeyTextColorRow", "getReturnKeyTextColorRow", "returnKeyTextColorRow$delegate", "section2ContentLayout", "getSection2ContentLayout", "section2ContentLayout$delegate", "sectionDividerLine", "getSectionDividerLine", "sectionDividerLine$delegate", "selectedKeyConsoleBar", "getSelectedKeyConsoleBar", "selectedKeyConsoleBar$delegate", "selectedKeyLabel", "shiftKeyActiveBgColorRow", "getShiftKeyActiveBgColorRow", "shiftKeyActiveBgColorRow$delegate", "shiftKeyBgColorRow", "getShiftKeyBgColorRow", "shiftKeyBgColorRow$delegate", "shiftKeyLockBgColorRow", "getShiftKeyLockBgColorRow", "shiftKeyLockBgColorRow$delegate", "shiftKeyPressColorRow", "getShiftKeyPressColorRow", "shiftKeyPressColorRow$delegate", "shiftKeyTextColorRow", "getShiftKeyTextColorRow", "shiftKeyTextColorRow$delegate", "sideSymbolKeyBgColorRow", "getSideSymbolKeyBgColorRow", "sideSymbolKeyBgColorRow$delegate", "sideSymbolKeyTextColorRow", "getSideSymbolKeyTextColorRow", "sideSymbolKeyTextColorRow$delegate", "spaceKeyBgColorRow", "getSpaceKeyBgColorRow", "spaceKeyBgColorRow$delegate", "spaceKeyPressColorRow", "getSpaceKeyPressColorRow", "spaceKeyPressColorRow$delegate", "spaceKeyTextColorRow", "getSpaceKeyTextColorRow", "spaceKeyTextColorRow$delegate", "symbolKeyBgColorRow", "getSymbolKeyBgColorRow", "symbolKeyBgColorRow$delegate", "symbolKeyPressColorRow", "getSymbolKeyPressColorRow", "symbolKeyPressColorRow$delegate", "symbolKeyTextColorRow", "getSymbolKeyTextColorRow", "symbolKeyTextColorRow$delegate", "theme", "getTheme", "()Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "themeHistoryStack", "Ljava/util/ArrayDeque;", "themeTabLayout", "Lcom/google/android/material/tabs/TabLayout;", "getThemeTabLayout", "()Lcom/google/android/material/tabs/TabLayout;", "themeTabLayout$delegate", "themeViewPager", "Landroidx/viewpager2/widget/ViewPager2;", "getThemeViewPager", "()Landroidx/viewpager2/widget/ViewPager2;", "themeViewPager$delegate", "toolbar", "Landroidx/appcompat/widget/Toolbar;", "getToolbar", "()Landroidx/appcompat/widget/Toolbar;", "toolbar$delegate", "toolbarActiveIconColorRow", "getToolbarActiveIconColorRow", "toolbarActiveIconColorRow$delegate", "toolbarLogoButtonsRow", "getToolbarLogoButtonsRow", "toolbarLogoButtonsRow$delegate", "toolbarTextColorRow", "getToolbarTextColorRow", "toolbarTextColorRow$delegate", "tvSelectedKeyTitle", "getTvSelectedKeyTitle", "tvSelectedKeyTitle$delegate", "ui", "Landroidx/constraintlayout/widget/ConstraintLayout;", "getUi", "()Landroidx/constraintlayout/widget/ConstraintLayout;", "ui$delegate", "variantLabel", "getVariantLabel", "variantLabel$delegate", "variantSwitch", "Landroidx/appcompat/widget/SwitchCompat;", "getVariantSwitch", "()Landroidx/appcompat/widget/SwitchCompat;", "variantSwitch$delegate", "wallpaperButtonsRow", "getWallpaperButtonsRow", "wallpaperButtonsRow$delegate", "cancel", "", "compressAndSaveLogo", "inputStream", "Ljava/io/InputStream;", "outputFile", "Ljava/io/File;", "maxDimension", "createCapsuleButton", "defaultText", "onClick", "Lkotlin/Function1;", "createColorPickerItem", "title", "getColor", "Lkotlin/Function0;", "onHeaderClick", "onColorSelected", "createOpacitySlider", "getAlpha", "onAlphaChanged", "createRoundedRectButton", "createTextView", "string", "ripple", "(Ljava/lang/Integer;Z)Landroid/widget/TextView;", "delete", "done", "getCurrentKeyboardName", "getInitialBackgroundDrawable", "Landroid/graphics/drawable/Drawable;", "getThemeTextColor", "handleKeySelectionInEditMode", "key", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "handleToolbarSelectionInEditMode", "hideAllKeyColorRows", "isNumberKeyInActivity", "isShiftKeyInActivity", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onCreateOptionsMenu", "menu", "Landroid/view/Menu;", "onOptionsItemSelected", "item", "Landroid/view/MenuItem;", "promptDelete", "promptRenameTheme", "pushThemeHistory", "safeAddView", "parent", "Landroid/view/ViewGroup;", "childView", "params", "Landroid/view/ViewGroup$LayoutParams;", "setConsoleBarContent", "views", "", "(Ljava/lang/String;[Landroid/view/View;)V", "setKeyVariant", "background", "Lcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground;", "darkKeys", "showCapsuleDropdown", "anchorView", "options", "onSelected", "(Landroid/view/View;[Ljava/lang/String;Lkotlin/jvm/functions/Function1;)V", "showCustomHexColorDialog", "currentColor", "onColorEntered", "undoLastThemeChange", "updateCapsuleDrawable", "view", "color", "isSelected", "updateColorTheme", "updateBlock", "updateSection2Visibility", "updateState", "whenHasBackground", "block", "Lkotlin/Function2;", "Lkotlin/ExtensionFunctionType;", "launchCrop", "w", "h", "withAlpha", "alpha", "BackgroundResult", "BackgroundStates", "Companion", "Contract", "yuyansdk_offlineDebug"})
@kotlin.Suppress(names = {"ALL"})
@android.annotation.SuppressLint(value = {"ALL"})
public final class CustomThemeActivity extends androidx.appcompat.app.AppCompatActivity {
    private com.yuyan.imemodule.data.theme.Theme.Custom customTheme;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy toolbar$delegate = null;
    private com.yuyan.imemodule.keyboard.KeyboardPreviewView previewUi;
    private android.widget.FrameLayout previewScaleContainer;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy variantLabel$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy variantSwitch$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy brightnessLabel$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy brightnessValue$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy brightnessSeekBar$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy cropLabel$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy btnKeyboardCapsule$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy btnStateCapsule$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.ArrayDeque<com.yuyan.imemodule.data.theme.Theme.Custom> themeHistoryStack = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy btnUndoCapsule$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy capsuleBarLayout$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy selectedKeyConsoleBar$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy tvSelectedKeyTitle$delegate = null;
    private boolean isToolbarLogoInitialized = false;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy toolbarLogoButtonsRow$delegate = null;
    @org.jetbrains.annotations.Nullable()
    private java.lang.String selectedKeyLabel;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy keyboardColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy keyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy keyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy keySmallSymbolColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy keyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy popupBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy popupHighlightColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy sideSymbolKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy sideSymbolKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy deleteKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy deleteKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy deleteKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy clearKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy clearKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy clearKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy returnKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy returnKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy returnKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy shiftKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy shiftKeyActiveBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy shiftKeyLockBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy shiftKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy shiftKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy atKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy atKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy atKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy toolbarTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy toolbarActiveIconColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy candidateTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy arrowBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy arrowTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy symbolKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy symbolKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy symbolKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy periodKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy periodKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy periodKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy numberKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy numberKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy numberKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy spaceKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy spaceKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy spaceKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy accentKeyBgColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy accentKeyTextColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy accentKeyPressColorRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy sectionDividerLine$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy blurLabel$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy blurSeekBar$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.activity.result.ActivityResultLauncher<java.lang.String> changeWallpaperImageLauncher = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy wallpaperButtonsRow$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy logoLabel$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.activity.result.ActivityResultLauncher<com.yuyan.imemodule.libs.cropper.CropImageContractOptions> cropLogoLauncher = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.activity.result.ActivityResultLauncher<java.lang.String> pickLogoImageLauncher = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy section2ContentLayout$delegate = null;
    private int activeThemeTabIndex = 0;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy themeTabLayout$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy themeViewPager$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy ui$delegate = null;
    private boolean newCreated = true;
    @org.jetbrains.annotations.Nullable()
    private java.lang.String originThemeName;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy backgroundStates$delegate = null;
    @org.jetbrains.annotations.Nullable()
    private android.view.View activeExpandRow;
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String RESULT = "result";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String ORIGIN_THEME = "origin_theme";
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.Companion Companion = null;
    
    public CustomThemeActivity() {
        super();
    }
    
    private final com.yuyan.imemodule.data.theme.Theme.Custom getTheme() {
        return null;
    }
    
    private final androidx.appcompat.widget.Toolbar getToolbar() {
        return null;
    }
    
    private final int getThemeTextColor() {
        return 0;
    }
    
    private final android.widget.TextView createTextView(@androidx.annotation.StringRes()
    java.lang.Integer string, boolean ripple) {
        return null;
    }
    
    private final android.widget.TextView getVariantLabel() {
        return null;
    }
    
    private final androidx.appcompat.widget.SwitchCompat getVariantSwitch() {
        return null;
    }
    
    private final android.widget.TextView getBrightnessLabel() {
        return null;
    }
    
    private final android.widget.TextView getBrightnessValue() {
        return null;
    }
    
    private final com.yuyan.imemodule.view.widget.seekbar.SignSeekBar getBrightnessSeekBar() {
        return null;
    }
    
    private final android.widget.TextView getCropLabel() {
        return null;
    }
    
    private final java.lang.String getCurrentKeyboardName() {
        return null;
    }
    
    private final android.widget.TextView createCapsuleButton(java.lang.String defaultText, kotlin.jvm.functions.Function1<? super android.view.View, kotlin.Unit> onClick) {
        return null;
    }
    
    private final void showCapsuleDropdown(android.view.View anchorView, java.lang.String[] options, kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onSelected) {
    }
    
    private final android.widget.TextView getBtnKeyboardCapsule() {
        return null;
    }
    
    private final android.widget.TextView getBtnStateCapsule() {
        return null;
    }
    
    private final void pushThemeHistory() {
    }
    
    private final void undoLastThemeChange() {
    }
    
    private final android.widget.TextView getBtnUndoCapsule() {
        return null;
    }
    
    private final android.widget.LinearLayout getCapsuleBarLayout() {
        return null;
    }
    
    private final android.widget.LinearLayout getSelectedKeyConsoleBar() {
        return null;
    }
    
    private final android.widget.TextView getTvSelectedKeyTitle() {
        return null;
    }
    
    private final int withAlpha(int $this$withAlpha, int alpha) {
        return 0;
    }
    
    private final android.view.View createOpacitySlider(kotlin.jvm.functions.Function0<java.lang.Integer> getAlpha, kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onAlphaChanged) {
        return null;
    }
    
    private final android.widget.TextView createRoundedRectButton(java.lang.String defaultText, kotlin.jvm.functions.Function1<? super android.view.View, kotlin.Unit> onClick) {
        return null;
    }
    
    private final android.widget.LinearLayout getToolbarLogoButtonsRow() {
        return null;
    }
    
    private final void hideAllKeyColorRows() {
    }
    
    private final boolean isNumberKeyInActivity(com.yuyan.imemodule.entity.keyboard.SoftKey key) {
        return false;
    }
    
    private final boolean isShiftKeyInActivity(com.yuyan.imemodule.entity.keyboard.SoftKey key) {
        return false;
    }
    
    private final void setConsoleBarContent(java.lang.String title, android.view.View... views) {
    }
    
    private final void handleKeySelectionInEditMode(com.yuyan.imemodule.entity.keyboard.SoftKey key) {
    }
    
    private final void handleToolbarSelectionInEditMode() {
    }
    
    private final android.view.View getKeyboardColorRow() {
        return null;
    }
    
    private final android.view.View getKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getKeySmallSymbolColorRow() {
        return null;
    }
    
    private final android.view.View getKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getPopupBgColorRow() {
        return null;
    }
    
    private final android.view.View getPopupHighlightColorRow() {
        return null;
    }
    
    private final android.view.View getSideSymbolKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getSideSymbolKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getDeleteKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getDeleteKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getDeleteKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getClearKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getClearKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getClearKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getReturnKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getReturnKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getReturnKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getShiftKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getShiftKeyActiveBgColorRow() {
        return null;
    }
    
    private final android.view.View getShiftKeyLockBgColorRow() {
        return null;
    }
    
    private final android.view.View getShiftKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getShiftKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getAtKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getAtKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getAtKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getToolbarTextColorRow() {
        return null;
    }
    
    private final android.view.View getToolbarActiveIconColorRow() {
        return null;
    }
    
    private final android.view.View getCandidateTextColorRow() {
        return null;
    }
    
    private final android.view.View getArrowBgColorRow() {
        return null;
    }
    
    private final android.view.View getArrowTextColorRow() {
        return null;
    }
    
    private final android.view.View getSymbolKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getSymbolKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getSymbolKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getPeriodKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getPeriodKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getPeriodKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getNumberKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getNumberKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getNumberKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getSpaceKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getSpaceKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getSpaceKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getAccentKeyBgColorRow() {
        return null;
    }
    
    private final android.view.View getAccentKeyTextColorRow() {
        return null;
    }
    
    private final android.view.View getAccentKeyPressColorRow() {
        return null;
    }
    
    private final android.view.View getSectionDividerLine() {
        return null;
    }
    
    private final android.widget.TextView getBlurLabel() {
        return null;
    }
    
    private final com.yuyan.imemodule.view.widget.seekbar.SignSeekBar getBlurSeekBar() {
        return null;
    }
    
    private final void safeAddView(android.view.ViewGroup parent, android.view.View childView, android.view.ViewGroup.LayoutParams params) {
    }
    
    private final android.widget.LinearLayout getWallpaperButtonsRow() {
        return null;
    }
    
    private final void updateSection2Visibility() {
    }
    
    private final android.widget.TextView getLogoLabel() {
        return null;
    }
    
    private final void compressAndSaveLogo(java.io.InputStream inputStream, java.io.File outputFile, int maxDimension) {
    }
    
    private final android.widget.LinearLayout getSection2ContentLayout() {
        return null;
    }
    
    private final com.google.android.material.tabs.TabLayout getThemeTabLayout() {
        return null;
    }
    
    private final androidx.viewpager2.widget.ViewPager2 getThemeViewPager() {
        return null;
    }
    
    private final androidx.constraintlayout.widget.ConstraintLayout getUi() {
        return null;
    }
    
    private final com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundStates getBackgroundStates() {
        return null;
    }
    
    private final void whenHasBackground(kotlin.jvm.functions.Function2<? super com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundStates, ? super com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground, kotlin.Unit> block) {
    }
    
    private final void setKeyVariant(com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground background, boolean darkKeys) {
    }
    
    private final android.graphics.drawable.Drawable getInitialBackgroundDrawable() {
        return null;
    }
    
    @java.lang.Override()
    protected void onCreate(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
    }
    
    private final void launchCrop(com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundStates $this$launchCrop, int w, int h) {
    }
    
    @android.annotation.SuppressLint(value = {"SetTextI18n"})
    private final void updateState() {
    }
    
    private final void promptRenameTheme() {
    }
    
    private final void cancel() {
    }
    
    private final void done() {
    }
    
    private final void delete() {
    }
    
    private final void promptDelete() {
    }
    
    private final void updateColorTheme(kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.data.theme.Theme.Custom, com.yuyan.imemodule.data.theme.Theme.Custom> updateBlock) {
    }
    
    private final android.view.View createColorPickerItem(java.lang.String title, kotlin.jvm.functions.Function0<java.lang.Integer> getColor, kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onColorSelected) {
        return null;
    }
    
    private final android.view.View createColorPickerItem(java.lang.String title, kotlin.jvm.functions.Function0<java.lang.Integer> getColor, kotlin.jvm.functions.Function0<kotlin.Unit> onHeaderClick, kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onColorSelected) {
        return null;
    }
    
    private final void showCustomHexColorDialog(java.lang.String title, int currentColor, kotlin.jvm.functions.Function1<? super java.lang.Integer, kotlin.Unit> onColorEntered) {
    }
    
    private final void updateCapsuleDrawable(android.view.View view, int color, boolean isSelected) {
    }
    
    @java.lang.Override()
    public boolean onCreateOptionsMenu(@org.jetbrains.annotations.NotNull()
    android.view.Menu menu) {
        return false;
    }
    
    @java.lang.Override()
    public boolean onOptionsItemSelected(@org.jetbrains.annotations.NotNull()
    android.view.MenuItem item) {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001:\u0003\u0002\u0003\u0004\u0082\u0001\u0003\u0005\u0006\u0007\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult;", "Landroid/os/Parcelable;", "Created", "Deleted", "Updated", "Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult$Created;", "Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult$Deleted;", "Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult$Updated;", "yuyansdk_offlineDebug"})
    public static abstract interface BackgroundResult extends android.os.Parcelable {
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003H\u00c6\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u00c6\u0001J\t\u0010\t\u001a\u00020\nH\u00d6\u0001J\u0013\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u00d6\u0003J\t\u0010\u000f\u001a\u00020\nH\u00d6\u0001J\t\u0010\u0010\u001a\u00020\u0011H\u00d6\u0001J\u0019\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\nH\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0017"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult$Created;", "Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult;", "theme", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "(Lcom/yuyan/imemodule/data/theme/Theme$Custom;)V", "getTheme", "()Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "component1", "copy", "describeContents", "", "equals", "", "other", "", "hashCode", "toString", "", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "yuyansdk_offlineDebug"})
        @kotlinx.parcelize.Parcelize()
        public static final class Created implements com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundResult {
            @org.jetbrains.annotations.NotNull()
            private final com.yuyan.imemodule.data.theme.Theme.Custom theme = null;
            
            public Created(@org.jetbrains.annotations.NotNull()
            com.yuyan.imemodule.data.theme.Theme.Custom theme) {
                super();
            }
            
            @org.jetbrains.annotations.NotNull()
            public final com.yuyan.imemodule.data.theme.Theme.Custom getTheme() {
                return null;
            }
            
            @org.jetbrains.annotations.NotNull()
            public final com.yuyan.imemodule.data.theme.Theme.Custom component1() {
                return null;
            }
            
            @org.jetbrains.annotations.NotNull()
            public final com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundResult.Created copy(@org.jetbrains.annotations.NotNull()
            com.yuyan.imemodule.data.theme.Theme.Custom theme) {
                return null;
            }
            
            @java.lang.Override()
            public int describeContents() {
                return 0;
            }
            
            @java.lang.Override()
            public boolean equals(@org.jetbrains.annotations.Nullable()
            java.lang.Object other) {
                return false;
            }
            
            @java.lang.Override()
            public int hashCode() {
                return 0;
            }
            
            @java.lang.Override()
            @org.jetbrains.annotations.NotNull()
            public java.lang.String toString() {
                return null;
            }
            
            @java.lang.Override()
            public void writeToParcel(@org.jetbrains.annotations.NotNull()
            android.os.Parcel parcel, int flags) {
            }
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003H\u00c6\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u00c6\u0001J\t\u0010\t\u001a\u00020\nH\u00d6\u0001J\u0013\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u00d6\u0003J\t\u0010\u000f\u001a\u00020\nH\u00d6\u0001J\t\u0010\u0010\u001a\u00020\u0003H\u00d6\u0001J\u0019\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\nH\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0016"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult$Deleted;", "Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult;", "name", "", "(Ljava/lang/String;)V", "getName", "()Ljava/lang/String;", "component1", "copy", "describeContents", "", "equals", "", "other", "", "hashCode", "toString", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "yuyansdk_offlineDebug"})
        @kotlinx.parcelize.Parcelize()
        public static final class Deleted implements com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundResult {
            @org.jetbrains.annotations.NotNull()
            private final java.lang.String name = null;
            
            public Deleted(@org.jetbrains.annotations.NotNull()
            java.lang.String name) {
                super();
            }
            
            @org.jetbrains.annotations.NotNull()
            public final java.lang.String getName() {
                return null;
            }
            
            @org.jetbrains.annotations.NotNull()
            public final java.lang.String component1() {
                return null;
            }
            
            @org.jetbrains.annotations.NotNull()
            public final com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundResult.Deleted copy(@org.jetbrains.annotations.NotNull()
            java.lang.String name) {
                return null;
            }
            
            @java.lang.Override()
            public int describeContents() {
                return 0;
            }
            
            @java.lang.Override()
            public boolean equals(@org.jetbrains.annotations.Nullable()
            java.lang.Object other) {
                return false;
            }
            
            @java.lang.Override()
            public int hashCode() {
                return 0;
            }
            
            @java.lang.Override()
            @org.jetbrains.annotations.NotNull()
            public java.lang.String toString() {
                return null;
            }
            
            @java.lang.Override()
            public void writeToParcel(@org.jetbrains.annotations.NotNull()
            android.os.Parcel parcel, int flags) {
            }
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\t\u0010\u0007\u001a\u00020\u0003H\u00c6\u0003J\u0013\u0010\b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003H\u00c6\u0001J\t\u0010\t\u001a\u00020\nH\u00d6\u0001J\u0013\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u00d6\u0003J\t\u0010\u000f\u001a\u00020\nH\u00d6\u0001J\t\u0010\u0010\u001a\u00020\u0011H\u00d6\u0001J\u0019\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\nH\u00d6\u0001R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0017"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult$Updated;", "Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult;", "theme", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "(Lcom/yuyan/imemodule/data/theme/Theme$Custom;)V", "getTheme", "()Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "component1", "copy", "describeContents", "", "equals", "", "other", "", "hashCode", "toString", "", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "yuyansdk_offlineDebug"})
        @kotlinx.parcelize.Parcelize()
        public static final class Updated implements com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundResult {
            @org.jetbrains.annotations.NotNull()
            private final com.yuyan.imemodule.data.theme.Theme.Custom theme = null;
            
            public Updated(@org.jetbrains.annotations.NotNull()
            com.yuyan.imemodule.data.theme.Theme.Custom theme) {
                super();
            }
            
            @org.jetbrains.annotations.NotNull()
            public final com.yuyan.imemodule.data.theme.Theme.Custom getTheme() {
                return null;
            }
            
            @org.jetbrains.annotations.NotNull()
            public final com.yuyan.imemodule.data.theme.Theme.Custom component1() {
                return null;
            }
            
            @org.jetbrains.annotations.NotNull()
            public final com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundResult.Updated copy(@org.jetbrains.annotations.NotNull()
            com.yuyan.imemodule.data.theme.Theme.Custom theme) {
                return null;
            }
            
            @java.lang.Override()
            public int describeContents() {
                return 0;
            }
            
            @java.lang.Override()
            public boolean equals(@org.jetbrains.annotations.Nullable()
            java.lang.Object other) {
                return false;
            }
            
            @java.lang.Override()
            public int hashCode() {
                return 0;
            }
            
            @java.lang.Override()
            @org.jetbrains.annotations.NotNull()
            public java.lang.String toString() {
                return null;
            }
            
            @java.lang.Override()
            public void writeToParcel(@org.jetbrains.annotations.NotNull()
            android.os.Parcel parcel, int flags) {
            }
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0012\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0006\u00104\u001a\u000205J\u0006\u00106\u001a\u000205J\u0006\u00107\u001a\u000205J\u0006\u00108\u001a\u000205R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\nX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u00020\u0010X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0015\u001a\u00020\u0016X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR \u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u001c\u0010\"\u001a\u0004\u0018\u00010#X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b$\u0010%\"\u0004\b&\u0010\'R\u001c\u0010(\u001a\u0004\u0018\u00010)X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b*\u0010+\"\u0004\b,\u0010-R\u001a\u0010.\u001a\u00020\u0010X\u0086.\u00a2\u0006\u000e\n\u0000\u001a\u0004\b/\u0010\u0012\"\u0004\b0\u0010\u0014R\u001c\u00101\u001a\u0004\u0018\u00010\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b2\u0010\u0012\"\u0004\b3\u0010\u0014\u00a8\u00069"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundStates;", "", "()V", "cropRect", "Landroid/graphics/Rect;", "getCropRect", "()Landroid/graphics/Rect;", "setCropRect", "(Landroid/graphics/Rect;)V", "croppedBitmap", "Landroid/graphics/Bitmap;", "getCroppedBitmap", "()Landroid/graphics/Bitmap;", "setCroppedBitmap", "(Landroid/graphics/Bitmap;)V", "croppedImageFile", "Ljava/io/File;", "getCroppedImageFile", "()Ljava/io/File;", "setCroppedImageFile", "(Ljava/io/File;)V", "filteredDrawable", "Landroid/graphics/drawable/BitmapDrawable;", "getFilteredDrawable", "()Landroid/graphics/drawable/BitmapDrawable;", "setFilteredDrawable", "(Landroid/graphics/drawable/BitmapDrawable;)V", "launcher", "Landroidx/activity/result/ActivityResultLauncher;", "Lcom/yuyan/imemodule/libs/cropper/CropImageContractOptions;", "getLauncher", "()Landroidx/activity/result/ActivityResultLauncher;", "setLauncher", "(Landroidx/activity/result/ActivityResultLauncher;)V", "srcImageBuffer", "", "getSrcImageBuffer", "()[B", "setSrcImageBuffer", "([B)V", "srcImageExtension", "", "getSrcImageExtension", "()Ljava/lang/String;", "setSrcImageExtension", "(Ljava/lang/String;)V", "srcImageFile", "getSrcImageFile", "setSrcImageFile", "tempImageFile", "getTempImageFile", "setTempImageFile", "isCroppedBitmapInitialized", "", "isCroppedImageFileInitialized", "isFilteredDrawableInitialized", "isSrcImageFileInitialized", "yuyansdk_offlineDebug"})
    static final class BackgroundStates {
        public androidx.activity.result.ActivityResultLauncher<com.yuyan.imemodule.libs.cropper.CropImageContractOptions> launcher;
        @org.jetbrains.annotations.Nullable()
        private java.lang.String srcImageExtension;
        @org.jetbrains.annotations.Nullable()
        private byte[] srcImageBuffer;
        @org.jetbrains.annotations.Nullable()
        private java.io.File tempImageFile;
        @org.jetbrains.annotations.Nullable()
        private android.graphics.Rect cropRect;
        public android.graphics.Bitmap croppedBitmap;
        public android.graphics.drawable.BitmapDrawable filteredDrawable;
        public java.io.File srcImageFile;
        public java.io.File croppedImageFile;
        
        public BackgroundStates() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final androidx.activity.result.ActivityResultLauncher<com.yuyan.imemodule.libs.cropper.CropImageContractOptions> getLauncher() {
            return null;
        }
        
        public final void setLauncher(@org.jetbrains.annotations.NotNull()
        androidx.activity.result.ActivityResultLauncher<com.yuyan.imemodule.libs.cropper.CropImageContractOptions> p0) {
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.String getSrcImageExtension() {
            return null;
        }
        
        public final void setSrcImageExtension(@org.jetbrains.annotations.Nullable()
        java.lang.String p0) {
        }
        
        @org.jetbrains.annotations.Nullable()
        public final byte[] getSrcImageBuffer() {
            return null;
        }
        
        public final void setSrcImageBuffer(@org.jetbrains.annotations.Nullable()
        byte[] p0) {
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.io.File getTempImageFile() {
            return null;
        }
        
        public final void setTempImageFile(@org.jetbrains.annotations.Nullable()
        java.io.File p0) {
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Rect getCropRect() {
            return null;
        }
        
        public final void setCropRect(@org.jetbrains.annotations.Nullable()
        android.graphics.Rect p0) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.graphics.Bitmap getCroppedBitmap() {
            return null;
        }
        
        public final void setCroppedBitmap(@org.jetbrains.annotations.NotNull()
        android.graphics.Bitmap p0) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.graphics.drawable.BitmapDrawable getFilteredDrawable() {
            return null;
        }
        
        public final void setFilteredDrawable(@org.jetbrains.annotations.NotNull()
        android.graphics.drawable.BitmapDrawable p0) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.io.File getSrcImageFile() {
            return null;
        }
        
        public final void setSrcImageFile(@org.jetbrains.annotations.NotNull()
        java.io.File p0) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.io.File getCroppedImageFile() {
            return null;
        }
        
        public final void setCroppedImageFile(@org.jetbrains.annotations.NotNull()
        java.io.File p0) {
        }
        
        public final boolean isFilteredDrawableInitialized() {
            return false;
        }
        
        public final boolean isCroppedImageFileInitialized() {
            return false;
        }
        
        public final boolean isCroppedBitmapInitialized() {
            return false;
        }
        
        public final boolean isSrcImageFileInitialized() {
            return false;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$Companion;", "", "()V", "ORIGIN_THEME", "", "RESULT", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\b\u0007\u0018\u00002\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\u0006\u0012\u0004\u0018\u00010\u00030\u0001B\u0005\u00a2\u0006\u0002\u0010\u0004J\u001a\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\u0002H\u0016J\u001c\u0010\n\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u0006H\u0016\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$Contract;", "Landroidx/activity/result/contract/ActivityResultContract;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "Lcom/yuyan/imemodule/ui/fragment/theme/CustomThemeActivity$BackgroundResult;", "()V", "createIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "input", "parseResult", "resultCode", "", "intent", "yuyansdk_offlineDebug"})
    public static final class Contract extends androidx.activity.result.contract.ActivityResultContract<com.yuyan.imemodule.data.theme.Theme.Custom, com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundResult> {
        
        public Contract() {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public android.content.Intent createIntent(@org.jetbrains.annotations.NotNull()
        android.content.Context context, @org.jetbrains.annotations.Nullable()
        com.yuyan.imemodule.data.theme.Theme.Custom input) {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.Nullable()
        public com.yuyan.imemodule.ui.fragment.theme.CustomThemeActivity.BackgroundResult parseResult(int resultCode, @org.jetbrains.annotations.Nullable()
        android.content.Intent intent) {
            return null;
        }
    }
}
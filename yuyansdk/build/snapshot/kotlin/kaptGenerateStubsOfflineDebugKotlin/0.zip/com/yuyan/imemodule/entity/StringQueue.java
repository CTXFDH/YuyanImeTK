package com.yuyan.imemodule.entity;

/**
 * 字符串队列
 * 存入：当队列满时，移除最早进入的（即队头），然后加入新元素到队尾。
 * 取出：按照进入队列的倒序，即从最晚进入的开始取出（也就是从队尾开始取）。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\b\u001a\u00020\tJ\u0006\u0010\n\u001a\u00020\u000bJ\b\u0010\f\u001a\u0004\u0018\u00010\u0007J\u000e\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u0007J\u0006\u0010\u000f\u001a\u00020\u0003R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/entity/StringQueue;", "", "maxSize", "", "(I)V", "items", "Lkotlin/collections/ArrayDeque;", "", "clear", "", "isEmpty", "", "popInReverseOrder", "push", "item", "size", "yuyansdk_offlineDebug"})
public final class StringQueue {
    private final int maxSize = 0;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.collections.ArrayDeque<java.lang.String> items = null;
    
    public StringQueue(int maxSize) {
        super();
    }
    
    public final void push(@org.jetbrains.annotations.NotNull()
    java.lang.String item) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String popInReverseOrder() {
        return null;
    }
    
    public final int size() {
        return 0;
    }
    
    public final boolean isEmpty() {
        return false;
    }
    
    public final void clear() {
    }
    
    public StringQueue() {
        super();
    }
}
package com.yuyan.imemodule.keyboard;

/**
 * 键盘根布局
 *
 * 由于之前键盘体验问题，当前基于Android内置键盘[android.inputmethodservice.KeyboardView]进行调整开发。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u001f\b\u0017\u0018\u0000 L2\u00020\u0001:\u0001LB\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0002\u0010\u0004J\b\u0010-\u001a\u00020.H\u0016J\b\u0010/\u001a\u00020.H\u0002J*\u00100\u001a\u00020\r2\b\u00101\u001a\u0004\u0018\u00010*2\u0006\u00102\u001a\u00020*2\u0006\u00103\u001a\u00020\u00062\u0006\u00104\u001a\u00020\u0006H\u0002J\u001a\u00105\u001a\u0004\u0018\u00010\u000f2\u0006\u00106\u001a\u00020\t2\u0006\u00107\u001a\u00020\tH\u0016J\u0006\u00108\u001a\u00020#J\b\u00109\u001a\u00020.H\u0002J\u0006\u0010:\u001a\u00020.J\u0012\u0010;\u001a\u00020\r2\b\u0010<\u001a\u0004\u0018\u00010\u000fH\u0014J\b\u0010=\u001a\u00020.H\u0014J\b\u0010>\u001a\u00020.H\u0016J\b\u0010?\u001a\u00020.H\u0016J\u0010\u0010@\u001a\u00020\r2\u0006\u0010A\u001a\u00020*H\u0002J\u0010\u0010B\u001a\u00020\r2\u0006\u0010A\u001a\u00020*H\u0017J\b\u0010C\u001a\u00020.H\u0002J\b\u0010D\u001a\u00020.H\u0002J\b\u0010E\u001a\u00020\rH\u0002J\u000e\u0010F\u001a\u00020.2\u0006\u0010G\u001a\u00020\u001dJ\u0010\u0010H\u001a\u00020.2\u0006\u0010I\u001a\u00020#H\u0016J\u0010\u0010J\u001a\u00020.2\u0006\u0010<\u001a\u00020\u000fH\u0002J\u0012\u0010K\u001a\u00020.2\b\u0010<\u001a\u0004\u0018\u00010\u000fH\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0010\u001a\u00020\rX\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0019\u001a\u00020\rX\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001a\u0010\u0012\"\u0004\b\u001b\u0010\u0014R\u001c\u0010\u001c\u001a\u0004\u0018\u00010\u001dX\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u001c\u0010\"\u001a\u0004\u0018\u00010#X\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b$\u0010%\"\u0004\b&\u0010\'R\u0014\u0010(\u001a\b\u0012\u0004\u0012\u00020*0)X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020,X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006M"}, d2 = {"Lcom/yuyan/imemodule/keyboard/BaseKeyboardView;", "Landroid/view/View;", "mContext", "Landroid/content/Context;", "(Landroid/content/Context;)V", "currentDistanceX", "", "currentDistanceY", "lastEventActionIndex", "", "lastEventX", "lastEventY", "mAbortKey", "", "mCurrentKey", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "mDrawPending", "getMDrawPending", "()Z", "setMDrawPending", "(Z)V", "mGestureDetector", "Landroid/view/GestureDetector;", "mHandler", "Landroid/os/Handler;", "mLongPressKey", "getMLongPressKey", "setMLongPressKey", "mService", "Lcom/yuyan/imemodule/keyboard/InputView;", "getMService", "()Lcom/yuyan/imemodule/keyboard/InputView;", "setMService", "(Lcom/yuyan/imemodule/keyboard/InputView;)V", "mSoftKeyboard", "Lcom/yuyan/imemodule/entity/keyboard/SoftKeyboard;", "getMSoftKeyboard", "()Lcom/yuyan/imemodule/entity/keyboard/SoftKeyboard;", "setMSoftKeyboard", "(Lcom/yuyan/imemodule/entity/keyboard/SoftKeyboard;)V", "motionEventQueue", "Ljava/util/Queue;", "Landroid/view/MotionEvent;", "popupComponent", "Lcom/yuyan/imemodule/view/popup/PopupComponent;", "closing", "", "dismissPreview", "dispatchGestureEvent", "downEvent", "currentEvent", "distanceX", "distanceY", "getKeyIndices", "x", "y", "getSoftKeyboard", "initGestureDetector", "invalidateKey", "isSpaceKey", "key", "onAttachedToWindow", "onBufferDraw", "onDetachedFromWindow", "onModifiedTouchEvent", "me", "onTouchEvent", "openPopupIfRequired", "removeMessages", "repeatKey", "setResponseKeyEvent", "service", "setSoftKeyboard", "softSkb", "showBalloonText", "showPreview", "Companion", "yuyansdk_offlineDebug"})
public class BaseKeyboardView extends android.view.View {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.popup.PopupComponent popupComponent = null;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.entity.keyboard.SoftKeyboard mSoftKeyboard;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.entity.keyboard.SoftKey mCurrentKey;
    @org.jetbrains.annotations.Nullable()
    private android.view.GestureDetector mGestureDetector;
    private boolean mLongPressKey = false;
    private boolean mAbortKey = false;
    @org.jetbrains.annotations.Nullable()
    private android.os.Handler mHandler;
    private boolean mDrawPending = false;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.keyboard.InputView mService;
    @org.jetbrains.annotations.NotNull()
    private java.util.Queue<android.view.MotionEvent> motionEventQueue;
    private float lastEventX = -1.0F;
    private float lastEventY = -1.0F;
    private float currentDistanceY = 0.0F;
    private float currentDistanceX = 0.0F;
    private int lastEventActionIndex = 0;
    private static final int MSG_SHOW_PREVIEW = 1;
    private static final int MSG_REPEAT = 3;
    private static final int MSG_LONGPRESS = 4;
    private static final long REPEAT_INTERVAL = 50L;
    private static final long REPEAT_START_DELAY = 400L;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.keyboard.BaseKeyboardView.Companion Companion = null;
    
    public BaseKeyboardView(@org.jetbrains.annotations.Nullable()
    android.content.Context mContext) {
        super(null);
    }
    
    @org.jetbrains.annotations.Nullable()
    protected final com.yuyan.imemodule.entity.keyboard.SoftKeyboard getMSoftKeyboard() {
        return null;
    }
    
    protected final void setMSoftKeyboard(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.keyboard.SoftKeyboard p0) {
    }
    
    protected final boolean getMLongPressKey() {
        return false;
    }
    
    protected final void setMLongPressKey(boolean p0) {
    }
    
    protected final boolean getMDrawPending() {
        return false;
    }
    
    protected final void setMDrawPending(boolean p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    protected final com.yuyan.imemodule.keyboard.InputView getMService() {
        return null;
    }
    
    protected final void setMService(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.keyboard.InputView p0) {
    }
    
    public final void setResponseKeyEvent(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView service) {
    }
    
    @java.lang.Override()
    protected void onAttachedToWindow() {
    }
    
    private final void initGestureDetector() {
    }
    
    public final void invalidateKey() {
    }
    
    public void onBufferDraw() {
    }
    
    private final void openPopupIfRequired() {
    }
    
    @java.lang.Override()
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public boolean onTouchEvent(@org.jetbrains.annotations.NotNull()
    android.view.MotionEvent me) {
        return false;
    }
    
    private final boolean onModifiedTouchEvent(android.view.MotionEvent me) {
        return false;
    }
    
    private final boolean dispatchGestureEvent(android.view.MotionEvent downEvent, android.view.MotionEvent currentEvent, float distanceX, float distanceY) {
        return false;
    }
    
    private final boolean repeatKey() {
        return false;
    }
    
    private final void removeMessages() {
    }
    
    @java.lang.Override()
    public void onDetachedFromWindow() {
    }
    
    /**
     * 显示短按气泡
     */
    private final void showPreview(com.yuyan.imemodule.entity.keyboard.SoftKey key) {
    }
    
    /**
     * 隐藏短按气泡
     */
    private final void dismissPreview() {
    }
    
    public void closing() {
    }
    
    private final void showBalloonText(com.yuyan.imemodule.entity.keyboard.SoftKey key) {
    }
    
    protected boolean isSpaceKey(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.keyboard.SoftKey key) {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public com.yuyan.imemodule.entity.keyboard.SoftKey getKeyIndices(int x, int y) {
        return null;
    }
    
    public void setSoftKeyboard(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.keyboard.SoftKeyboard softSkb) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.keyboard.SoftKeyboard getSoftKeyboard() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/imemodule/keyboard/BaseKeyboardView$Companion;", "", "()V", "MSG_LONGPRESS", "", "MSG_REPEAT", "MSG_SHOW_PREVIEW", "REPEAT_INTERVAL", "", "REPEAT_START_DELAY", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
}
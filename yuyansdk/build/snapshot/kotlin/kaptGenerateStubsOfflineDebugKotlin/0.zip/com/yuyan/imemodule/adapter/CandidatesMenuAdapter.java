package com.yuyan.imemodule.adapter;

/**
 * 候选词界面适配器
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\f\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0003345B\u000f\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\u0002\u0010\u0005J\b\u0010\u001d\u001a\u00020\u000fH\u0016J\u0010\u0010\u001e\u001a\u0004\u0018\u00010\u001f2\u0006\u0010 \u001a\u00020\u000fJ\u0010\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u0012H\u0002J\u0006\u0010$\u001a\u00020%J\u0018\u0010&\u001a\u00020%2\u0006\u0010\'\u001a\u00020\u00022\u0006\u0010 \u001a\u00020\u000fH\u0016J\u0018\u0010(\u001a\u00020\u00022\u0006\u0010)\u001a\u00020*2\u0006\u0010+\u001a\u00020\u000fH\u0016J\u0010\u0010,\u001a\u00020%2\b\u0010-\u001a\u0004\u0018\u00010\u001aJ\u0010\u0010.\u001a\u00020%2\b\u0010/\u001a\u0004\u0018\u00010\u001cJ\u0016\u00100\u001a\u00020%2\u0006\u00101\u001a\u00020\u000f2\u0006\u00102\u001a\u00020\u000fR\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000bR\u000e\u0010\f\u001a\u00020\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R0\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00120\u00112\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011@FX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0014\u0010\u0015\"\u0004\b\u0016\u0010\u0017R\u000e\u0010\u0018\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001b\u001a\u0004\u0018\u00010\u001cX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00066"}, d2 = {"Lcom/yuyan/imemodule/adapter/CandidatesMenuAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/adapter/CandidatesMenuAdapter$SymbolHolder;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "activeTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "getActiveTheme", "()Lcom/yuyan/imemodule/data/theme/Theme;", "setActiveTheme", "(Lcom/yuyan/imemodule/data/theme/Theme;)V", "inflater", "Landroid/view/LayoutInflater;", "itemHeight", "", "value", "", "Lcom/yuyan/imemodule/entity/SkbFunItem;", "items", "getItems", "()Ljava/util/List;", "setItems", "(Ljava/util/List;)V", "mMenuPadding", "mOnItemClickListener", "Lcom/yuyan/imemodule/callback/OnRecyclerItemClickListener;", "mOnItemLongClickListener", "Lcom/yuyan/imemodule/adapter/CandidatesMenuAdapter$OnRecyclerItemLongClickListener;", "getItemCount", "getMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "position", "isSettingsMenuSelect", "", "data", "notifyChanged", "", "onBindViewHolder", "holder", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setOnItemClickLitener", "mOnItemClickLitener", "setOnItemLongClickListener", "listener", "swapItems", "fromPosition", "toPosition", "MyDiffCallback", "OnRecyclerItemLongClickListener", "SymbolHolder", "yuyansdk_offlineDebug"})
public final class CandidatesMenuAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.adapter.CandidatesMenuAdapter.SymbolHolder> {
    @org.jetbrains.annotations.NotNull()
    private final android.view.LayoutInflater inflater = null;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.callback.OnRecyclerItemClickListener mOnItemClickListener;
    private int itemHeight;
    private int mMenuPadding;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.data.theme.Theme activeTheme;
    @org.jetbrains.annotations.NotNull()
    private java.util.List<com.yuyan.imemodule.entity.SkbFunItem> items;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.adapter.CandidatesMenuAdapter.OnRecyclerItemLongClickListener mOnItemLongClickListener;
    
    public CandidatesMenuAdapter(@org.jetbrains.annotations.Nullable()
    android.content.Context context) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme getActiveTheme() {
        return null;
    }
    
    public final void setActiveTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> getItems() {
        return null;
    }
    
    public final void setItems(@org.jetbrains.annotations.NotNull()
    java.util.List<com.yuyan.imemodule.entity.SkbFunItem> value) {
    }
    
    public final void swapItems(int fromPosition, int toPosition) {
    }
    
    public final void setOnItemClickLitener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.callback.OnRecyclerItemClickListener mOnItemClickLitener) {
    }
    
    public final void setOnItemLongClickListener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.adapter.CandidatesMenuAdapter.OnRecyclerItemLongClickListener listener) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.adapter.CandidatesMenuAdapter.SymbolHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.adapter.CandidatesMenuAdapter.SymbolHolder holder, int position) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.prefs.behavior.SkbMenuMode getMenuMode(int position) {
        return null;
    }
    
    private final boolean isSettingsMenuSelect(com.yuyan.imemodule.entity.SkbFunItem data) {
        return false;
    }
    
    public final void notifyChanged() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B!\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u00a2\u0006\u0002\u0010\u0006J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\nH\u0016J\u0018\u0010\f\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\nH\u0016J\b\u0010\r\u001a\u00020\nH\u0016J\b\u0010\u000e\u001a\u00020\nH\u0016R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000f"}, d2 = {"Lcom/yuyan/imemodule/adapter/CandidatesMenuAdapter$MyDiffCallback;", "Landroidx/recyclerview/widget/DiffUtil$Callback;", "oldList", "", "Lcom/yuyan/imemodule/entity/SkbFunItem;", "newList", "(Ljava/util/List;Ljava/util/List;)V", "areContentsTheSame", "", "oldItemPosition", "", "newItemPosition", "areItemsTheSame", "getNewListSize", "getOldListSize", "yuyansdk_offlineDebug"})
    public static final class MyDiffCallback extends androidx.recyclerview.widget.DiffUtil.Callback {
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> oldList = null;
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> newList = null;
        
        public MyDiffCallback(@org.jetbrains.annotations.NotNull()
        java.util.List<com.yuyan.imemodule.entity.SkbFunItem> oldList, @org.jetbrains.annotations.NotNull()
        java.util.List<com.yuyan.imemodule.entity.SkbFunItem> newList) {
            super();
        }
        
        @java.lang.Override()
        public int getOldListSize() {
            return 0;
        }
        
        @java.lang.Override()
        public int getNewListSize() {
            return 0;
        }
        
        @java.lang.Override()
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            return false;
        }
        
        @java.lang.Override()
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
            return false;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J(\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\tH&\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/imemodule/adapter/CandidatesMenuAdapter$OnRecyclerItemLongClickListener;", "", "onItemLongClick", "", "parent", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "view", "Landroid/view/View;", "position", "", "yuyansdk_offlineDebug"})
    public static abstract interface OnRecyclerItemLongClickListener {
        
        public abstract boolean onItemLongClick(@org.jetbrains.annotations.Nullable()
        androidx.recyclerview.widget.RecyclerView.Adapter<?> parent, @org.jetbrains.annotations.Nullable()
        android.view.View view, int position);
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\n\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/adapter/CandidatesMenuAdapter$SymbolHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "(Landroid/view/View;)V", "entranceIconImageView", "Landroid/widget/ImageView;", "getEntranceIconImageView", "()Landroid/widget/ImageView;", "setEntranceIconImageView", "(Landroid/widget/ImageView;)V", "yuyansdk_offlineDebug"})
    public static final class SymbolHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.Nullable()
        private android.widget.ImageView entranceIconImageView;
        
        public SymbolHolder(@org.jetbrains.annotations.NotNull()
        android.view.View view) {
            super(null);
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.widget.ImageView getEntranceIconImageView() {
            return null;
        }
        
        public final void setEntranceIconImageView(@org.jetbrains.annotations.Nullable()
        android.widget.ImageView p0) {
        }
    }
}
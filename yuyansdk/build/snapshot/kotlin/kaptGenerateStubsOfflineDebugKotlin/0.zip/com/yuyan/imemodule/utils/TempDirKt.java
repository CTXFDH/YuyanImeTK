package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0010\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a+\u0010\u0000\u001a\u0002H\u0001\"\u0004\b\u0000\u0010\u00012\u0012\u0010\u0002\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u0002H\u00010\u0003H\u0086\b\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u0005\u0082\u0002\u0007\n\u0005\b\u009920\u0001\u00a8\u0006\u0006"}, d2 = {"withTempDir", "T", "block", "Lkotlin/Function1;", "Ljava/io/File;", "(Lkotlin/jvm/functions/Function1;)Ljava/lang/Object;", "yuyansdk_offlineDebug"})
public final class TempDirKt {
    
    public static final <T extends java.lang.Object>T withTempDir(@org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.io.File, ? extends T> block) {
        return null;
    }
}
package com.yuyan.imemodule.speech;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\b\u0010\u0006\u001a\u00020\u0007H&J\b\u0010\b\u001a\u00020\tH&J\b\u0010\n\u001a\u00020\tH\u0016J\u0010\u0010\u000b\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\rH&J\b\u0010\u000e\u001a\u00020\u0007H&J\\\u0010\u000f\u001a\u00020\u00072\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00070\u00112\u0016\b\u0002\u0010\u0012\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0007\u0018\u00010\u00112\u0012\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u0014\u0012\u0004\u0012\u00020\u00070\u00112\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00070\u0011H&J\b\u0010\u0016\u001a\u00020\tH&J\b\u0010\u0017\u001a\u00020\u0007H&R\u0012\u0010\u0002\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0004\u0010\u0005\u00a8\u0006\u0018"}, d2 = {"Lcom/yuyan/imemodule/speech/AsrBackend;", "", "name", "", "getName", "()Ljava/lang/String;", "cancel", "", "initialize", "", "isAvailable", "processAudioChunk", "buffer", "", "release", "setCallbacks", "onResult", "Lkotlin/Function1;", "onPartialResult", "onStateChange", "Lcom/yuyan/imemodule/speech/RecognitionState;", "onError", "start", "stop", "yuyansdk_offlineDebug"})
public abstract interface AsrBackend {
    
    @org.jetbrains.annotations.NotNull()
    public abstract java.lang.String getName();
    
    public abstract void setCallbacks(@org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onResult, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onPartialResult, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.speech.RecognitionState, kotlin.Unit> onStateChange, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.lang.String, kotlin.Unit> onError);
    
    public abstract boolean initialize();
    
    public abstract boolean start();
    
    public abstract void processAudioChunk(@org.jetbrains.annotations.NotNull()
    byte[] buffer);
    
    public abstract void stop();
    
    public abstract void cancel();
    
    public abstract void release();
    
    public abstract boolean isAvailable();
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 3, xi = 48)
    public static final class DefaultImpls {
        
        public static boolean isAvailable(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.speech.AsrBackend $this) {
            return false;
        }
    }
}
package com.yuyan.imemodule.service;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0012\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u0000 $2\u00020\u0001:\u0002#$B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\u000f\u001a\u00020\u0010J\u000e\u0010\u0011\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\u0012J\u000e\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u0014\u001a\u00020\u0015J\u000e\u0010\u0016\u001a\u00020\u0010H\u0086@\u00a2\u0006\u0002\u0010\u0012J\b\u0010\u0017\u001a\u00020\u000eH\u0002J\u0016\u0010\u0018\u001a\u00020\u00102\u0006\u0010\u0019\u001a\u00020\bH\u0086@\u00a2\u0006\u0002\u0010\u001aJ\u001e\u0010\u001b\u001a\u00020\b2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u001fH\u0086@\u00a2\u0006\u0002\u0010 J\u000e\u0010!\u001a\u00020\u001dH\u0086@\u00a2\u0006\u0002\u0010\u0012J\u0006\u0010\"\u001a\u00020\u0010R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006%"}, d2 = {"Lcom/yuyan/imemodule/service/AsrInferenceClient;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "asrCallbackStub", "Lcom/yuyan/imemodule/service/IInferenceAsrCallback$Stub;", "bound", "", "connectLatch", "Ljava/util/concurrent/CountDownLatch;", "connection", "Landroid/content/ServiceConnection;", "service", "Lcom/yuyan/imemodule/service/IInferenceAsrService;", "cancelAsr", "", "ensureBound", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "pushAsrAudio", "audioData", "", "releaseAsr", "requireService", "setKeepModelAlive", "keepAlive", "(ZLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "startAsr", "modelDir", "", "callback", "Lcom/yuyan/imemodule/service/AsrInferenceClient$AsrCallback;", "(Ljava/lang/String;Lcom/yuyan/imemodule/service/AsrInferenceClient$AsrCallback;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "stopAsr", "unbind", "AsrCallback", "Companion", "yuyansdk_offlineDebug"})
public final class AsrInferenceClient {
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context context = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String TAG = "AsrInferenceClient";
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.service.IInferenceAsrService service;
    private boolean bound = false;
    @kotlin.jvm.Volatile()
    @org.jetbrains.annotations.NotNull()
    private volatile java.util.concurrent.CountDownLatch connectLatch;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.service.IInferenceAsrCallback.Stub asrCallbackStub = null;
    @org.jetbrains.annotations.NotNull()
    private final android.content.ServiceConnection connection = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.service.AsrInferenceClient.Companion Companion = null;
    
    public AsrInferenceClient(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object ensureBound(@org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
    
    public final void unbind() {
    }
    
    private final com.yuyan.imemodule.service.IInferenceAsrService requireService() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object startAsr(@org.jetbrains.annotations.NotNull()
    java.lang.String modelDir, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.service.AsrInferenceClient.AsrCallback callback, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.Boolean> $completion) {
        return null;
    }
    
    public final void pushAsrAudio(@org.jetbrains.annotations.NotNull()
    byte[] audioData) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object stopAsr(@org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super java.lang.String> $completion) {
        return null;
    }
    
    public final void cancelAsr() {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object releaseAsr(@org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Object setKeepModelAlive(boolean keepAlive, @org.jetbrains.annotations.NotNull()
    kotlin.coroutines.Continuation<? super kotlin.Unit> $completion) {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&J\u0010\u0010\u0006\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u0005H&J\u0010\u0010\b\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u0005H&\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/service/AsrInferenceClient$AsrCallback;", "", "onError", "", "message", "", "onFinalResult", "text", "onPartialResult", "yuyansdk_offlineDebug"})
    public static abstract interface AsrCallback {
        
        public abstract void onPartialResult(@org.jetbrains.annotations.NotNull()
        java.lang.String text);
        
        public abstract void onFinalResult(@org.jetbrains.annotations.NotNull()
        java.lang.String text);
        
        public abstract void onError(@org.jetbrains.annotations.NotNull()
        java.lang.String message);
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/service/AsrInferenceClient$Companion;", "", "()V", "TAG", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
}
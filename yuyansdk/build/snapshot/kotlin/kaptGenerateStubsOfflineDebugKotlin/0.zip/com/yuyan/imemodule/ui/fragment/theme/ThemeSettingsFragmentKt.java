package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\"\u0014\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2 = {"skbStyleMode", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "Lcom/yuyan/imemodule/prefs/behavior/SkbStyleMode;", "skbStyleModeListener", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "yuyansdk_offlineDebug"})
public final class ThemeSettingsFragmentKt {
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.SkbStyleMode> skbStyleMode = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<com.yuyan.imemodule.prefs.behavior.SkbStyleMode> skbStyleModeListener = null;
}
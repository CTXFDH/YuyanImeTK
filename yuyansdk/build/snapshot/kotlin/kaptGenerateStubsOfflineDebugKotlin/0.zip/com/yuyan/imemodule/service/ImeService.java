package com.yuyan.imemodule.service;

/**
 * Main class of the Pinyin input method. 输入法服务
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0096\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\r\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\nJ\u0016\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\n2\u0006\u0010\u001a\u001a\u00020\u001bJ\u000e\u0010\u001c\u001a\u00020\u00182\u0006\u0010\u001d\u001a\u00020\u001bJ\u000e\u0010\u001e\u001a\u00020\u00182\u0006\u0010\u001f\u001a\u00020\u001bJ\u001a\u0010\u001e\u001a\u00020\u00102\b\b\u0002\u0010 \u001a\u00020\u001b2\b\b\u0002\u0010!\u001a\u00020\u001bJ\u0006\u0010\"\u001a\u00020\u0018J\u0018\u0010#\u001a\u00020\n2\u0006\u0010\u001f\u001a\u00020\u001b2\b\b\u0002\u0010$\u001a\u00020\u001bJ\u000e\u0010%\u001a\u00020\n2\u0006\u0010\u001f\u001a\u00020\u001bJ\u0012\u0010&\u001a\u00020\u00102\n\b\u0002\u0010\'\u001a\u0004\u0018\u00010(J\u0010\u0010)\u001a\u00020\u00182\u0006\u0010*\u001a\u00020+H\u0016J\u0010\u0010,\u001a\u00020\u00182\u0006\u0010\'\u001a\u00020(H\u0016J\b\u0010-\u001a\u00020\u0018H\u0016J\b\u0010.\u001a\u00020/H\u0016J\b\u00100\u001a\u00020/H\u0016J\b\u00101\u001a\u00020\u0018H\u0016J\b\u00102\u001a\u00020\u0010H\u0016J\b\u00103\u001a\u00020\u0010H\u0016J\b\u00104\u001a\u00020\u0018H\u0016J\u0010\u00105\u001a\u00020\u00182\u0006\u00106\u001a\u00020\u0010H\u0016J\u0018\u00107\u001a\u00020\u00102\u0006\u00108\u001a\u00020\u001b2\u0006\u00109\u001a\u00020:H\u0016J\u0018\u0010;\u001a\u00020\u00102\u0006\u00108\u001a\u00020\u001b2\u0006\u00109\u001a\u00020:H\u0016J\b\u0010<\u001a\u00020\u0018H\u0016J\u001a\u0010=\u001a\u00020\u00182\b\u0010>\u001a\u0004\u0018\u00010?2\u0006\u0010@\u001a\u00020\u0010H\u0016J\u0018\u0010A\u001a\u00020\u00182\u0006\u0010>\u001a\u00020?2\u0006\u0010@\u001a\u00020\u0010H\u0016J\u0010\u0010B\u001a\u00020\u00182\u0006\u0010C\u001a\u00020\u001bH\u0016J\u0012\u0010D\u001a\u00020\u00182\b\u0010E\u001a\u0004\u0018\u00010FH\u0016J8\u0010G\u001a\u00020\u00182\u0006\u0010H\u001a\u00020\u001b2\u0006\u0010I\u001a\u00020\u001b2\u0006\u0010J\u001a\u00020\u001b2\u0006\u0010K\u001a\u00020\u001b2\u0006\u0010L\u001a\u00020\u001b2\u0006\u0010M\u001a\u00020\u001bH\u0016J\b\u0010N\u001a\u00020\u0018H\u0016J\b\u0010O\u001a\u00020\u0018H\u0016J\u000e\u0010P\u001a\u00020\u00182\u0006\u0010Q\u001a\u00020\u001bJ,\u0010R\u001a\u00020\u00182\u0006\u0010S\u001a\u00020\u001b2\b\b\u0002\u0010T\u001a\u00020\u00102\b\b\u0002\u0010U\u001a\u00020\u00102\b\b\u0002\u0010V\u001a\u00020\u0010J \u0010W\u001a\u00020\u00182\u0006\u0010X\u001a\u00020Y2\u0006\u0010S\u001a\u00020\u001b2\b\b\u0002\u0010Z\u001a\u00020\u001bJ\u0006\u0010[\u001a\u00020\u0018J \u0010\\\u001a\u00020\u00182\u0006\u0010X\u001a\u00020Y2\u0006\u0010S\u001a\u00020\u001b2\b\b\u0002\u0010Z\u001a\u00020\u001bJ\u000e\u0010]\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020^J\u0016\u0010_\u001a\u00020\u00182\u0006\u0010`\u001a\u00020\u001b2\u0006\u0010a\u001a\u00020\u001bJ\u000e\u0010b\u001a\u00020\u00182\u0006\u0010c\u001a\u00020\u0010R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0005\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00100\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006d"}, d2 = {"Lcom/yuyan/imemodule/service/ImeService;", "Landroid/inputmethodservice/InputMethodService;", "()V", "candidateView", "Lcom/yuyan/imemodule/candidate/CandidateView;", "candidatesObserver", "Landroidx/lifecycle/Observer;", "", "clipboardUpdateContentListener", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "", "cursorAnchorPosition", "", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "isHardwareKeyboard", "", "mInputView", "Lcom/yuyan/imemodule/callback/IKeyboardView;", "onThemeChangeListener", "Lcom/yuyan/imemodule/data/theme/ThemeManager$OnThemeChangeListener;", "showVirtualKeyboardOnPhysicalKeyboard", "showVirtualKeyboardOnPhysicalKeyboardListener", "commitText", "", "text", "newCursorPosition", "", "commitTextEditMenu", "id", "deleteSurroundingText", "length", "beforeLength", "afterLength", "finishComposingText", "getTextAfterCursor", "flags", "getTextBeforeCursor", "handleHardwareKeyboard", "newConfig", "Landroid/content/res/Configuration;", "onComputeInsets", "outInsets", "Landroid/inputmethodservice/InputMethodService$Insets;", "onConfigurationChanged", "onCreate", "onCreateCandidatesView", "Landroid/view/View;", "onCreateInputView", "onDestroy", "onEvaluateFullscreenMode", "onEvaluateInputViewShown", "onFinishInput", "onFinishInputView", "finishingInput", "onKeyDown", "keyCode", "event", "Landroid/view/KeyEvent;", "onKeyUp", "onLowMemory", "onStartInput", "editorInfo", "Landroid/view/inputmethod/EditorInfo;", "restarting", "onStartInputView", "onTrimMemory", "level", "onUpdateCursorAnchorInfo", "cursorAnchorInfo", "Landroid/view/inputmethod/CursorAnchorInfo;", "onUpdateSelection", "oldSelStart", "oldSelEnd", "newSelStart", "newSelEnd", "candidatesStart", "candidatesEnd", "onWindowHidden", "onWindowShown", "performEditorAction", "editorAction", "sendCombinationKeyEvents", "keyEventCode", "alt", "ctrl", "shift", "sendDownKeyEvent", "eventTime", "", "metaState", "sendEnterKeyEvent", "sendUpKeyEvent", "setComposingText", "", "setSelection", "start", "end", "updateCandidatesViewShown", "shown", "yuyansdk_offlineDebug"})
public final class ImeService extends android.inputmethodservice.InputMethodService {
    private boolean isHardwareKeyboard = false;
    private boolean showVirtualKeyboardOnPhysicalKeyboard = false;
    private com.yuyan.imemodule.candidate.CandidateView candidateView;
    private com.yuyan.imemodule.keyboard.InputView inputView;
    private com.yuyan.imemodule.callback.IKeyboardView mInputView;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.ThemeManager.OnThemeChangeListener onThemeChangeListener = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<java.lang.String> clipboardUpdateContentListener = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<java.lang.Boolean> showVirtualKeyboardOnPhysicalKeyboardListener = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.lifecycle.Observer<java.lang.Object> candidatesObserver = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] cursorAnchorPosition = null;
    
    public ImeService() {
        super();
    }
    
    @java.lang.Override()
    public void onCreate() {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateInputView() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateCandidatesView() {
        return null;
    }
    
    @java.lang.Override()
    public boolean onEvaluateInputViewShown() {
        return false;
    }
    
    @java.lang.Override()
    public void onStartInput(@org.jetbrains.annotations.Nullable()
    android.view.inputmethod.EditorInfo editorInfo, boolean restarting) {
    }
    
    @java.lang.Override()
    public void onStartInputView(@org.jetbrains.annotations.NotNull()
    android.view.inputmethod.EditorInfo editorInfo, boolean restarting) {
    }
    
    @java.lang.Override()
    public void onFinishInputView(boolean finishingInput) {
    }
    
    @java.lang.Override()
    public void onFinishInput() {
    }
    
    public final boolean deleteSurroundingText(int beforeLength, int afterLength) {
        return false;
    }
    
    @java.lang.Override()
    public void onDestroy() {
    }
    
    /**
     * 横竖屏无缝无闪烁原绘切换 (0ms 延迟，原位无缝更新，媲美百度输入法)
     */
    @java.lang.Override()
    public void onConfigurationChanged(@org.jetbrains.annotations.NotNull()
    android.content.res.Configuration newConfig) {
    }
    
    @java.lang.Override()
    public boolean onKeyDown(int keyCode, @org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    @java.lang.Override()
    public boolean onKeyUp(int keyCode, @org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    @java.lang.Override()
    public void onTrimMemory(int level) {
    }
    
    @java.lang.Override()
    public void onLowMemory() {
    }
    
    @java.lang.Override()
    public boolean onEvaluateFullscreenMode() {
        return false;
    }
    
    @java.lang.Override()
    public void onComputeInsets(@org.jetbrains.annotations.NotNull()
    android.inputmethodservice.InputMethodService.Insets outInsets) {
    }
    
    @java.lang.Override()
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candidatesStart, int candidatesEnd) {
    }
    
    @java.lang.Override()
    public void onUpdateCursorAnchorInfo(@org.jetbrains.annotations.Nullable()
    android.view.inputmethod.CursorAnchorInfo cursorAnchorInfo) {
    }
    
    @java.lang.Override()
    public void onWindowShown() {
    }
    
    @java.lang.Override()
    public void onWindowHidden() {
    }
    
    /**
     * 模拟Enter按键点击
     */
    public final void sendEnterKeyEvent() {
    }
    
    public final void sendCombinationKeyEvents(int keyEventCode, boolean alt, boolean ctrl, boolean shift) {
    }
    
    public final void sendDownKeyEvent(long eventTime, int keyEventCode, int metaState) {
    }
    
    public final void sendUpKeyEvent(long eventTime, int keyEventCode, int metaState) {
    }
    
    /**
     * 向输入框提交预选词
     */
    public final void setComposingText(@org.jetbrains.annotations.NotNull()
    java.lang.CharSequence text) {
    }
    
    /**
     * 结束提交预选词
     */
    public final void finishComposingText() {
    }
    
    /**
     * 发送字符串给编辑框 (安全空判断，防范 Activity/预览模式下白屏闪退)
     */
    public final void commitText(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
    }
    
    /**
     * 发送字符串给编辑框
     */
    public final void commitText(@org.jetbrains.annotations.NotNull()
    java.lang.String text, int newCursorPosition) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getTextBeforeCursor(int length) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getTextAfterCursor(int length, int flags) {
        return null;
    }
    
    public final void commitTextEditMenu(int id) {
    }
    
    public final void performEditorAction(int editorAction) {
    }
    
    public final void deleteSurroundingText(int length) {
    }
    
    public final void setSelection(int start, int end) {
    }
    
    public final boolean handleHardwareKeyboard(@org.jetbrains.annotations.Nullable()
    android.content.res.Configuration newConfig) {
        return false;
    }
    
    public final void updateCandidatesViewShown(boolean shown) {
    }
}
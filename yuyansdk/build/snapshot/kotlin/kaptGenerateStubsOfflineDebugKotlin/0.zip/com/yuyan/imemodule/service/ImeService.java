package com.yuyan.imemodule.service;

/**
 * Main class of the Pinyin input method. 输入法服务
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u00d0\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\r\n\u0002\b\b\b\u0007\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u0004B\u0005\u00a2\u0006\u0002\u0010\u0005J\u000e\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\rJ\u0016\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\r2\u0006\u00107\u001a\u000208J\u000e\u00109\u001a\u0002052\u0006\u0010:\u001a\u000208J\u000e\u0010;\u001a\u0002052\u0006\u0010<\u001a\u000208J\u001a\u0010;\u001a\u00020\u00132\b\b\u0002\u0010=\u001a\u0002082\b\b\u0002\u0010>\u001a\u000208J\u0006\u0010?\u001a\u000205J\u0018\u0010@\u001a\u00020\r2\u0006\u0010<\u001a\u0002082\b\b\u0002\u0010A\u001a\u000208J\u000e\u0010B\u001a\u00020\r2\u0006\u0010<\u001a\u000208J\u0012\u0010C\u001a\u00020\u00132\n\b\u0002\u0010D\u001a\u0004\u0018\u00010EJ\u000e\u0010F\u001a\u0002052\u0006\u0010G\u001a\u000208J\u0010\u0010H\u001a\u0002052\u0006\u0010I\u001a\u00020JH\u0016J\u0010\u0010K\u001a\u0002052\u0006\u0010D\u001a\u00020EH\u0016J\b\u0010L\u001a\u000205H\u0016J\b\u0010M\u001a\u00020NH\u0016J\b\u0010O\u001a\u00020NH\u0016J\b\u0010P\u001a\u000205H\u0016J\b\u0010Q\u001a\u00020\u0013H\u0016J\b\u0010R\u001a\u00020\u0013H\u0016J\b\u0010S\u001a\u000205H\u0016J\u0010\u0010T\u001a\u0002052\u0006\u0010U\u001a\u00020\u0013H\u0016J\u0018\u0010V\u001a\u00020\u00132\u0006\u0010W\u001a\u0002082\u0006\u0010X\u001a\u00020YH\u0016J\u0018\u0010Z\u001a\u00020\u00132\u0006\u0010W\u001a\u0002082\u0006\u0010X\u001a\u00020YH\u0016J\b\u0010[\u001a\u000205H\u0016J\u001a\u0010\\\u001a\u0002052\b\u0010]\u001a\u0004\u0018\u00010^2\u0006\u0010_\u001a\u00020\u0013H\u0016J\u0018\u0010`\u001a\u0002052\u0006\u0010]\u001a\u00020^2\u0006\u0010_\u001a\u00020\u0013H\u0016J\u0010\u0010a\u001a\u0002052\u0006\u0010b\u001a\u000208H\u0016J\u0012\u0010c\u001a\u0002052\b\u0010d\u001a\u0004\u0018\u00010eH\u0016J8\u0010f\u001a\u0002052\u0006\u0010g\u001a\u0002082\u0006\u0010h\u001a\u0002082\u0006\u0010i\u001a\u0002082\u0006\u0010j\u001a\u0002082\u0006\u0010k\u001a\u0002082\u0006\u0010l\u001a\u000208H\u0016J\b\u0010m\u001a\u000205H\u0016J\b\u0010n\u001a\u000205H\u0016J\u000e\u0010o\u001a\u0002052\u0006\u0010p\u001a\u000208J,\u0010q\u001a\u0002052\u0006\u0010r\u001a\u0002082\b\b\u0002\u0010s\u001a\u00020\u00132\b\b\u0002\u0010t\u001a\u00020\u00132\b\b\u0002\u0010u\u001a\u00020\u0013J \u0010v\u001a\u0002052\u0006\u0010w\u001a\u00020x2\u0006\u0010r\u001a\u0002082\b\b\u0002\u0010y\u001a\u000208J\u0006\u0010z\u001a\u000205J \u0010{\u001a\u0002052\u0006\u0010w\u001a\u00020x2\u0006\u0010r\u001a\u0002082\b\b\u0002\u0010y\u001a\u000208J\u000e\u0010|\u001a\u0002052\u0006\u00106\u001a\u00020}J\u0017\u0010~\u001a\u0002052\u0006\u0010\u007f\u001a\u0002082\u0007\u0010\u0080\u0001\u001a\u000208J\u0007\u0010\u0081\u0001\u001a\u000205J\u0007\u0010\u0082\u0001\u001a\u000205J\u0010\u0010\u0083\u0001\u001a\u0002052\u0007\u0010\u0084\u0001\u001a\u00020\u0013R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.\u00a2\u0006\u0002\n\u0000R\u0016\u0010\b\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\n0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0015\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0013@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0014\u0010\u0017\u001a\u00020\u00188VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0019\u0010\u001aR\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020 X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010!\u001a\u00020\"8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b#\u0010$R\u000e\u0010%\u001a\u00020&X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\'\u001a\u00020\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010(\u001a\b\u0012\u0004\u0012\u00020\u00130\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001b\u0010)\u001a\u00020*8FX\u0086\u0084\u0002\u00a2\u0006\f\n\u0004\b-\u0010.\u001a\u0004\b+\u0010,R\u000e\u0010/\u001a\u000200X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u00101\u001a\u0002008VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b2\u00103\u00a8\u0006\u0085\u0001"}, d2 = {"Lcom/yuyan/imemodule/service/ImeService;", "Landroid/inputmethodservice/InputMethodService;", "Landroidx/lifecycle/LifecycleOwner;", "Landroidx/savedstate/SavedStateRegistryOwner;", "Landroidx/lifecycle/ViewModelStoreOwner;", "()V", "candidateView", "Lcom/yuyan/imemodule/candidate/CandidateView;", "candidatesObserver", "Landroidx/lifecycle/Observer;", "", "clipboardUpdateContentListener", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "", "cursorAnchorPosition", "", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "isHardwareKeyboard", "", "<set-?>", "isSpaceVoiceActive", "()Z", "lifecycle", "Landroidx/lifecycle/Lifecycle;", "getLifecycle", "()Landroidx/lifecycle/Lifecycle;", "lifecycleRegistry", "Landroidx/lifecycle/LifecycleRegistry;", "mInputView", "Lcom/yuyan/imemodule/callback/IKeyboardView;", "onThemeChangeListener", "Lcom/yuyan/imemodule/data/theme/ThemeManager$OnThemeChangeListener;", "savedStateRegistry", "Landroidx/savedstate/SavedStateRegistry;", "getSavedStateRegistry", "()Landroidx/savedstate/SavedStateRegistry;", "savedStateRegistryController", "Landroidx/savedstate/SavedStateRegistryController;", "showVirtualKeyboardOnPhysicalKeyboard", "showVirtualKeyboardOnPhysicalKeyboardListener", "spaceVoiceRecognitionHandler", "Lcom/yuyan/imemodule/service/VoiceRecognitionHandler;", "getSpaceVoiceRecognitionHandler", "()Lcom/yuyan/imemodule/service/VoiceRecognitionHandler;", "spaceVoiceRecognitionHandler$delegate", "Lkotlin/Lazy;", "store", "Landroidx/lifecycle/ViewModelStore;", "viewModelStore", "getViewModelStore", "()Landroidx/lifecycle/ViewModelStore;", "commitText", "", "text", "newCursorPosition", "", "commitTextEditMenu", "id", "deleteSurroundingText", "length", "beforeLength", "afterLength", "finishComposingText", "getTextAfterCursor", "flags", "getTextBeforeCursor", "handleHardwareKeyboard", "newConfig", "Landroid/content/res/Configuration;", "moveCursorSafely", "direction", "onComputeInsets", "outInsets", "Landroid/inputmethodservice/InputMethodService$Insets;", "onConfigurationChanged", "onCreate", "onCreateCandidatesView", "Landroid/view/View;", "onCreateInputView", "onDestroy", "onEvaluateFullscreenMode", "onEvaluateInputViewShown", "onFinishInput", "onFinishInputView", "finishingInput", "onKeyDown", "keyCode", "event", "Landroid/view/KeyEvent;", "onKeyUp", "onLowMemory", "onStartInput", "editorInfo", "Landroid/view/inputmethod/EditorInfo;", "restarting", "onStartInputView", "onTrimMemory", "level", "onUpdateCursorAnchorInfo", "cursorAnchorInfo", "Landroid/view/inputmethod/CursorAnchorInfo;", "onUpdateSelection", "oldSelStart", "oldSelEnd", "newSelStart", "newSelEnd", "candidatesStart", "candidatesEnd", "onWindowHidden", "onWindowShown", "performEditorAction", "editorAction", "sendCombinationKeyEvents", "keyEventCode", "alt", "ctrl", "shift", "sendDownKeyEvent", "eventTime", "", "metaState", "sendEnterKeyEvent", "sendUpKeyEvent", "setComposingText", "", "setSelection", "start", "end", "startSpaceVoiceRecognition", "stopSpaceVoiceRecognition", "updateCandidatesViewShown", "shown", "yuyansdk_offlineDebug"})
public final class ImeService extends android.inputmethodservice.InputMethodService implements androidx.lifecycle.LifecycleOwner, androidx.savedstate.SavedStateRegistryOwner, androidx.lifecycle.ViewModelStoreOwner {
    @org.jetbrains.annotations.NotNull()
    private final androidx.lifecycle.LifecycleRegistry lifecycleRegistry = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.savedstate.SavedStateRegistryController savedStateRegistryController = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.lifecycle.ViewModelStore store = null;
    private boolean isHardwareKeyboard = false;
    private boolean showVirtualKeyboardOnPhysicalKeyboard = false;
    private com.yuyan.imemodule.candidate.CandidateView candidateView;
    private com.yuyan.imemodule.keyboard.InputView inputView;
    private com.yuyan.imemodule.callback.IKeyboardView mInputView;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.ThemeManager.OnThemeChangeListener onThemeChangeListener = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<java.lang.String> clipboardUpdateContentListener = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<java.lang.Boolean> showVirtualKeyboardOnPhysicalKeyboardListener = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.lifecycle.Observer<java.lang.Object> candidatesObserver = null;
    @kotlin.jvm.Volatile()
    private volatile boolean isSpaceVoiceActive = false;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy spaceVoiceRecognitionHandler$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] cursorAnchorPosition = null;
    
    public ImeService() {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public androidx.lifecycle.Lifecycle getLifecycle() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public androidx.savedstate.SavedStateRegistry getSavedStateRegistry() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public androidx.lifecycle.ViewModelStore getViewModelStore() {
        return null;
    }
    
    @java.lang.Override()
    public void onCreate() {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateInputView() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateCandidatesView() {
        return null;
    }
    
    @java.lang.Override()
    public boolean onEvaluateInputViewShown() {
        return false;
    }
    
    @java.lang.Override()
    public void onStartInput(@org.jetbrains.annotations.Nullable()
    android.view.inputmethod.EditorInfo editorInfo, boolean restarting) {
    }
    
    @java.lang.Override()
    public void onStartInputView(@org.jetbrains.annotations.NotNull()
    android.view.inputmethod.EditorInfo editorInfo, boolean restarting) {
    }
    
    @java.lang.Override()
    public void onFinishInputView(boolean finishingInput) {
    }
    
    @java.lang.Override()
    public void onFinishInput() {
    }
    
    public final boolean deleteSurroundingText(int beforeLength, int afterLength) {
        return false;
    }
    
    @java.lang.Override()
    public void onDestroy() {
    }
    
    public final boolean isSpaceVoiceActive() {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.service.VoiceRecognitionHandler getSpaceVoiceRecognitionHandler() {
        return null;
    }
    
    public final void startSpaceVoiceRecognition() {
    }
    
    public final void stopSpaceVoiceRecognition() {
    }
    
    /**
     * 横竖屏无缝无闪烁原绘切换 (0ms 延迟，原位无缝更新，媲美百度输入法)
     */
    @java.lang.Override()
    public void onConfigurationChanged(@org.jetbrains.annotations.NotNull()
    android.content.res.Configuration newConfig) {
    }
    
    @java.lang.Override()
    public boolean onKeyDown(int keyCode, @org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    @java.lang.Override()
    public boolean onKeyUp(int keyCode, @org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    @java.lang.Override()
    public void onTrimMemory(int level) {
    }
    
    @java.lang.Override()
    public void onLowMemory() {
    }
    
    @java.lang.Override()
    public boolean onEvaluateFullscreenMode() {
        return false;
    }
    
    @java.lang.Override()
    public void onComputeInsets(@org.jetbrains.annotations.NotNull()
    android.inputmethodservice.InputMethodService.Insets outInsets) {
    }
    
    @java.lang.Override()
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candidatesStart, int candidatesEnd) {
    }
    
    @java.lang.Override()
    public void onUpdateCursorAnchorInfo(@org.jetbrains.annotations.Nullable()
    android.view.inputmethod.CursorAnchorInfo cursorAnchorInfo) {
    }
    
    @java.lang.Override()
    public void onWindowShown() {
    }
    
    @java.lang.Override()
    public void onWindowHidden() {
    }
    
    /**
     * 模拟Enter按键点击
     */
    public final void sendEnterKeyEvent() {
    }
    
    public final void moveCursorSafely(int direction) {
    }
    
    public final void sendCombinationKeyEvents(int keyEventCode, boolean alt, boolean ctrl, boolean shift) {
    }
    
    public final void sendDownKeyEvent(long eventTime, int keyEventCode, int metaState) {
    }
    
    public final void sendUpKeyEvent(long eventTime, int keyEventCode, int metaState) {
    }
    
    /**
     * 向输入框提交预选词 (设置下划线并标注 SPAN_COMPOSING，防范微信等第三方输入框留存拼音编码)
     */
    public final void setComposingText(@org.jetbrains.annotations.NotNull()
    java.lang.CharSequence text) {
    }
    
    /**
     * 结束提交预选词
     */
    public final void finishComposingText() {
    }
    
    /**
     * 发送字符串给编辑框 (安全空判断，防范 Activity/预览模式下白屏闪退)
     */
    public final void commitText(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
    }
    
    /**
     * 发送字符串给编辑框
     */
    public final void commitText(@org.jetbrains.annotations.NotNull()
    java.lang.String text, int newCursorPosition) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getTextBeforeCursor(int length) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getTextAfterCursor(int length, int flags) {
        return null;
    }
    
    public final void commitTextEditMenu(int id) {
    }
    
    public final void performEditorAction(int editorAction) {
    }
    
    public final void deleteSurroundingText(int length) {
    }
    
    @kotlin.Suppress(names = {"unused"})
    public final void setSelection(int start, int end) {
    }
    
    public final boolean handleHardwareKeyboard(@org.jetbrains.annotations.Nullable()
    android.content.res.Configuration newConfig) {
        return false;
    }
    
    public final void updateCandidatesViewShown(boolean shown) {
    }
}
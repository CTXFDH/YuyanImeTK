package com.yuyan.imemodule.ui.fragment;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0012\u0010\t\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0016J\u001c\u0010\r\u001a\u00020\n2\b\u0010\u000b\u001a\u0004\u0018\u00010\f2\b\u0010\u000e\u001a\u0004\u0018\u00010\u0005H\u0016J6\u0010\u000f\u001a\u00020\n*\u00020\u00102\b\b\u0001\u0010\u0011\u001a\u00020\u00122\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u00052\b\b\u0001\u0010\u0014\u001a\u00020\u00122\b\b\u0001\u0010\u0015\u001a\u00020\u0012H\u0002J4\u0010\u000f\u001a\u00020\n*\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00052\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u00052\b\b\u0001\u0010\u0014\u001a\u00020\u00122\b\b\u0001\u0010\u0015\u001a\u00020\u0012H\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/ImeSettingsFragment;", "Lcom/yuyan/imemodule/ui/fragment/base/CsPreferenceFragment;", "()V", "exportLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "", "exportTimestamp", "", "importLauncher", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "onCreatePreferences", "rootKey", "addDestinationPreference", "Landroidx/preference/PreferenceGroup;", "title", "", "summary", "icon", "destination", "yuyansdk_offlineDebug"})
public final class ImeSettingsFragment extends com.yuyan.imemodule.ui.fragment.base.CsPreferenceFragment {
    private long exportTimestamp;
    private androidx.activity.result.ActivityResultLauncher<java.lang.String> exportLauncher;
    private androidx.activity.result.ActivityResultLauncher<java.lang.String> importLauncher;
    
    public ImeSettingsFragment() {
        super();
    }
    
    @java.lang.Override()
    public void onCreate(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
    }
    
    private final void addDestinationPreference(androidx.preference.PreferenceGroup $this$addDestinationPreference, @androidx.annotation.StringRes()
    int title, java.lang.String summary, @androidx.annotation.DrawableRes()
    int icon, @androidx.annotation.IdRes()
    int destination) {
    }
    
    private final void addDestinationPreference(androidx.preference.PreferenceGroup $this$addDestinationPreference, java.lang.String title, java.lang.String summary, @androidx.annotation.DrawableRes()
    int icon, @androidx.annotation.IdRes()
    int destination) {
    }
    
    @java.lang.Override()
    public void onCreatePreferences(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState, @org.jetbrains.annotations.Nullable()
    java.lang.String rootKey) {
    }
}
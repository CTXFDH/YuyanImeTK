package com.yuyan.inputmethod.core;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B9\u0012\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\t\u00a2\u0006\u0002\u0010\nJ\u000b\u0010\u0018\u001a\u0004\u0018\u00010\u0003H\u00c6\u0003J\u000b\u0010\u0019\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003J\u000b\u0010\u001a\u001a\u0004\u0018\u00010\u0007H\u00c6\u0003J\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00070\tH\u00c6\u0003\u00a2\u0006\u0002\u0010\u0016JB\u0010\u001c\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\tH\u00c6\u0001\u00a2\u0006\u0002\u0010\u001dJ\u0013\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\b\u0010!\u001a\u00020\"H\u0016J\t\u0010#\u001a\u00020\u0007H\u00d6\u0001R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\t8F\u00a2\u0006\u0006\u001a\u0004\b\r\u0010\u000eR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0019\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\t\u00a2\u0006\n\n\u0002\u0010\u0017\u001a\u0004\b\u0015\u0010\u0016\u00a8\u0006$"}, d2 = {"Lcom/yuyan/inputmethod/core/RimeContext;", "", "composition", "Lcom/yuyan/inputmethod/core/RimeComposition;", "menu", "Lcom/yuyan/inputmethod/core/RimeMenu;", "commitTextPreview", "", "selectLabels", "", "(Lcom/yuyan/inputmethod/core/RimeComposition;Lcom/yuyan/inputmethod/core/RimeMenu;Ljava/lang/String;[Ljava/lang/String;)V", "candidates", "Lcom/yuyan/inputmethod/core/CandidateListItem;", "getCandidates", "()[Lcom/yuyan/inputmethod/core/CandidateListItem;", "getCommitTextPreview", "()Ljava/lang/String;", "getComposition", "()Lcom/yuyan/inputmethod/core/RimeComposition;", "getMenu", "()Lcom/yuyan/inputmethod/core/RimeMenu;", "getSelectLabels", "()[Ljava/lang/String;", "[Ljava/lang/String;", "component1", "component2", "component3", "component4", "copy", "(Lcom/yuyan/inputmethod/core/RimeComposition;Lcom/yuyan/inputmethod/core/RimeMenu;Ljava/lang/String;[Ljava/lang/String;)Lcom/yuyan/inputmethod/core/RimeContext;", "equals", "", "other", "hashCode", "", "toString", "yuyansdk_offlineDebug"})
@androidx.annotation.Keep()
public final class RimeContext {
    @org.jetbrains.annotations.Nullable()
    private final com.yuyan.inputmethod.core.RimeComposition composition = null;
    @org.jetbrains.annotations.Nullable()
    private final com.yuyan.inputmethod.core.RimeMenu menu = null;
    @org.jetbrains.annotations.Nullable()
    private final java.lang.String commitTextPreview = null;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String[] selectLabels = null;
    
    public RimeContext(@org.jetbrains.annotations.Nullable()
    com.yuyan.inputmethod.core.RimeComposition composition, @org.jetbrains.annotations.Nullable()
    com.yuyan.inputmethod.core.RimeMenu menu, @org.jetbrains.annotations.Nullable()
    java.lang.String commitTextPreview, @org.jetbrains.annotations.NotNull()
    java.lang.String[] selectLabels) {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.inputmethod.core.RimeComposition getComposition() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.inputmethod.core.RimeMenu getMenu() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getCommitTextPreview() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[] getSelectLabels() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.inputmethod.core.CandidateListItem[] getCandidates() {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    public RimeContext() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.inputmethod.core.RimeComposition component1() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.inputmethod.core.RimeMenu component2() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component3() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[] component4() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.inputmethod.core.RimeContext copy(@org.jetbrains.annotations.Nullable()
    com.yuyan.inputmethod.core.RimeComposition composition, @org.jetbrains.annotations.Nullable()
    com.yuyan.inputmethod.core.RimeMenu menu, @org.jetbrains.annotations.Nullable()
    java.lang.String commitTextPreview, @org.jetbrains.annotations.NotNull()
    java.lang.String[] selectLabels) {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}
package com.yuyan.imemodule.libs.cropper;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u008e\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\b\b\u0017\u0018\u0000 D2\u00020\u00012\u00020\u00022\u00020\u0003:\u0002DEB\u0005\u00a2\u0006\u0002\u0010\u0004J\b\u0010\u0013\u001a\u00020\u0014H\u0016J*\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\n2\u000e\u0010\u0018\u001a\n\u0018\u00010\u0019j\u0004\u0018\u0001`\u001a2\u0006\u0010\u001b\u001a\u00020\u001cH\u0016J\b\u0010\u001d\u001a\u00020\nH\u0002J\u0012\u0010\u001e\u001a\u00020\u00142\b\u0010\u001f\u001a\u0004\u0018\u00010 H\u0016J\u0010\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$H\u0016J\u0018\u0010%\u001a\u00020\u00142\u0006\u0010&\u001a\u00020\f2\u0006\u0010\'\u001a\u00020(H\u0016J\u0010\u0010)\u001a\u00020\"2\u0006\u0010*\u001a\u00020+H\u0016J\u0012\u0010,\u001a\u00020\u00142\b\u0010-\u001a\u0004\u0018\u00010\nH\u0014J\u0010\u0010.\u001a\u00020\u00142\u0006\u0010/\u001a\u00020 H\u0014J(\u00100\u001a\u00020\u00142\u0006\u0010&\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\n2\u000e\u0010\u0018\u001a\n\u0018\u00010\u0019j\u0004\u0018\u0001`\u001aH\u0016J\b\u00101\u001a\u00020\u0014H\u0016J\b\u00102\u001a\u00020\u0014H\u0016J\b\u00103\u001a\u00020\u0014H\u0002J\u0010\u00104\u001a\u00020\u00142\u0006\u00105\u001a\u000206H\u0002J\u0010\u00107\u001a\u00020\u00142\u0006\u00108\u001a\u00020\u001cH\u0016J\u0010\u00109\u001a\u00020\u00142\u0006\u0010\u000b\u001a\u00020\fH\u0016J\b\u0010:\u001a\u00020\u0014H\u0002J*\u0010;\u001a\u00020\u00142\b\u0010\u0017\u001a\u0004\u0018\u00010\n2\u000e\u0010\u0018\u001a\n\u0018\u00010\u0019j\u0004\u0018\u0001`\u001a2\u0006\u0010\u001b\u001a\u00020\u001cH\u0016J\b\u0010<\u001a\u00020\u0014H\u0016J\u001c\u0010=\u001a\u00020\u00142\u0012\u00104\u001a\u000e\u0012\u0004\u0012\u000206\u0012\u0004\u0012\u00020\u00140>H\u0016J\b\u0010?\u001a\u00020\u0014H\u0002J \u0010@\u001a\u00020\u00142\u0006\u0010#\u001a\u00020$2\u0006\u0010A\u001a\u00020\u001c2\u0006\u0010B\u001a\u00020\u001cH\u0016J \u0010C\u001a\u00020\u00142\u0006\u0010#\u001a\u00020$2\u0006\u0010A\u001a\u00020\u001c2\u0006\u0010B\u001a\u00020\u001cH\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u000e\u001a\u0010\u0012\f\u0012\n \u0011*\u0004\u0018\u00010\u00100\u00100\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0012\u001a\u0010\u0012\f\u0012\n \u0011*\u0004\u0018\u00010\n0\n0\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006F"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnSetImageUriCompleteListener;", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$OnCropImageCompleteListener;", "()V", "binding", "Lcom/yuyan/imemodule/databinding/CropImageActivityBinding;", "cropImageOptions", "Lcom/yuyan/imemodule/libs/cropper/CropImageOptions;", "cropImageUri", "Landroid/net/Uri;", "cropImageView", "Lcom/yuyan/imemodule/libs/cropper/CropImageView;", "latestTmpUri", "pickImageGallery", "Landroidx/activity/result/ActivityResultLauncher;", "", "kotlin.jvm.PlatformType", "takePicture", "cropImage", "", "getResultIntent", "Landroid/content/Intent;", "uri", "error", "Ljava/lang/Exception;", "Lkotlin/Exception;", "sampleSize", "", "getTmpFileUri", "onCreate", "savedInstanceState", "Landroid/os/Bundle;", "onCreateOptionsMenu", "", "menu", "Landroid/view/Menu;", "onCropImageComplete", "view", "result", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropResult;", "onOptionsItemSelected", "item", "Landroid/view/MenuItem;", "onPickImageResult", "resultUri", "onSaveInstanceState", "outState", "onSetImageUriComplete", "onStart", "onStop", "openCamera", "openSource", "source", "Lcom/yuyan/imemodule/libs/cropper/CropImageActivity$Source;", "rotateImage", "degrees", "setCropImageView", "setCustomizations", "setResult", "setResultCancel", "showImageSourceDialog", "Lkotlin/Function1;", "showIntentChooser", "updateMenuItemIconColor", "itemId", "color", "updateMenuItemTextColor", "Companion", "Source", "yuyansdk_offlineDebug"})
public class CropImageActivity extends androidx.appcompat.app.AppCompatActivity implements com.yuyan.imemodule.libs.cropper.CropImageView.OnSetImageUriCompleteListener, com.yuyan.imemodule.libs.cropper.CropImageView.OnCropImageCompleteListener {
    
    /**
     * Persist URI image to crop URI if specific permissions are required.
     */
    @org.jetbrains.annotations.Nullable()
    private android.net.Uri cropImageUri;
    
    /**
     * The options that were set for the crop image
     */
    private com.yuyan.imemodule.libs.cropper.CropImageOptions cropImageOptions;
    
    /**
     * The crop image view library widget used in the activity.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView cropImageView;
    private com.yuyan.imemodule.databinding.CropImageActivityBinding binding;
    @org.jetbrains.annotations.Nullable()
    private android.net.Uri latestTmpUri;
    @org.jetbrains.annotations.NotNull()
    private final androidx.activity.result.ActivityResultLauncher<java.lang.String> pickImageGallery = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.activity.result.ActivityResultLauncher<android.net.Uri> takePicture = null;
    @org.jetbrains.annotations.NotNull()
    @java.lang.Deprecated()
    public static final java.lang.String BUNDLE_KEY_TMP_URI = "bundle_key_tmp_uri";
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.libs.cropper.CropImageActivity.Companion Companion = null;
    
    public CropImageActivity() {
        super();
    }
    
    @java.lang.Override()
    public void onCreate(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
    }
    
    private final void setCustomizations() {
    }
    
    private final void showIntentChooser() {
    }
    
    private final void openSource(com.yuyan.imemodule.libs.cropper.CropImageActivity.Source source) {
    }
    
    private final void openCamera() {
    }
    
    private final android.net.Uri getTmpFileUri() {
        return null;
    }
    
    /**
     * This method show the dialog for user source choice, it is an open function so can be overridden
     * and customised with the app layout if you need.
     */
    public void showImageSourceDialog(@org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.libs.cropper.CropImageActivity.Source, kotlin.Unit> openSource) {
    }
    
    @java.lang.Override()
    public void onStart() {
    }
    
    @java.lang.Override()
    public void onStop() {
    }
    
    @java.lang.Override()
    protected void onSaveInstanceState(@org.jetbrains.annotations.NotNull()
    android.os.Bundle outState) {
    }
    
    @java.lang.Override()
    public boolean onCreateOptionsMenu(@org.jetbrains.annotations.NotNull()
    android.view.Menu menu) {
        return false;
    }
    
    @java.lang.Override()
    public boolean onOptionsItemSelected(@org.jetbrains.annotations.NotNull()
    android.view.MenuItem item) {
        return false;
    }
    
    protected void onPickImageResult(@org.jetbrains.annotations.Nullable()
    android.net.Uri resultUri) {
    }
    
    @java.lang.Override()
    public void onSetImageUriComplete(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView view, @org.jetbrains.annotations.NotNull()
    android.net.Uri uri, @org.jetbrains.annotations.Nullable()
    java.lang.Exception error) {
    }
    
    @java.lang.Override()
    public void onCropImageComplete(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView view, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropResult result) {
    }
    
    /**
     * Execute crop image and save the result tou output uri.
     */
    public void cropImage() {
    }
    
    /**
     * When extending this activity, please set your own ImageCropView
     */
    public void setCropImageView(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView cropImageView) {
    }
    
    /**
     * Rotate the image in the crop image view.
     */
    public void rotateImage(int degrees) {
    }
    
    /**
     * Result with cropped image data or error if failed.
     */
    public void setResult(@org.jetbrains.annotations.Nullable()
    android.net.Uri uri, @org.jetbrains.annotations.Nullable()
    java.lang.Exception error, int sampleSize) {
    }
    
    /**
     * Cancel of cropping activity.
     */
    public void setResultCancel() {
    }
    
    /**
     * Get intent instance to be used for the result of this activity.
     */
    @org.jetbrains.annotations.NotNull()
    public android.content.Intent getResultIntent(@org.jetbrains.annotations.Nullable()
    android.net.Uri uri, @org.jetbrains.annotations.Nullable()
    java.lang.Exception error, int sampleSize) {
        return null;
    }
    
    /**
     * Update the color of a specific menu item to the given color.
     */
    public void updateMenuItemIconColor(@org.jetbrains.annotations.NotNull()
    android.view.Menu menu, int itemId, int color) {
    }
    
    /**
     * Update the color of a specific menu item to the given color.
     */
    public void updateMenuItemTextColor(@org.jetbrains.annotations.NotNull()
    android.view.Menu menu, int itemId, int color) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0082\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageActivity$Companion;", "", "()V", "BUNDLE_KEY_TMP_URI", "", "yuyansdk_offlineDebug"})
    static final class Companion {
        
        private Companion() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0004\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageActivity$Source;", "", "(Ljava/lang/String;I)V", "CAMERA", "GALLERY", "yuyansdk_offlineDebug"})
    public static enum Source {
        /*public static final*/ CAMERA /* = new CAMERA() */,
        /*public static final*/ GALLERY /* = new GALLERY() */;
        
        Source() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.libs.cropper.CropImageActivity.Source> getEntries() {
            return null;
        }
    }
}
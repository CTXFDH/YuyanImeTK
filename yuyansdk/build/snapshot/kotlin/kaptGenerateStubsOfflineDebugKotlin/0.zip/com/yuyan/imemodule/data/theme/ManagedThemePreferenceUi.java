package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B=\u0012\b\b\u0001\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\n\b\u0003\u0010\t\u001a\u0004\u0018\u00010\u0004\u0012\u0010\b\u0002\u0010\n\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u000b\u00a2\u0006\u0002\u0010\rJ\u0010\u0010\u0015\u001a\u00020\u00022\u0006\u0010\u0016\u001a\u00020\u0017H\u0016R\u0011\u0010\u0007\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0015\u0010\t\u001a\u0004\u0018\u00010\u0004\u00a2\u0006\n\n\u0002\u0010\u0012\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014\u00a8\u0006\u0018"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ManagedThemePreferenceUi;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "Lcom/yuyan/imemodule/view/preference/ThemeSelectPreference;", "title", "", "key", "", "defaultValue", "Lcom/yuyan/imemodule/data/theme/Theme;", "summary", "enableUiOn", "Lkotlin/Function0;", "", "(ILjava/lang/String;Lcom/yuyan/imemodule/data/theme/Theme;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)V", "getDefaultValue", "()Lcom/yuyan/imemodule/data/theme/Theme;", "getSummary", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getTitle", "()I", "createUi", "context", "Landroid/content/Context;", "yuyansdk_offlineDebug"})
public final class ManagedThemePreferenceUi extends com.yuyan.imemodule.prefs.ManagedPreferenceUi<com.yuyan.imemodule.view.preference.ThemeSelectPreference> {
    private final int title = 0;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.Theme defaultValue = null;
    @org.jetbrains.annotations.Nullable()
    private final java.lang.Integer summary = null;
    
    public ManagedThemePreferenceUi(@androidx.annotation.StringRes()
    int title, @org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme defaultValue, @androidx.annotation.StringRes()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer summary, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
        super(null, null);
    }
    
    public final int getTitle() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme getDefaultValue() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer getSummary() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.view.preference.ThemeSelectPreference createUi(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        return null;
    }
}
package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u0018\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/utils/DialogStyleUtils;", "", "()V", "isDarkUiMode", "", "context", "Landroid/content/Context;", "styleDialog", "", "dialog", "Landroidx/appcompat/app/AlertDialog;", "yuyansdk_offlineDebug"})
public final class DialogStyleUtils {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.DialogStyleUtils INSTANCE = null;
    
    private DialogStyleUtils() {
        super();
    }
    
    /**
     * 判断当前系统/设置页面 Activity 是否处于夜间暗色模式
     */
    public final boolean isDarkUiMode(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        return false;
    }
    
    /**
     * 为 AlertDialog 统一应用圆角卡片背景与设置页面日夜间模式调色，完全解耦键盘主题
     */
    public final void styleDialog(@org.jetbrains.annotations.NotNull()
    androidx.appcompat.app.AlertDialog dialog, @org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
}
package com.yuyan.imemodule.keyboard;

/**
 * 输入法主界面。
 * 包含拼音显示、候选词栏、键盘界面等。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0084\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u000b\n\u0002\u0010\u0007\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0010\u0015\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\r\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0014\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002:\u0002\u00a7\u0001B\u0015\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J\u0006\u0010M\u001a\u00020NJ\u0010\u0010O\u001a\u00020N2\b\b\u0002\u0010P\u001a\u00020HJ\u000e\u0010Q\u001a\u00020N2\u0006\u0010R\u001a\u00020SJ\u0012\u0010T\u001a\u00020N2\b\u0010U\u001a\u0004\u0018\u00010SH\u0002J\u0010\u0010V\u001a\u00020N2\u0006\u0010R\u001a\u00020SH\u0002J\u0010\u0010W\u001a\u00020N2\u0006\u0010R\u001a\u00020SH\u0002J\u0017\u0010X\u001a\u00020N2\b\u0010Y\u001a\u0004\u0018\u00010HH\u0002\u00a2\u0006\u0002\u0010ZJ\u0006\u0010[\u001a\u00020NJ\b\u0010\\\u001a\u00020]H\u0016J\u0012\u0010^\u001a\u00020N2\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\u0002J\u0010\u0010_\u001a\u00020N2\u0006\u0010\u0003\u001a\u00020\u0004H\u0007J\u000e\u0010`\u001a\u00020\r2\u0006\u0010a\u001a\u00020HJ\b\u0010b\u001a\u00020NH\u0016J\u0010\u0010c\u001a\u00020N2\u0006\u0010d\u001a\u00020eH\u0002J\u001a\u0010f\u001a\u00020\r2\u0006\u0010g\u001a\u00020e2\b\u0010h\u001a\u0004\u0018\u00010iH\u0002J\u001a\u0010j\u001a\u00020N2\u0006\u0010k\u001a\u00020l2\n\b\u0002\u0010m\u001a\u0004\u0018\u00010nJ\u0018\u0010o\u001a\u00020N2\u0006\u0010p\u001a\u00020q2\u0006\u0010r\u001a\u00020\rH\u0016J0\u0010s\u001a\u00020N2\u0006\u0010t\u001a\u00020H2\u0006\u0010u\u001a\u00020H2\u0006\u0010v\u001a\u00020H2\u0006\u0010w\u001a\u00020H2\u0006\u0010x\u001a\u00020HH\u0016J\b\u0010y\u001a\u00020NH\u0016J\b\u0010z\u001a\u00020NH\u0016J\u000e\u0010{\u001a\u00020N2\u0006\u0010|\u001a\u00020HJ\u0010\u0010}\u001a\u00020\r2\u0006\u0010h\u001a\u00020~H\u0002J\u0010\u0010\u007f\u001a\u00020N2\u0006\u0010h\u001a\u00020~H\u0002J\u0011\u0010\u0080\u0001\u001a\u00020\r2\u0006\u0010h\u001a\u00020~H\u0002J\u0019\u0010\u0081\u0001\u001a\u00020\r2\u0006\u0010a\u001a\u00020H2\u0006\u0010h\u001a\u00020~H\u0016J\u0011\u0010\u0082\u0001\u001a\u00020\r2\u0006\u0010h\u001a\u00020~H\u0016J\u0011\u0010\u0083\u0001\u001a\u00020\r2\u0006\u0010h\u001a\u00020~H\u0002J\u001a\u0010\u0084\u0001\u001a\u00020N2\u0006\u0010a\u001a\u00020H2\u0007\u0010\u0085\u0001\u001a\u00020SH\u0002J\u0007\u0010\u0086\u0001\u001a\u00020NJ\t\u0010\u0087\u0001\u001a\u00020NH\u0002J\u0007\u0010\u0088\u0001\u001a\u00020NJ \u0010\u0089\u0001\u001a\u00020N2\u000f\u0010\u008a\u0001\u001a\n\u0012\u0005\u0012\u00030\u008c\u00010\u008b\u0001H\u0016\u00a2\u0006\u0003\u0010\u008d\u0001J\u0013\u0010\u008e\u0001\u001a\u00020N2\b\u0010\u008f\u0001\u001a\u00030\u0090\u0001H\u0016J \u0010\u0091\u0001\u001a\u00020N2\u0015\u0010\u0092\u0001\u001a\u0010\u0012\u0005\u0012\u00030\u0094\u0001\u0012\u0004\u0012\u00020S0\u0093\u0001H\u0016J\u0010\u0010\u0095\u0001\u001a\u00020N2\u0007\u0010\u0096\u0001\u001a\u00020HJ\u0011\u0010\u0097\u0001\u001a\u00020N2\u0006\u0010a\u001a\u00020HH\u0002J\u0012\u0010\u0098\u0001\u001a\u00020N2\u0007\u0010R\u001a\u00030\u0099\u0001H\u0002J\u0013\u0010\u009a\u0001\u001a\u00020N2\b\u0010\u009b\u0001\u001a\u00030\u009c\u0001H\u0016J\u001f\u0010\u009d\u0001\u001a\u00020N2\u000e\u0010\u009e\u0001\u001a\t\u0012\u0004\u0012\u00020S0\u008b\u0001H\u0016\u00a2\u0006\u0003\u0010\u009f\u0001J\t\u0010\u00a0\u0001\u001a\u00020NH\u0002J\u0007\u0010\u00a1\u0001\u001a\u00020NJ\u0007\u0010\u00a2\u0001\u001a\u00020NJ\u0013\u0010\u00a3\u0001\u001a\u00020N2\b\u0010\u00a4\u0001\u001a\u00030\u00a5\u0001H\u0016J\t\u0010\u00a6\u0001\u001a\u00020NH\u0016R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\f\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u000f\"\u0004\b\u0014\u0010\u0011R\u0011\u0010\u0015\u001a\u00020\u00068F\u00a2\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0019X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0019X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0019X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u001d\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001d\u0010\u000f\"\u0004\b\u001e\u0010\u0011R\u001a\u0010\u001f\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001f\u0010\u000f\"\u0004\b \u0010\u0011R\u001a\u0010!\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b!\u0010\u000f\"\u0004\b\"\u0010\u0011R\u001a\u0010#\u001a\u00020$X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b%\u0010&\"\u0004\b\'\u0010(R\u000e\u0010)\u001a\u00020*X\u0082.\u00a2\u0006\u0002\n\u0000R\u0012\u0010+\u001a\u00060,R\u00020\u0000X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u000200X\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u00101\u001a\u0004\u0018\u000102X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00103\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00105\u001a\u000206X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00108\u001a\u000206X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u00109\u001a\u00020.X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010:\u001a\u00020*X\u0082.\u00a2\u0006\u0002\n\u0000R\u001a\u0010;\u001a\u00020<X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b=\u0010>\"\u0004\b?\u0010@R\u001a\u0010A\u001a\u00020BX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bC\u0010D\"\u0004\bE\u0010FR\u000e\u0010G\u001a\u00020HX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010I\u001a\u00020HX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010J\u001a\u00020HX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010K\u001a\u00020LX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u00a8\u0001"}, d2 = {"Lcom/yuyan/imemodule/keyboard/InputView;", "Lcom/yuyan/imemodule/callback/IKeyboardView;", "Lcom/yuyan/imemodule/callback/IResponseKeyEvent;", "context", "Landroid/content/Context;", "service", "Lcom/yuyan/imemodule/service/ImeService;", "(Landroid/content/Context;Lcom/yuyan/imemodule/service/ImeService;)V", "appPrefs", "Lcom/yuyan/imemodule/prefs/AppPrefs;", "chinesePredictionMode", "Lcom/yuyan/imemodule/prefs/behavior/ChineseAssociationMode;", "hasSelection", "", "getHasSelection", "()Z", "setHasSelection", "(Z)V", "hasSelectionAll", "getHasSelectionAll", "setHasSelectionAll", "imeService", "getImeService", "()Lcom/yuyan/imemodule/service/ImeService;", "initialTouchX", "", "initialTouchY", "initialTranslationX", "initialTranslationY", "isAddPhrases", "setAddPhrases", "isCursorSwiping", "setCursorSwiping", "isInternalOperation", "setInternalOperation", "mAddPhrasesLayout", "Lcom/yuyan/imemodule/view/EditPhrasesView;", "getMAddPhrasesLayout", "()Lcom/yuyan/imemodule/view/EditPhrasesView;", "setMAddPhrasesLayout", "(Lcom/yuyan/imemodule/view/EditPhrasesView;)V", "mBottomPaddingKey", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "mChoiceNotifier", "Lcom/yuyan/imemodule/keyboard/InputView$ChoiceNotifier;", "mComposingTagContainer", "Landroid/widget/LinearLayout;", "mComposingView", "Landroid/widget/TextView;", "mFullDisplayKeyboardBar", "Lcom/yuyan/imemodule/view/FullDisplayKeyboardBar;", "mHoderLayoutLeft", "mHoderLayoutRight", "mInputKeyboardContainer", "Landroid/view/ViewGroup;", "mLlKeyboardBottomHolder", "mLlMainKeyboardCard", "mOnehandHoderLayout", "mRightPaddingKey", "mSkbCandidatesBarView", "Lcom/yuyan/imemodule/view/CandidatesBar;", "getMSkbCandidatesBarView", "()Lcom/yuyan/imemodule/view/CandidatesBar;", "setMSkbCandidatesBarView", "(Lcom/yuyan/imemodule/view/CandidatesBar;)V", "mSkbRoot", "Landroid/widget/RelativeLayout;", "getMSkbRoot", "()Landroid/widget/RelativeLayout;", "setMSkbRoot", "(Landroid/widget/RelativeLayout;)V", "oldCandidatesEnd", "", "selEnd", "selStart", "textBeforeCursors", "Lcom/yuyan/imemodule/entity/StringQueue;", "applyTopWindowCornerRadius", "", "chooseAndUpdate", "candId", "commitClipboardText", "text", "", "commitDecInfoText", "resultText", "commitPairSymbol", "commitText", "commitTextEditMenu", "id", "(Ljava/lang/Integer;)V", "ensureKeyboardVisible", "getKeyboardRect", "", "initNavbarBackground", "initView", "isFunctionKey", "keyCode", "onCandidateChanged", "onClick", "view", "Landroid/view/View;", "onMoveKeyboardEvent", "v", "event", "Landroid/view/MotionEvent;", "onSettingsMenuClick", "skbMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "extra", "Lcom/yuyan/imemodule/database/entry/Phrase;", "onStartInputView", "editorInfo", "Landroid/view/inputmethod/EditorInfo;", "restarting", "onUpdateSelection", "oldSelStart", "oldSelEnd", "newSelStart", "newSelEnd", "candidatesEnd", "onWindowHidden", "onWindowShown", "performEditorAction", "editorAction", "processEnglishKey", "Landroid/view/KeyEvent;", "processFunctionKey", "processInput", "processKeyDown", "processKeyUp", "processSystemKeys", "processUserDefKey", "label", "requestHideSelf", "resetCandidateWindow", "resetToIdleState", "responseHandwritingResultEvent", "words", "", "Lcom/yuyan/inputmethod/core/CandidateListItem;", "([Lcom/yuyan/inputmethod/core/CandidateListItem;)V", "responseKeyEvent", "sKey", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "responseLongKeyEvent", "result", "Lkotlin/Pair;", "Lcom/yuyan/imemodule/prefs/behavior/PopupMenuMode;", "selectPrefix", "position", "sendKeyEvent", "setComposingText", "", "setConfiguration", "newConfig", "Landroid/content/res/Configuration;", "showSymbols", "symbols", "([Ljava/lang/String;)V", "updateCandidate", "updateCandidateBar", "updateComposingTagTheme", "updatePosition", "anchor", "", "updateTheme", "ChoiceNotifier", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class InputView extends com.yuyan.imemodule.callback.IKeyboardView implements com.yuyan.imemodule.callback.IResponseKeyEvent {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.service.ImeService service = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.AppPrefs appPrefs = null;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.prefs.behavior.ChineseAssociationMode chinesePredictionMode = com.yuyan.imemodule.prefs.behavior.ChineseAssociationMode.CONTINUOUS;
    private boolean isAddPhrases = false;
    private boolean isInternalOperation = false;
    private boolean isCursorSwiping = false;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.keyboard.InputView.ChoiceNotifier mChoiceNotifier = null;
    @org.jetbrains.annotations.NotNull()
    private android.widget.RelativeLayout mSkbRoot;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.view.CandidatesBar mSkbCandidatesBarView;
    @org.jetbrains.annotations.NotNull()
    private android.widget.LinearLayout mHoderLayoutLeft;
    @org.jetbrains.annotations.NotNull()
    private android.widget.LinearLayout mHoderLayoutRight;
    private android.widget.LinearLayout mOnehandHoderLayout;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.view.EditPhrasesView mAddPhrasesLayout;
    @org.jetbrains.annotations.NotNull()
    private android.widget.LinearLayout mLlKeyboardBottomHolder;
    @org.jetbrains.annotations.NotNull()
    private android.view.ViewGroup mInputKeyboardContainer;
    private android.view.ViewGroup mLlMainKeyboardCard;
    private android.widget.LinearLayout mComposingTagContainer;
    private android.widget.TextView mComposingView;
    private com.yuyan.imemodule.view.preference.ManagedPreference.PInt mRightPaddingKey;
    private com.yuyan.imemodule.view.preference.ManagedPreference.PInt mBottomPaddingKey;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.view.FullDisplayKeyboardBar mFullDisplayKeyboardBar;
    private boolean hasSelection = false;
    private boolean hasSelectionAll = false;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.entity.StringQueue textBeforeCursors = null;
    private float initialTouchX = 0.0F;
    private float initialTouchY = 0.0F;
    private float initialTranslationX = 0.0F;
    private float initialTranslationY = 0.0F;
    private int selStart = 0;
    private int selEnd = 0;
    private int oldCandidatesEnd = 0;
    
    public InputView(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.service.ImeService service) {
        super(null);
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.service.ImeService getImeService() {
        return null;
    }
    
    public final boolean isAddPhrases() {
        return false;
    }
    
    public final void setAddPhrases(boolean p0) {
    }
    
    public final boolean isInternalOperation() {
        return false;
    }
    
    public final void setInternalOperation(boolean p0) {
    }
    
    public final boolean isCursorSwiping() {
        return false;
    }
    
    public final void setCursorSwiping(boolean p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.widget.RelativeLayout getMSkbRoot() {
        return null;
    }
    
    public final void setMSkbRoot(@org.jetbrains.annotations.NotNull()
    android.widget.RelativeLayout p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.CandidatesBar getMSkbCandidatesBarView() {
        return null;
    }
    
    public final void setMSkbCandidatesBarView(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.CandidatesBar p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.EditPhrasesView getMAddPhrasesLayout() {
        return null;
    }
    
    public final void setMAddPhrasesLayout(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.EditPhrasesView p0) {
    }
    
    public final boolean getHasSelection() {
        return false;
    }
    
    public final void setHasSelection(boolean p0) {
    }
    
    public final boolean getHasSelectionAll() {
        return false;
    }
    
    public final void setHasSelectionAll(boolean p0) {
    }
    
    @java.lang.Override()
    public void onCandidateChanged() {
    }
    
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public final void initView(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    public final void applyTopWindowCornerRadius() {
    }
    
    private final boolean onMoveKeyboardEvent(android.view.View v, android.view.MotionEvent event) {
        return false;
    }
    
    @java.lang.Override()
    public void updateTheme() {
    }
    
    public final void updateComposingTagTheme() {
    }
    
    private final void onClick(android.view.View view) {
    }
    
    @java.lang.Override()
    public void responseLongKeyEvent(@org.jetbrains.annotations.NotNull()
    kotlin.Pair<? extends com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> result) {
    }
    
    @java.lang.Override()
    public void responseHandwritingResultEvent(@org.jetbrains.annotations.NotNull()
    com.yuyan.inputmethod.core.CandidateListItem[] words) {
    }
    
    @java.lang.Override()
    public void responseKeyEvent(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.keyboard.SoftKey sKey) {
    }
    
    @java.lang.Override()
    public boolean processKeyDown(int keyCode, @org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    @java.lang.Override()
    public boolean processKeyUp(@org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    private final boolean processEnglishKey(android.view.KeyEvent event) {
        return false;
    }
    
    private final boolean processSystemKeys(android.view.KeyEvent event) {
        return false;
    }
    
    public final boolean isFunctionKey(int keyCode) {
        return false;
    }
    
    private final void processFunctionKey(android.view.KeyEvent event) {
    }
    
    private final void processUserDefKey(int keyCode, java.lang.String label) {
    }
    
    private final boolean processInput(android.view.KeyEvent event) {
        return false;
    }
    
    public final void resetToIdleState() {
    }
    
    public final void chooseAndUpdate(int candId) {
    }
    
    private final void updateCandidate() {
    }
    
    public final void updateCandidateBar() {
    }
    
    private final void resetCandidateWindow() {
    }
    
    public final void onSettingsMenuClick(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode, @org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.database.entry.Phrase extra) {
    }
    
    public final void selectPrefix(int position) {
    }
    
    @java.lang.Override()
    public void showSymbols(@org.jetbrains.annotations.NotNull()
    java.lang.String[] symbols) {
    }
    
    public final void requestHideSelf() {
    }
    
    private final void sendKeyEvent(int keyCode) {
    }
    
    private final void setComposingText(java.lang.CharSequence text) {
    }
    
    private final void commitText(java.lang.String text) {
    }
    
    public final void commitClipboardText(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
    }
    
    private final void commitPairSymbol(java.lang.String text) {
    }
    
    private final void commitTextEditMenu(java.lang.Integer id) {
    }
    
    public final void performEditorAction(int editorAction) {
    }
    
    private final void commitDecInfoText(java.lang.String resultText) {
    }
    
    private final void initNavbarBackground(com.yuyan.imemodule.service.ImeService service) {
    }
    
    @java.lang.Override()
    public void onStartInputView(@org.jetbrains.annotations.NotNull()
    android.view.inputmethod.EditorInfo editorInfo, boolean restarting) {
    }
    
    public final void ensureKeyboardVisible() {
    }
    
    @java.lang.Override()
    public void onWindowShown() {
    }
    
    @java.lang.Override()
    public void onWindowHidden() {
    }
    
    @java.lang.Override()
    public void updatePosition(@org.jetbrains.annotations.NotNull()
    float[] anchor) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public int[] getKeyboardRect() {
        return null;
    }
    
    @java.lang.Override()
    public void setConfiguration(@org.jetbrains.annotations.NotNull()
    android.content.res.Configuration newConfig) {
    }
    
    @java.lang.Override()
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candidatesEnd) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0007\b\u0000\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016J\b\u0010\u0007\u001a\u00020\u0004H\u0016J\b\u0010\b\u001a\u00020\u0004H\u0016J\u0010\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u000bH\u0016J\u0010\u0010\f\u001a\u00020\u00042\u0006\u0010\r\u001a\u00020\u0006H\u0016\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/keyboard/InputView$ChoiceNotifier;", "Lcom/yuyan/imemodule/callback/CandidateViewListener;", "(Lcom/yuyan/imemodule/keyboard/InputView;)V", "onClickChoice", "", "choiceId", "", "onClickClearCandidate", "onClickClearClipBoard", "onClickMenu", "skbMenuMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "onClickMore", "level", "yuyansdk_offlineDebug"})
    public final class ChoiceNotifier implements com.yuyan.imemodule.callback.CandidateViewListener {
        
        public ChoiceNotifier() {
            super();
        }
        
        @java.lang.Override()
        public void onClickChoice(int choiceId) {
        }
        
        @java.lang.Override()
        public void onClickMore(int level) {
        }
        
        @java.lang.Override()
        public void onClickMenu(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.prefs.behavior.SkbMenuMode skbMenuMode) {
        }
        
        @java.lang.Override()
        public void onClickClearCandidate() {
        }
        
        @java.lang.Override()
        public void onClickClearClipBoard() {
        }
    }
}
package com.yuyan.imemodule.database.dao;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0005\bg\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u0012\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u0006H\'J\u001a\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u00062\b\b\u0002\u0010\u0005\u001a\u00020\u0006H\'J\u000e\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00020\nH\'J\u000e\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00020\nH\'J\u001c\u0010\f\u001a\u0004\u0018\u00010\u00022\u0006\u0010\b\u001a\u00020\u00062\b\b\u0002\u0010\u0005\u001a\u00020\u0006H\'J\"\u0010\r\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\u00062\b\b\u0002\u0010\u0005\u001a\u00020\u0006H\'\u00a8\u0006\u000f"}, d2 = {"Lcom/yuyan/imemodule/database/dao/SideSymbolDao;", "Lcom/yuyan/imemodule/database/BaseDao;", "Lcom/yuyan/imemodule/database/entry/SideSymbol;", "deleteAll", "", "type", "", "deleteByKey", "key", "getAllSideSymbolNumber", "", "getAllSideSymbolPinyin", "getByKey", "updateSymbol", "value", "yuyansdk_offlineDebug"})
@androidx.room.Dao()
public abstract interface SideSymbolDao extends com.yuyan.imemodule.database.BaseDao<com.yuyan.imemodule.database.entry.SideSymbol> {
    
    @androidx.room.Query(value = "select * from side_symbol where symbolKey = :key AND type = :type")
    @org.jetbrains.annotations.Nullable()
    public abstract com.yuyan.imemodule.database.entry.SideSymbol getByKey(@org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    java.lang.String type);
    
    @androidx.room.Query(value = "select * from side_symbol where type = \'number\'")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> getAllSideSymbolNumber();
    
    @androidx.room.Query(value = "select * from side_symbol where type = \'pinyin\'")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> getAllSideSymbolPinyin();
    
    @androidx.room.Query(value = "delete from side_symbol where symbolKey = :key AND type = :type")
    public abstract void deleteByKey(@org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    java.lang.String type);
    
    @androidx.room.Query(value = "delete from side_symbol where type = :type")
    public abstract void deleteAll(@org.jetbrains.annotations.NotNull()
    java.lang.String type);
    
    @androidx.room.Query(value = "update side_symbol set symbolValue =:value where symbolKey =:key AND type = :type")
    public abstract void updateSymbol(@org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    java.lang.String value, @org.jetbrains.annotations.NotNull()
    java.lang.String type);
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 3, xi = 48)
    public static final class DefaultImpls {
    }
}
package com.yuyan.inputmethod.data;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0006\u001a\u00020\u0007J\u001a\u0010\b\u001a\u00020\u00072\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00070\nJ\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eJ\u0006\u0010\u000f\u001a\u00020\u0010J\b\u0010\u0011\u001a\u0004\u0018\u00010\u0005J\u0006\u0010\u0012\u001a\u00020\u0007J\u0006\u0010\u0013\u001a\u00020\u0007J\u000e\u0010\u0014\u001a\u00020\u00102\u0006\u0010\u0015\u001a\u00020\u0016J\u0012\u0010\u0017\u001a\u0004\u0018\u00010\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u000eJ\u0010\u0010\u001a\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u0018H\u0002J\u0014\u0010\u001c\u001a\u0004\u0018\u00010\u00182\n\b\u0002\u0010\u001b\u001a\u0004\u0018\u00010\u0018J8\u0010\u001d\u001a\u00020\u0007\"\u0004\b\u0000\u0010\u001e*\u0012\u0012\u0004\u0012\u0002H\u001e0\u0004j\b\u0012\u0004\u0012\u0002H\u001e`\u001f2\u0006\u0010 \u001a\u00020\f2\f\u0010!\u001a\b\u0012\u0004\u0012\u0002H\u001e0\"H\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006#"}, d2 = {"Lcom/yuyan/inputmethod/data/KeyRecordStack;", "", "()V", "keyRecords", "Ljava/util/ArrayList;", "Lcom/yuyan/inputmethod/data/InputKey;", "clear", "", "forEachReversed", "action", "Lkotlin/Function1;", "getRimeKeycodeByName", "", "name", "", "isEmpty", "", "pop", "processDelAction", "pushCandidateSelectAction", "pushKey", "event", "Landroid/view/KeyEvent;", "pushPinyinSelectAction", "Lcom/yuyan/inputmethod/data/InputKey$PinyinKey;", "pinyin", "replacePinyinWithT9Keys", "pinyinKey", "restorePinyinToT9Key", "replaceAt", "T", "Lkotlin/collections/ArrayList;", "index", "elements", "", "yuyansdk_offlineDebug"})
public final class KeyRecordStack {
    @org.jetbrains.annotations.NotNull()
    private final java.util.ArrayList<com.yuyan.inputmethod.data.InputKey> keyRecords = null;
    
    public KeyRecordStack() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.inputmethod.data.InputKey pop() {
        return null;
    }
    
    public final void clear() {
    }
    
    public final boolean isEmpty() {
        return false;
    }
    
    public final void forEachReversed(@org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.yuyan.inputmethod.data.InputKey, kotlin.Unit> action) {
    }
    
    public final boolean pushKey(@org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event) {
        return false;
    }
    
    public final void processDelAction() {
    }
    
    private final void replacePinyinWithT9Keys(com.yuyan.inputmethod.data.InputKey.PinyinKey pinyinKey) {
    }
    
    /**
     * 获取Rime定义键值
     */
    public final int getRimeKeycodeByName(@org.jetbrains.annotations.NotNull()
    java.lang.String name) {
        return 0;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.inputmethod.data.InputKey.PinyinKey pushPinyinSelectAction(@org.jetbrains.annotations.Nullable()
    java.lang.String pinyin) {
        return null;
    }
    
    public final void pushCandidateSelectAction() {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.inputmethod.data.InputKey.PinyinKey restorePinyinToT9Key(@org.jetbrains.annotations.Nullable()
    com.yuyan.inputmethod.data.InputKey.PinyinKey pinyinKey) {
        return null;
    }
    
    private final <T extends java.lang.Object>void replaceAt(java.util.ArrayList<T> $this$replaceAt, int index, java.util.List<? extends T> elements) {
    }
}
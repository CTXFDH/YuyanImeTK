package com.yuyan.imemodule.view.preference;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0017\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0016\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ImeSwitchPreference;", "Landroidx/preference/SwitchPreference;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "onBindViewHolder", "", "holder", "Landroidx/preference/PreferenceViewHolder;", "yuyansdk_offlineDebug"})
public class ImeSwitchPreference extends androidx.preference.SwitchPreference {
    
    public ImeSwitchPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null, null, 0, 0);
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceViewHolder holder) {
    }
}
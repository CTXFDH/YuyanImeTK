package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\n\n\u0000\n\u0002\u0010#\n\u0002\b\u0002\u001a\u0012\u0010\u0000\u001a\b\u0012\u0004\u0012\u0002H\u00020\u0001\"\u0004\b\u0000\u0010\u0002\u00a8\u0006\u0003"}, d2 = {"WeakHashSet", "", "T", "yuyansdk_offlineDebug"})
public final class WeakHashSetKt {
    
    @kotlin.Suppress(names = {"FunctionName"})
    @org.jetbrains.annotations.NotNull()
    public static final <T extends java.lang.Object>java.util.Set<T> WeakHashSet() {
        return null;
    }
}
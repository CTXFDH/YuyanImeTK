package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u000e\u0010\r\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\u00020\u0015X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0018\u001a\u00020\u0019\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001b\u00a8\u0006\u001c"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/NewThemeEntryUi;", "Lsplitties/views/dsl/core/Ui;", "ctx", "Landroid/content/Context;", "(Landroid/content/Context;)V", "cardBgDrawable", "Landroid/graphics/drawable/GradientDrawable;", "getCtx", "()Landroid/content/Context;", "icon", "Landroid/widget/ImageView;", "getIcon", "()Landroid/widget/ImageView;", "iconBadgeDrawable", "iconContainer", "Landroid/widget/FrameLayout;", "getIconContainer", "()Landroid/widget/FrameLayout;", "isDark", "", "root", "Landroid/widget/LinearLayout;", "getRoot", "()Landroid/widget/LinearLayout;", "text", "Landroid/widget/TextView;", "getText", "()Landroid/widget/TextView;", "yuyansdk_offlineDebug"})
public final class NewThemeEntryUi implements splitties.views.dsl.core.Ui {
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context ctx = null;
    private final boolean isDark = false;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.drawable.GradientDrawable cardBgDrawable = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.drawable.GradientDrawable iconBadgeDrawable = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ImageView icon = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.FrameLayout iconContainer = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.TextView text = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.LinearLayout root = null;
    
    public NewThemeEntryUi(@org.jetbrains.annotations.NotNull()
    android.content.Context ctx) {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.content.Context getCtx() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.widget.ImageView getIcon() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.widget.FrameLayout getIconContainer() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.widget.TextView getText() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.widget.LinearLayout getRoot() {
        return null;
    }
}
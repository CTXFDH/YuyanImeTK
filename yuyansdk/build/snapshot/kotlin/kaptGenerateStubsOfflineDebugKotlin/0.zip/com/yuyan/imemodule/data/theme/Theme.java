package com.yuyan.imemodule.data.theme;

@kotlinx.serialization.Serializable()
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0010\u0000\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\bI\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b7\u0018\u0000 \u0099\u00012\u00020\u0001:\u0006\u0098\u0001\u0099\u0001\u009a\u0001B\u0019\b\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006B\u0007\b\u0004\u00a2\u0006\u0002\u0010\u0007J\u0015\u0010\u008e\u0001\u001a\u00030\u008f\u00012\t\b\u0002\u0010\u0090\u0001\u001a\u00020?H\u0016J(\u0010\u0091\u0001\u001a\u00030\u0092\u00012\u0007\u0010\u0093\u0001\u001a\u00020\u00002\b\u0010\u0094\u0001\u001a\u00030\u0095\u00012\b\u0010\u0096\u0001\u001a\u00030\u0097\u0001H\u00c7\u0001R\u0012\u0010\b\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b\t\u0010\nR\u0014\u0010\u000b\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\f\u0010\nR\u0012\u0010\r\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b\u000e\u0010\nR\u0014\u0010\u000f\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0010\u0010\nR\u0014\u0010\u0011\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0012\u0010\nR\u0014\u0010\u0013\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0014\u0010\nR\u0014\u0010\u0015\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0016\u0010\nR\u0014\u0010\u0017\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0018\u0010\nR\u0014\u0010\u0019\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u001a\u0010\nR\u0016\u0010\u001b\u001a\u0004\u0018\u00010\u001c8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u001d\u0010\u001eR\u0012\u0010\u001f\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b \u0010\nR\u0014\u0010!\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\"\u0010\nR\u0014\u0010#\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b$\u0010\nR\u0014\u0010%\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b&\u0010\nR\u0014\u0010\'\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b(\u0010\nR\u0016\u0010)\u001a\u0004\u0018\u00010*8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b+\u0010,R\u0016\u0010-\u001a\u0004\u0018\u00010.8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b/\u00100R\u0016\u00101\u001a\u0004\u0018\u00010\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b2\u00103R\u0014\u00104\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b5\u0010\nR\u0014\u00106\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b7\u0010\nR\u0014\u00108\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b9\u0010\nR\u0012\u0010:\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b;\u0010\nR\u0012\u0010<\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b=\u0010\nR\u0012\u0010>\u001a\u00020?X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b>\u0010@R\u0012\u0010A\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\bB\u0010\nR \u0010C\u001a\u000e\u0012\u0004\u0012\u00020.\u0012\u0004\u0012\u00020E0D8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bF\u0010GR\u0012\u0010H\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\bI\u0010\nR\u0014\u0010J\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bK\u0010\nR\u0012\u0010L\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\bM\u0010\nR\u0014\u0010N\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bO\u0010\nR\u0012\u0010P\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\bQ\u0010\nR\u0012\u0010R\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\bS\u0010\nR\u0012\u0010T\u001a\u00020.X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\bU\u00100R\u0014\u0010V\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bW\u0010\nR\u0014\u0010X\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bY\u0010\nR\u0014\u0010Z\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b[\u0010\nR\u0014\u0010\\\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b]\u0010\nR\u0014\u0010^\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b_\u0010\nR\u0014\u0010`\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\ba\u0010\nR\u0012\u0010b\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\bc\u0010\nR\u0014\u0010d\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\be\u0010\nR\u0014\u0010f\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bg\u0010\nR\u0014\u0010h\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bi\u0010\nR\u0014\u0010j\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bk\u0010\nR\u0014\u0010l\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bm\u0010\nR\u0014\u0010n\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bo\u0010\nR\u0014\u0010p\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bq\u0010\nR\u0014\u0010r\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bs\u0010\nR\u0014\u0010t\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\bu\u0010\nR\u0012\u0010v\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\bw\u0010\nR\u0012\u0010x\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\by\u0010\nR\u0012\u0010z\u001a\u00020\u0003X\u00a6\u0004\u00a2\u0006\u0006\u001a\u0004\b{\u0010\nR\u0014\u0010|\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b}\u0010\nR\u0014\u0010~\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u007f\u0010\nR\u0016\u0010\u0080\u0001\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\b\u0081\u0001\u0010\nR\u0016\u0010\u0082\u0001\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\b\u0083\u0001\u0010\nR\u0016\u0010\u0084\u0001\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\b\u0085\u0001\u0010\nR\u0016\u0010\u0086\u0001\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\b\u0087\u0001\u0010\nR\u0016\u0010\u0088\u0001\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\b\u0089\u0001\u0010\nR\u0016\u0010\u008a\u0001\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\b\u008b\u0001\u0010\nR\u0016\u0010\u008c\u0001\u001a\u00020\u00038VX\u0096\u0004\u00a2\u0006\u0007\u001a\u0005\b\u008d\u0001\u0010\n\u0082\u0001\u0004\u009b\u0001\u009c\u0001\u00a8\u0006\u009d\u0001"}, d2 = {"Lcom/yuyan/imemodule/data/theme/Theme;", "Landroid/os/Parcelable;", "seen1", "", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILkotlinx/serialization/internal/SerializationConstructorMarker;)V", "()V", "accentKeyBackgroundColor", "getAccentKeyBackgroundColor", "()I", "accentKeyPressColor", "getAccentKeyPressColor", "accentKeyTextColor", "getAccentKeyTextColor", "arrowButtonBackgroundColor", "getArrowButtonBackgroundColor", "arrowButtonTextColor", "getArrowButtonTextColor", "atKeyBackgroundColor", "getAtKeyBackgroundColor", "atKeyPressColor", "getAtKeyPressColor", "atKeyTextColor", "getAtKeyTextColor", "backgroundBlurRadius", "getBackgroundBlurRadius", "backgroundImage", "", "getBackgroundImage", "()Ljava/lang/Object;", "barColor", "getBarColor", "candidateTextColor", "getCandidateTextColor", "clearKeyBackgroundColor", "getClearKeyBackgroundColor", "clearKeyPressColor", "getClearKeyPressColor", "clearKeyTextColor", "getClearKeyTextColor", "customLogoCropRect", "Landroid/graphics/Rect;", "getCustomLogoCropRect", "()Landroid/graphics/Rect;", "customLogoFilePath", "", "getCustomLogoFilePath", "()Ljava/lang/String;", "customLogoResId", "getCustomLogoResId", "()Ljava/lang/Integer;", "deleteKeyBackgroundColor", "getDeleteKeyBackgroundColor", "deleteKeyPressColor", "getDeleteKeyPressColor", "deleteKeyTextColor", "getDeleteKeyTextColor", "functionKeyBackgroundColor", "getFunctionKeyBackgroundColor", "functionKeyPressHighlightColor", "getFunctionKeyPressHighlightColor", "isDark", "", "()Z", "keyBackgroundColor", "getKeyBackgroundColor", "keyCustomOverrides", "", "Lcom/yuyan/imemodule/data/theme/KeyCustomOverride;", "getKeyCustomOverrides", "()Ljava/util/Map;", "keyPressHighlightColor", "getKeyPressHighlightColor", "keySmallSymbolColor", "getKeySmallSymbolColor", "keyTextColor", "getKeyTextColor", "keyboardAlpha", "getKeyboardAlpha", "keyboardColor", "getKeyboardColor", "keyboardResources", "getKeyboardResources", "name", "getName", "numberKeyBackgroundColor", "getNumberKeyBackgroundColor", "numberKeyPressColor", "getNumberKeyPressColor", "numberKeyTextColor", "getNumberKeyTextColor", "periodKeyBackgroundColor", "getPeriodKeyBackgroundColor", "periodKeyPressColor", "getPeriodKeyPressColor", "periodKeyTextColor", "getPeriodKeyTextColor", "popupBackgroundColor", "getPopupBackgroundColor", "popupHighlightColor", "getPopupHighlightColor", "returnKeyBackgroundColor", "getReturnKeyBackgroundColor", "returnKeyPressColor", "getReturnKeyPressColor", "returnKeyTextColor", "getReturnKeyTextColor", "shiftKeyActiveBackgroundColor", "getShiftKeyActiveBackgroundColor", "shiftKeyBackgroundColor", "getShiftKeyBackgroundColor", "shiftKeyLockBackgroundColor", "getShiftKeyLockBackgroundColor", "shiftKeyPressColor", "getShiftKeyPressColor", "shiftKeyTextColor", "getShiftKeyTextColor", "sideSymbolKeyBackgroundColor", "getSideSymbolKeyBackgroundColor", "sideSymbolKeyPressColor", "getSideSymbolKeyPressColor", "sideSymbolKeyTextColor", "getSideSymbolKeyTextColor", "spaceKeyBackgroundColor", "getSpaceKeyBackgroundColor", "spaceKeyPressHighlightColor", "getSpaceKeyPressHighlightColor", "spaceKeyTextColor", "getSpaceKeyTextColor", "symbolKeyBackgroundColor", "getSymbolKeyBackgroundColor", "symbolKeyPressColor", "getSymbolKeyPressColor", "symbolKeyTextColor", "getSymbolKeyTextColor", "toolbarActiveIconColor", "getToolbarActiveIconColor", "toolbarBackgroundColor", "getToolbarBackgroundColor", "toolbarTextColor", "getToolbarTextColor", "backgroundDrawable", "Landroid/graphics/drawable/Drawable;", "keyBorder", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "Builtin", "Companion", "Custom", "Lcom/yuyan/imemodule/data/theme/Theme$Builtin;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "yuyansdk_offlineDebug"})
public abstract class Theme implements android.os.Parcelable {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.theme.Theme.Companion Companion = null;
    
    private Theme() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public abstract java.lang.String getName();
    
    public abstract boolean isDark();
    
    public abstract int getBarColor();
    
    public abstract int getKeyboardResources();
    
    public abstract int getKeyboardColor();
    
    @org.jetbrains.annotations.Nullable()
    public java.lang.Object getBackgroundImage() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public java.lang.String getCustomLogoFilePath() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public android.graphics.Rect getCustomLogoCropRect() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public java.lang.Integer getCustomLogoResId() {
        return null;
    }
    
    public int getBackgroundBlurRadius() {
        return 0;
    }
    
    public int getKeyboardAlpha() {
        return 0;
    }
    
    public abstract int getKeyTextColor();
    
    public int getKeySmallSymbolColor() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> getKeyCustomOverrides() {
        return null;
    }
    
    public abstract int getKeyBackgroundColor();
    
    public abstract int getKeyPressHighlightColor();
    
    public int getSpaceKeyBackgroundColor() {
        return 0;
    }
    
    public int getSpaceKeyTextColor() {
        return 0;
    }
    
    public int getSpaceKeyPressHighlightColor() {
        return 0;
    }
    
    public int getDeleteKeyBackgroundColor() {
        return 0;
    }
    
    public int getDeleteKeyTextColor() {
        return 0;
    }
    
    public int getDeleteKeyPressColor() {
        return 0;
    }
    
    public int getClearKeyBackgroundColor() {
        return 0;
    }
    
    public int getClearKeyTextColor() {
        return 0;
    }
    
    public int getClearKeyPressColor() {
        return 0;
    }
    
    public int getReturnKeyBackgroundColor() {
        return 0;
    }
    
    public int getReturnKeyTextColor() {
        return 0;
    }
    
    public int getReturnKeyPressColor() {
        return 0;
    }
    
    public int getSymbolKeyBackgroundColor() {
        return 0;
    }
    
    public int getSymbolKeyTextColor() {
        return 0;
    }
    
    public int getSymbolKeyPressColor() {
        return 0;
    }
    
    public int getPeriodKeyBackgroundColor() {
        return 0;
    }
    
    public int getPeriodKeyTextColor() {
        return 0;
    }
    
    public int getPeriodKeyPressColor() {
        return 0;
    }
    
    public int getShiftKeyBackgroundColor() {
        return 0;
    }
    
    public int getShiftKeyActiveBackgroundColor() {
        return 0;
    }
    
    public int getShiftKeyLockBackgroundColor() {
        return 0;
    }
    
    public int getShiftKeyTextColor() {
        return 0;
    }
    
    public int getShiftKeyPressColor() {
        return 0;
    }
    
    public int getAtKeyBackgroundColor() {
        return 0;
    }
    
    public int getAtKeyTextColor() {
        return 0;
    }
    
    public int getAtKeyPressColor() {
        return 0;
    }
    
    public int getNumberKeyBackgroundColor() {
        return 0;
    }
    
    public int getNumberKeyTextColor() {
        return 0;
    }
    
    public int getNumberKeyPressColor() {
        return 0;
    }
    
    public abstract int getSideSymbolKeyBackgroundColor();
    
    public abstract int getSideSymbolKeyTextColor();
    
    public abstract int getSideSymbolKeyPressColor();
    
    public int getToolbarBackgroundColor() {
        return 0;
    }
    
    public int getToolbarTextColor() {
        return 0;
    }
    
    public int getToolbarActiveIconColor() {
        return 0;
    }
    
    public int getCandidateTextColor() {
        return 0;
    }
    
    public int getArrowButtonBackgroundColor() {
        return 0;
    }
    
    public int getArrowButtonTextColor() {
        return 0;
    }
    
    public int getAccentKeyPressColor() {
        return 0;
    }
    
    public int getPopupHighlightColor() {
        return 0;
    }
    
    public abstract int getFunctionKeyBackgroundColor();
    
    public abstract int getFunctionKeyPressHighlightColor();
    
    public abstract int getAccentKeyBackgroundColor();
    
    public abstract int getAccentKeyTextColor();
    
    public abstract int getPopupBackgroundColor();
    
    @org.jetbrains.annotations.NotNull()
    public android.graphics.drawable.Drawable backgroundDrawable(boolean keyBorder) {
        return null;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final void write$Self(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme self, @org.jetbrains.annotations.NotNull()
    kotlinx.serialization.encoding.CompositeEncoder output, @org.jetbrains.annotations.NotNull()
    kotlinx.serialization.descriptors.SerialDescriptor serialDesc) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0004\n\u0002\b\u000b\n\u0002\u0010\b\n\u0002\b\u0010\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\bC\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001Bo\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\u0006\u0010\u000b\u001a\u00020\u0007\u0012\u0006\u0010\f\u001a\u00020\u0007\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u0007\u0012\u0006\u0010\u000f\u001a\u00020\u0007\u0012\u0006\u0010\u0010\u001a\u00020\u0007\u0012\u0006\u0010\u0011\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\u0012B\u009b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0013\u0012\u0006\u0010\b\u001a\u00020\u0013\u0012\u0006\u0010\t\u001a\u00020\u0013\u0012\u0006\u0010\n\u001a\u00020\u0013\u0012\u0006\u0010\u000b\u001a\u00020\u0013\u0012\u0006\u0010\f\u001a\u00020\u0013\u0012\u0006\u0010\r\u001a\u00020\u0013\u0012\u0006\u0010\u000e\u001a\u00020\u0013\u0012\u0006\u0010\u000f\u001a\u00020\u0013\u0012\u0006\u0010\u0010\u001a\u00020\u0013\u0012\u0006\u0010\u0011\u001a\u00020\u0013\u0012\n\b\u0002\u0010\u0014\u001a\u0004\u0018\u00010\u0013\u0012\b\b\u0002\u0010\u0015\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0016\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0017\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0018\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u0019\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u001a\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u001b\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u001c\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u001d\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u001e\u001a\u00020\u0013\u0012\b\b\u0002\u0010\u001f\u001a\u00020\u0013\u0012\b\b\u0002\u0010 \u001a\u00020\u0013\u0012\b\b\u0002\u0010!\u001a\u00020\u0013\u0012\b\b\u0002\u0010\"\u001a\u00020\u0013\u0012\u0014\b\u0002\u0010#\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020%0$\u00a2\u0006\u0002\u0010&J\t\u0010I\u001a\u00020\u0003H\u00c6\u0003J\t\u0010J\u001a\u00020\u0013H\u00c6\u0003J\t\u0010K\u001a\u00020\u0013H\u00c6\u0003J\t\u0010L\u001a\u00020\u0013H\u00c6\u0003J\t\u0010M\u001a\u00020\u0013H\u00c6\u0003J\u0010\u0010N\u001a\u0004\u0018\u00010\u0013H\u00c6\u0003\u00a2\u0006\u0002\u0010-J\t\u0010O\u001a\u00020\u0013H\u00c6\u0003J\t\u0010P\u001a\u00020\u0013H\u00c6\u0003J\t\u0010Q\u001a\u00020\u0013H\u00c6\u0003J\t\u0010R\u001a\u00020\u0013H\u00c6\u0003J\t\u0010S\u001a\u00020\u0013H\u00c6\u0003J\t\u0010T\u001a\u00020\u0005H\u00c6\u0003J\t\u0010U\u001a\u00020\u0013H\u00c6\u0003J\t\u0010V\u001a\u00020\u0013H\u00c6\u0003J\t\u0010W\u001a\u00020\u0013H\u00c6\u0003J\t\u0010X\u001a\u00020\u0013H\u00c6\u0003J\t\u0010Y\u001a\u00020\u0013H\u00c6\u0003J\t\u0010Z\u001a\u00020\u0013H\u00c6\u0003J\t\u0010[\u001a\u00020\u0013H\u00c6\u0003J\t\u0010\\\u001a\u00020\u0013H\u00c6\u0003J\t\u0010]\u001a\u00020\u0013H\u00c6\u0003J\u0015\u0010^\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020%0$H\u00c6\u0003J\t\u0010_\u001a\u00020\u0013H\u00c6\u0003J\t\u0010`\u001a\u00020\u0013H\u00c6\u0003J\t\u0010a\u001a\u00020\u0013H\u00c6\u0003J\t\u0010b\u001a\u00020\u0013H\u00c6\u0003J\t\u0010c\u001a\u00020\u0013H\u00c6\u0003J\t\u0010d\u001a\u00020\u0013H\u00c6\u0003J\t\u0010e\u001a\u00020\u0013H\u00c6\u0003J\u00be\u0002\u0010f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00132\b\b\u0002\u0010\b\u001a\u00020\u00132\b\b\u0002\u0010\t\u001a\u00020\u00132\b\b\u0002\u0010\n\u001a\u00020\u00132\b\b\u0002\u0010\u000b\u001a\u00020\u00132\b\b\u0002\u0010\f\u001a\u00020\u00132\b\b\u0002\u0010\r\u001a\u00020\u00132\b\b\u0002\u0010\u000e\u001a\u00020\u00132\b\b\u0002\u0010\u000f\u001a\u00020\u00132\b\b\u0002\u0010\u0010\u001a\u00020\u00132\b\b\u0002\u0010\u0011\u001a\u00020\u00132\n\b\u0002\u0010\u0014\u001a\u0004\u0018\u00010\u00132\b\b\u0002\u0010\u0015\u001a\u00020\u00132\b\b\u0002\u0010\u0016\u001a\u00020\u00132\b\b\u0002\u0010\u0017\u001a\u00020\u00132\b\b\u0002\u0010\u0018\u001a\u00020\u00132\b\b\u0002\u0010\u0019\u001a\u00020\u00132\b\b\u0002\u0010\u001a\u001a\u00020\u00132\b\b\u0002\u0010\u001b\u001a\u00020\u00132\b\b\u0002\u0010\u001c\u001a\u00020\u00132\b\b\u0002\u0010\u001d\u001a\u00020\u00132\b\b\u0002\u0010\u001e\u001a\u00020\u00132\b\b\u0002\u0010\u001f\u001a\u00020\u00132\b\b\u0002\u0010 \u001a\u00020\u00132\b\b\u0002\u0010!\u001a\u00020\u00132\b\b\u0002\u0010\"\u001a\u00020\u00132\u0014\b\u0002\u0010#\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020%0$H\u00c6\u0001\u00a2\u0006\u0002\u0010gJ8\u0010h\u001a\u00020i2\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010j\u001a\u00020\u00032\b\b\u0002\u0010k\u001a\u00020\u00132\n\b\u0002\u0010l\u001a\u0004\u0018\u00010m2\n\b\u0002\u0010n\u001a\u0004\u0018\u00010\u0003J\u001a\u0010o\u001a\u00020i2\u0006\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010n\u001a\u0004\u0018\u00010\u0003J\t\u0010p\u001a\u00020\u0013H\u00d6\u0001J\u0013\u0010q\u001a\u00020\u00052\b\u0010r\u001a\u0004\u0018\u00010sH\u00d6\u0003J\t\u0010t\u001a\u00020\u0013H\u00d6\u0001J\t\u0010u\u001a\u00020\u0003H\u00d6\u0001J\u0019\u0010v\u001a\u00020w2\u0006\u0010x\u001a\u00020y2\u0006\u0010z\u001a\u00020\u0013H\u00d6\u0001R\u0014\u0010\f\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010(R\u0014\u0010\r\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010(R\u0014\u0010\b\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010(R\u0014\u0010\"\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010(R\u0018\u0010\u0014\u001a\u0004\u0018\u00010\u0013X\u0096\u0004\u00a2\u0006\n\n\u0002\u0010.\u001a\u0004\b,\u0010-R\u0014\u0010\u001c\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u0010(R\u0014\u0010\u001d\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u0010(R\u0014\u0010\u0010\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u0010(R\u0014\u0010\u0011\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u0010(R\u0014\u0010\u0004\u001a\u00020\u0005X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0004\u00103R\u0014\u0010\n\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b4\u0010(R \u0010#\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020%0$X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b5\u00106R\u0014\u0010\u000e\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b7\u0010(R\u0014\u0010\u000b\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b8\u0010(R\u0014\u0010\t\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b9\u0010(R\u0014\u0010\u0006\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b:\u0010(R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b;\u0010<R\u0014\u0010\u001a\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b=\u0010(R\u0014\u0010\u001b\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b>\u0010(R\u0014\u0010\u000f\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b?\u0010(R\u0014\u0010\u001e\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b@\u0010(R\u0014\u0010\u001f\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bA\u0010(R\u0014\u0010\u0015\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bB\u0010(R\u0014\u0010\u0017\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bC\u0010(R\u0014\u0010\u0016\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bD\u0010(R\u0014\u0010\u0018\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bE\u0010(R\u0014\u0010\u0019\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bF\u0010(R\u0014\u0010!\u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bG\u0010(R\u0014\u0010 \u001a\u00020\u0013X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bH\u0010(\u00a8\u0006{"}, d2 = {"Lcom/yuyan/imemodule/data/theme/Theme$Builtin;", "Lcom/yuyan/imemodule/data/theme/Theme;", "name", "", "isDark", "", "keyboardResources", "", "barColor", "keyboardColor", "keyBackgroundColor", "keyTextColor", "accentKeyBackgroundColor", "accentKeyTextColor", "keyPressHighlightColor", "popupBackgroundColor", "functionKeyBackgroundColor", "functionKeyPressHighlightColor", "(Ljava/lang/String;ZLjava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;Ljava/lang/Number;)V", "", "customLogoResId", "sideSymbolKeyBackgroundColor", "sideSymbolKeyTextColor", "sideSymbolKeyPressColor", "symbolKeyBackgroundColor", "symbolKeyTextColor", "numberKeyBackgroundColor", "numberKeyTextColor", "deleteKeyBackgroundColor", "deleteKeyTextColor", "returnKeyBackgroundColor", "returnKeyTextColor", "toolbarTextColor", "toolbarActiveIconColor", "candidateTextColor", "keyCustomOverrides", "", "Lcom/yuyan/imemodule/data/theme/KeyCustomOverride;", "(Ljava/lang/String;ZIIIIIIIIIIILjava/lang/Integer;IIIIIIIIIIIIIILjava/util/Map;)V", "getAccentKeyBackgroundColor", "()I", "getAccentKeyTextColor", "getBarColor", "getCandidateTextColor", "getCustomLogoResId", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getDeleteKeyBackgroundColor", "getDeleteKeyTextColor", "getFunctionKeyBackgroundColor", "getFunctionKeyPressHighlightColor", "()Z", "getKeyBackgroundColor", "getKeyCustomOverrides", "()Ljava/util/Map;", "getKeyPressHighlightColor", "getKeyTextColor", "getKeyboardColor", "getKeyboardResources", "getName", "()Ljava/lang/String;", "getNumberKeyBackgroundColor", "getNumberKeyTextColor", "getPopupBackgroundColor", "getReturnKeyBackgroundColor", "getReturnKeyTextColor", "getSideSymbolKeyBackgroundColor", "getSideSymbolKeyPressColor", "getSideSymbolKeyTextColor", "getSymbolKeyBackgroundColor", "getSymbolKeyTextColor", "getToolbarActiveIconColor", "getToolbarTextColor", "component1", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "component19", "component2", "component20", "component21", "component22", "component23", "component24", "component25", "component26", "component27", "component28", "component29", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "(Ljava/lang/String;ZIIIIIIIIIIILjava/lang/Integer;IIIIIIIIIIIIIILjava/util/Map;)Lcom/yuyan/imemodule/data/theme/Theme$Builtin;", "deriveCustomBackground", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "originBackgroundImage", "brightness", "cropBackgroundRect", "Landroid/graphics/Rect;", "customLogo", "deriveCustomNoBackground", "describeContents", "equals", "other", "", "hashCode", "toString", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "yuyansdk_offlineDebug"})
    @kotlinx.parcelize.Parcelize()
    public static final class Builtin extends com.yuyan.imemodule.data.theme.Theme {
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String name = null;
        private final boolean isDark = false;
        private final int keyboardResources = 0;
        private final int barColor = 0;
        private final int keyboardColor = 0;
        private final int keyBackgroundColor = 0;
        private final int keyTextColor = 0;
        private final int accentKeyBackgroundColor = 0;
        private final int accentKeyTextColor = 0;
        private final int keyPressHighlightColor = 0;
        private final int popupBackgroundColor = 0;
        private final int functionKeyBackgroundColor = 0;
        private final int functionKeyPressHighlightColor = 0;
        @org.jetbrains.annotations.Nullable()
        private final java.lang.Integer customLogoResId = null;
        private final int sideSymbolKeyBackgroundColor = 0;
        private final int sideSymbolKeyTextColor = 0;
        private final int sideSymbolKeyPressColor = 0;
        private final int symbolKeyBackgroundColor = 0;
        private final int symbolKeyTextColor = 0;
        private final int numberKeyBackgroundColor = 0;
        private final int numberKeyTextColor = 0;
        private final int deleteKeyBackgroundColor = 0;
        private final int deleteKeyTextColor = 0;
        private final int returnKeyBackgroundColor = 0;
        private final int returnKeyTextColor = 0;
        private final int toolbarTextColor = 0;
        private final int toolbarActiveIconColor = 0;
        private final int candidateTextColor = 0;
        @org.jetbrains.annotations.NotNull()
        private final java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> keyCustomOverrides = null;
        
        public Builtin(@org.jetbrains.annotations.NotNull()
        java.lang.String name, boolean isDark, int keyboardResources, int barColor, int keyboardColor, int keyBackgroundColor, int keyTextColor, int accentKeyBackgroundColor, int accentKeyTextColor, int keyPressHighlightColor, int popupBackgroundColor, int functionKeyBackgroundColor, int functionKeyPressHighlightColor, @org.jetbrains.annotations.Nullable()
        java.lang.Integer customLogoResId, int sideSymbolKeyBackgroundColor, int sideSymbolKeyTextColor, int sideSymbolKeyPressColor, int symbolKeyBackgroundColor, int symbolKeyTextColor, int numberKeyBackgroundColor, int numberKeyTextColor, int deleteKeyBackgroundColor, int deleteKeyTextColor, int returnKeyBackgroundColor, int returnKeyTextColor, int toolbarTextColor, int toolbarActiveIconColor, int candidateTextColor, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> keyCustomOverrides) {
            super(0, null);
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String getName() {
            return null;
        }
        
        @java.lang.Override()
        public boolean isDark() {
            return false;
        }
        
        @java.lang.Override()
        public int getKeyboardResources() {
            return 0;
        }
        
        @java.lang.Override()
        public int getBarColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyboardColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getAccentKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getAccentKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyPressHighlightColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getPopupBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getFunctionKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getFunctionKeyPressHighlightColor() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.Nullable()
        public java.lang.Integer getCustomLogoResId() {
            return null;
        }
        
        @java.lang.Override()
        public int getSideSymbolKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSideSymbolKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSideSymbolKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSymbolKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSymbolKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getNumberKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getNumberKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getDeleteKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getDeleteKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getReturnKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getReturnKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getToolbarTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getToolbarActiveIconColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getCandidateTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> getKeyCustomOverrides() {
            return null;
        }
        
        public Builtin(@org.jetbrains.annotations.NotNull()
        java.lang.String name, boolean isDark, @org.jetbrains.annotations.NotNull()
        java.lang.Number keyboardResources, @org.jetbrains.annotations.NotNull()
        java.lang.Number barColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number keyboardColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number keyBackgroundColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number keyTextColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number accentKeyBackgroundColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number accentKeyTextColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number keyPressHighlightColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number popupBackgroundColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number functionKeyBackgroundColor, @org.jetbrains.annotations.NotNull()
        java.lang.Number functionKeyPressHighlightColor) {
            super(0, null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.data.theme.Theme.Custom deriveCustomNoBackground(@org.jetbrains.annotations.NotNull()
        java.lang.String name, @org.jetbrains.annotations.Nullable()
        java.lang.String customLogo) {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.data.theme.Theme.Custom deriveCustomBackground(@org.jetbrains.annotations.NotNull()
        java.lang.String name, @org.jetbrains.annotations.NotNull()
        java.lang.String originBackgroundImage, int brightness, @org.jetbrains.annotations.Nullable()
        android.graphics.Rect cropBackgroundRect, @org.jetbrains.annotations.Nullable()
        java.lang.String customLogo) {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component1() {
            return null;
        }
        
        public final int component10() {
            return 0;
        }
        
        public final int component11() {
            return 0;
        }
        
        public final int component12() {
            return 0;
        }
        
        public final int component13() {
            return 0;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.Integer component14() {
            return null;
        }
        
        public final int component15() {
            return 0;
        }
        
        public final int component16() {
            return 0;
        }
        
        public final int component17() {
            return 0;
        }
        
        public final int component18() {
            return 0;
        }
        
        public final int component19() {
            return 0;
        }
        
        public final boolean component2() {
            return false;
        }
        
        public final int component20() {
            return 0;
        }
        
        public final int component21() {
            return 0;
        }
        
        public final int component22() {
            return 0;
        }
        
        public final int component23() {
            return 0;
        }
        
        public final int component24() {
            return 0;
        }
        
        public final int component25() {
            return 0;
        }
        
        public final int component26() {
            return 0;
        }
        
        public final int component27() {
            return 0;
        }
        
        public final int component28() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> component29() {
            return null;
        }
        
        public final int component3() {
            return 0;
        }
        
        public final int component4() {
            return 0;
        }
        
        public final int component5() {
            return 0;
        }
        
        public final int component6() {
            return 0;
        }
        
        public final int component7() {
            return 0;
        }
        
        public final int component8() {
            return 0;
        }
        
        public final int component9() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.data.theme.Theme.Builtin copy(@org.jetbrains.annotations.NotNull()
        java.lang.String name, boolean isDark, int keyboardResources, int barColor, int keyboardColor, int keyBackgroundColor, int keyTextColor, int accentKeyBackgroundColor, int accentKeyTextColor, int keyPressHighlightColor, int popupBackgroundColor, int functionKeyBackgroundColor, int functionKeyPressHighlightColor, @org.jetbrains.annotations.Nullable()
        java.lang.Integer customLogoResId, int sideSymbolKeyBackgroundColor, int sideSymbolKeyTextColor, int sideSymbolKeyPressColor, int symbolKeyBackgroundColor, int symbolKeyTextColor, int numberKeyBackgroundColor, int numberKeyTextColor, int deleteKeyBackgroundColor, int deleteKeyTextColor, int returnKeyBackgroundColor, int returnKeyTextColor, int toolbarTextColor, int toolbarActiveIconColor, int candidateTextColor, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> keyCustomOverrides) {
            return null;
        }
        
        @java.lang.Override()
        public int describeContents() {
            return 0;
        }
        
        @java.lang.Override()
        public boolean equals(@org.jetbrains.annotations.Nullable()
        java.lang.Object other) {
            return false;
        }
        
        @java.lang.Override()
        public int hashCode() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String toString() {
            return null;
        }
        
        @java.lang.Override()
        public void writeToParcel(@org.jetbrains.annotations.NotNull()
        android.os.Parcel parcel, int flags) {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u00c6\u0001\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/data/theme/Theme$Companion;", "", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/yuyan/imemodule/data/theme/Theme;", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlinx.serialization.KSerializer<com.yuyan.imemodule.data.theme.Theme> serializer() {
            return null;
        }
    }
    
    @kotlinx.serialization.Serializable()
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000x\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b4\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\bA\n\u0002\u0018\u0002\n\u0002\b>\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0087\b\u0018\u0000 \u00d9\u00012\u00020\u0001:\u0006\u00d8\u0001\u00d9\u0001\u00da\u0001B\u008e\u0004\b\u0011\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\u0006\u0012\u0017\u0010\f\u001a\u0013\u0018\u00010\r\u00a2\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\t0\u0010\u0012\u0006\u0010\u0011\u001a\u00020\u0003\u0012\u0006\u0010\u0012\u001a\u00020\u0003\u0012\u0006\u0010\u0013\u001a\u00020\u0003\u0012\u0006\u0010\u0014\u001a\u00020\u0003\u0012\u0006\u0010\u0015\u001a\u00020\u0003\u0012\u0006\u0010\u0016\u001a\u00020\u0003\u0012\u0006\u0010\u0017\u001a\u00020\u0003\u0012\u0006\u0010\u0018\u001a\u00020\u0003\u0012\u0006\u0010\u0019\u001a\u00020\u0003\u0012\u0006\u0010\u001a\u001a\u00020\u0003\u0012\u0006\u0010\u001b\u001a\u00020\u0003\u0012\u0006\u0010\u001c\u001a\u00020\u0003\u0012\u0006\u0010\u001d\u001a\u00020\u0003\u0012\u0006\u0010\u001e\u001a\u00020\u0003\u0012\u0006\u0010\u001f\u001a\u00020\u0003\u0012\u0006\u0010 \u001a\u00020\u0003\u0012\u0006\u0010!\u001a\u00020\u0003\u0012\u0006\u0010\"\u001a\u00020\u0003\u0012\u0006\u0010#\u001a\u00020\u0003\u0012\u0006\u0010$\u001a\u00020\u0003\u0012\u0006\u0010%\u001a\u00020\u0003\u0012\u0006\u0010&\u001a\u00020\u0003\u0012\u0006\u0010\'\u001a\u00020\u0003\u0012\u0006\u0010(\u001a\u00020\u0003\u0012\u0006\u0010)\u001a\u00020\u0003\u0012\u0006\u0010*\u001a\u00020\u0003\u0012\u0006\u0010+\u001a\u00020\u0003\u0012\u0006\u0010,\u001a\u00020\u0003\u0012\u0006\u0010-\u001a\u00020\u0003\u0012\u0006\u0010.\u001a\u00020\u0003\u0012\u0006\u0010/\u001a\u00020\u0003\u0012\u0006\u00100\u001a\u00020\u0003\u0012\u0006\u00101\u001a\u00020\u0003\u0012\u0006\u00102\u001a\u00020\u0003\u0012\u0006\u00103\u001a\u00020\u0003\u0012\u0006\u00104\u001a\u00020\u0003\u0012\u0006\u00105\u001a\u00020\u0003\u0012\u0006\u00106\u001a\u00020\u0003\u0012\u0006\u00107\u001a\u00020\u0003\u0012\u0006\u00108\u001a\u00020\u0003\u0012\u0006\u00109\u001a\u00020\u0003\u0012\u0006\u0010:\u001a\u00020\u0003\u0012\u0006\u0010;\u001a\u00020\u0003\u0012\u0006\u0010<\u001a\u00020\u0003\u0012\u0006\u0010=\u001a\u00020\u0003\u0012\u0006\u0010>\u001a\u00020\u0003\u0012\u0006\u0010?\u001a\u00020\u0003\u0012\u0006\u0010@\u001a\u00020\u0003\u0012\u0006\u0010A\u001a\u00020\u0003\u0012\u0006\u0010B\u001a\u00020\u0003\u0012\u0006\u0010C\u001a\u00020\u0003\u0012\u0014\u0010D\u001a\u0010\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020F\u0018\u00010E\u0012\b\u0010G\u001a\u0004\u0018\u00010H\u00a2\u0006\u0002\u0010IB\u00c4\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0006\u0012\u0019\b\u0002\u0010\f\u001a\u0013\u0018\u00010\r\u00a2\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\t0\u0010\u0012\u0006\u0010\u0011\u001a\u00020\u0003\u0012\u0006\u0010\u0012\u001a\u00020\u0003\u0012\u0006\u0010\u0013\u001a\u00020\u0003\u0012\u0006\u0010\u0014\u001a\u00020\u0003\u0012\u0006\u0010\u0015\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0016\u001a\u00020\u0003\u0012\u0006\u0010\u0017\u001a\u00020\u0003\u0012\u0006\u0010\u0018\u001a\u00020\u0003\u0012\u0006\u0010\u0019\u001a\u00020\u0003\u0012\u0006\u0010\u001a\u001a\u00020\u0003\u0012\u0006\u0010\u001b\u001a\u00020\u0003\u0012\u0006\u0010\u001c\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u001d\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u001e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u001f\u001a\u00020\u0003\u0012\b\b\u0002\u0010 \u001a\u00020\u0003\u0012\b\b\u0002\u0010!\u001a\u00020\u0003\u0012\b\b\u0002\u0010\"\u001a\u00020\u0003\u0012\b\b\u0002\u0010#\u001a\u00020\u0003\u0012\b\b\u0002\u0010$\u001a\u00020\u0003\u0012\b\b\u0002\u0010%\u001a\u00020\u0003\u0012\b\b\u0002\u0010&\u001a\u00020\u0003\u0012\b\b\u0002\u0010\'\u001a\u00020\u0003\u0012\b\b\u0002\u0010(\u001a\u00020\u0003\u0012\b\b\u0002\u0010)\u001a\u00020\u0003\u0012\b\b\u0002\u0010*\u001a\u00020\u0003\u0012\b\b\u0002\u0010+\u001a\u00020\u0003\u0012\b\b\u0002\u0010,\u001a\u00020\u0003\u0012\b\b\u0002\u0010-\u001a\u00020\u0003\u0012\b\b\u0002\u0010.\u001a\u00020\u0003\u0012\b\b\u0002\u0010/\u001a\u00020\u0003\u0012\b\b\u0002\u00100\u001a\u00020\u0003\u0012\b\b\u0002\u00101\u001a\u00020\u0003\u0012\b\b\u0002\u00102\u001a\u00020\u0003\u0012\b\b\u0002\u00103\u001a\u00020\u0003\u0012\b\b\u0002\u00104\u001a\u00020\u0003\u0012\b\b\u0002\u00105\u001a\u00020\u0003\u0012\b\b\u0002\u00106\u001a\u00020\u0003\u0012\b\b\u0002\u00107\u001a\u00020\u0003\u0012\b\b\u0002\u00108\u001a\u00020\u0003\u0012\b\b\u0002\u00109\u001a\u00020\u0003\u0012\b\b\u0002\u0010:\u001a\u00020\u0003\u0012\b\b\u0002\u0010;\u001a\u00020\u0003\u0012\b\b\u0002\u0010<\u001a\u00020\u0003\u0012\b\b\u0002\u0010=\u001a\u00020\u0003\u0012\b\b\u0002\u0010>\u001a\u00020\u0003\u0012\b\b\u0002\u0010?\u001a\u00020\u0003\u0012\b\b\u0002\u0010@\u001a\u00020\u0003\u0012\b\b\u0002\u0010A\u001a\u00020\u0003\u0012\b\b\u0002\u0010B\u001a\u00020\u0003\u0012\b\b\u0002\u0010C\u001a\u00020\u0003\u0012\u0014\b\u0002\u0010D\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020F0E\u00a2\u0006\u0002\u0010JJ\u0013\u0010\u0089\u0001\u001a\u00030\u008a\u00012\u0007\u0010\u008b\u0001\u001a\u00020\bH\u0016J\n\u0010\u008c\u0001\u001a\u00020\u0006H\u00c6\u0003J\n\u0010\u008d\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u008e\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u008f\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0090\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0091\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0092\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0093\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0094\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0095\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0096\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0097\u0001\u001a\u00020\bH\u00c6\u0003J\n\u0010\u0098\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0099\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u009a\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u009b\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u009c\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u009d\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u009e\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u009f\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00a0\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00a1\u0001\u001a\u00020\u0003H\u00c6\u0003J\f\u0010\u00a2\u0001\u001a\u0004\u0018\u00010\nH\u00c6\u0003J\n\u0010\u00a3\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00a4\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00a5\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00a6\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00a7\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00a8\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00a9\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00aa\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00ab\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00ac\u0001\u001a\u00020\u0003H\u00c6\u0003J\f\u0010\u00ad\u0001\u001a\u0004\u0018\u00010\u0006H\u00c6\u0003J\n\u0010\u00ae\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00af\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00b0\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00b1\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00b2\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00b3\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00b4\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00b5\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00b6\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00b7\u0001\u001a\u00020\u0003H\u00c6\u0003J\u001b\u0010\u00b8\u0001\u001a\u0013\u0018\u00010\r\u00a2\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\t0\u0010H\u00c6\u0003J\n\u0010\u00b9\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00ba\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00bb\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00bc\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00bd\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00be\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00bf\u0001\u001a\u00020\u0003H\u00c6\u0003J\u0016\u0010\u00c0\u0001\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020F0EH\u00c6\u0003J\n\u0010\u00c1\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00c2\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00c3\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u00c4\u0001\u001a\u00020\u0003H\u00c6\u0003J\u00e5\u0004\u0010\u00c5\u0001\u001a\u00020\u00002\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u00062\u0019\b\u0002\u0010\f\u001a\u0013\u0018\u00010\r\u00a2\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\t0\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u00032\b\b\u0002\u0010\u0012\u001a\u00020\u00032\b\b\u0002\u0010\u0013\u001a\u00020\u00032\b\b\u0002\u0010\u0014\u001a\u00020\u00032\b\b\u0002\u0010\u0015\u001a\u00020\u00032\b\b\u0002\u0010\u0016\u001a\u00020\u00032\b\b\u0002\u0010\u0017\u001a\u00020\u00032\b\b\u0002\u0010\u0018\u001a\u00020\u00032\b\b\u0002\u0010\u0019\u001a\u00020\u00032\b\b\u0002\u0010\u001a\u001a\u00020\u00032\b\b\u0002\u0010\u001b\u001a\u00020\u00032\b\b\u0002\u0010\u001c\u001a\u00020\u00032\b\b\u0002\u0010\u001d\u001a\u00020\u00032\b\b\u0002\u0010\u001e\u001a\u00020\u00032\b\b\u0002\u0010\u001f\u001a\u00020\u00032\b\b\u0002\u0010 \u001a\u00020\u00032\b\b\u0002\u0010!\u001a\u00020\u00032\b\b\u0002\u0010\"\u001a\u00020\u00032\b\b\u0002\u0010#\u001a\u00020\u00032\b\b\u0002\u0010$\u001a\u00020\u00032\b\b\u0002\u0010%\u001a\u00020\u00032\b\b\u0002\u0010&\u001a\u00020\u00032\b\b\u0002\u0010\'\u001a\u00020\u00032\b\b\u0002\u0010(\u001a\u00020\u00032\b\b\u0002\u0010)\u001a\u00020\u00032\b\b\u0002\u0010*\u001a\u00020\u00032\b\b\u0002\u0010+\u001a\u00020\u00032\b\b\u0002\u0010,\u001a\u00020\u00032\b\b\u0002\u0010-\u001a\u00020\u00032\b\b\u0002\u0010.\u001a\u00020\u00032\b\b\u0002\u0010/\u001a\u00020\u00032\b\b\u0002\u00100\u001a\u00020\u00032\b\b\u0002\u00101\u001a\u00020\u00032\b\b\u0002\u00102\u001a\u00020\u00032\b\b\u0002\u00103\u001a\u00020\u00032\b\b\u0002\u00104\u001a\u00020\u00032\b\b\u0002\u00105\u001a\u00020\u00032\b\b\u0002\u00106\u001a\u00020\u00032\b\b\u0002\u00107\u001a\u00020\u00032\b\b\u0002\u00108\u001a\u00020\u00032\b\b\u0002\u00109\u001a\u00020\u00032\b\b\u0002\u0010:\u001a\u00020\u00032\b\b\u0002\u0010;\u001a\u00020\u00032\b\b\u0002\u0010<\u001a\u00020\u00032\b\b\u0002\u0010=\u001a\u00020\u00032\b\b\u0002\u0010>\u001a\u00020\u00032\b\b\u0002\u0010?\u001a\u00020\u00032\b\b\u0002\u0010@\u001a\u00020\u00032\b\b\u0002\u0010A\u001a\u00020\u00032\b\b\u0002\u0010B\u001a\u00020\u00032\b\b\u0002\u0010C\u001a\u00020\u00032\u0014\b\u0002\u0010D\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020F0EH\u00c6\u0001J\n\u0010\u00c6\u0001\u001a\u00020\u0003H\u00d6\u0001J\u0016\u0010\u00c7\u0001\u001a\u00020\b2\n\u0010\u00c8\u0001\u001a\u0005\u0018\u00010\u00c9\u0001H\u00d6\u0003J\n\u0010\u00ca\u0001\u001a\u00020\u0003H\u00d6\u0001J\n\u0010\u00cb\u0001\u001a\u00020\u0006H\u00d6\u0001J.\u0010\u00cc\u0001\u001a\u00030\u00cd\u00012\u0007\u0010\u00ce\u0001\u001a\u00020\u00002\b\u0010\u00cf\u0001\u001a\u00030\u00d0\u00012\b\u0010\u00d1\u0001\u001a\u00030\u00d2\u0001H\u00c1\u0001\u00a2\u0006\u0003\b\u00d3\u0001J\u001e\u0010\u00d4\u0001\u001a\u00030\u00cd\u00012\b\u0010\u00d5\u0001\u001a\u00030\u00d6\u00012\u0007\u0010\u00d7\u0001\u001a\u00020\u0003H\u00d6\u0001R\u0014\u0010\u0017\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bK\u0010LR\u0014\u0010@\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bM\u0010LR\u0014\u0010\u0018\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bN\u0010LR\u0014\u0010=\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bO\u0010LR\u0014\u0010>\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bP\u0010LR\u0014\u0010+\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bQ\u0010LR\u0014\u0010-\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bR\u0010LR\u0014\u0010,\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bS\u0010LR\u0014\u0010B\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bT\u0010LR\u0016\u0010\t\u001a\u0004\u0018\u00010\nX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bU\u0010VR\u0014\u0010\u0012\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bW\u0010LR\u0014\u0010<\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bX\u0010LR\u0014\u0010 \u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bY\u0010LR\u0014\u0010\"\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bZ\u0010LR\u0014\u0010!\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b[\u0010LR%\u0010\f\u001a\u0013\u0018\u00010\r\u00a2\u0006\f\b\u000e\u0012\b\b\u000f\u0012\u0004\b\t0\u0010X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\\\u0010]R\u0016\u0010\u000b\u001a\u0004\u0018\u00010\u0006X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b^\u0010_R\u0014\u0010\u001d\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b`\u0010LR\u0014\u0010\u001f\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\ba\u0010LR\u0014\u0010\u001e\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bb\u0010LR\u0014\u0010\u001b\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bc\u0010LR\u0014\u0010\u001c\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bd\u0010LR\u0014\u0010\u0007\u001a\u00020\bX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010eR\u0014\u0010\u0014\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bf\u0010LR \u0010D\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020F0EX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bg\u0010hR\u0014\u0010\u0019\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bi\u0010LR\u0014\u0010\u0016\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bj\u0010LR\u0014\u0010\u0015\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bk\u0010LR\u0014\u0010C\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bl\u0010LR\u0014\u0010\u0013\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bm\u0010LR\u0014\u0010\u0011\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bn\u0010LR\u0014\u0010\u0005\u001a\u00020\u0006X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bo\u0010_R\u0014\u00104\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bp\u0010LR\u0014\u00106\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bq\u0010LR\u0014\u00105\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\br\u0010LR\u0014\u00101\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bs\u0010LR\u0014\u00103\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bt\u0010LR\u0014\u00102\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bu\u0010LR\u0014\u0010\u001a\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bv\u0010LR\u0014\u0010A\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bw\u0010LR\u0014\u0010#\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bx\u0010LR\u0014\u0010%\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\by\u0010LR\u0014\u0010$\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\bz\u0010LR\u0014\u0010\'\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b{\u0010LR\u0014\u0010&\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b|\u0010LR\u0014\u0010(\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b}\u0010LR\u0014\u0010*\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b~\u0010LR\u0014\u0010)\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u007f\u0010LR\u0015\u00107\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0080\u0001\u0010LR\u0015\u00109\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0081\u0001\u0010LR\u0015\u00108\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0082\u0001\u0010LR\u0015\u0010?\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0083\u0001\u0010LR\u0015\u0010.\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0084\u0001\u0010LR\u0015\u00100\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0085\u0001\u0010LR\u0015\u0010/\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0086\u0001\u0010LR\u0015\u0010;\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0087\u0001\u0010LR\u0015\u0010:\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\t\n\u0000\u001a\u0005\b\u0088\u0001\u0010L\u00a8\u0006\u00db\u0001"}, d2 = {"Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "Lcom/yuyan/imemodule/data/theme/Theme;", "seen1", "", "seen2", "name", "", "isDark", "", "backgroundImage", "Lcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground;", "customLogoFilePath", "customLogoCropRect", "Landroid/graphics/Rect;", "Lkotlinx/serialization/Serializable;", "with", "Lcom/yuyan/imemodule/utils/RectSerializer;", "keyboardResources", "barColor", "keyboardColor", "keyBackgroundColor", "keyTextColor", "keySmallSymbolColor", "accentKeyBackgroundColor", "accentKeyTextColor", "keyPressHighlightColor", "popupBackgroundColor", "functionKeyBackgroundColor", "functionKeyPressHighlightColor", "deleteKeyBackgroundColor", "deleteKeyTextColor", "deleteKeyPressColor", "clearKeyBackgroundColor", "clearKeyTextColor", "clearKeyPressColor", "returnKeyBackgroundColor", "returnKeyTextColor", "returnKeyPressColor", "shiftKeyBackgroundColor", "shiftKeyActiveBackgroundColor", "shiftKeyLockBackgroundColor", "shiftKeyTextColor", "shiftKeyPressColor", "atKeyBackgroundColor", "atKeyTextColor", "atKeyPressColor", "symbolKeyBackgroundColor", "symbolKeyTextColor", "symbolKeyPressColor", "periodKeyBackgroundColor", "periodKeyTextColor", "periodKeyPressColor", "numberKeyBackgroundColor", "numberKeyTextColor", "numberKeyPressColor", "sideSymbolKeyBackgroundColor", "sideSymbolKeyTextColor", "sideSymbolKeyPressColor", "toolbarTextColor", "toolbarActiveIconColor", "candidateTextColor", "arrowButtonBackgroundColor", "arrowButtonTextColor", "spaceKeyTextColor", "accentKeyPressColor", "popupHighlightColor", "backgroundBlurRadius", "keyboardAlpha", "keyCustomOverrides", "", "Lcom/yuyan/imemodule/data/theme/KeyCustomOverride;", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(IILjava/lang/String;ZLcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground;Ljava/lang/String;Landroid/graphics/Rect;IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIILjava/util/Map;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "(Ljava/lang/String;ZLcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground;Ljava/lang/String;Landroid/graphics/Rect;IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIILjava/util/Map;)V", "getAccentKeyBackgroundColor", "()I", "getAccentKeyPressColor", "getAccentKeyTextColor", "getArrowButtonBackgroundColor", "getArrowButtonTextColor", "getAtKeyBackgroundColor", "getAtKeyPressColor", "getAtKeyTextColor", "getBackgroundBlurRadius", "getBackgroundImage", "()Lcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground;", "getBarColor", "getCandidateTextColor", "getClearKeyBackgroundColor", "getClearKeyPressColor", "getClearKeyTextColor", "getCustomLogoCropRect", "()Landroid/graphics/Rect;", "getCustomLogoFilePath", "()Ljava/lang/String;", "getDeleteKeyBackgroundColor", "getDeleteKeyPressColor", "getDeleteKeyTextColor", "getFunctionKeyBackgroundColor", "getFunctionKeyPressHighlightColor", "()Z", "getKeyBackgroundColor", "getKeyCustomOverrides", "()Ljava/util/Map;", "getKeyPressHighlightColor", "getKeySmallSymbolColor", "getKeyTextColor", "getKeyboardAlpha", "getKeyboardColor", "getKeyboardResources", "getName", "getNumberKeyBackgroundColor", "getNumberKeyPressColor", "getNumberKeyTextColor", "getPeriodKeyBackgroundColor", "getPeriodKeyPressColor", "getPeriodKeyTextColor", "getPopupBackgroundColor", "getPopupHighlightColor", "getReturnKeyBackgroundColor", "getReturnKeyPressColor", "getReturnKeyTextColor", "getShiftKeyActiveBackgroundColor", "getShiftKeyBackgroundColor", "getShiftKeyLockBackgroundColor", "getShiftKeyPressColor", "getShiftKeyTextColor", "getSideSymbolKeyBackgroundColor", "getSideSymbolKeyPressColor", "getSideSymbolKeyTextColor", "getSpaceKeyTextColor", "getSymbolKeyBackgroundColor", "getSymbolKeyPressColor", "getSymbolKeyTextColor", "getToolbarActiveIconColor", "getToolbarTextColor", "backgroundDrawable", "Landroid/graphics/drawable/Drawable;", "keyBorder", "component1", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "component19", "component2", "component20", "component21", "component22", "component23", "component24", "component25", "component26", "component27", "component28", "component29", "component3", "component30", "component31", "component32", "component33", "component34", "component35", "component36", "component37", "component38", "component39", "component4", "component40", "component41", "component42", "component43", "component44", "component45", "component46", "component47", "component48", "component49", "component5", "component50", "component51", "component52", "component53", "component54", "component55", "component56", "component57", "component6", "component7", "component8", "component9", "copy", "describeContents", "equals", "other", "", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$yuyansdk_offlineDebug", "writeToParcel", "parcel", "Landroid/os/Parcel;", "flags", "$serializer", "Companion", "CustomBackground", "yuyansdk_offlineDebug"})
    @kotlinx.parcelize.Parcelize()
    public static final class Custom extends com.yuyan.imemodule.data.theme.Theme {
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String name = null;
        private final boolean isDark = false;
        
        /**
         * absolute paths of cropped and src png files
         */
        @org.jetbrains.annotations.Nullable()
        private final com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground backgroundImage = null;
        @org.jetbrains.annotations.Nullable()
        private final java.lang.String customLogoFilePath = null;
        @org.jetbrains.annotations.Nullable()
        private final android.graphics.Rect customLogoCropRect = null;
        private final int keyboardResources = 0;
        private final int barColor = 0;
        private final int keyboardColor = 0;
        private final int keyBackgroundColor = 0;
        private final int keyTextColor = 0;
        private final int keySmallSymbolColor = 0;
        private final int accentKeyBackgroundColor = 0;
        private final int accentKeyTextColor = 0;
        private final int keyPressHighlightColor = 0;
        private final int popupBackgroundColor = 0;
        private final int functionKeyBackgroundColor = 0;
        private final int functionKeyPressHighlightColor = 0;
        private final int deleteKeyBackgroundColor = 0;
        private final int deleteKeyTextColor = 0;
        private final int deleteKeyPressColor = 0;
        private final int clearKeyBackgroundColor = 0;
        private final int clearKeyTextColor = 0;
        private final int clearKeyPressColor = 0;
        private final int returnKeyBackgroundColor = 0;
        private final int returnKeyTextColor = 0;
        private final int returnKeyPressColor = 0;
        private final int shiftKeyBackgroundColor = 0;
        private final int shiftKeyActiveBackgroundColor = 0;
        private final int shiftKeyLockBackgroundColor = 0;
        private final int shiftKeyTextColor = 0;
        private final int shiftKeyPressColor = 0;
        private final int atKeyBackgroundColor = 0;
        private final int atKeyTextColor = 0;
        private final int atKeyPressColor = 0;
        private final int symbolKeyBackgroundColor = 0;
        private final int symbolKeyTextColor = 0;
        private final int symbolKeyPressColor = 0;
        private final int periodKeyBackgroundColor = 0;
        private final int periodKeyTextColor = 0;
        private final int periodKeyPressColor = 0;
        private final int numberKeyBackgroundColor = 0;
        private final int numberKeyTextColor = 0;
        private final int numberKeyPressColor = 0;
        private final int sideSymbolKeyBackgroundColor = 0;
        private final int sideSymbolKeyTextColor = 0;
        private final int sideSymbolKeyPressColor = 0;
        private final int toolbarTextColor = 0;
        private final int toolbarActiveIconColor = 0;
        private final int candidateTextColor = 0;
        private final int arrowButtonBackgroundColor = 0;
        private final int arrowButtonTextColor = 0;
        private final int spaceKeyTextColor = 0;
        private final int accentKeyPressColor = 0;
        private final int popupHighlightColor = 0;
        private final int backgroundBlurRadius = 0;
        private final int keyboardAlpha = 0;
        @org.jetbrains.annotations.NotNull()
        private final java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> keyCustomOverrides = null;
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.data.theme.Theme.Custom.Companion Companion = null;
        
        public Custom(@org.jetbrains.annotations.NotNull()
        java.lang.String name, boolean isDark, @org.jetbrains.annotations.Nullable()
        com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground backgroundImage, @org.jetbrains.annotations.Nullable()
        java.lang.String customLogoFilePath, @org.jetbrains.annotations.Nullable()
        android.graphics.Rect customLogoCropRect, int keyboardResources, int barColor, int keyboardColor, int keyBackgroundColor, int keyTextColor, int keySmallSymbolColor, int accentKeyBackgroundColor, int accentKeyTextColor, int keyPressHighlightColor, int popupBackgroundColor, int functionKeyBackgroundColor, int functionKeyPressHighlightColor, int deleteKeyBackgroundColor, int deleteKeyTextColor, int deleteKeyPressColor, int clearKeyBackgroundColor, int clearKeyTextColor, int clearKeyPressColor, int returnKeyBackgroundColor, int returnKeyTextColor, int returnKeyPressColor, int shiftKeyBackgroundColor, int shiftKeyActiveBackgroundColor, int shiftKeyLockBackgroundColor, int shiftKeyTextColor, int shiftKeyPressColor, int atKeyBackgroundColor, int atKeyTextColor, int atKeyPressColor, int symbolKeyBackgroundColor, int symbolKeyTextColor, int symbolKeyPressColor, int periodKeyBackgroundColor, int periodKeyTextColor, int periodKeyPressColor, int numberKeyBackgroundColor, int numberKeyTextColor, int numberKeyPressColor, int sideSymbolKeyBackgroundColor, int sideSymbolKeyTextColor, int sideSymbolKeyPressColor, int toolbarTextColor, int toolbarActiveIconColor, int candidateTextColor, int arrowButtonBackgroundColor, int arrowButtonTextColor, int spaceKeyTextColor, int accentKeyPressColor, int popupHighlightColor, int backgroundBlurRadius, int keyboardAlpha, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> keyCustomOverrides) {
            super(0, null);
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String getName() {
            return null;
        }
        
        @java.lang.Override()
        public boolean isDark() {
            return false;
        }
        
        /**
         * absolute paths of cropped and src png files
         */
        @java.lang.Override()
        @org.jetbrains.annotations.Nullable()
        public com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground getBackgroundImage() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.Nullable()
        public java.lang.String getCustomLogoFilePath() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.Nullable()
        public android.graphics.Rect getCustomLogoCropRect() {
            return null;
        }
        
        @java.lang.Override()
        public int getKeyboardResources() {
            return 0;
        }
        
        @java.lang.Override()
        public int getBarColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyboardColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeySmallSymbolColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getAccentKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getAccentKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyPressHighlightColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getPopupBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getFunctionKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getFunctionKeyPressHighlightColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getDeleteKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getDeleteKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getDeleteKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getClearKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getClearKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getClearKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getReturnKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getReturnKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getReturnKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getShiftKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getShiftKeyActiveBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getShiftKeyLockBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getShiftKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getShiftKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getAtKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getAtKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getAtKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSymbolKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSymbolKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSymbolKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getPeriodKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getPeriodKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getPeriodKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getNumberKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getNumberKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getNumberKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSideSymbolKeyBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSideSymbolKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSideSymbolKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getToolbarTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getToolbarActiveIconColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getCandidateTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getArrowButtonBackgroundColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getArrowButtonTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getSpaceKeyTextColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getAccentKeyPressColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getPopupHighlightColor() {
            return 0;
        }
        
        @java.lang.Override()
        public int getBackgroundBlurRadius() {
            return 0;
        }
        
        @java.lang.Override()
        public int getKeyboardAlpha() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> getKeyCustomOverrides() {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public android.graphics.drawable.Drawable backgroundDrawable(boolean keyBorder) {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component1() {
            return null;
        }
        
        public final int component10() {
            return 0;
        }
        
        public final int component11() {
            return 0;
        }
        
        public final int component12() {
            return 0;
        }
        
        public final int component13() {
            return 0;
        }
        
        public final int component14() {
            return 0;
        }
        
        public final int component15() {
            return 0;
        }
        
        public final int component16() {
            return 0;
        }
        
        public final int component17() {
            return 0;
        }
        
        public final int component18() {
            return 0;
        }
        
        public final int component19() {
            return 0;
        }
        
        public final boolean component2() {
            return false;
        }
        
        public final int component20() {
            return 0;
        }
        
        public final int component21() {
            return 0;
        }
        
        public final int component22() {
            return 0;
        }
        
        public final int component23() {
            return 0;
        }
        
        public final int component24() {
            return 0;
        }
        
        public final int component25() {
            return 0;
        }
        
        public final int component26() {
            return 0;
        }
        
        public final int component27() {
            return 0;
        }
        
        public final int component28() {
            return 0;
        }
        
        public final int component29() {
            return 0;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground component3() {
            return null;
        }
        
        public final int component30() {
            return 0;
        }
        
        public final int component31() {
            return 0;
        }
        
        public final int component32() {
            return 0;
        }
        
        public final int component33() {
            return 0;
        }
        
        public final int component34() {
            return 0;
        }
        
        public final int component35() {
            return 0;
        }
        
        public final int component36() {
            return 0;
        }
        
        public final int component37() {
            return 0;
        }
        
        public final int component38() {
            return 0;
        }
        
        public final int component39() {
            return 0;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final java.lang.String component4() {
            return null;
        }
        
        public final int component40() {
            return 0;
        }
        
        public final int component41() {
            return 0;
        }
        
        public final int component42() {
            return 0;
        }
        
        public final int component43() {
            return 0;
        }
        
        public final int component44() {
            return 0;
        }
        
        public final int component45() {
            return 0;
        }
        
        public final int component46() {
            return 0;
        }
        
        public final int component47() {
            return 0;
        }
        
        public final int component48() {
            return 0;
        }
        
        public final int component49() {
            return 0;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Rect component5() {
            return null;
        }
        
        public final int component50() {
            return 0;
        }
        
        public final int component51() {
            return 0;
        }
        
        public final int component52() {
            return 0;
        }
        
        public final int component53() {
            return 0;
        }
        
        public final int component54() {
            return 0;
        }
        
        public final int component55() {
            return 0;
        }
        
        public final int component56() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> component57() {
            return null;
        }
        
        public final int component6() {
            return 0;
        }
        
        public final int component7() {
            return 0;
        }
        
        public final int component8() {
            return 0;
        }
        
        public final int component9() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.data.theme.Theme.Custom copy(@org.jetbrains.annotations.NotNull()
        java.lang.String name, boolean isDark, @org.jetbrains.annotations.Nullable()
        com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground backgroundImage, @org.jetbrains.annotations.Nullable()
        java.lang.String customLogoFilePath, @org.jetbrains.annotations.Nullable()
        android.graphics.Rect customLogoCropRect, int keyboardResources, int barColor, int keyboardColor, int keyBackgroundColor, int keyTextColor, int keySmallSymbolColor, int accentKeyBackgroundColor, int accentKeyTextColor, int keyPressHighlightColor, int popupBackgroundColor, int functionKeyBackgroundColor, int functionKeyPressHighlightColor, int deleteKeyBackgroundColor, int deleteKeyTextColor, int deleteKeyPressColor, int clearKeyBackgroundColor, int clearKeyTextColor, int clearKeyPressColor, int returnKeyBackgroundColor, int returnKeyTextColor, int returnKeyPressColor, int shiftKeyBackgroundColor, int shiftKeyActiveBackgroundColor, int shiftKeyLockBackgroundColor, int shiftKeyTextColor, int shiftKeyPressColor, int atKeyBackgroundColor, int atKeyTextColor, int atKeyPressColor, int symbolKeyBackgroundColor, int symbolKeyTextColor, int symbolKeyPressColor, int periodKeyBackgroundColor, int periodKeyTextColor, int periodKeyPressColor, int numberKeyBackgroundColor, int numberKeyTextColor, int numberKeyPressColor, int sideSymbolKeyBackgroundColor, int sideSymbolKeyTextColor, int sideSymbolKeyPressColor, int toolbarTextColor, int toolbarActiveIconColor, int candidateTextColor, int arrowButtonBackgroundColor, int arrowButtonTextColor, int spaceKeyTextColor, int accentKeyPressColor, int popupHighlightColor, int backgroundBlurRadius, int keyboardAlpha, @org.jetbrains.annotations.NotNull()
        java.util.Map<java.lang.String, com.yuyan.imemodule.data.theme.KeyCustomOverride> keyCustomOverrides) {
            return null;
        }
        
        @java.lang.Override()
        public int describeContents() {
            return 0;
        }
        
        @java.lang.Override()
        public boolean equals(@org.jetbrains.annotations.Nullable()
        java.lang.Object other) {
            return false;
        }
        
        @java.lang.Override()
        public int hashCode() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String toString() {
            return null;
        }
        
        @kotlin.jvm.JvmStatic()
        public static final void write$Self$yuyansdk_offlineDebug(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.data.theme.Theme.Custom self, @org.jetbrains.annotations.NotNull()
        kotlinx.serialization.encoding.CompositeEncoder output, @org.jetbrains.annotations.NotNull()
        kotlinx.serialization.descriptors.SerialDescriptor serialDesc) {
        }
        
        @java.lang.Override()
        public void writeToParcel(@org.jetbrains.annotations.NotNull()
        android.os.Parcel parcel, int flags) {
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0018\u0010\b\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\n0\tH\u00d6\u0001\u00a2\u0006\u0002\u0010\u000bJ\u0011\u0010\f\u001a\u00020\u00022\u0006\u0010\r\u001a\u00020\u000eH\u00d6\u0001J\u0019\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0002H\u00d6\u0001R\u0014\u0010\u0004\u001a\u00020\u00058VX\u00d6\u0005\u00a2\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007\u00a8\u0006\u0014"}, d2 = {"com/yuyan/imemodule/data/theme/Theme.Custom.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "()V", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "yuyansdk_offlineDebug"})
        @java.lang.Deprecated()
        public static final class $serializer implements kotlinx.serialization.internal.GeneratedSerializer<com.yuyan.imemodule.data.theme.Theme.Custom> {
            @org.jetbrains.annotations.NotNull()
            public static final com.yuyan.imemodule.data.theme.Theme.Custom.$serializer INSTANCE = null;
            
            private $serializer() {
                super();
            }
            
            @java.lang.Override()
            @org.jetbrains.annotations.NotNull()
            public kotlinx.serialization.KSerializer<?>[] childSerializers() {
                return null;
            }
            
            @java.lang.Override()
            @org.jetbrains.annotations.NotNull()
            public com.yuyan.imemodule.data.theme.Theme.Custom deserialize(@org.jetbrains.annotations.NotNull()
            kotlinx.serialization.encoding.Decoder decoder) {
                return null;
            }
            
            @java.lang.Override()
            @org.jetbrains.annotations.NotNull()
            public kotlinx.serialization.descriptors.SerialDescriptor getDescriptor() {
                return null;
            }
            
            @java.lang.Override()
            public void serialize(@org.jetbrains.annotations.NotNull()
            kotlinx.serialization.encoding.Encoder encoder, @org.jetbrains.annotations.NotNull()
            com.yuyan.imemodule.data.theme.Theme.Custom value) {
            }
            
            @java.lang.Override()
            @org.jetbrains.annotations.NotNull()
            public kotlinx.serialization.KSerializer<?>[] typeParametersSerializers() {
                return null;
            }
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u00c6\u0001\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/data/theme/Theme$Custom$Companion;", "", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "yuyansdk_offlineDebug"})
        public static final class Companion {
            
            private Companion() {
                super();
            }
            
            @org.jetbrains.annotations.NotNull()
            public final kotlinx.serialization.KSerializer<com.yuyan.imemodule.data.theme.Theme.Custom> serializer() {
                return null;
            }
        }
        
        @kotlinx.serialization.Serializable()
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 32\u00020\u0001:\u000223BD\b\u0011\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0017\u0010\u0007\u001a\u0013\u0018\u00010\b\u00a2\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\t0\u000b\u0012\b\u0010\f\u001a\u0004\u0018\u00010\r\u00a2\u0006\u0002\u0010\u000eB0\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\u0017\u0010\u0007\u001a\u0013\u0018\u00010\b\u00a2\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\t0\u000b\u00a2\u0006\u0002\u0010\u000fJ\t\u0010\u0016\u001a\u00020\u0005H\u00c6\u0003J\t\u0010\u0017\u001a\u00020\u0003H\u00c6\u0003J\u001a\u0010\u0018\u001a\u0013\u0018\u00010\b\u00a2\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\t0\u000bH\u00c6\u0003J8\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\u0019\b\u0002\u0010\u0007\u001a\u0013\u0018\u00010\b\u00a2\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\t0\u000bH\u00c6\u0001J\t\u0010\u001a\u001a\u00020\u0003H\u00d6\u0001J\u0013\u0010\u001b\u001a\u00020\u001c2\b\u0010\u001d\u001a\u0004\u0018\u00010\u001eH\u00d6\u0003J\t\u0010\u001f\u001a\u00020\u0003H\u00d6\u0001J&\u0010 \u001a\u0004\u0018\u00010!2\b\b\u0002\u0010\"\u001a\u00020\u00032\b\b\u0002\u0010#\u001a\u00020\u00032\b\b\u0002\u0010$\u001a\u00020\u0003J\t\u0010%\u001a\u00020\u0005H\u00d6\u0001J&\u0010&\u001a\u00020\'2\u0006\u0010(\u001a\u00020\u00002\u0006\u0010)\u001a\u00020*2\u0006\u0010+\u001a\u00020,H\u00c1\u0001\u00a2\u0006\u0002\b-J\u0019\u0010.\u001a\u00020\'2\u0006\u0010/\u001a\u0002002\u0006\u00101\u001a\u00020\u0003H\u00d6\u0001R\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\"\u0010\u0007\u001a\u0013\u0018\u00010\b\u00a2\u0006\f\b\t\u0012\b\b\n\u0012\u0004\b\t0\u000b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015\u00a8\u00064"}, d2 = {"Lcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground;", "Landroid/os/Parcelable;", "seen1", "", "srcFilePath", "", "brightness", "cropRect", "Landroid/graphics/Rect;", "Lkotlinx/serialization/Serializable;", "with", "Lcom/yuyan/imemodule/utils/RectSerializer;", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;ILandroid/graphics/Rect;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "(Ljava/lang/String;ILandroid/graphics/Rect;)V", "getBrightness", "()I", "getCropRect", "()Landroid/graphics/Rect;", "getSrcFilePath", "()Ljava/lang/String;", "component1", "component2", "component3", "copy", "describeContents", "equals", "", "other", "", "hashCode", "toDrawable", "Landroid/graphics/drawable/Drawable;", "blurRadius", "reqWidth", "reqHeight", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$yuyansdk_offlineDebug", "writeToParcel", "parcel", "Landroid/os/Parcel;", "flags", "$serializer", "Companion", "yuyansdk_offlineDebug"})
        @kotlinx.parcelize.Parcelize()
        public static final class CustomBackground implements android.os.Parcelable {
            @org.jetbrains.annotations.NotNull()
            private final java.lang.String srcFilePath = null;
            private final int brightness = 0;
            @org.jetbrains.annotations.Nullable()
            private final android.graphics.Rect cropRect = null;
            @org.jetbrains.annotations.NotNull()
            private static final android.util.LruCache<java.lang.String, android.graphics.Bitmap> bitmapCache = null;
            @org.jetbrains.annotations.NotNull()
            public static final com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground.Companion Companion = null;
            
            public CustomBackground(@org.jetbrains.annotations.NotNull()
            java.lang.String srcFilePath, int brightness, @org.jetbrains.annotations.Nullable()
            android.graphics.Rect cropRect) {
                super();
            }
            
            @org.jetbrains.annotations.NotNull()
            public final java.lang.String getSrcFilePath() {
                return null;
            }
            
            public final int getBrightness() {
                return 0;
            }
            
            @org.jetbrains.annotations.Nullable()
            public final android.graphics.Rect getCropRect() {
                return null;
            }
            
            @org.jetbrains.annotations.Nullable()
            public final android.graphics.drawable.Drawable toDrawable(int blurRadius, int reqWidth, int reqHeight) {
                return null;
            }
            
            @org.jetbrains.annotations.NotNull()
            public final java.lang.String component1() {
                return null;
            }
            
            public final int component2() {
                return 0;
            }
            
            @org.jetbrains.annotations.Nullable()
            public final android.graphics.Rect component3() {
                return null;
            }
            
            @org.jetbrains.annotations.NotNull()
            public final com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground copy(@org.jetbrains.annotations.NotNull()
            java.lang.String srcFilePath, int brightness, @org.jetbrains.annotations.Nullable()
            android.graphics.Rect cropRect) {
                return null;
            }
            
            @java.lang.Override()
            public int describeContents() {
                return 0;
            }
            
            @java.lang.Override()
            public boolean equals(@org.jetbrains.annotations.Nullable()
            java.lang.Object other) {
                return false;
            }
            
            @java.lang.Override()
            public int hashCode() {
                return 0;
            }
            
            @java.lang.Override()
            @org.jetbrains.annotations.NotNull()
            public java.lang.String toString() {
                return null;
            }
            
            @kotlin.jvm.JvmStatic()
            public static final void write$Self$yuyansdk_offlineDebug(@org.jetbrains.annotations.NotNull()
            com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground self, @org.jetbrains.annotations.NotNull()
            kotlinx.serialization.encoding.CompositeEncoder output, @org.jetbrains.annotations.NotNull()
            kotlinx.serialization.descriptors.SerialDescriptor serialDesc) {
            }
            
            @java.lang.Override()
            public void writeToParcel(@org.jetbrains.annotations.NotNull()
            android.os.Parcel parcel, int flags) {
            }
            
            @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0018\u0010\b\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\n0\tH\u00d6\u0001\u00a2\u0006\u0002\u0010\u000bJ\u0011\u0010\f\u001a\u00020\u00022\u0006\u0010\r\u001a\u00020\u000eH\u00d6\u0001J\u0019\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0002H\u00d6\u0001R\u0014\u0010\u0004\u001a\u00020\u00058VX\u00d6\u0005\u00a2\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007\u00a8\u0006\u0014"}, d2 = {"com/yuyan/imemodule/data/theme/Theme.Custom.CustomBackground.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground;", "()V", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "yuyansdk_offlineDebug"})
            @java.lang.Deprecated()
            public static final class $serializer implements kotlinx.serialization.internal.GeneratedSerializer<com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground> {
                @org.jetbrains.annotations.NotNull()
                public static final com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground.$serializer INSTANCE = null;
                
                private $serializer() {
                    super();
                }
                
                @java.lang.Override()
                @org.jetbrains.annotations.NotNull()
                public kotlinx.serialization.KSerializer<?>[] childSerializers() {
                    return null;
                }
                
                @java.lang.Override()
                @org.jetbrains.annotations.NotNull()
                public com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground deserialize(@org.jetbrains.annotations.NotNull()
                kotlinx.serialization.encoding.Decoder decoder) {
                    return null;
                }
                
                @java.lang.Override()
                @org.jetbrains.annotations.NotNull()
                public kotlinx.serialization.descriptors.SerialDescriptor getDescriptor() {
                    return null;
                }
                
                @java.lang.Override()
                public void serialize(@org.jetbrains.annotations.NotNull()
                kotlinx.serialization.encoding.Encoder encoder, @org.jetbrains.annotations.NotNull()
                com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground value) {
                }
                
                @java.lang.Override()
                @org.jetbrains.annotations.NotNull()
                public kotlinx.serialization.KSerializer<?>[] typeParametersSerializers() {
                    return null;
                }
            }
            
            @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J \u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\bH\u0002J\u0006\u0010\r\u001a\u00020\u000eJ\u000f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u0010H\u00c6\u0001R\u001a\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0012"}, d2 = {"Lcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground$Companion;", "", "()V", "bitmapCache", "Landroid/util/LruCache;", "", "Landroid/graphics/Bitmap;", "calculateInSampleSize", "", "options", "Landroid/graphics/BitmapFactory$Options;", "reqWidth", "reqHeight", "clearCache", "", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom$CustomBackground;", "yuyansdk_offlineDebug"})
            public static final class Companion {
                
                private Companion() {
                    super();
                }
                
                public final void clearCache() {
                }
                
                private final int calculateInSampleSize(android.graphics.BitmapFactory.Options options, int reqWidth, int reqHeight) {
                    return 0;
                }
                
                @org.jetbrains.annotations.NotNull()
                public final kotlinx.serialization.KSerializer<com.yuyan.imemodule.data.theme.Theme.Custom.CustomBackground> serializer() {
                    return null;
                }
            }
        }
    }
}
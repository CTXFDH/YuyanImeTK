package com.yuyan.imemodule.ui.setup;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000  2\u00020\u0001:\u0001 B\u0005\u00a2\u0006\u0002\u0010\u0002J$\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cH\u0016J\b\u0010\u001d\u001a\u00020\u001eH\u0016J\u0006\u0010\u001f\u001a\u00020\u001eR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u001e\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0006@BX\u0082\u000e\u00a2\u0006\b\n\u0000\"\u0004\b\b\u0010\tR\u001b\u0010\n\u001a\u00020\u000b8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\f\u0010\rR\u001b\u0010\u0010\u001a\u00020\u00118BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0014\u0010\u000f\u001a\u0004\b\u0012\u0010\u0013\u00a8\u0006!"}, d2 = {"Lcom/yuyan/imemodule/ui/setup/SetupFragment;", "Landroidx/fragment/app/Fragment;", "()V", "binding", "Lcom/yuyan/imemodule/databinding/FragmentSetupBinding;", "value", "", "isDone", "setDone", "(Z)V", "page", "Lcom/yuyan/imemodule/ui/setup/SetupPage;", "getPage", "()Lcom/yuyan/imemodule/ui/setup/SetupPage;", "page$delegate", "Lkotlin/Lazy;", "viewModel", "Lcom/yuyan/imemodule/ui/setup/SetupViewModel;", "getViewModel", "()Lcom/yuyan/imemodule/ui/setup/SetupViewModel;", "viewModel$delegate", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onResume", "", "sync", "Companion", "yuyansdk_offlineDebug"})
public final class SetupFragment extends androidx.fragment.app.Fragment {
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy viewModel$delegate = null;
    private com.yuyan.imemodule.databinding.FragmentSetupBinding binding;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy page$delegate = null;
    private boolean isDone = false;
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String PAGE = "page";
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.ui.setup.SetupFragment.Companion Companion = null;
    
    public SetupFragment() {
        super();
    }
    
    private final com.yuyan.imemodule.ui.setup.SetupViewModel getViewModel() {
        return null;
    }
    
    private final com.yuyan.imemodule.ui.setup.SetupPage getPage() {
        return null;
    }
    
    private final void setDone(boolean value) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateView(@org.jetbrains.annotations.NotNull()
    android.view.LayoutInflater inflater, @org.jetbrains.annotations.Nullable()
    android.view.ViewGroup container, @org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
        return null;
    }
    
    public final void sync() {
    }
    
    @java.lang.Override()
    public void onResume() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2 = {"Lcom/yuyan/imemodule/ui/setup/SetupFragment$Companion;", "", "()V", "PAGE", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
}
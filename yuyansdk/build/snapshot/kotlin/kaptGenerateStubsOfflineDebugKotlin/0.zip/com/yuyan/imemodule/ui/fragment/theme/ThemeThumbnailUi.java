package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001%B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\u001d\u001a\u00020\u000f2\u0006\u0010\u001e\u001a\u00020\u001fJ\u000e\u0010\u001d\u001a\u00020\u000f2\u0006\u0010 \u001a\u00020!J\u000e\u0010\"\u001a\u00020\u000f2\u0006\u0010#\u001a\u00020$R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\n\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\"\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0010\u0010\u0011\"\u0004\b\u0012\u0010\u0013R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0016\u001a\u00020\u0017X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u000e\u0010\u001a\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006&"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ThemeThumbnailUi;", "Lsplitties/views/dsl/core/Ui;", "ctx", "Landroid/content/Context;", "(Landroid/content/Context;)V", "bkg", "Landroid/widget/ImageView;", "checkMark", "getCtx", "()Landroid/content/Context;", "editButton", "getEditButton", "()Landroid/widget/ImageView;", "onExportClick", "Lkotlin/Function0;", "", "getOnExportClick", "()Lkotlin/jvm/functions/Function0;", "setOnExportClick", "(Lkotlin/jvm/functions/Function0;)V", "returnKey", "Landroid/view/View;", "root", "Landroidx/constraintlayout/widget/ConstraintLayout;", "getRoot", "()Landroidx/constraintlayout/widget/ConstraintLayout;", "spaceBar", "themeNameView", "Landroid/widget/TextView;", "setChecked", "state", "Lcom/yuyan/imemodule/ui/fragment/theme/ThemeThumbnailUi$State;", "checked", "", "setTheme", "theme", "Lcom/yuyan/imemodule/data/theme/Theme;", "State", "yuyansdk_offlineDebug"})
public final class ThemeThumbnailUi implements splitties.views.dsl.core.Ui {
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context ctx = null;
    @org.jetbrains.annotations.Nullable()
    private kotlin.jvm.functions.Function0<kotlin.Unit> onExportClick;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ImageView bkg = null;
    @org.jetbrains.annotations.NotNull()
    private final android.view.View spaceBar = null;
    @org.jetbrains.annotations.NotNull()
    private final android.view.View returnKey = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ImageView checkMark = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ImageView editButton = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.TextView themeNameView = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.constraintlayout.widget.ConstraintLayout root = null;
    
    public ThemeThumbnailUi(@org.jetbrains.annotations.NotNull()
    android.content.Context ctx) {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.content.Context getCtx() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final kotlin.jvm.functions.Function0<kotlin.Unit> getOnExportClick() {
        return null;
    }
    
    public final void setOnExportClick(@org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.widget.ImageView getEditButton() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public androidx.constraintlayout.widget.ConstraintLayout getRoot() {
        return null;
    }
    
    public final void setTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    public final void setChecked(boolean checked) {
    }
    
    public final void setChecked(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.ui.fragment.theme.ThemeThumbnailUi.State state) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ThemeThumbnailUi$State;", "", "(Ljava/lang/String;I)V", "Normal", "Selected", "LightMode", "DarkMode", "yuyansdk_offlineDebug"})
    public static enum State {
        /*public static final*/ Normal /* = new Normal() */,
        /*public static final*/ Selected /* = new Selected() */,
        /*public static final*/ LightMode /* = new LightMode() */,
        /*public static final*/ DarkMode /* = new DarkMode() */;
        
        State() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.ui.fragment.theme.ThemeThumbnailUi.State> getEntries() {
            return null;
        }
    }
}
package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010!\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000b\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\rJ\u0006\u0010\u000e\u001a\u00020\nJ\u000e\u0010\u000f\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\nJ\u000e\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0012\u001a\u00020\nJ\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\r0\u0014J\u0012\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00040\u0016J\u001a\u0010\u0017\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\r2\n\b\u0002\u0010\u0018\u001a\u0004\u0018\u00010\nJ\u0010\u0010\u0019\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\rH\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u001a"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ThemeFilesManager;", "", "()V", "dir", "Ljava/io/File;", "getDir", "()Ljava/io/File;", "deleteThemeFileByName", "", "name", "", "deleteThemeFiles", "theme", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "generateNextThemeName", "generateUniqueThemeName", "preferredName", "getThemeDir", "themeName", "listThemes", "", "newCustomBackgroundImages", "Lkotlin/Pair;", "saveThemeFiles", "oldName", "themeFile", "yuyansdk_offlineDebug"})
public final class ThemeFilesManager {
    @org.jetbrains.annotations.NotNull()
    private static final java.io.File dir = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.theme.ThemeFilesManager INSTANCE = null;
    
    private ThemeFilesManager() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.io.File getDir() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.io.File getThemeDir(@org.jetbrains.annotations.NotNull()
    java.lang.String themeName) {
        return null;
    }
    
    private final java.io.File themeFile(com.yuyan.imemodule.data.theme.Theme.Custom theme) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String generateNextThemeName() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String generateUniqueThemeName(@org.jetbrains.annotations.NotNull()
    java.lang.String preferredName) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlin.Pair<java.lang.String, java.io.File> newCustomBackgroundImages() {
        return null;
    }
    
    public final void saveThemeFiles(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme.Custom theme, @org.jetbrains.annotations.Nullable()
    java.lang.String oldName) {
    }
    
    public final void deleteThemeFiles(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme.Custom theme) {
    }
    
    public final void deleteThemeFileByName(@org.jetbrains.annotations.NotNull()
    java.lang.String name) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.data.theme.Theme.Custom> listThemes() {
        return null;
    }
}
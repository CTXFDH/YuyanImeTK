package com.yuyan.imemodule.keyboard.container;

/**
 * 候选词键盘容器
 *
 * 选择候选词界面分两种效果：九宫格（[InputModeSwitcher.isChineseT9])情况下显示左侧拼音选择栏；全键,手写等情况下不显示拼音选择栏。
 * @see InputModeSwitcher.isChineseT9
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\b\u0010\u0017\u001a\u00020\u0018H\u0003J\u0010\u0010\u0019\u001a\u00020\u001a2\u0006\u0010\u0002\u001a\u00020\u0003H\u0002J\b\u0010\u001b\u001a\u00020\u001aH\u0014J\b\u0010\u001c\u001a\u00020\u001aH\u0014J\u0006\u0010\u001d\u001a\u00020\u001aJ\b\u0010\u001e\u001a\u00020\u001aH\u0002R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0010X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00160\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/CandidatesContainer;", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "isLoadingMore", "", "mCandidatesAdapter", "Lcom/yuyan/imemodule/adapter/CandidatesAdapter;", "mDeleteHandler", "Landroid/os/Handler;", "mLlAddSymbol", "Landroid/widget/LinearLayout;", "mRVLeftPrefix", "Lcom/yuyan/imemodule/libs/recyclerview/SwipeRecyclerView;", "mRVSymbolsView", "mRepeatDeleteRunnable", "Ljava/lang/Runnable;", "mSideSymbolsPinyin", "", "Lcom/yuyan/imemodule/database/entry/SideSymbol;", "getIvDelete", "Landroid/widget/ImageView;", "initView", "", "onAttachedToWindow", "onDetachedFromWindow", "showCandidatesView", "updatePrefixsView", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class CandidatesContainer extends com.yuyan.imemodule.keyboard.container.BaseContainer {
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> mSideSymbolsPinyin = null;
    private com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView mRVSymbolsView;
    private com.yuyan.imemodule.adapter.CandidatesAdapter mCandidatesAdapter;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView mRVLeftPrefix;
    private boolean isLoadingMore = false;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.LinearLayout mLlAddSymbol = null;
    @org.jetbrains.annotations.Nullable()
    private android.os.Handler mDeleteHandler;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.Runnable mRepeatDeleteRunnable = null;
    
    public CandidatesContainer(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    @java.lang.Override()
    protected void onAttachedToWindow() {
    }
    
    @java.lang.Override()
    protected void onDetachedFromWindow() {
    }
    
    private final void initView(android.content.Context context) {
    }
    
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    private final android.widget.ImageView getIvDelete() {
        return null;
    }
    
    /**
     * 显示候选词界面 , 点击候选词时执行
     */
    public final void showCandidatesView() {
    }
    
    private final void updatePrefixsView() {
    }
}
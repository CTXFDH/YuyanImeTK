package com.yuyan.imemodule.keyboard.container;

/**
 * 候选词键盘容器
 *
 * 选择候选词界面分两种效果：九宫格（[InputModeSwitcher.isChineseT9])情况下显示左侧拼音选择栏；全键、手写等情况下不显示拼音选择栏。
 * @see InputModeSwitcher.isChineseT9
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\b\u0010\u0013\u001a\u00020\u0014H\u0003J\u0010\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0002\u001a\u00020\u0003H\u0002J\u0006\u0010\u0017\u001a\u00020\u0016J\b\u0010\u0018\u001a\u00020\u0016H\u0002R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u000eX\u0082.\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00120\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0019"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/CandidatesContainer;", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "isLoadingMore", "", "mCandidatesAdapter", "Lcom/yuyan/imemodule/adapter/CandidatesAdapter;", "mLlAddSymbol", "Landroid/widget/LinearLayout;", "mRVLeftPrefix", "Lcom/yuyan/imemodule/libs/recyclerview/SwipeRecyclerView;", "mRVSymbolsView", "mSideSymbolsPinyin", "", "Lcom/yuyan/imemodule/database/entry/SideSymbol;", "getIvDelete", "Landroid/widget/ImageView;", "initView", "", "showCandidatesView", "updatePrefixsView", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class CandidatesContainer extends com.yuyan.imemodule.keyboard.container.BaseContainer {
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> mSideSymbolsPinyin = null;
    private com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView mRVSymbolsView;
    private com.yuyan.imemodule.adapter.CandidatesAdapter mCandidatesAdapter;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView mRVLeftPrefix;
    private boolean isLoadingMore = false;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.LinearLayout mLlAddSymbol = null;
    
    public CandidatesContainer(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    private final void initView(android.content.Context context) {
    }
    
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    private final android.widget.ImageView getIvDelete() {
        return null;
    }
    
    /**
     * 显示候选词界面 , 点击候选词时执行
     */
    public final void showCandidatesView() {
    }
    
    private final void updatePrefixsView() {
    }
}
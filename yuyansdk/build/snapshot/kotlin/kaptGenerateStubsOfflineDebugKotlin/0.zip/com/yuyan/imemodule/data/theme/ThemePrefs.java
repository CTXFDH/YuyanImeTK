package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004JE\u00107\u001a\u00020\u00062\b\b\u0001\u00108\u001a\u0002092\u0006\u0010:\u001a\u00020\u000b2\u0006\u0010;\u001a\u00020<2\n\b\u0003\u0010=\u001a\u0004\u0018\u0001092\u0010\b\u0002\u0010>\u001a\n\u0012\u0004\u0012\u00020@\u0018\u00010?H\u0002\u00a2\u0006\u0002\u0010AR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0012\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011R\u0011\u0010\u0014\u001a\u00020\u0015\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0018\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0011R\u0011\u0010\u001a\u001a\u00020\u0015\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0017R\u0011\u0010\u001c\u001a\u00020\u0015\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0017R\u0011\u0010\u001e\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0011R\u0011\u0010 \u001a\u00020\u0015\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0017R\u0011\u0010\"\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\u0011R\u0011\u0010$\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010\bR\u0011\u0010&\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010\bR\u0017\u0010(\u001a\b\u0012\u0004\u0012\u00020*0)\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010,R\u0017\u0010-\u001a\b\u0012\u0004\u0012\u00020.0)\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u0010,R\u0013\u00100\u001a\u000201\u00a2\u0006\n\n\u0002\u00104\u001a\u0004\b2\u00103R\u0013\u00105\u001a\u000201\u00a2\u0006\n\n\u0002\u00104\u001a\u0004\b6\u00103\u00a8\u0006B"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ThemePrefs;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceCategory;", "sharedPreferences", "Landroid/content/SharedPreferences;", "(Landroid/content/SharedPreferences;)V", "darkModeTheme", "Lcom/yuyan/imemodule/data/theme/ManagedThemePreference;", "getDarkModeTheme", "()Lcom/yuyan/imemodule/data/theme/ManagedThemePreference;", "dayNightModePrefNames", "", "", "getDayNightModePrefNames", "()Ljava/util/Set;", "followSystemDayNightTheme", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "getFollowSystemDayNightTheme", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "keyBorder", "getKeyBorder", "keyRadius", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "getKeyRadius", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "keyShadow", "getKeyShadow", "keyXMargin", "getKeyXMargin", "keyYMargin", "getKeyYMargin", "keyboardFontBold", "getKeyboardFontBold", "keyboardFontSize", "getKeyboardFontSize", "keyboardSymbol", "getKeyboardSymbol", "lightModeTheme", "getLightModeTheme", "normalModeTheme", "getNormalModeTheme", "skbStyleMode", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "Lcom/yuyan/imemodule/prefs/behavior/SkbStyleMode;", "getSkbStyleMode", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "symbolSlideUpMod", "Lcom/yuyan/imemodule/prefs/behavior/KeyboardSymbolSlideUpMod;", "getSymbolSlideUpMod", "themeSetting", "", "getThemeSetting", "()Lkotlin/Unit;", "Lkotlin/Unit;", "titleKeyboardSetting", "getTitleKeyboardSetting", "themePreference", "title", "", "key", "defaultValue", "Lcom/yuyan/imemodule/data/theme/Theme;", "summary", "enableUiOn", "Lkotlin/Function0;", "", "(ILjava/lang/String;Lcom/yuyan/imemodule/data/theme/Theme;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lcom/yuyan/imemodule/data/theme/ManagedThemePreference;", "yuyansdk_offlineDebug"})
public final class ThemePrefs extends com.yuyan.imemodule.prefs.ManagedPreferenceCategory {
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Unit themeSetting = null;
    
    /**
     * When [followSystemDayNightTheme] is disabled, this theme is used.
     * This is effectively an internal preference which does not need UI.
     */
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.ManagedThemePreference normalModeTheme = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.SkbStyleMode> skbStyleMode = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool followSystemDayNightTheme = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.ManagedThemePreference lightModeTheme = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.ManagedThemePreference darkModeTheme = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.Set<java.lang.String> dayNightModePrefNames = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Unit titleKeyboardSetting = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardFontBold = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardFontSize = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardSymbol = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.KeyboardSymbolSlideUpMod> symbolSlideUpMod = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyBorder = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyShadow = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyXMargin = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyYMargin = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyRadius = null;
    
    public ThemePrefs(@org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences sharedPreferences) {
        super(0, null);
    }
    
    private final com.yuyan.imemodule.data.theme.ManagedThemePreference themePreference(@androidx.annotation.StringRes()
    int title, java.lang.String key, com.yuyan.imemodule.data.theme.Theme defaultValue, @androidx.annotation.StringRes()
    java.lang.Integer summary, kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlin.Unit getThemeSetting() {
        return null;
    }
    
    /**
     * When [followSystemDayNightTheme] is disabled, this theme is used.
     * This is effectively an internal preference which does not need UI.
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.ManagedThemePreference getNormalModeTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.SkbStyleMode> getSkbStyleMode() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getFollowSystemDayNightTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.ManagedThemePreference getLightModeTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.ManagedThemePreference getDarkModeTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Set<java.lang.String> getDayNightModePrefNames() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlin.Unit getTitleKeyboardSetting() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardFontBold() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardFontSize() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardSymbol() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<com.yuyan.imemodule.prefs.behavior.KeyboardSymbolSlideUpMod> getSymbolSlideUpMod() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyBorder() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyShadow() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyXMargin() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyYMargin() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyRadius() {
        return null;
    }
}
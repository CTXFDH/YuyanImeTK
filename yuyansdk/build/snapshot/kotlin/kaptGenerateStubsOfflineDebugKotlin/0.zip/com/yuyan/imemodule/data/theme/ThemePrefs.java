package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004JE\u00103\u001a\u00020\n2\b\b\u0001\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\u000f2\u0006\u00107\u001a\u0002082\n\b\u0003\u00109\u001a\u0004\u0018\u0001052\u0010\b\u0002\u0010:\u001a\n\u0012\u0004\u0012\u00020<\u0018\u00010;H\u0002\u00a2\u0006\u0002\u0010=R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0012\u001a\u00020\u0013\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0016\u001a\u00020\u0013\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0015R\u0011\u0010\u0018\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\bR\u0011\u0010\u001a\u001a\u00020\u0013\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0015R\u0011\u0010\u001c\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\bR\u0011\u0010\u001e\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\bR\u0011\u0010 \u001a\u00020\u0013\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\u0015R\u0011\u0010\"\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010\bR\u0011\u0010$\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010\bR\u0011\u0010&\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010\fR\u0011\u0010(\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010\fR\u0013\u0010*\u001a\u00020+\u00a2\u0006\n\n\u0002\u0010.\u001a\u0004\b,\u0010-R\u0013\u0010/\u001a\u00020+\u00a2\u0006\n\n\u0002\u0010.\u001a\u0004\b0\u0010-R\u0011\u00101\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u0010\b\u00a8\u0006>"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ThemePrefs;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceCategory;", "sharedPreferences", "Landroid/content/SharedPreferences;", "(Landroid/content/SharedPreferences;)V", "candidateTextSize", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "getCandidateTextSize", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "darkModeTheme", "Lcom/yuyan/imemodule/data/theme/ManagedThemePreference;", "getDarkModeTheme", "()Lcom/yuyan/imemodule/data/theme/ManagedThemePreference;", "dayNightModePrefNames", "", "", "getDayNightModePrefNames", "()Ljava/util/Set;", "followSystemDayNightTheme", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "getFollowSystemDayNightTheme", "()Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "keyBorder", "getKeyBorder", "keyRadius", "getKeyRadius", "keyShadow", "getKeyShadow", "keyXMargin", "getKeyXMargin", "keyYMargin", "getKeyYMargin", "keyboardBalloonShow", "getKeyboardBalloonShow", "keyboardFontSize", "getKeyboardFontSize", "keyboardFontWeight", "getKeyboardFontWeight", "lightModeTheme", "getLightModeTheme", "normalModeTheme", "getNormalModeTheme", "themeSetting", "", "getThemeSetting", "()Lkotlin/Unit;", "Lkotlin/Unit;", "titleKeyboardSetting", "getTitleKeyboardSetting", "windowCornerRadiusDp", "getWindowCornerRadiusDp", "themePreference", "title", "", "key", "defaultValue", "Lcom/yuyan/imemodule/data/theme/Theme;", "summary", "enableUiOn", "Lkotlin/Function0;", "", "(ILjava/lang/String;Lcom/yuyan/imemodule/data/theme/Theme;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)Lcom/yuyan/imemodule/data/theme/ManagedThemePreference;", "yuyansdk_offlineDebug"})
public final class ThemePrefs extends com.yuyan.imemodule.prefs.ManagedPreferenceCategory {
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Unit themeSetting = null;
    
    /**
     * When [followSystemDayNightTheme] is disabled, this theme is used.
     * This is effectively an internal preference which does not need UI.
     */
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.ManagedThemePreference normalModeTheme = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool followSystemDayNightTheme = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.ManagedThemePreference lightModeTheme = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.data.theme.ManagedThemePreference darkModeTheme = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.Set<java.lang.String> dayNightModePrefNames = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Unit titleKeyboardSetting = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt windowCornerRadiusDp = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt candidateTextSize = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardFontWeight = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyboardFontSize = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyboardBalloonShow = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyBorder = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PBool keyShadow = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyXMargin = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyYMargin = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.PInt keyRadius = null;
    
    public ThemePrefs(@org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences sharedPreferences) {
        super(0, null);
    }
    
    private final com.yuyan.imemodule.data.theme.ManagedThemePreference themePreference(@androidx.annotation.StringRes()
    int title, java.lang.String key, com.yuyan.imemodule.data.theme.Theme defaultValue, @androidx.annotation.StringRes()
    java.lang.Integer summary, kotlin.jvm.functions.Function0<java.lang.Boolean> enableUiOn) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlin.Unit getThemeSetting() {
        return null;
    }
    
    /**
     * When [followSystemDayNightTheme] is disabled, this theme is used.
     * This is effectively an internal preference which does not need UI.
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.ManagedThemePreference getNormalModeTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getFollowSystemDayNightTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.ManagedThemePreference getLightModeTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.ManagedThemePreference getDarkModeTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Set<java.lang.String> getDayNightModePrefNames() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlin.Unit getTitleKeyboardSetting() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getWindowCornerRadiusDp() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getCandidateTextSize() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardFontWeight() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyboardFontSize() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyboardBalloonShow() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyBorder() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PBool getKeyShadow() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyXMargin() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyYMargin() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.preference.ManagedPreference.PInt getKeyRadius() {
        return null;
    }
}
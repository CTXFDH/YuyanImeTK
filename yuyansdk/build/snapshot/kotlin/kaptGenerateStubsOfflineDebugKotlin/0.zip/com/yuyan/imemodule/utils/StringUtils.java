package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\f\n\u0002\b\t\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\t\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eJ\u000e\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u000eJ\u0010\u0010\u0013\u001a\u00020\u00112\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eJ\u0012\u0010\u0014\u001a\u00020\u00112\b\u0010\u0015\u001a\u0004\u0018\u00010\u000eH\u0007J\u0012\u0010\u0016\u001a\u00020\u00112\b\u0010\u0015\u001a\u0004\u0018\u00010\u000eH\u0007J\u0012\u0010\u0017\u001a\u00020\u00112\b\u0010\u0015\u001a\u0004\u0018\u00010\u000eH\u0007J\u0010\u0010\u0018\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u0004H\u0002J\u0014\u0010\u0019\u001a\u0004\u0018\u00010\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001a"}, d2 = {"Lcom/yuyan/imemodule/utils/StringUtils;", "", "()V", "ASCII_END", "", "ASCII_START", "DBC_PERIOD", "DBC_SBC_STEP", "DBC_SPACE", "SBC_PERIOD", "SBC_SPACE", "UNICODE_END", "UNICODE_START", "converted2FlowerTypeface", "", "src", "isChineseEnd", "", "input", "isDBCSymbol", "isEnglishWord", "str", "isLetter", "isNumber", "sbc2dbc", "sbc2dbcCase", "yuyansdk_offlineDebug"})
public final class StringUtils {
    public static final char SBC_SPACE = '\u3000';
    public static final char DBC_SPACE = ' ';
    public static final char SBC_PERIOD = '\u3002';
    public static final char DBC_PERIOD = '\uff61';
    public static final char ASCII_START = '\u001e';
    public static final char ASCII_END = '~';
    public static final char UNICODE_START = '\ufefe';
    public static final char UNICODE_END = '\uff5e';
    public static final char DBC_SBC_STEP = '\ufee0';
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.StringUtils INSTANCE = null;
    
    private StringUtils() {
        super();
    }
    
    /**
     * 判断字符串是不是字母
     */
    @kotlin.jvm.JvmStatic()
    public static final boolean isLetter(@org.jetbrains.annotations.Nullable()
    java.lang.String str) {
        return false;
    }
    
    /**
     * 判断字符串是不是英文
     */
    @kotlin.jvm.JvmStatic()
    public static final boolean isEnglishWord(@org.jetbrains.annotations.Nullable()
    java.lang.String str) {
        return false;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final boolean isNumber(@org.jetbrains.annotations.Nullable()
    java.lang.String str) {
        return false;
    }
    
    public final boolean isChineseEnd(@org.jetbrains.annotations.NotNull()
    java.lang.String input) {
        return false;
    }
    
    private final char sbc2dbc(char src) {
        return '\u0000';
    }
    
    @kotlin.jvm.JvmStatic()
    @org.jetbrains.annotations.Nullable()
    public static final java.lang.String sbc2dbcCase(@org.jetbrains.annotations.Nullable()
    java.lang.String src) {
        return null;
    }
    
    /**
     * 判断是否是半角符号
     * 排除数字、大小写字母
     */
    public final boolean isDBCSymbol(@org.jetbrains.annotations.Nullable()
    java.lang.String src) {
        return false;
    }
    
    /**
     * 字符串转花漾字
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String converted2FlowerTypeface(@org.jetbrains.annotations.NotNull()
    java.lang.String src) {
        return null;
    }
}
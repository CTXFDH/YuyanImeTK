package com.yuyan.imemodule.view.widget;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u00004\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\b\b\u0001\u0010\u0003\u001a\u00020\u0004\u001aI\u0010\u0005\u001a\u00020\u0006*\u00020\u00072\u0006\u0010\b\u001a\u00020\u00022\b\b\u0003\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\t\u001a\u00020\n2\u001c\u0010\u000b\u001a\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\r\u0012\u0006\u0012\u0004\u0018\u00010\u000e0\f\u00a2\u0006\u0002\u0010\u000f\u00a8\u0006\u0010"}, d2 = {"ProgressBarDialogIndeterminate", "Landroidx/appcompat/app/AlertDialog$Builder;", "Landroid/content/Context;", "title", "", "withLoadingDialog", "", "Landroidx/lifecycle/LifecycleCoroutineScope;", "context", "threshold", "", "action", "Lkotlin/Function1;", "Lkotlin/coroutines/Continuation;", "", "(Landroidx/lifecycle/LifecycleCoroutineScope;Landroid/content/Context;IJLkotlin/jvm/functions/Function1;)V", "yuyansdk_offlineDebug"})
public final class ProgressBarDialogIndeterminateKt {
    
    @kotlin.Suppress(names = {"FunctionName"})
    @org.jetbrains.annotations.NotNull()
    public static final androidx.appcompat.app.AlertDialog.Builder ProgressBarDialogIndeterminate(@org.jetbrains.annotations.NotNull()
    android.content.Context $this$ProgressBarDialogIndeterminate, @androidx.annotation.StringRes()
    int title) {
        return null;
    }
    
    public static final void withLoadingDialog(@org.jetbrains.annotations.NotNull()
    androidx.lifecycle.LifecycleCoroutineScope $this$withLoadingDialog, @org.jetbrains.annotations.NotNull()
    android.content.Context context, @androidx.annotation.StringRes()
    int title, long threshold, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> action) {
    }
}
package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000`\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\n\b\u00c7\u0002\u0018\u00002\u00020\u0001:\u00017B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u001aJ\u000e\u0010$\u001a\u00020\"2\u0006\u0010%\u001a\u00020&J\b\u0010\'\u001a\u00020\fH\u0002J\b\u0010(\u001a\u00020\"H\u0002J\u0014\u0010)\u001a\u0010\u0012\f\u0012\n **\u0004\u0018\u00010\f0\f0\u0004J\u0010\u0010+\u001a\u0004\u0018\u00010\f2\u0006\u0010%\u001a\u00020&J\u000e\u0010,\u001a\u00020\"2\u0006\u0010-\u001a\u00020.J\u000e\u0010/\u001a\u00020\"2\u0006\u00100\u001a\u00020\u0017J\u0006\u00101\u001a\u00020\"J\u000e\u00102\u001a\u00020\"2\u0006\u0010#\u001a\u00020\u001aJ\u001a\u00103\u001a\u00020\"2\u0006\u00104\u001a\u00020\u00152\n\b\u0002\u00105\u001a\u0004\u0018\u00010&J\u000e\u00106\u001a\u00020\"2\u0006\u00104\u001a\u00020\fR\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0011\u0010\b\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u000e\u0010\u000b\u001a\u00020\fX\u0082.\u00a2\u0006\u0002\n\u0000R$\u0010\u000e\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\f8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u001a0\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00010\u001c8\u0002X\u0083\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u001d\u001a\u00020\u001e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 \u00a8\u00068"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ThemeManager;", "", "()V", "BuiltinThemes", "", "Lcom/yuyan/imemodule/data/theme/Theme$Builtin;", "getBuiltinThemes", "()Ljava/util/List;", "DefaultTheme", "getDefaultTheme", "()Lcom/yuyan/imemodule/data/theme/Theme$Builtin;", "_activeTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "value", "activeTheme", "getActiveTheme", "()Lcom/yuyan/imemodule/data/theme/Theme;", "setActiveTheme", "(Lcom/yuyan/imemodule/data/theme/Theme;)V", "customThemes", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "isDarkMode", "", "onChangeListeners", "Ljava/util/concurrent/CopyOnWriteArraySet;", "Lcom/yuyan/imemodule/data/theme/ThemeManager$OnThemeChangeListener;", "onThemePrefsChange", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "prefs", "Lcom/yuyan/imemodule/data/theme/ThemePrefs;", "getPrefs", "()Lcom/yuyan/imemodule/data/theme/ThemePrefs;", "addOnChangedListener", "", "listener", "deleteTheme", "name", "", "evaluateActiveTheme", "fireChange", "getAllThemes", "kotlin.jvm.PlatformType", "getTheme", "init", "configuration", "Landroid/content/res/Configuration;", "onSystemDarkModeChange", "isDark", "refreshThemes", "removeOnChangedListener", "saveTheme", "theme", "oldName", "setNormalModeTheme", "OnThemeChangeListener", "yuyansdk_offlineDebug"})
public final class ThemeManager {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.List<com.yuyan.imemodule.data.theme.Theme.Builtin> BuiltinThemes = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.Theme.Builtin DefaultTheme = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.concurrent.CopyOnWriteArrayList<com.yuyan.imemodule.data.theme.Theme.Custom> customThemes = null;
    
    /**
     * [backing property](https://kotlinlang.org/docs/properties.html#backing-properties)
     * of [activeTheme]; holds the [Theme] object currently in use
     */
    private static com.yuyan.imemodule.data.theme.Theme _activeTheme;
    private static boolean isDarkMode = false;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.concurrent.CopyOnWriteArraySet<com.yuyan.imemodule.data.theme.ThemeManager.OnThemeChangeListener> onChangeListeners = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.data.theme.ThemePrefs prefs = null;
    @androidx.annotation.Keep()
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<java.lang.Object> onThemePrefsChange = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.theme.ThemeManager INSTANCE = null;
    
    private ThemeManager() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.data.theme.Theme.Builtin> getBuiltinThemes() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme.Builtin getDefaultTheme() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.data.theme.Theme getTheme(@org.jetbrains.annotations.NotNull()
    java.lang.String name) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.data.theme.Theme> getAllThemes() {
        return null;
    }
    
    public final void refreshThemes() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.Theme getActiveTheme() {
        return null;
    }
    
    public final void setActiveTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme value) {
    }
    
    public final void addOnChangedListener(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.ThemeManager.OnThemeChangeListener listener) {
    }
    
    public final void removeOnChangedListener(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.ThemeManager.OnThemeChangeListener listener) {
    }
    
    private final void fireChange() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.data.theme.ThemePrefs getPrefs() {
        return null;
    }
    
    public final void saveTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme.Custom theme, @org.jetbrains.annotations.Nullable()
    java.lang.String oldName) {
    }
    
    public final void deleteTheme(@org.jetbrains.annotations.NotNull()
    java.lang.String name) {
    }
    
    public final void setNormalModeTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    private final com.yuyan.imemodule.data.theme.Theme evaluateActiveTheme() {
        return null;
    }
    
    public final void init(@org.jetbrains.annotations.NotNull()
    android.content.res.Configuration configuration) {
    }
    
    public final void onSystemDarkModeChange(boolean isDark) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ThemeManager$OnThemeChangeListener;", "", "onThemeChange", "", "theme", "Lcom/yuyan/imemodule/data/theme/Theme;", "yuyansdk_offlineDebug"})
    public static abstract interface OnThemeChangeListener {
        
        public abstract void onThemeChange(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.data.theme.Theme theme);
    }
}
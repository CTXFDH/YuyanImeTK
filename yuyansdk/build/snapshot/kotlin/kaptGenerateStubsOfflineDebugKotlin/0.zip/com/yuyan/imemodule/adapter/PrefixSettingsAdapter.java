package com.yuyan.imemodule.adapter;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u0014B\u001b\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bJ\b\u0010\n\u001a\u00020\u000bH\u0016J\u001c\u0010\f\u001a\u00020\r2\n\u0010\u000e\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u000bH\u0016J\u001c\u0010\u0010\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u000bH\u0016R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/adapter/PrefixSettingsAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/adapter/PrefixSettingsAdapter$PrefixSettingsHolder;", "mDatas", "", "Lcom/yuyan/imemodule/database/entry/SideSymbol;", "type", "", "(Ljava/util/List;Ljava/lang/String;)V", "mType", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "PrefixSettingsHolder", "yuyansdk_offlineDebug"})
public final class PrefixSettingsAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.adapter.PrefixSettingsAdapter.PrefixSettingsHolder> {
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> mDatas = null;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String mType = "pinyin";
    
    public PrefixSettingsAdapter(@org.jetbrains.annotations.NotNull()
    java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> mDatas, @org.jetbrains.annotations.NotNull()
    java.lang.String type) {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.adapter.PrefixSettingsAdapter.PrefixSettingsHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.adapter.PrefixSettingsAdapter.PrefixSettingsHolder holder, int position) {
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001a\u0010\u0005\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\b\"\u0004\b\r\u0010\n\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/adapter/PrefixSettingsAdapter$PrefixSettingsHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "(Lcom/yuyan/imemodule/adapter/PrefixSettingsAdapter;Landroid/view/View;)V", "etPrefixKey", "Landroid/widget/EditText;", "getEtPrefixKey", "()Landroid/widget/EditText;", "setEtPrefixKey", "(Landroid/widget/EditText;)V", "etPrefixValue", "getEtPrefixValue", "setEtPrefixValue", "yuyansdk_offlineDebug"})
    public final class PrefixSettingsHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.NotNull()
        private android.widget.EditText etPrefixKey;
        @org.jetbrains.annotations.NotNull()
        private android.widget.EditText etPrefixValue;
        
        public PrefixSettingsHolder(@org.jetbrains.annotations.NotNull()
        android.view.View view) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.EditText getEtPrefixKey() {
            return null;
        }
        
        public final void setEtPrefixKey(@org.jetbrains.annotations.NotNull()
        android.widget.EditText p0) {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.EditText getEtPrefixValue() {
            return null;
        }
        
        public final void setEtPrefixValue(@org.jetbrains.annotations.NotNull()
        android.widget.EditText p0) {
        }
    }
}
package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ThemeSettingsFragment;", "Lcom/yuyan/imemodule/ui/fragment/base/ManagedPreferenceFragment;", "()V", "yuyansdk_offlineDebug"})
public final class ThemeSettingsFragment extends com.yuyan.imemodule.ui.fragment.base.ManagedPreferenceFragment {
    
    public ThemeSettingsFragment() {
        super(null);
    }
}
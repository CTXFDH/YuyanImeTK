package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0003\u001a\u00020\u0004H\u0016J\b\u0010\u0005\u001a\u00020\u0004H\u0016\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ThemeSettingsFragment;", "Lcom/yuyan/imemodule/ui/fragment/base/ManagedPreferenceFragment;", "()V", "onStart", "", "onStop", "yuyansdk_offlineDebug"})
public final class ThemeSettingsFragment extends com.yuyan.imemodule.ui.fragment.base.ManagedPreferenceFragment {
    
    public ThemeSettingsFragment() {
        super(null);
    }
    
    @java.lang.Override()
    public void onStart() {
    }
    
    @java.lang.Override()
    public void onStop() {
    }
}
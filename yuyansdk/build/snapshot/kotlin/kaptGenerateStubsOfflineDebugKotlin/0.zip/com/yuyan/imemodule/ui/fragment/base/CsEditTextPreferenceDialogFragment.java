package com.yuyan.imemodule.ui.fragment.base;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 \n2\u00020\u0001:\u0001\nB\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0014J\u0010\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\tH\u0014\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/base/CsEditTextPreferenceDialogFragment;", "Landroidx/preference/EditTextPreferenceDialogFragmentCompat;", "()V", "onBindDialogView", "", "view", "Landroid/view/View;", "onPrepareDialogBuilder", "builder", "Landroidx/appcompat/app/AlertDialog$Builder;", "Companion", "yuyansdk_offlineDebug"})
public final class CsEditTextPreferenceDialogFragment extends androidx.preference.EditTextPreferenceDialogFragmentCompat {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.ui.fragment.base.CsEditTextPreferenceDialogFragment.Companion Companion = null;
    
    public CsEditTextPreferenceDialogFragment() {
        super();
    }
    
    @java.lang.Override()
    protected void onPrepareDialogBuilder(@org.jetbrains.annotations.NotNull()
    androidx.appcompat.app.AlertDialog.Builder builder) {
    }
    
    @java.lang.Override()
    protected void onBindDialogView(@org.jetbrains.annotations.NotNull()
    android.view.View view) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/base/CsEditTextPreferenceDialogFragment$Companion;", "", "()V", "newInstance", "Lcom/yuyan/imemodule/ui/fragment/base/CsEditTextPreferenceDialogFragment;", "key", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.ui.fragment.base.CsEditTextPreferenceDialogFragment newInstance(@org.jetbrains.annotations.NotNull()
        java.lang.String key) {
            return null;
        }
    }
}
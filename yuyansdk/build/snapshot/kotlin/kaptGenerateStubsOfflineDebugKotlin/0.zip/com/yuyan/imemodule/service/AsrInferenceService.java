package com.yuyan.imemodule.service;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \u001d2\u00020\u0001:\u0001\u001dB\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0013\u001a\u00020\u0014H\u0002J\u0010\u0010\u0015\u001a\u00020\u00062\u0006\u0010\u0016\u001a\u00020\u0012H\u0002J\u0010\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aH\u0016J\b\u0010\u001b\u001a\u00020\u0014H\u0016J\b\u0010\u001c\u001a\u00020\u0014H\u0002R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001e"}, d2 = {"Lcom/yuyan/imemodule/service/AsrInferenceService;", "Landroid/app/Service;", "()V", "asrCallback", "Lcom/yuyan/imemodule/service/IInferenceAsrCallback;", "asrHandle", "", "asrLock", "", "binder", "Lcom/yuyan/imemodule/service/IInferenceAsrService$Stub;", "idleHandler", "Landroid/os/Handler;", "idleReleaseRunnable", "Ljava/lang/Runnable;", "keepModelAlive", "", "loadedModelDir", "", "cancelIdleRelease", "", "createAsrHandle", "modelDir", "onBind", "Landroid/os/IBinder;", "intent", "Landroid/content/Intent;", "onDestroy", "scheduleIdleRelease", "Companion", "yuyansdk_offlineDebug"})
public final class AsrInferenceService extends android.app.Service {
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String TAG = "AsrInferenceService";
    private static final long IDLE_RELEASE_DELAY_MS = 60000L;
    private long asrHandle = 0L;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.service.IInferenceAsrCallback asrCallback;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.Object asrLock = null;
    @org.jetbrains.annotations.Nullable()
    private java.lang.String loadedModelDir;
    @kotlin.jvm.Volatile()
    private volatile boolean keepModelAlive = false;
    @org.jetbrains.annotations.NotNull()
    private final android.os.Handler idleHandler = null;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.Runnable idleReleaseRunnable = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.service.IInferenceAsrService.Stub binder = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.service.AsrInferenceService.Companion Companion = null;
    
    public AsrInferenceService() {
        super();
    }
    
    private final void scheduleIdleRelease() {
    }
    
    private final void cancelIdleRelease() {
    }
    
    private final long createAsrHandle(java.lang.String modelDir) {
        return 0L;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.os.IBinder onBind(@org.jetbrains.annotations.NotNull()
    android.content.Intent intent) {
        return null;
    }
    
    @java.lang.Override()
    public void onDestroy() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\'\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00042\b\u0010\n\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u000b\u001a\u00020\u0006H\u0000\u00a2\u0006\u0002\b\fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/service/AsrInferenceService$Companion;", "", "()V", "IDLE_RELEASE_DELAY_MS", "", "TAG", "", "shouldReloadHandle", "", "handle", "loadedDir", "requestedDir", "shouldReloadHandle$yuyansdk_offlineDebug", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        public final boolean shouldReloadHandle$yuyansdk_offlineDebug(long handle, @org.jetbrains.annotations.Nullable()
        java.lang.String loadedDir, @org.jetbrains.annotations.NotNull()
        java.lang.String requestedDir) {
            return false;
        }
    }
}
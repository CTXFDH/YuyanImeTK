package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u000b\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B9\u0012\u0012\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003\"\u00020\u0004\u0012\u001e\u0010\u0005\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007\u0012\u0004\u0012\u00020\n0\u0006\u00a2\u0006\u0002\u0010\u000bJ\u0006\u0010\u0011\u001a\u00020\nJ\u0006\u0010\u0012\u001a\u00020\nR\u0016\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00010\r8\u0002X\u0083\u0004\u00a2\u0006\u0002\n\u0000R&\u0010\u0005\u001a\u001a\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007\u0012\u0004\u0012\u00020\n0\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0018\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u000eR\u001a\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0013"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceVisibilityEvaluator;", "", "providers", "", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "onVisibilityChanged", "Lkotlin/Function1;", "", "", "", "", "([Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;Lkotlin/jvm/functions/Function1;)V", "onValueChangeListener", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "[Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "visibility", "", "destroy", "evaluateVisibility", "yuyansdk_offlineDebug"})
public final class ManagedPreferenceVisibilityEvaluator {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.prefs.ManagedPreferenceProvider[] providers = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function1<java.util.Map<java.lang.String, java.lang.Boolean>, kotlin.Unit> onVisibilityChanged = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.Map<java.lang.String, java.lang.Boolean> visibility = null;
    @androidx.annotation.Keep()
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<java.lang.Object> onValueChangeListener = null;
    
    public ManagedPreferenceVisibilityEvaluator(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.ManagedPreferenceProvider[] providers, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.util.Map<java.lang.String, java.lang.Boolean>, kotlin.Unit> onVisibilityChanged) {
        super();
    }
    
    public final void evaluateVisibility() {
    }
    
    public final void destroy() {
    }
}
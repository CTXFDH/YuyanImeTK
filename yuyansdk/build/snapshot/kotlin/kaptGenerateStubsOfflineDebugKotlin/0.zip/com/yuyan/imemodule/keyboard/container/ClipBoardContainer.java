package com.yuyan.imemodule.keyboard.container;

/**
 * 粘贴板列表键盘容器 (选中【常用语】时右侧空白处显示加号图标，支持手动添加常用语)
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0016\u0010!\u001a\u00020\"2\f\u0010#\u001a\b\u0012\u0004\u0012\u00020%0$H\u0002J\u0006\u0010&\u001a\u00020\u0012J\u0018\u0010\'\u001a\u00020\u00152\u0006\u0010#\u001a\u00020(2\u0006\u0010)\u001a\u00020\u0015H\u0002J\u0010\u0010*\u001a\u00020\"2\u0006\u0010\u0002\u001a\u00020\u0003H\u0002J\b\u0010+\u001a\u00020\"H\u0002J\u000e\u0010,\u001a\u00020\"2\u0006\u0010-\u001a\u00020\u0012R\u000e\u0010\u0007\u001a\u00020\bX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020\u00150\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0010X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0010X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001fX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006."}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/ClipBoardContainer;", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "btnAddPhrases", "Landroid/widget/ImageView;", "btnCancelSelect", "Landroid/widget/TextView;", "btnDeleteSelected", "btnSelectAll", "currentAdapter", "Lcom/yuyan/imemodule/adapter/ClipBoardAdapter;", "innerRoot", "Landroid/widget/LinearLayout;", "itemMode", "Lcom/yuyan/imemodule/prefs/behavior/SkbMenuMode;", "mHashMapSymbols", "Ljava/util/HashMap;", "", "mPaint", "Landroid/graphics/Paint;", "mRVSymbolsView", "Lcom/yuyan/imemodule/libs/recyclerview/SwipeRecyclerView;", "mTVLable", "multiSelectTopContainer", "normalTabsContainer", "tabClipboard", "tabLayout", "Landroid/widget/RelativeLayout;", "tabPhrases", "calculateColumn", "", "data", "", "Lcom/yuyan/imemodule/database/entry/Clipboard;", "getMenuMode", "getSymbolsCount", "", "itemWidth", "initView", "rootLayoutAddEmptyView", "showClipBoardView", "item", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class ClipBoardContainer extends com.yuyan.imemodule.keyboard.container.BaseContainer {
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Paint mPaint = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView mRVSymbolsView = null;
    @org.jetbrains.annotations.Nullable()
    private android.widget.TextView mTVLable;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.prefs.behavior.SkbMenuMode itemMode = com.yuyan.imemodule.prefs.behavior.SkbMenuMode.ClipBoard;
    private android.widget.LinearLayout innerRoot;
    private android.widget.RelativeLayout tabLayout;
    private android.widget.LinearLayout normalTabsContainer;
    private android.widget.LinearLayout multiSelectTopContainer;
    private android.widget.TextView tabClipboard;
    private android.widget.TextView tabPhrases;
    private android.widget.ImageView btnAddPhrases;
    private android.widget.TextView btnSelectAll;
    private android.widget.TextView btnDeleteSelected;
    private android.widget.TextView btnCancelSelect;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.adapter.ClipBoardAdapter currentAdapter;
    @org.jetbrains.annotations.NotNull()
    private final java.util.HashMap<java.lang.Integer, java.lang.Integer> mHashMapSymbols = null;
    
    public ClipBoardContainer(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    private final void initView(android.content.Context context) {
    }
    
    /**
     * 显示剪贴板或常用语视图
     */
    public final void showClipBoardView(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.behavior.SkbMenuMode item) {
    }
    
    private final void rootLayoutAddEmptyView() {
    }
    
    private final void calculateColumn(java.util.List<com.yuyan.imemodule.database.entry.Clipboard> data) {
    }
    
    private final int getSymbolsCount(java.lang.String data, int itemWidth) {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.prefs.behavior.SkbMenuMode getMenuMode() {
        return null;
    }
}
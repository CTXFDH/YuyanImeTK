package com.yuyan.imemodule.speech;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u0000 ,2\u00020\u0001:\u0002+,B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0010\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\bJ\u0018\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u0018\u0010\u000f\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u0018\u0010\u0010\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u0018\u0010\u0013\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0015\u001a\u00020\u000eJ\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0015\u001a\u00020\u000eJ$\u0010\u0017\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0015\u001a\u00020\u000e2\u0012\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\n0\u0019J\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0015\u001a\u00020\u000eJ\u0010\u0010\u001b\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0015\u001a\u00020\u000eJ\u000e\u0010\u001c\u001a\u00020\u00062\u0006\u0010\r\u001a\u00020\u000eJ\f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u001f0\u001eJ\u000e\u0010 \u001a\u00020\u000e2\u0006\u0010\u0007\u001a\u00020\bJ\u000e\u0010!\u001a\u00020\u001f2\u0006\u0010\u0007\u001a\u00020\bJ\b\u0010\"\u001a\u0004\u0018\u00010\u000eJ\b\u0010#\u001a\u0004\u0018\u00010\bJ\b\u0010$\u001a\u0004\u0018\u00010\u001fJ\u0018\u0010%\u001a\u00020\n2\u0006\u0010&\u001a\u00020\'2\b\b\u0002\u0010\u0007\u001a\u00020\bJ\u000e\u0010(\u001a\u00020\n2\u0006\u0010\u0007\u001a\u00020\bJ\u0006\u0010)\u001a\u00020\nJ\u000e\u0010*\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006-"}, d2 = {"Lcom/yuyan/imemodule/speech/AsrModelManager;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "ensureAssetsModelInstalled", "", "modelId", "", "extractTarBz2", "", "inputStream", "Ljava/io/InputStream;", "targetDir", "Ljava/io/File;", "extractTarGz", "extractTarStream", "tarIn", "Lorg/apache/commons/compress/archivers/tar/TarArchiveInputStream;", "extractZip", "findDecoderFile", "dir", "findEncoderFile", "findFileMatching", "predicate", "Lkotlin/Function1;", "findJoinerFile", "findTokensFile", "flattenModelDirectory", "getAsrModels", "", "Lcom/yuyan/imemodule/speech/AsrModelManager$AsrModelInfo;", "getModelDir", "getModelInfo", "getSelectedModelDir", "getSelectedModelId", "getSelectedModelInfo", "importModelFromArchive", "uri", "Landroid/net/Uri;", "isModelInstalled", "isModelReady", "setModel", "AsrModelInfo", "Companion", "yuyansdk_offlineDebug"})
public final class AsrModelManager {
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context context = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String PREFS_NAME = "asr_model";
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String KEY_SELECTED_MODEL = "selected_model";
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String TOKENS_FILE = "tokens.txt";
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.speech.AsrModelManager.Companion Companion = null;
    
    public AsrModelManager(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.speech.AsrModelManager.AsrModelInfo> getAsrModels() {
        return null;
    }
    
    public final boolean isModelReady() {
        return false;
    }
    
    public final void ensureAssetsModelInstalled(@org.jetbrains.annotations.NotNull()
    java.lang.String modelId) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.speech.AsrModelManager.AsrModelInfo getModelInfo(@org.jetbrains.annotations.NotNull()
    java.lang.String modelId) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.io.File findEncoderFile(@org.jetbrains.annotations.NotNull()
    java.io.File dir) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.io.File findDecoderFile(@org.jetbrains.annotations.NotNull()
    java.io.File dir) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.io.File findJoinerFile(@org.jetbrains.annotations.NotNull()
    java.io.File dir) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.io.File findTokensFile(@org.jetbrains.annotations.NotNull()
    java.io.File dir) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.io.File findFileMatching(@org.jetbrains.annotations.NotNull()
    java.io.File dir, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.io.File, java.lang.Boolean> predicate) {
        return null;
    }
    
    public final void flattenModelDirectory(@org.jetbrains.annotations.NotNull()
    java.io.File targetDir) {
    }
    
    public final boolean isModelInstalled(@org.jetbrains.annotations.NotNull()
    java.lang.String modelId) {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.io.File getModelDir(@org.jetbrains.annotations.NotNull()
    java.lang.String modelId) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.io.File getSelectedModelDir() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getSelectedModelId() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.speech.AsrModelManager.AsrModelInfo getSelectedModelInfo() {
        return null;
    }
    
    public final void setModel(@org.jetbrains.annotations.NotNull()
    java.lang.String modelId) {
    }
    
    public final boolean importModelFromArchive(@org.jetbrains.annotations.NotNull()
    android.net.Uri uri, @org.jetbrains.annotations.NotNull()
    java.lang.String modelId) {
        return false;
    }
    
    private final boolean extractZip(java.io.InputStream inputStream, java.io.File targetDir) {
        return false;
    }
    
    private final boolean extractTarBz2(java.io.InputStream inputStream, java.io.File targetDir) {
        return false;
    }
    
    private final boolean extractTarGz(java.io.InputStream inputStream, java.io.File targetDir) {
        return false;
    }
    
    private final boolean extractTarStream(org.apache.commons.compress.archivers.tar.TarArchiveInputStream tarIn, java.io.File targetDir) {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b \n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001Bw\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\t\u001a\u00020\u0003\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00030\u000b\u0012\b\b\u0002\u0010\f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\r\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0010\u00a2\u0006\u0002\u0010\u0011J\t\u0010!\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\"\u001a\u00020\u0003H\u00c6\u0003J\t\u0010#\u001a\u00020\u0003H\u00c6\u0003J\t\u0010$\u001a\u00020\u0010H\u00c6\u0003J\t\u0010%\u001a\u00020\u0003H\u00c6\u0003J\t\u0010&\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\'\u001a\u00020\u0003H\u00c6\u0003J\t\u0010(\u001a\u00020\u0003H\u00c6\u0003J\t\u0010)\u001a\u00020\u0003H\u00c6\u0003J\t\u0010*\u001a\u00020\u0003H\u00c6\u0003J\u000f\u0010+\u001a\b\u0012\u0004\u0012\u00020\u00030\u000bH\u00c6\u0003J\t\u0010,\u001a\u00020\u0003H\u00c6\u0003J\u0087\u0001\u0010-\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00030\u000b2\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00032\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u0010H\u00c6\u0001J\u0013\u0010.\u001a\u00020\u00102\b\u0010/\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u00100\u001a\u000201H\u00d6\u0001J\t\u00102\u001a\u00020\u0003H\u00d6\u0001R\u0011\u0010\r\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0005\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0013R\u0011\u0010\b\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0013R\u0011\u0010\f\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00030\u000b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013R\u0011\u0010\u000e\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0013R\u0011\u0010\t\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0013R\u0011\u0010\u000f\u001a\u00020\u0010\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0011\u0010\u0007\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u0013\u00a8\u00063"}, d2 = {"Lcom/yuyan/imemodule/speech/AsrModelManager$AsrModelInfo;", "", "id", "", "name", "description", "language", "size", "downloadUrl", "modelType", "files", "", "encoderFile", "decoderFile", "joinerFile", "needsAutoPunctuation", "", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V", "getDecoderFile", "()Ljava/lang/String;", "getDescription", "getDownloadUrl", "getEncoderFile", "getFiles", "()Ljava/util/List;", "getId", "getJoinerFile", "getLanguage", "getModelType", "getName", "getNeedsAutoPunctuation", "()Z", "getSize", "component1", "component10", "component11", "component12", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "", "toString", "yuyansdk_offlineDebug"})
    public static final class AsrModelInfo {
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String id = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String name = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String description = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String language = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String size = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String downloadUrl = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String modelType = null;
        @org.jetbrains.annotations.NotNull()
        private final java.util.List<java.lang.String> files = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String encoderFile = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String decoderFile = null;
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String joinerFile = null;
        private final boolean needsAutoPunctuation = false;
        
        public AsrModelInfo(@org.jetbrains.annotations.NotNull()
        java.lang.String id, @org.jetbrains.annotations.NotNull()
        java.lang.String name, @org.jetbrains.annotations.NotNull()
        java.lang.String description, @org.jetbrains.annotations.NotNull()
        java.lang.String language, @org.jetbrains.annotations.NotNull()
        java.lang.String size, @org.jetbrains.annotations.NotNull()
        java.lang.String downloadUrl, @org.jetbrains.annotations.NotNull()
        java.lang.String modelType, @org.jetbrains.annotations.NotNull()
        java.util.List<java.lang.String> files, @org.jetbrains.annotations.NotNull()
        java.lang.String encoderFile, @org.jetbrains.annotations.NotNull()
        java.lang.String decoderFile, @org.jetbrains.annotations.NotNull()
        java.lang.String joinerFile, boolean needsAutoPunctuation) {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getId() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getName() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getDescription() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getLanguage() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getSize() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getDownloadUrl() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getModelType() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<java.lang.String> getFiles() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getEncoderFile() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getDecoderFile() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String getJoinerFile() {
            return null;
        }
        
        public final boolean getNeedsAutoPunctuation() {
            return false;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component1() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component10() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component11() {
            return null;
        }
        
        public final boolean component12() {
            return false;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component2() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component3() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component4() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component5() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component6() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component7() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<java.lang.String> component8() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String component9() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.speech.AsrModelManager.AsrModelInfo copy(@org.jetbrains.annotations.NotNull()
        java.lang.String id, @org.jetbrains.annotations.NotNull()
        java.lang.String name, @org.jetbrains.annotations.NotNull()
        java.lang.String description, @org.jetbrains.annotations.NotNull()
        java.lang.String language, @org.jetbrains.annotations.NotNull()
        java.lang.String size, @org.jetbrains.annotations.NotNull()
        java.lang.String downloadUrl, @org.jetbrains.annotations.NotNull()
        java.lang.String modelType, @org.jetbrains.annotations.NotNull()
        java.util.List<java.lang.String> files, @org.jetbrains.annotations.NotNull()
        java.lang.String encoderFile, @org.jetbrains.annotations.NotNull()
        java.lang.String decoderFile, @org.jetbrains.annotations.NotNull()
        java.lang.String joinerFile, boolean needsAutoPunctuation) {
            return null;
        }
        
        @java.lang.Override()
        public boolean equals(@org.jetbrains.annotations.Nullable()
        java.lang.Object other) {
            return false;
        }
        
        @java.lang.Override()
        public int hashCode() {
            return 0;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String toString() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\f\u0010\u0007\u001a\u00020\b*\u00020\tH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/imemodule/speech/AsrModelManager$Companion;", "", "()V", "KEY_SELECTED_MODEL", "", "PREFS_NAME", "TOKENS_FILE", "toAsrModelInfo", "Lcom/yuyan/imemodule/speech/AsrModelManager$AsrModelInfo;", "Lcom/yuyan/imemodule/speech/models/AsrModelProfile;", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        private final com.yuyan.imemodule.speech.AsrModelManager.AsrModelInfo toAsrModelInfo(com.yuyan.imemodule.speech.models.AsrModelProfile $this$toAsrModelInfo) {
            return null;
        }
    }
}
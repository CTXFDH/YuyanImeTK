package com.yuyan.imemodule.data.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0002\u00a2\u0006\u0002\u0010\bJ\b\u0010\t\u001a\u00020\u0002H\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J\u0010\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u0002H\u0016\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/data/theme/ManagedThemePreference;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "Lcom/yuyan/imemodule/data/theme/Theme;", "sharedPreferences", "Landroid/content/SharedPreferences;", "key", "", "defaultValue", "(Landroid/content/SharedPreferences;Ljava/lang/String;Lcom/yuyan/imemodule/data/theme/Theme;)V", "getValue", "putValueTo", "", "editor", "Landroid/content/SharedPreferences$Editor;", "setValue", "value", "yuyansdk_offlineDebug"})
public final class ManagedThemePreference extends com.yuyan.imemodule.view.preference.ManagedPreference<com.yuyan.imemodule.data.theme.Theme> {
    
    public ManagedThemePreference(@org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences sharedPreferences, @org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme defaultValue) {
        super(null, null, null);
    }
    
    @java.lang.Override()
    public void setValue(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme value) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.data.theme.Theme getValue() {
        return null;
    }
    
    @java.lang.Override()
    public void putValueTo(@org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences.Editor editor) {
    }
}
package com.yuyan.imemodule.view.preference;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0017\u0018\u00002\u00020\u0001:\u0001&B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0012\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aH\u0016J\u0010\u0010\u001b\u001a\u00020\u00062\u0006\u0010\u001c\u001a\u00020\u0006H\u0002J\u0018\u0010\u001d\u001a\u00020\u001a2\u0006\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u0006H\u0014J\u0012\u0010!\u001a\u00020\"2\b\u0010#\u001a\u0004\u0018\u00010\u001aH\u0014J\u0012\u0010$\u001a\u00020\"2\b\u0010%\u001a\u0004\u0018\u00010\u0011H\u0016R\u0014\u0010\u0005\u001a\u00020\u00068BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\b\"\u0004\b\u000b\u0010\fR\u001a\u0010\r\u001a\u00020\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\b\"\u0004\b\u000f\u0010\fR\u001a\u0010\u0010\u001a\u00020\u0011X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u000e\u0010\u0016\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\'"}, d2 = {"Lcom/yuyan/imemodule/view/preference/EditTextIntPreference;", "Landroidx/preference/EditTextPreference;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "currentValue", "", "getCurrentValue", "()I", "max", "getMax", "setMax", "(I)V", "min", "getMin", "setMin", "unit", "", "getUnit", "()Ljava/lang/String;", "setUnit", "(Ljava/lang/String;)V", "value", "callChangeListener", "", "newValue", "", "fitValue", "v", "onGetDefaultValue", "a", "Landroid/content/res/TypedArray;", "index", "onSetInitialValue", "", "defaultValue", "setText", "text", "SimpleSummaryProvider", "yuyansdk_offlineDebug"})
public class EditTextIntPreference extends androidx.preference.EditTextPreference {
    private int value = 0;
    private int min = -2147483648;
    private int max = 2147483647;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String unit = "";
    
    public EditTextIntPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null, null, 0, 0);
    }
    
    public final int getMin() {
        return 0;
    }
    
    public final void setMin(int p0) {
    }
    
    public final int getMax() {
        return 0;
    }
    
    public final void setMax(int p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getUnit() {
        return null;
    }
    
    public final void setUnit(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    private final int getCurrentValue() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    protected java.lang.Object onGetDefaultValue(@org.jetbrains.annotations.NotNull()
    android.content.res.TypedArray a, int index) {
        return null;
    }
    
    @java.lang.Override()
    protected void onSetInitialValue(@org.jetbrains.annotations.Nullable()
    java.lang.Object defaultValue) {
    }
    
    private final int fitValue(int v) {
        return 0;
    }
    
    @java.lang.Override()
    public void setText(@org.jetbrains.annotations.Nullable()
    java.lang.String text) {
    }
    
    @java.lang.Override()
    public boolean callChangeListener(@org.jetbrains.annotations.Nullable()
    java.lang.Object newValue) {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\r\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0002H\u0016\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/view/preference/EditTextIntPreference$SimpleSummaryProvider;", "Landroidx/preference/Preference$SummaryProvider;", "Lcom/yuyan/imemodule/view/preference/EditTextIntPreference;", "()V", "provideSummary", "", "preference", "yuyansdk_offlineDebug"})
    public static final class SimpleSummaryProvider implements androidx.preference.Preference.SummaryProvider<com.yuyan.imemodule.view.preference.EditTextIntPreference> {
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.view.preference.EditTextIntPreference.SimpleSummaryProvider INSTANCE = null;
        
        private SimpleSummaryProvider() {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.CharSequence provideSummary(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.view.preference.EditTextIntPreference preference) {
            return null;
        }
    }
}
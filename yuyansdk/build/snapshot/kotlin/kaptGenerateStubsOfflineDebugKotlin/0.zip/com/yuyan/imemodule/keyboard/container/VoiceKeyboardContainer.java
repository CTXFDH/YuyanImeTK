package com.yuyan.imemodule.keyboard.container;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0010\u0014\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\b\u0010\'\u001a\u00020(H\u0002J\u0012\u0010)\u001a\u00020\b2\b\u0010*\u001a\u0004\u0018\u00010+H\u0016J\b\u0010,\u001a\u00020(H\u0014J\b\u0010-\u001a\u00020(H\u0014R+\u0010\t\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00020\b8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\b\r\u0010\u000e\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR+\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u000f8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u0004\u00a2\u0006\u0002\n\u0000R+\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u0007\u001a\u00020\u00198B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\b\u001f\u0010\u000e\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR+\u0010!\u001a\u00020 2\u0006\u0010\u0007\u001a\u00020 8B@BX\u0082\u008e\u0002\u00a2\u0006\u0012\n\u0004\b&\u0010\u000e\u001a\u0004\b\"\u0010#\"\u0004\b$\u0010%\u00a8\u0006."}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/VoiceKeyboardContainer;", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "<set-?>", "", "isVoiceActive", "()Z", "setVoiceActive", "(Z)V", "isVoiceActive$delegate", "Landroidx/compose/runtime/MutableState;", "", "voiceAmplitude", "getVoiceAmplitude", "()F", "setVoiceAmplitude", "(F)V", "voiceAmplitude$delegate", "Landroidx/compose/runtime/MutableFloatState;", "voiceHandler", "Lcom/yuyan/imemodule/service/VoiceRecognitionHandler;", "", "voiceSpectrum", "getVoiceSpectrum", "()[F", "setVoiceSpectrum", "([F)V", "voiceSpectrum$delegate", "Lcom/yuyan/imemodule/speech/RecognitionState;", "voiceState", "getVoiceState", "()Lcom/yuyan/imemodule/speech/RecognitionState;", "setVoiceState", "(Lcom/yuyan/imemodule/speech/RecognitionState;)V", "voiceState$delegate", "checkAndStartVoice", "", "dispatchTouchEvent", "ev", "Landroid/view/MotionEvent;", "onAttachedToWindow", "onDetachedFromWindow", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class VoiceKeyboardContainer extends com.yuyan.imemodule.keyboard.container.BaseContainer {
    @org.jetbrains.annotations.NotNull()
    private final androidx.compose.runtime.MutableState voiceState$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.compose.runtime.MutableFloatState voiceAmplitude$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.compose.runtime.MutableState voiceSpectrum$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final androidx.compose.runtime.MutableState isVoiceActive$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.service.VoiceRecognitionHandler voiceHandler = null;
    
    public VoiceKeyboardContainer(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    private final com.yuyan.imemodule.speech.RecognitionState getVoiceState() {
        return null;
    }
    
    private final void setVoiceState(com.yuyan.imemodule.speech.RecognitionState p0) {
    }
    
    private final float getVoiceAmplitude() {
        return 0.0F;
    }
    
    private final void setVoiceAmplitude(float p0) {
    }
    
    private final float[] getVoiceSpectrum() {
        return null;
    }
    
    private final void setVoiceSpectrum(float[] p0) {
    }
    
    private final boolean isVoiceActive() {
        return false;
    }
    
    private final void setVoiceActive(boolean p0) {
    }
    
    private final void checkAndStartVoice() {
    }
    
    @java.lang.Override()
    public boolean dispatchTouchEvent(@org.jetbrains.annotations.Nullable()
    android.view.MotionEvent ev) {
        return false;
    }
    
    @java.lang.Override()
    protected void onAttachedToWindow() {
    }
    
    @java.lang.Override()
    protected void onDetachedFromWindow() {
    }
}
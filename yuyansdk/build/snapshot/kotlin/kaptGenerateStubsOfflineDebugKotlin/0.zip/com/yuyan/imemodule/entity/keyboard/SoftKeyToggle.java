package com.yuyan.imemodule.entity.keyboard;

/**
 * 可以变换状态的按键。See [com.yuyan.imemodule.entity.keyboard.ToggleState] 按键状态
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0010\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0016J\u000e\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u0003J\u0016\u0010\u0019\u001a\u00020\u00142\u000e\u0010\u001a\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eR\u0016\u0010\u0005\u001a\u0004\u0018\u00010\u00068VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\t\u001a\u00020\n8VX\u0096\u0004\u00a2\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u0016\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000f\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0010\u001a\u0004\u0018\u00010\u000f8BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\u0011\u0010\u0012\u00a8\u0006\u001b"}, d2 = {"Lcom/yuyan/imemodule/entity/keyboard/SoftKeyToggle;", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "code", "", "(I)V", "keyIcon", "Landroid/graphics/drawable/Drawable;", "getKeyIcon", "()Landroid/graphics/drawable/Drawable;", "keyLabel", "", "getKeyLabel", "()Ljava/lang/String;", "mToggleStates", "", "Lcom/yuyan/imemodule/entity/keyboard/ToggleState;", "toggleState", "getToggleState", "()Lcom/yuyan/imemodule/entity/keyboard/ToggleState;", "changeCase", "", "upperCase", "", "enableToggleState", "stateId", "setToggleStates", "toggleStates", "yuyansdk_offlineDebug"})
public final class SoftKeyToggle extends com.yuyan.imemodule.entity.keyboard.SoftKey {
    @org.jetbrains.annotations.Nullable()
    private java.util.List<com.yuyan.imemodule.entity.keyboard.ToggleState> mToggleStates;
    
    public SoftKeyToggle(int code) {
        super(0, null, null, null);
    }
    
    public final void setToggleStates(@org.jetbrains.annotations.Nullable()
    java.util.List<com.yuyan.imemodule.entity.keyboard.ToggleState> toggleStates) {
    }
    
    /**
     * 查找该按键是否有stateId的状态，如果有就切换到这个状态。
     * @return 返回状态是否切换.true:状态变化  false：无该状态或状态未变化。
     */
    public final boolean enableToggleState(int stateId) {
        return false;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.Nullable()
    public android.graphics.drawable.Drawable getKeyIcon() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String getKeyLabel() {
        return null;
    }
    
    @java.lang.Override()
    public void changeCase(boolean upperCase) {
    }
    
    private final com.yuyan.imemodule.entity.keyboard.ToggleState getToggleState() {
        return null;
    }
}
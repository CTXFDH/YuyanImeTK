package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J0\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\fH\u0002J0\u0010\r\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\fH\u0007\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/imemodule/utils/AssetUtils;", "", "()V", "copyFile", "", "context", "Landroid/content/Context;", "parentAssetPath", "", "filename", "destParent", "overwrite", "", "copyFileOrDir", "parent", "path", "yuyansdk_offlineDebug"})
public final class AssetUtils {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.AssetUtils INSTANCE = null;
    
    private AssetUtils() {
        super();
    }
    
    @kotlin.jvm.JvmStatic()
    public static final void copyFileOrDir(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    java.lang.String parent, @org.jetbrains.annotations.NotNull()
    java.lang.String path, @org.jetbrains.annotations.NotNull()
    java.lang.String destParent, boolean overwrite) {
    }
    
    private final void copyFile(android.content.Context context, java.lang.String parentAssetPath, java.lang.String filename, java.lang.String destParent, boolean overwrite) {
    }
}
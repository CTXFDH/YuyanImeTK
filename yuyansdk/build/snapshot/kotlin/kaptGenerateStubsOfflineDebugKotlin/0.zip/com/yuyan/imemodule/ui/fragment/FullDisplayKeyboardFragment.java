package com.yuyan.imemodule.ui.fragment;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001:\u0002\u0012\u0013B\u0005\u00a2\u0006\u0002\u0010\u0002J$\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0016J\b\u0010\u0010\u001a\u00020\u0011H\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0014"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/FullDisplayKeyboardFragment;", "Landroidx/fragment/app/Fragment;", "()V", "advancedContainer", "Lcom/yuyan/imemodule/ui/fragment/FullDisplayKeyboardFragment$Container;", "items", "Landroid/widget/LinearLayout;", "normalContainer", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onStop", "", "Container", "Item", "yuyansdk_offlineDebug"})
public final class FullDisplayKeyboardFragment extends androidx.fragment.app.Fragment {
    private com.yuyan.imemodule.ui.fragment.FullDisplayKeyboardFragment.Container advancedContainer;
    private com.yuyan.imemodule.ui.fragment.FullDisplayKeyboardFragment.Container normalContainer;
    private android.widget.LinearLayout items;
    
    public FullDisplayKeyboardFragment() {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.view.View onCreateView(@org.jetbrains.annotations.NotNull()
    android.view.LayoutInflater inflater, @org.jetbrains.annotations.Nullable()
    android.view.ViewGroup container, @org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState) {
        return null;
    }
    
    @java.lang.Override()
    public void onStop() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u001c\u0010\t\u001a\u0004\u0018\u00010\nX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u0011\u0010\u000f\u001a\u00020\u0010\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012\u00a8\u0006\u0017"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/FullDisplayKeyboardFragment$Container;", "Landroid/widget/LinearLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "icon", "Landroid/widget/ImageView;", "getIcon", "()Landroid/widget/ImageView;", "mOnClickListener", "Landroid/view/View$OnClickListener;", "getMOnClickListener", "()Landroid/view/View$OnClickListener;", "setMOnClickListener", "(Landroid/view/View$OnClickListener;)V", "tip", "Landroid/widget/TextView;", "getTip", "()Landroid/widget/TextView;", "updateView", "", "isSelect", "", "yuyansdk_offlineDebug"})
    public static final class Container extends android.widget.LinearLayout {
        @org.jetbrains.annotations.NotNull()
        private final android.widget.TextView tip = null;
        @org.jetbrains.annotations.NotNull()
        private final android.widget.ImageView icon = null;
        @org.jetbrains.annotations.Nullable()
        private android.view.View.OnClickListener mOnClickListener;
        
        public Container(@org.jetbrains.annotations.Nullable()
        android.content.Context context) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.TextView getTip() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.ImageView getIcon() {
            return null;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.view.View.OnClickListener getMOnClickListener() {
            return null;
        }
        
        public final void setMOnClickListener(@org.jetbrains.annotations.Nullable()
        android.view.View.OnClickListener p0) {
        }
        
        public final void updateView(boolean isSelect) {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u001f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0007R\u001c\u0010\b\u001a\u0004\u0018\u00010\tX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011\u00a8\u0006\u0012"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/FullDisplayKeyboardFragment$Item;", "Landroid/widget/LinearLayout;", "context", "Landroid/content/Context;", "keyModId", "", "select", "(Landroid/content/Context;II)V", "onItemSelected", "Lcom/yuyan/imemodule/callback/OnItemSelectedListener;", "getOnItemSelected", "()Lcom/yuyan/imemodule/callback/OnItemSelectedListener;", "setOnItemSelected", "(Lcom/yuyan/imemodule/callback/OnItemSelectedListener;)V", "title", "Landroid/widget/TextView;", "getTitle", "()Landroid/widget/TextView;", "yuyansdk_offlineDebug"})
    @android.annotation.SuppressLint(value = {"ViewConstructor"})
    public static final class Item extends android.widget.LinearLayout {
        @org.jetbrains.annotations.NotNull()
        private final android.widget.TextView title = null;
        @org.jetbrains.annotations.Nullable()
        private com.yuyan.imemodule.callback.OnItemSelectedListener onItemSelected;
        
        public Item(@org.jetbrains.annotations.Nullable()
        android.content.Context context, int keyModId, int select) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.widget.TextView getTitle() {
            return null;
        }
        
        @org.jetbrains.annotations.Nullable()
        public final com.yuyan.imemodule.callback.OnItemSelectedListener getOnItemSelected() {
            return null;
        }
        
        public final void setOnItemSelected(@org.jetbrains.annotations.Nullable()
        com.yuyan.imemodule.callback.OnItemSelectedListener p0) {
        }
    }
}
package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000<\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a#\u0010\u0007\u001a\n \u0002*\u0004\u0018\u00010\b0\b\"\b\b\u0000\u0010\t*\u00020\n*\u0002H\tH\u0002\u00a2\u0006\u0002\u0010\u000b\u001a\u0012\u0010\f\u001a\u00020\r*\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010\u001a\u0019\u0010\u0011\u001a\u00020\r\"\b\b\u0000\u0010\t*\u00020\u0012*\u0002H\t\u00a2\u0006\u0002\u0010\u0013\u001a\u0019\u0010\u0011\u001a\u00020\r\"\b\b\u0000\u0010\t*\u00020\u0014*\u0002H\t\u00a2\u0006\u0002\u0010\u0015\u001a\u0019\u0010\u0011\u001a\u00020\r\"\b\b\u0000\u0010\t*\u00020\u0016*\u0002H\t\u00a2\u0006\u0002\u0010\u0017\"#\u0010\u0000\u001a\n \u0002*\u0004\u0018\u00010\u00010\u00018BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0005\u0010\u0006\u001a\u0004\b\u0003\u0010\u0004\u00a8\u0006\u0018"}, d2 = {"mDefault", "Ljava/lang/reflect/Field;", "kotlin.jvm.PlatformType", "getMDefault", "()Ljava/lang/reflect/Field;", "mDefault$delegate", "Lkotlin/Lazy;", "def", "", "T", "Landroidx/preference/Preference;", "(Landroidx/preference/Preference;)Ljava/lang/Object;", "fixDialogMargin", "", "Landroidx/preference/PreferenceDialogFragmentCompat;", "contentView", "Landroid/view/View;", "restore", "Landroidx/preference/EditTextPreference;", "(Landroidx/preference/EditTextPreference;)V", "Landroidx/preference/ListPreference;", "(Landroidx/preference/ListPreference;)V", "Landroidx/preference/SwitchPreference;", "(Landroidx/preference/SwitchPreference;)V", "yuyansdk_offlineDebug"})
public final class FunctionsKt {
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.Lazy mDefault$delegate = null;
    
    private static final java.lang.reflect.Field getMDefault() {
        return null;
    }
    
    private static final <T extends androidx.preference.Preference>java.lang.Object def(T $this$def) {
        return null;
    }
    
    public static final <T extends androidx.preference.EditTextPreference>void restore(@org.jetbrains.annotations.NotNull()
    T $this$restore) {
    }
    
    public static final <T extends androidx.preference.ListPreference>void restore(@org.jetbrains.annotations.NotNull()
    T $this$restore) {
    }
    
    public static final <T extends androidx.preference.SwitchPreference>void restore(@org.jetbrains.annotations.NotNull()
    T $this$restore) {
    }
    
    public static final void fixDialogMargin(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceDialogFragmentCompat $this$fixDialogMargin, @org.jetbrains.annotations.NotNull()
    android.view.View contentView) {
    }
}
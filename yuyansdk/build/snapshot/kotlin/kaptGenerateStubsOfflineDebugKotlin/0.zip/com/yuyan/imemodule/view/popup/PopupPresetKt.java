package com.yuyan.imemodule.view.popup;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010\u0011\n\u0002\b\u0005\"#\u0010\u0000\u001a\u0014\u0012\u0004\u0012\u00020\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005\"#\u0010\u0006\u001a\u0014\u0012\u0004\u0012\u00020\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00020\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\u0005\u00a8\u0006\b"}, d2 = {"PopupPreset", "", "", "", "getPopupPreset", "()Ljava/util/Map;", "PopupSmallPreset", "getPopupSmallPreset", "yuyansdk_offlineDebug"})
public final class PopupPresetKt {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.String, java.lang.String[]> PopupPreset = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.String, java.lang.String[]> PopupSmallPreset = null;
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.String, java.lang.String[]> getPopupPreset() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.String, java.lang.String[]> getPopupSmallPreset() {
        return null;
    }
}
package com.yuyan.imemodule.libs.expression.tokenizer;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\f\b\u0000\u0018\u0000 \u00112\u00060\u0001j\u0002`\u0002:\u0001\u0011B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\bR\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0014\u0010\u000b\u001a\u00020\u0004X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u000f\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\n\u00a8\u0006\u0012"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/UnknownFunctionOrVariableException;", "Ljava/lang/IllegalArgumentException;", "Lkotlin/IllegalArgumentException;", "expression", "", "position", "", "length", "(Ljava/lang/String;II)V", "getExpression", "()Ljava/lang/String;", "message", "getMessage", "getPosition", "()I", "token", "getToken", "Companion", "yuyansdk_offlineDebug"})
public final class UnknownFunctionOrVariableException extends java.lang.IllegalArgumentException {
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String expression = null;
    private final int position = 0;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String message = null;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String token = null;
    
    /**
     * Serial version UID.
     */
    private static final long serialVersionUID = 1L;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.expression.tokenizer.UnknownFunctionOrVariableException.Companion Companion = null;
    
    public UnknownFunctionOrVariableException(@org.jetbrains.annotations.NotNull()
    java.lang.String expression, int position, int length) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getExpression() {
        return null;
    }
    
    public final int getPosition() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String getMessage() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getToken() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J \u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\tH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/UnknownFunctionOrVariableException$Companion;", "", "()V", "serialVersionUID", "", "token", "", "expression", "position", "", "length", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        private final java.lang.String token(java.lang.String expression, int position, int length) {
            return null;
        }
    }
}
package com.yuyan.imemodule.libs.cropper;

/**
 * Handler to update crop window edges by the move type - Horizontal, Vertical, Corner or Center.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u001f\b\u0000\u0018\u0000 82\u00020\u0001:\u000289B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\tJH\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001bH\u0002J\u0018\u0010\u001d\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0007H\u0002J@\u0010\u001e\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001f\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u001b2\u0006\u0010!\u001a\u00020\u001bH\u0002J\u0018\u0010\"\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0007H\u0002J \u0010#\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0007H\u0002JH\u0010$\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010%\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010&\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010 \u001a\u00020\u001b2\u0006\u0010!\u001a\u00020\u001bH\u0002J\u0018\u0010\'\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0007H\u0002J@\u0010(\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010)\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u001bH\u0002J \u0010*\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0007H\u0002J\u0018\u0010+\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u0007H\u0002J \u0010,\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0002JN\u0010-\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010.\u001a\u00020\u00072\u0006\u0010/\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010&\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00072\u0006\u00100\u001a\u00020\u001b2\u0006\u0010\u0019\u001a\u00020\u0007J@\u00101\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010.\u001a\u00020\u00072\u0006\u0010/\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010&\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u00102\u001a\u00020\u0007H\u0002JH\u00103\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010.\u001a\u00020\u00072\u0006\u0010/\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010&\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u0007H\u0002J@\u00104\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010.\u001a\u00020\u00072\u0006\u0010/\u001a\u00020\u00072\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u0010&\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0007H\u0002J \u00105\u001a\u00020\u00112\u0006\u00106\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u00132\u0006\u00107\u001a\u00020\u0007H\u0002R\u000e\u0010\n\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006:"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropWindowMoveHandler;", "", "type", "Lcom/yuyan/imemodule/libs/cropper/CropWindowMoveHandler$Type;", "cropWindowHandler", "Lcom/yuyan/imemodule/libs/cropper/CropWindowHandler;", "touchX", "", "touchY", "(Lcom/yuyan/imemodule/libs/cropper/CropWindowMoveHandler$Type;Lcom/yuyan/imemodule/libs/cropper/CropWindowHandler;FF)V", "mMaxCropHeight", "mMaxCropWidth", "mMinCropHeight", "mMinCropWidth", "mTouchOffset", "Landroid/graphics/PointF;", "adjustBottom", "", "rect", "Landroid/graphics/RectF;", "bottom", "bounds", "viewHeight", "", "snapMargin", "aspectRatio", "leftMoves", "", "rightMoves", "adjustBottomByAspectRatio", "adjustLeft", "left", "topMoves", "bottomMoves", "adjustLeftByAspectRatio", "adjustLeftRightByAspectRatio", "adjustRight", "right", "viewWidth", "adjustRightByAspectRatio", "adjustTop", "top", "adjustTopBottomByAspectRatio", "adjustTopByAspectRatio", "calculateTouchOffset", "move", "x", "y", "fixedAspectRatio", "moveCenter", "snapRadius", "moveSizeWithFixedAspectRatio", "moveSizeWithFreeAspectRatio", "snapEdgesToBounds", "edges", "margin", "Companion", "Type", "yuyansdk_offlineDebug"})
public final class CropWindowMoveHandler {
    
    /**
     * The type of move this handler is executing
     */
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler.Type type = null;
    
    /**
     * Minimum width in pixels that the crop window can get.
     */
    private final float mMinCropWidth = 0.0F;
    
    /**
     * Minimum width in pixels that the crop window can get.
     */
    private final float mMinCropHeight = 0.0F;
    
    /**
     * Maximum height in pixels that the crop window can get.
     */
    private final float mMaxCropWidth = 0.0F;
    
    /**
     * Maximum height in pixels that the crop window can get.
     */
    private final float mMaxCropHeight = 0.0F;
    
    /**
     * Holds the x and y offset between the exact touch location and the exact handle location that is
     * activated. There may be an offset because we allow for some leeway (specified by mHandleRadius)
     * in activating a handle. However, we want to maintain these offset values while the handle is
     * being dragged so that the handle doesn't jump.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.PointF mTouchOffset = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler.Companion Companion = null;
    
    public CropWindowMoveHandler(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler.Type type, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropWindowHandler cropWindowHandler, float touchX, float touchY) {
        super();
    }
    
    /**
     * Updates the crop window by change in the touch location.<br></br>
     * Move type handled by this instance, as initialized in creation, affects how the change in touch
     * location changes the crop window position and size.<br></br>
     * After the crop window position/size is changed by touch move it may result in values that
     * violate constraints: outside the bounds of the shown bitmap, smaller/larger than min/max size or
     * mismatch in aspect ratio. So a series of fixes is executed on "secondary" edges to adjust it
     * by the "primary" edge movement.<br></br>
     * Primary is the edge directly affected by move type, secondary is the other edge.<br></br>
     * The crop window is changed by directly setting the Edge coordinates.
     *
     * [x] the new x-coordinate of this handle
     * [y] the new y-coordinate of this handle
     * [bounds] the bounding rectangle of the image
     * [viewWidth] The bounding image view width used to know the crop overlay is at view edges.
     * [viewHeight] The bounding image view height used to know the crop overlay is at view edges.
     * [snapMargin] the maximum distance (in pixels) at which the crop window should snap to the image
     * [fixedAspectRatio] is the aspect ratio fixed and 'targetAspectRatio' should be used
     * [aspectRatio] the aspect ratio to maintain
     */
    public final void move(@org.jetbrains.annotations.NotNull()
    android.graphics.RectF rect, float x, float y, @org.jetbrains.annotations.NotNull()
    android.graphics.RectF bounds, int viewWidth, int viewHeight, float snapMargin, boolean fixedAspectRatio, float aspectRatio) {
    }
    
    /**
     * Calculates the offset of the touch point from the precise location of the specified handle.<br></br>
     * Save these values in a member variable since we want to maintain this offset as we drag the
     * handle.
     */
    private final void calculateTouchOffset(android.graphics.RectF rect, float touchX, float touchY) {
    }
    
    /**
     * Center move only changes the position of the crop window without changing the size.
     */
    private final void moveCenter(android.graphics.RectF rect, float x, float y, android.graphics.RectF bounds, int viewWidth, int viewHeight, float snapRadius) {
    }
    
    /**
     * Change the size of the crop window on the required edge (or edges for corner size move) without
     * affecting "secondary" edges.<br></br>
     * Only the primary edge(s) are fixed to stay within limits.
     */
    private final void moveSizeWithFreeAspectRatio(android.graphics.RectF rect, float x, float y, android.graphics.RectF bounds, int viewWidth, int viewHeight, float snapMargin) {
    }
    
    /**
     * Change the size of the crop window on the required "primary" edge WITH affect to relevant
     * "secondary" edge via aspect ratio.<br></br>
     * Example: change in the left edge (primary) will affect top and bottom edges (secondary) to
     * preserve the given aspect ratio.
     */
    private final void moveSizeWithFixedAspectRatio(android.graphics.RectF rect, float x, float y, android.graphics.RectF bounds, int viewWidth, int viewHeight, float snapMargin, float aspectRatio) {
    }
    
    /**
     * Check if edges have gone out of bounds (including snap margin), and fix if needed.
     */
    private final void snapEdgesToBounds(android.graphics.RectF edges, android.graphics.RectF bounds, float margin) {
    }
    
    /**
     * Get the resulting x-position of the left edge of the crop window given the handle's position
     * and the image's bounding box and snap radius.
     *
     * [left] the position that the left edge is dragged to
     * [bounds] the bounding box of the image that is being cropped
     * [snapMargin] the snap distance to the image edge (in pixels)
     */
    private final void adjustLeft(android.graphics.RectF rect, float left, android.graphics.RectF bounds, float snapMargin, float aspectRatio, boolean topMoves, boolean bottomMoves) {
    }
    
    /**
     * Get the resulting x-position of the right edge of the crop window given the handle's position
     * and the image's bounding box and snap radius.
     *
     * [right] the position that the right edge is dragged to
     * [bounds] the bounding box of the image that is being cropped
     * [viewWidth]
     * [snapMargin] the snap distance to the image edge (in pixels)
     */
    private final void adjustRight(android.graphics.RectF rect, float right, android.graphics.RectF bounds, int viewWidth, float snapMargin, float aspectRatio, boolean topMoves, boolean bottomMoves) {
    }
    
    /**
     * Get the resulting y-position of the top edge of the crop window given the handle's position and
     * the image's bounding box and snap radius.
     *
     * [top] the x-position that the top edge is dragged to
     * [bounds] the bounding box of the image that is being cropped
     * [snapMargin] the snap distance to the image edge (in pixels)
     */
    private final void adjustTop(android.graphics.RectF rect, float top, android.graphics.RectF bounds, float snapMargin, float aspectRatio, boolean leftMoves, boolean rightMoves) {
    }
    
    /**
     * Get the resulting y-position of the bottom edge of the crop window given the handle's position
     * and the image's bounding box and snap radius.
     *
     * [bottom] the position that the bottom edge is dragged to
     * [bounds] the bounding box of the image that is being cropped
     * [viewHeight]
     * [snapMargin] the snap distance to the image edge (in pixels)
     */
    private final void adjustBottom(android.graphics.RectF rect, float bottom, android.graphics.RectF bounds, int viewHeight, float snapMargin, float aspectRatio, boolean leftMoves, boolean rightMoves) {
    }
    
    /**
     * Adjust left edge by current crop window height and the given aspect ratio, the right edge
     * remains in position while the left adjusts to keep aspect ratio to the height.
     */
    private final void adjustLeftByAspectRatio(android.graphics.RectF rect, float aspectRatio) {
    }
    
    /**
     * Adjust top edge by current crop window width and the given aspect ratio, the bottom edge
     * remains in position while the top adjusts to keep aspect ratio to the width.
     */
    private final void adjustTopByAspectRatio(android.graphics.RectF rect, float aspectRatio) {
    }
    
    /**
     * Adjust right edge by current crop window height and the given aspect ratio, the left edge
     * remains in position while the left adjusts to keep aspect ratio to the height.
     */
    private final void adjustRightByAspectRatio(android.graphics.RectF rect, float aspectRatio) {
    }
    
    /**
     * Adjust bottom edge by current crop window width and the given aspect ratio, the top edge
     * remains in position while the top adjusts to keep aspect ratio to the width.
     */
    private final void adjustBottomByAspectRatio(android.graphics.RectF rect, float aspectRatio) {
    }
    
    /**
     * Adjust left and right edges by current crop window height and the given aspect ratio, both
     * right and left edges adjusts equally relative to center to keep aspect ratio to the height.
     */
    private final void adjustLeftRightByAspectRatio(android.graphics.RectF rect, android.graphics.RectF bounds, float aspectRatio) {
    }
    
    /**
     * Adjust top and bottom edges by current crop window width and the given aspect ratio, both top
     * and bottom edges adjusts equally relative to center to keep aspect ratio to the width.
     */
    private final void adjustTopBottomByAspectRatio(android.graphics.RectF rect, android.graphics.RectF bounds, float aspectRatio) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\u0006\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J-\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u0004H\u0000\u00a2\u0006\u0002\b\t\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropWindowMoveHandler$Companion;", "", "()V", "calculateAspectRatio", "", "left", "top", "right", "bottom", "calculateAspectRatio$yuyansdk_offlineDebug", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        /**
         * Calculates the aspect ratio given a rectangle.
         */
        public final float calculateAspectRatio$yuyansdk_offlineDebug(float left, float top, float right, float bottom) {
            return 0.0F;
        }
    }
    
    /**
     * The type of crop window move that is handled.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u000b\b\u0080\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b\u00a8\u0006\f"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropWindowMoveHandler$Type;", "", "(Ljava/lang/String;I)V", "TOP_LEFT", "TOP_RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT", "LEFT", "TOP", "RIGHT", "BOTTOM", "CENTER", "yuyansdk_offlineDebug"})
    public static enum Type {
        /*public static final*/ TOP_LEFT /* = new TOP_LEFT() */,
        /*public static final*/ TOP_RIGHT /* = new TOP_RIGHT() */,
        /*public static final*/ BOTTOM_LEFT /* = new BOTTOM_LEFT() */,
        /*public static final*/ BOTTOM_RIGHT /* = new BOTTOM_RIGHT() */,
        /*public static final*/ LEFT /* = new LEFT() */,
        /*public static final*/ TOP /* = new TOP() */,
        /*public static final*/ RIGHT /* = new RIGHT() */,
        /*public static final*/ BOTTOM /* = new BOTTOM() */,
        /*public static final*/ CENTER /* = new CENTER() */;
        
        Type() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler.Type> getEntries() {
            return null;
        }
    }
}
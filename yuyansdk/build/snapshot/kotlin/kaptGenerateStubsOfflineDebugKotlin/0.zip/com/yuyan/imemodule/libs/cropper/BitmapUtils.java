package com.yuyan.imemodule.libs.cropper;

/**
 * Utility class that deals with operations with an ImageView.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u009a\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0007\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\f\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\b\u00c0\u0002\u0018\u00002\u00020\u0001:\u0002ghB\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0018\u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020&2\u0006\u0010\'\u001a\u00020(H\u0002J\u0018\u0010)\u001a\u00020\f2\u0006\u0010*\u001a\u00020\f2\u0006\u0010+\u001a\u00020\fH\u0002J(\u0010,\u001a\u00020\f2\u0006\u0010*\u001a\u00020\f2\u0006\u0010+\u001a\u00020\f2\u0006\u0010-\u001a\u00020\f2\u0006\u0010.\u001a\u00020\fH\u0002Jp\u0010/\u001a\u0002002\u0006\u0010%\u001a\u00020&2\u0006\u00101\u001a\u00020$2\u0006\u00102\u001a\u00020\u000e2\u0006\u00103\u001a\u00020\f2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\f2\u0006\u00107\u001a\u00020\f2\u0006\u00108\u001a\u00020\f2\u0006\u00109\u001a\u00020\u00042\u0006\u0010*\u001a\u00020\f2\u0006\u0010+\u001a\u00020\f2\u0006\u0010:\u001a\u0002052\u0006\u0010;\u001a\u000205H\u0002Jx\u0010/\u001a\u0002002\u0006\u0010%\u001a\u00020&2\u0006\u00101\u001a\u00020$2\u0006\u00102\u001a\u00020\u000e2\u0006\u00103\u001a\u00020\f2\u0006\u0010<\u001a\u00020\f2\u0006\u0010=\u001a\u00020\f2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\f2\u0006\u00107\u001a\u00020\f2\u0006\u0010-\u001a\u00020\f2\u0006\u0010.\u001a\u00020\f2\u0006\u0010:\u001a\u0002052\u0006\u0010;\u001a\u0002052\u0006\u00108\u001a\u00020\fH\u0002Jp\u0010/\u001a\u0002002\u0006\u0010%\u001a\u00020&2\b\u00101\u001a\u0004\u0018\u00010$2\u0006\u00102\u001a\u00020\u000e2\u0006\u00103\u001a\u00020\f2\u0006\u0010<\u001a\u00020\f2\u0006\u0010=\u001a\u00020\f2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\f2\u0006\u00107\u001a\u00020\f2\u0006\u0010-\u001a\u00020\f2\u0006\u0010.\u001a\u00020\f2\u0006\u0010:\u001a\u0002052\u0006\u0010;\u001a\u000205JH\u0010>\u001a\u0002002\b\u0010?\u001a\u0004\u0018\u00010\u001b2\u0006\u00102\u001a\u00020\u000e2\u0006\u00103\u001a\u00020\f2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\f2\u0006\u00107\u001a\u00020\f2\u0006\u0010:\u001a\u0002052\u0006\u0010;\u001a\u000205JP\u0010@\u001a\u00020\u001b2\u0006\u0010?\u001a\u00020\u001b2\u0006\u00102\u001a\u00020\u000e2\u0006\u00103\u001a\u00020\f2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\f2\u0006\u00107\u001a\u00020\f2\u0006\u0010A\u001a\u00020B2\u0006\u0010:\u001a\u0002052\u0006\u0010;\u001a\u000205H\u0002J@\u0010C\u001a\u00020\u001b2\u0006\u0010?\u001a\u00020\u001b2\u0006\u00102\u001a\u00020\u000e2\u0006\u00109\u001a\u00020\u00042\u0006\u00103\u001a\u00020\f2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\f2\u0006\u00107\u001a\u00020\fH\u0002J\"\u0010D\u001a\u0004\u0018\u00010\u001b2\u0006\u0010E\u001a\u00020F2\u0006\u0010G\u001a\u00020$2\u0006\u0010H\u001a\u00020IH\u0002J\u0018\u0010J\u001a\u00020I2\u0006\u0010E\u001a\u00020F2\u0006\u0010G\u001a\u00020$H\u0002J&\u0010K\u001a\u0002002\u0006\u0010%\u001a\u00020&2\u0006\u0010G\u001a\u00020$2\u0006\u0010-\u001a\u00020\f2\u0006\u0010.\u001a\u00020\fJ8\u0010L\u001a\u0002002\u0006\u0010%\u001a\u00020&2\u0006\u0010G\u001a\u00020$2\u0006\u00109\u001a\u00020\u00042\u0006\u0010-\u001a\u00020\f2\u0006\u0010.\u001a\u00020\f2\u0006\u00108\u001a\u00020\fH\u0002J \u0010M\u001a\u00020N2\u0006\u00109\u001a\u00020\u00042\u0006\u00106\u001a\u00020\f2\u0006\u00107\u001a\u00020\fH\u0002J\u000e\u0010O\u001a\u00020B2\u0006\u0010P\u001a\u00020\u000eJ\u000e\u0010Q\u001a\u00020B2\u0006\u0010P\u001a\u00020\u000eJ\u000e\u0010R\u001a\u00020B2\u0006\u0010P\u001a\u00020\u000eJ6\u0010S\u001a\u00020\u00042\u0006\u00102\u001a\u00020\u000e2\u0006\u0010T\u001a\u00020\f2\u0006\u0010U\u001a\u00020\f2\u0006\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\f2\u0006\u00107\u001a\u00020\fJ\u000e\u0010V\u001a\u00020B2\u0006\u0010P\u001a\u00020\u000eJ\u000e\u0010W\u001a\u00020B2\u0006\u0010P\u001a\u00020\u000eJ\u000e\u0010X\u001a\u00020B2\u0006\u0010P\u001a\u00020\u000eJ\u000e\u0010Y\u001a\u00020B2\u0006\u0010P\u001a\u00020\u000eJ\u000e\u0010Z\u001a\u00020B2\u0006\u0010P\u001a\u00020\u000eJ \u0010[\u001a\u00020\\2\b\u0010?\u001a\u0004\u0018\u00010\u001b2\u0006\u0010%\u001a\u00020&2\u0006\u0010G\u001a\u00020$J\u0018\u0010[\u001a\u00020\\2\b\u0010?\u001a\u0004\u0018\u00010\u001b2\u0006\u0010]\u001a\u00020^J(\u0010_\u001a\u00020\u001b2\b\u0010?\u001a\u0004\u0018\u00010\u001b2\u0006\u0010-\u001a\u00020\f2\u0006\u0010.\u001a\u00020\f2\u0006\u0010H\u001a\u00020`J(\u0010a\u001a\u00020\u001b2\u0006\u0010?\u001a\u00020\u001b2\u0006\u0010b\u001a\u00020\f2\u0006\u0010:\u001a\u0002052\u0006\u0010;\u001a\u000205H\u0002J0\u0010c\u001a\u00020$2\u0006\u0010%\u001a\u00020&2\u0006\u0010?\u001a\u00020\u001b2\u0006\u0010\'\u001a\u00020(2\u0006\u0010d\u001a\u00020\f2\b\u0010e\u001a\u0004\u0018\u00010$J$\u0010f\u001a\u0004\u0018\u00010$2\u0006\u0010%\u001a\u00020&2\b\u0010?\u001a\u0004\u0018\u00010\u001b2\b\u0010e\u001a\u0004\u0018\u00010$R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u0011\u0010\u0007\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u000e\u0010\u000b\u001a\u00020\fX\u0082T\u00a2\u0006\u0002\n\u0000R\u0011\u0010\r\u001a\u00020\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0011\u001a\u00020\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0010R\u0011\u0010\u0013\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\nR\u000e\u0010\u0015\u001a\u00020\u0016X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R.\u0010\u0018\u001a\u0016\u0012\u0004\u0012\u00020\u0016\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001b0\u001a\u0018\u00010\u0019X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u001d\"\u0004\b\u001e\u0010\u001fR\u0014\u0010 \u001a\u00020\f8BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b!\u0010\"\u00a8\u0006i"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/BitmapUtils;", "", "()V", "EMPTY_RECT", "Landroid/graphics/Rect;", "getEMPTY_RECT", "()Landroid/graphics/Rect;", "EMPTY_RECT_F", "Landroid/graphics/RectF;", "getEMPTY_RECT_F", "()Landroid/graphics/RectF;", "IMAGE_MAX_BITMAP_DIMENSION", "", "POINTS", "", "getPOINTS", "()[F", "POINTS2", "getPOINTS2", "RECT", "getRECT", "WRITE_AND_TRUNCATE", "", "mMaxTextureSize", "mStateBitmap", "Landroid/util/Pair;", "Ljava/lang/ref/WeakReference;", "Landroid/graphics/Bitmap;", "getMStateBitmap", "()Landroid/util/Pair;", "setMStateBitmap", "(Landroid/util/Pair;)V", "maxTextureSize", "getMaxTextureSize", "()I", "buildUri", "Landroid/net/Uri;", "context", "Landroid/content/Context;", "compressFormat", "Landroid/graphics/Bitmap$CompressFormat;", "calculateInSampleSizeByMaxTextureSize", "width", "height", "calculateInSampleSizeByRequestedSize", "reqWidth", "reqHeight", "cropBitmap", "Lcom/yuyan/imemodule/libs/cropper/BitmapUtils$BitmapSampled;", "loadedImageUri", "cropPoints", "degreesRotated", "fixAspectRatio", "", "aspectRatioX", "aspectRatioY", "sampleMulti", "rect", "flipHorizontally", "flipVertically", "orgWidth", "orgHeight", "cropBitmapObjectHandleOOM", "bitmap", "cropBitmapObjectWithScale", "scale", "", "cropForRotatedImage", "decodeImage", "resolver", "Landroid/content/ContentResolver;", "uri", "options", "Landroid/graphics/BitmapFactory$Options;", "decodeImageForOption", "decodeSampledBitmap", "decodeSampledBitmapRegion", "fixRectForAspectRatio", "", "getRectBottom", "points", "getRectCenterX", "getRectCenterY", "getRectFromPoints", "imageWidth", "imageHeight", "getRectHeight", "getRectLeft", "getRectRight", "getRectTop", "getRectWidth", "orientateBitmapByExif", "Lcom/yuyan/imemodule/libs/cropper/BitmapUtils$RotateBitmapResult;", "exif", "Landroidx/exifinterface/media/ExifInterface;", "resizeBitmap", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$RequestSizeOptions;", "rotateAndFlipBitmapInt", "degrees", "writeBitmapToUri", "compressQuality", "customOutputUri", "writeTempStateStoreBitmap", "BitmapSampled", "RotateBitmapResult", "yuyansdk_offlineDebug"})
public final class BitmapUtils {
    @org.jetbrains.annotations.NotNull()
    private static final android.graphics.Rect EMPTY_RECT = null;
    @org.jetbrains.annotations.NotNull()
    private static final android.graphics.RectF EMPTY_RECT_F = null;
    private static final int IMAGE_MAX_BITMAP_DIMENSION = 2048;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String WRITE_AND_TRUNCATE = "wt";
    
    /**
     * Reusable rectangle for general internal usage
     */
    @org.jetbrains.annotations.NotNull()
    private static final android.graphics.RectF RECT = null;
    
    /**
     * Reusable point for general internal usage
     */
    @org.jetbrains.annotations.NotNull()
    private static final float[] POINTS = null;
    
    /**
     * Reusable point for general internal usage
     */
    @org.jetbrains.annotations.NotNull()
    private static final float[] POINTS2 = null;
    
    /**
     * Used to know the max texture size allowed to be rendered
     */
    private static int mMaxTextureSize = 0;
    
    /**
     * used to save bitmaps during state save and restore so not to reload them.
     */
    @org.jetbrains.annotations.Nullable()
    private static android.util.Pair<java.lang.String, java.lang.ref.WeakReference<android.graphics.Bitmap>> mStateBitmap;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.cropper.BitmapUtils INSTANCE = null;
    
    private BitmapUtils() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.Rect getEMPTY_RECT() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.RectF getEMPTY_RECT_F() {
        return null;
    }
    
    /**
     * Reusable rectangle for general internal usage
     */
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.RectF getRECT() {
        return null;
    }
    
    /**
     * Reusable point for general internal usage
     */
    @org.jetbrains.annotations.NotNull()
    public final float[] getPOINTS() {
        return null;
    }
    
    /**
     * Reusable point for general internal usage
     */
    @org.jetbrains.annotations.NotNull()
    public final float[] getPOINTS2() {
        return null;
    }
    
    /**
     * used to save bitmaps during state save and restore so not to reload them.
     */
    @org.jetbrains.annotations.Nullable()
    public final android.util.Pair<java.lang.String, java.lang.ref.WeakReference<android.graphics.Bitmap>> getMStateBitmap() {
        return null;
    }
    
    /**
     * used to save bitmaps during state save and restore so not to reload them.
     */
    public final void setMStateBitmap(@org.jetbrains.annotations.Nullable()
    android.util.Pair<java.lang.String, java.lang.ref.WeakReference<android.graphics.Bitmap>> p0) {
    }
    
    /**
     * Rotate the given image by reading the Exif value of the image (uri).<br></br>
     * If no rotation is required the image will not be rotated.<br></br>
     * New bitmap is created and the old one is recycled.
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.BitmapUtils.RotateBitmapResult orientateBitmapByExif(@org.jetbrains.annotations.Nullable()
    android.graphics.Bitmap bitmap, @org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    android.net.Uri uri) {
        return null;
    }
    
    /**
     * Rotate the given image by given Exif value.<br></br>
     * If no rotation is required the image will not be rotated.<br></br>
     * New bitmap is created and the old one is recycled.
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.BitmapUtils.RotateBitmapResult orientateBitmapByExif(@org.jetbrains.annotations.Nullable()
    android.graphics.Bitmap bitmap, @org.jetbrains.annotations.NotNull()
    androidx.exifinterface.media.ExifInterface exif) {
        return null;
    }
    
    /**
     * Decode bitmap from stream using sampling to get bitmap with the requested limit.
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.BitmapUtils.BitmapSampled decodeSampledBitmap(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    android.net.Uri uri, int reqWidth, int reqHeight) {
        return null;
    }
    
    /**
     * Crop image bitmap from given bitmap using the given points in the original bitmap and the given
     * rotation.<br></br>
     * if the rotation is not 0,90,180 or 270 degrees then we must first crop a larger area of the
     * image that contains the required rectangle, rotate and then crop again a sub rectangle.<br></br>
     * If crop fails due to OOM we scale the cropping image by 0.5 every time it fails until it is
     * small enough.
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.BitmapUtils.BitmapSampled cropBitmapObjectHandleOOM(@org.jetbrains.annotations.Nullable()
    android.graphics.Bitmap bitmap, @org.jetbrains.annotations.NotNull()
    float[] cropPoints, int degreesRotated, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, boolean flipHorizontally, boolean flipVertically) {
        return null;
    }
    
    /**
     * Crop image bitmap from given bitmap using the given points in the original bitmap and the given
     * rotation.<br></br>
     * if the rotation is not 0,90,180 or 270 degrees then we must first crop a larger area of the
     * image that contains the required rectangle, rotate and then crop again a sub rectangle.
     *
     * [scale] how much to scale the cropped image part, use 0.5 to lower the image by half (OOM
     * handling)
     */
    private final android.graphics.Bitmap cropBitmapObjectWithScale(android.graphics.Bitmap bitmap, float[] cropPoints, int degreesRotated, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, float scale, boolean flipHorizontally, boolean flipVertically) {
        return null;
    }
    
    /**
     * Crop image bitmap from URI by decoding it with specific width and height to down-sample if
     * required.<br></br>
     * Additionally if OOM is thrown try to increase the sampling (2,4,8).
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.BitmapUtils.BitmapSampled cropBitmap(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.net.Uri loadedImageUri, @org.jetbrains.annotations.NotNull()
    float[] cropPoints, int degreesRotated, int orgWidth, int orgHeight, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, int reqWidth, int reqHeight, boolean flipHorizontally, boolean flipVertically) {
        return null;
    }
    
    /**
     * Get left value of the bounding rectangle of the given points.
     */
    public final float getRectLeft(@org.jetbrains.annotations.NotNull()
    float[] points) {
        return 0.0F;
    }
    
    /**
     * Get top value of the bounding rectangle of the given points.
     */
    public final float getRectTop(@org.jetbrains.annotations.NotNull()
    float[] points) {
        return 0.0F;
    }
    
    /**
     * Get right value of the bounding rectangle of the given points.
     */
    public final float getRectRight(@org.jetbrains.annotations.NotNull()
    float[] points) {
        return 0.0F;
    }
    
    /**
     * Get bottom value of the bounding rectangle of the given points.
     */
    public final float getRectBottom(@org.jetbrains.annotations.NotNull()
    float[] points) {
        return 0.0F;
    }
    
    /**
     * Get width of the bounding rectangle of the given points.
     */
    public final float getRectWidth(@org.jetbrains.annotations.NotNull()
    float[] points) {
        return 0.0F;
    }
    
    /**
     * Get height of the bounding rectangle of the given points.
     */
    public final float getRectHeight(@org.jetbrains.annotations.NotNull()
    float[] points) {
        return 0.0F;
    }
    
    /**
     * Get horizontal center value of the bounding rectangle of the given points.
     */
    public final float getRectCenterX(@org.jetbrains.annotations.NotNull()
    float[] points) {
        return 0.0F;
    }
    
    /**
     * Get vertical center value of the bounding rectangle of the given points.
     */
    public final float getRectCenterY(@org.jetbrains.annotations.NotNull()
    float[] points) {
        return 0.0F;
    }
    
    /**
     * Get a rectangle for the given 4 points (x0,y0,x1,y1,x2,y2,x3,y3) by finding the min/max 2
     * points that contains the given 4 points and is a straight rectangle.
     */
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.Rect getRectFromPoints(@org.jetbrains.annotations.NotNull()
    float[] cropPoints, int imageWidth, int imageHeight, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY) {
        return null;
    }
    
    /**
     * Fix the given rectangle if it doesn't confirm to aspect ration rule.<br></br>
     * Make sure that width and height are equal if 1:1 fixed aspect ratio is requested.
     */
    private final void fixRectForAspectRatio(android.graphics.Rect rect, int aspectRatioX, int aspectRatioY) {
    }
    
    /**
     * Write given bitmap to a temp file. If file already exists no-op as we already saved the file in
     * this session. Uses JPEG 95% compression.
     *
     * @return the uri where the image was saved in, either the given uri or new pointing to temp
     * file.
     */
    @org.jetbrains.annotations.Nullable()
    public final android.net.Uri writeTempStateStoreBitmap(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.graphics.Bitmap bitmap, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri) {
        return null;
    }
    
    /**
     * Write the given bitmap to the given uri using the given compression.
     */
    @kotlin.jvm.Throws(exceptionClasses = {java.io.FileNotFoundException.class})
    @org.jetbrains.annotations.NotNull()
    public final android.net.Uri writeBitmapToUri(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap bitmap, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat compressFormat, int compressQuality, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri) throws java.io.FileNotFoundException {
        return null;
    }
    
    private final android.net.Uri buildUri(android.content.Context context, android.graphics.Bitmap.CompressFormat compressFormat) {
        return null;
    }
    
    /**
     * Resize the given bitmap to the given width/height by the given option.<br></br>
     */
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.Bitmap resizeBitmap(@org.jetbrains.annotations.Nullable()
    android.graphics.Bitmap bitmap, int reqWidth, int reqHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions options) {
        return null;
    }
    
    /**
     * Crop image bitmap from URI by decoding it with specific width and height to down-sample if
     * required.
     *
     * [orgWidth] used to get rectangle from points (handle edge cases to limit rectangle)
     * [orgHeight] used to get rectangle from points (handle edge cases to limit rectangle)
     * [sampleMulti] used to increase the sampling of the image to handle memory issues.
     */
    private final com.yuyan.imemodule.libs.cropper.BitmapUtils.BitmapSampled cropBitmap(android.content.Context context, android.net.Uri loadedImageUri, float[] cropPoints, int degreesRotated, int orgWidth, int orgHeight, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, int reqWidth, int reqHeight, boolean flipHorizontally, boolean flipVertically, int sampleMulti) {
        return null;
    }
    
    /**
     * Crop bitmap by fully loading the original and then cropping it, fallback in case cropping
     * region failed.
     */
    private final com.yuyan.imemodule.libs.cropper.BitmapUtils.BitmapSampled cropBitmap(android.content.Context context, android.net.Uri loadedImageUri, float[] cropPoints, int degreesRotated, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, int sampleMulti, android.graphics.Rect rect, int width, int height, boolean flipHorizontally, boolean flipVertically) {
        return null;
    }
    
    /**
     * Decode image from uri using "inJustDecodeBounds" to get the image dimensions.
     */
    @kotlin.jvm.Throws(exceptionClasses = {java.io.FileNotFoundException.class})
    private final android.graphics.BitmapFactory.Options decodeImageForOption(android.content.ContentResolver resolver, android.net.Uri uri) throws java.io.FileNotFoundException {
        return null;
    }
    
    /**
     * Decode image from uri using given "inSampleSize", but if failed due to out-of-memory then raise
     * the inSampleSize until success.
     */
    @kotlin.jvm.Throws(exceptionClasses = {java.io.FileNotFoundException.class})
    private final android.graphics.Bitmap decodeImage(android.content.ContentResolver resolver, android.net.Uri uri, android.graphics.BitmapFactory.Options options) throws java.io.FileNotFoundException {
        return null;
    }
    
    /**
     * Decode specific rectangle bitmap from stream using sampling to get bitmap with the requested
     * limit.
     *
     * [sampleMulti] used to increase the sampling of the image to handle memory issues.
     */
    private final com.yuyan.imemodule.libs.cropper.BitmapUtils.BitmapSampled decodeSampledBitmapRegion(android.content.Context context, android.net.Uri uri, android.graphics.Rect rect, int reqWidth, int reqHeight, int sampleMulti) {
        return null;
    }
    
    /**
     * Special crop of bitmap rotated by not straight angle, in this case the original crop bitmap
     * contains parts beyond the required crop area, this method crops the already cropped and rotated
     * bitmap to the final rectangle.<br></br>
     * Note: rotating by 0, 90, 180 or 270 degrees doesn't require extra cropping.
     */
    private final android.graphics.Bitmap cropForRotatedImage(android.graphics.Bitmap bitmap, float[] cropPoints, android.graphics.Rect rect, int degreesRotated, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY) {
        return null;
    }
    
    /**
     * Calculate the largest inSampleSize value that is a power of 2 and keeps both height and width
     * larger than the requested height and width.
     */
    private final int calculateInSampleSizeByRequestedSize(int width, int height, int reqWidth, int reqHeight) {
        return 0;
    }
    
    /**
     * Calculate the largest inSampleSize value that is a power of 2 and keeps both height and width
     * smaller than max texture size allowed for the device.
     */
    private final int calculateInSampleSizeByMaxTextureSize(int width, int height) {
        return 0;
    }
    
    /**
     * Rotate the given bitmap by the given degrees.<br></br>
     * New bitmap is created and the old one is recycled.
     */
    private final android.graphics.Bitmap rotateAndFlipBitmapInt(android.graphics.Bitmap bitmap, int degrees, boolean flipHorizontally, boolean flipVertically) {
        return null;
    }
    
    private final int getMaxTextureSize() {
        return 0;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\b\u0000\u0018\u00002\u00020\u0001B\u0017\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/BitmapUtils$BitmapSampled;", "", "bitmap", "Landroid/graphics/Bitmap;", "sampleSize", "", "(Landroid/graphics/Bitmap;I)V", "getBitmap", "()Landroid/graphics/Bitmap;", "getSampleSize", "()I", "yuyansdk_offlineDebug"})
    public static final class BitmapSampled {
        @org.jetbrains.annotations.Nullable()
        private final android.graphics.Bitmap bitmap = null;
        private final int sampleSize = 0;
        
        public BitmapSampled(@org.jetbrains.annotations.Nullable()
        android.graphics.Bitmap bitmap, int sampleSize) {
            super();
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Bitmap getBitmap() {
            return null;
        }
        
        public final int getSampleSize() {
            return 0;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\b\u0000\u0018\u00002\u00020\u0001B\'\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\tR\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\b\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000f\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/BitmapUtils$RotateBitmapResult;", "", "bitmap", "Landroid/graphics/Bitmap;", "degrees", "", "flipHorizontally", "", "flipVertically", "(Landroid/graphics/Bitmap;IZZ)V", "getBitmap", "()Landroid/graphics/Bitmap;", "getDegrees", "()I", "getFlipHorizontally", "()Z", "getFlipVertically", "yuyansdk_offlineDebug"})
    public static final class RotateBitmapResult {
        @org.jetbrains.annotations.Nullable()
        private final android.graphics.Bitmap bitmap = null;
        private final int degrees = 0;
        private final boolean flipHorizontally = false;
        private final boolean flipVertically = false;
        
        public RotateBitmapResult(@org.jetbrains.annotations.Nullable()
        android.graphics.Bitmap bitmap, int degrees, boolean flipHorizontally, boolean flipVertically) {
            super();
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Bitmap getBitmap() {
            return null;
        }
        
        public final int getDegrees() {
            return 0;
        }
        
        public final boolean getFlipHorizontally() {
            return false;
        }
        
        public final boolean getFlipVertically() {
            return false;
        }
    }
}
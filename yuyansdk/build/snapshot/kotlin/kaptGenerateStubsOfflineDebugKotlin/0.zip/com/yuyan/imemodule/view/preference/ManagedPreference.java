package com.yuyan.imemodule.view.preference;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0010\b\'\u0018\u0000*\b\b\u0000\u0010\u0001*\u00020\u00022\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\u0004\u0012\u0002H\u00010\u0003:\b%&\'()*+,B\u001d\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00028\u0000\u00a2\u0006\u0002\u0010\tJ\u0006\u0010\u0014\u001a\u00020\u0015J\r\u0010\u0016\u001a\u00028\u0000H&\u00a2\u0006\u0002\u0010\u000bJ$\u0010\u0016\u001a\u00028\u00002\b\u0010\u0017\u001a\u0004\u0018\u00010\u00022\n\u0010\u0018\u001a\u0006\u0012\u0002\b\u00030\u0019H\u0096\u0002\u00a2\u0006\u0002\u0010\u001aJ\u0010\u0010\u001b\u001a\u00020\u00152\u0006\u0010\u001c\u001a\u00020\u001dH&J\u0014\u0010\u001e\u001a\u00020\u00152\f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00028\u00000\u0011J\u0015\u0010 \u001a\u00020\u00152\u0006\u0010!\u001a\u00028\u0000H&\u00a2\u0006\u0002\u0010\"J,\u0010 \u001a\u00020\u00152\b\u0010\u0017\u001a\u0004\u0018\u00010\u00022\n\u0010\u0018\u001a\u0006\u0012\u0002\b\u00030\u00192\u0006\u0010!\u001a\u00028\u0000H\u0096\u0002\u00a2\u0006\u0002\u0010#J\u0014\u0010$\u001a\u00020\u00152\f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00028\u00000\u0011R\u0013\u0010\b\u001a\u00028\u0000\u00a2\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u001a\u0010\u000f\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00110\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013\u00a8\u0006-"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "T", "", "Lkotlin/properties/ReadWriteProperty;", "sharedPreferences", "Landroid/content/SharedPreferences;", "key", "", "defaultValue", "(Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/Object;)V", "getDefaultValue", "()Ljava/lang/Object;", "Ljava/lang/Object;", "getKey", "()Ljava/lang/String;", "listeners", "Ljava/util/concurrent/CopyOnWriteArraySet;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "getSharedPreferences", "()Landroid/content/SharedPreferences;", "fireChange", "", "getValue", "thisRef", "property", "Lkotlin/reflect/KProperty;", "(Ljava/lang/Object;Lkotlin/reflect/KProperty;)Ljava/lang/Object;", "putValueTo", "editor", "Landroid/content/SharedPreferences$Editor;", "registerOnChangeListener", "listener", "setValue", "value", "(Ljava/lang/Object;)V", "(Ljava/lang/Object;Lkotlin/reflect/KProperty;Ljava/lang/Object;)V", "unregisterOnChangeListener", "OnChangeListener", "PBool", "PFloat", "PInt", "PLong", "PString", "PStringLike", "StringLikeCodec", "yuyansdk_offlineDebug"})
public abstract class ManagedPreference<T extends java.lang.Object> implements kotlin.properties.ReadWriteProperty<java.lang.Object, T> {
    @org.jetbrains.annotations.NotNull()
    private final android.content.SharedPreferences sharedPreferences = null;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String key = null;
    @org.jetbrains.annotations.NotNull()
    private final T defaultValue = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.concurrent.CopyOnWriteArraySet<com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<T>> listeners = null;
    
    public ManagedPreference(@org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences sharedPreferences, @org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    T defaultValue) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.content.SharedPreferences getSharedPreferences() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getKey() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final T getDefaultValue() {
        return null;
    }
    
    public abstract void setValue(@org.jetbrains.annotations.NotNull()
    T value);
    
    @org.jetbrains.annotations.NotNull()
    public abstract T getValue();
    
    public abstract void putValueTo(@org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences.Editor editor);
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public T getValue(@org.jetbrains.annotations.Nullable()
    java.lang.Object thisRef, @org.jetbrains.annotations.NotNull()
    kotlin.reflect.KProperty<?> property) {
        return null;
    }
    
    @java.lang.Override()
    public void setValue(@org.jetbrains.annotations.Nullable()
    java.lang.Object thisRef, @org.jetbrains.annotations.NotNull()
    kotlin.reflect.KProperty<?> property, @org.jetbrains.annotations.NotNull()
    T value) {
    }
    
    public final void registerOnChangeListener(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<? super T> listener) {
    }
    
    public final void unregisterOnChangeListener(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.preference.ManagedPreference.OnChangeListener<? super T> listener) {
    }
    
    public final void fireChange() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u00e6\u0080\u0001\u0018\u0000*\n\b\u0001\u0010\u0001 \u0000*\u00020\u00022\u00020\u0002J\u001d\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00028\u0001H&\u00a2\u0006\u0002\u0010\b\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference$OnChangeListener;", "T", "", "onChange", "", "key", "", "value", "(Ljava/lang/String;Ljava/lang/Object;)V", "yuyansdk_offlineDebug"})
    public static abstract interface OnChangeListener<T extends java.lang.Object> {
        
        public abstract void onChange(@org.jetbrains.annotations.NotNull()
        java.lang.String key, @org.jetbrains.annotations.NotNull()
        T value);
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0002\u00a2\u0006\u0002\u0010\bJ\r\u0010\t\u001a\u00020\u0002H\u0016\u00a2\u0006\u0002\u0010\nJ\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u0002H\u0016\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "", "sharedPreferences", "Landroid/content/SharedPreferences;", "key", "", "defaultValue", "(Landroid/content/SharedPreferences;Ljava/lang/String;Z)V", "getValue", "()Ljava/lang/Boolean;", "putValueTo", "", "editor", "Landroid/content/SharedPreferences$Editor;", "setValue", "value", "yuyansdk_offlineDebug"})
    public static final class PBool extends com.yuyan.imemodule.view.preference.ManagedPreference<java.lang.Boolean> {
        
        public PBool(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences sharedPreferences, @org.jetbrains.annotations.NotNull()
        java.lang.String key, boolean defaultValue) {
            super(null, null, null);
        }
        
        @java.lang.Override()
        public void setValue(boolean value) {
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.Boolean getValue() {
            return null;
        }
        
        @java.lang.Override()
        public void putValueTo(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences.Editor editor) {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0002\u00a2\u0006\u0002\u0010\bJ\r\u0010\t\u001a\u00020\u0002H\u0016\u00a2\u0006\u0002\u0010\nJ\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u0002H\u0016\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference$PFloat;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "", "sharedPreferences", "Landroid/content/SharedPreferences;", "key", "", "defaultValue", "(Landroid/content/SharedPreferences;Ljava/lang/String;F)V", "getValue", "()Ljava/lang/Float;", "putValueTo", "", "editor", "Landroid/content/SharedPreferences$Editor;", "setValue", "value", "yuyansdk_offlineDebug"})
    public static final class PFloat extends com.yuyan.imemodule.view.preference.ManagedPreference<java.lang.Float> {
        
        public PFloat(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences sharedPreferences, @org.jetbrains.annotations.NotNull()
        java.lang.String key, float defaultValue) {
            super(null, null, null);
        }
        
        @java.lang.Override()
        public void setValue(float value) {
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.Float getValue() {
            return null;
        }
        
        @java.lang.Override()
        public void putValueTo(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences.Editor editor) {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0002\u00a2\u0006\u0002\u0010\bJ\r\u0010\t\u001a\u00020\u0002H\u0016\u00a2\u0006\u0002\u0010\nJ\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u0002H\u0016\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "", "sharedPreferences", "Landroid/content/SharedPreferences;", "key", "", "defaultValue", "(Landroid/content/SharedPreferences;Ljava/lang/String;I)V", "getValue", "()Ljava/lang/Integer;", "putValueTo", "", "editor", "Landroid/content/SharedPreferences$Editor;", "setValue", "value", "yuyansdk_offlineDebug"})
    public static final class PInt extends com.yuyan.imemodule.view.preference.ManagedPreference<java.lang.Integer> {
        
        public PInt(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences sharedPreferences, @org.jetbrains.annotations.NotNull()
        java.lang.String key, int defaultValue) {
            super(null, null, null);
        }
        
        @java.lang.Override()
        public void setValue(int value) {
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.Integer getValue() {
            return null;
        }
        
        @java.lang.Override()
        public void putValueTo(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences.Editor editor) {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0002\u00a2\u0006\u0002\u0010\bJ\r\u0010\t\u001a\u00020\u0002H\u0016\u00a2\u0006\u0002\u0010\nJ\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u0010\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u0002H\u0016\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference$PLong;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "", "sharedPreferences", "Landroid/content/SharedPreferences;", "key", "", "defaultValue", "(Landroid/content/SharedPreferences;Ljava/lang/String;J)V", "getValue", "()Ljava/lang/Long;", "putValueTo", "", "editor", "Landroid/content/SharedPreferences$Editor;", "setValue", "value", "yuyansdk_offlineDebug"})
    public static final class PLong extends com.yuyan.imemodule.view.preference.ManagedPreference<java.lang.Long> {
        
        public PLong(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences sharedPreferences, @org.jetbrains.annotations.NotNull()
        java.lang.String key, long defaultValue) {
            super(null, null, null);
        }
        
        @java.lang.Override()
        public void setValue(long value) {
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.Long getValue() {
            return null;
        }
        
        @java.lang.Override()
        public void putValueTo(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences.Editor editor) {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u001d\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0002\u00a2\u0006\u0002\u0010\u0007J\b\u0010\b\u001a\u00020\u0002H\u0016J\u0010\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH\u0016J\u0010\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u0002H\u0016\u00a8\u0006\u000f"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference$PString;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "", "sharedPreferences", "Landroid/content/SharedPreferences;", "key", "defaultValue", "(Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/String;)V", "getValue", "putValueTo", "", "editor", "Landroid/content/SharedPreferences$Editor;", "setValue", "value", "yuyansdk_offlineDebug"})
    public static final class PString extends com.yuyan.imemodule.view.preference.ManagedPreference<java.lang.String> {
        
        public PString(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences sharedPreferences, @org.jetbrains.annotations.NotNull()
        java.lang.String key, @org.jetbrains.annotations.NotNull()
        java.lang.String defaultValue) {
            super(null, null, null);
        }
        
        @java.lang.Override()
        public void setValue(@org.jetbrains.annotations.NotNull()
        java.lang.String value) {
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String getValue() {
            return null;
        }
        
        @java.lang.Override()
        public void putValueTo(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences.Editor editor) {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000*\b\b\u0001\u0010\u0001*\u00020\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0003B+\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00028\u0001\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00010\n\u00a2\u0006\u0002\u0010\u000bJ\r\u0010\f\u001a\u00028\u0001H\u0016\u00a2\u0006\u0002\u0010\rJ\u0010\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0016J\u0015\u0010\u0012\u001a\u00020\u000f2\u0006\u0010\u0013\u001a\u00028\u0001H\u0016\u00a2\u0006\u0002\u0010\u0014R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00010\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "T", "", "Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "sharedPreferences", "Landroid/content/SharedPreferences;", "key", "", "defaultValue", "codec", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "(Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/Object;Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;)V", "getValue", "()Ljava/lang/Object;", "putValueTo", "", "editor", "Landroid/content/SharedPreferences$Editor;", "setValue", "value", "(Ljava/lang/Object;)V", "yuyansdk_offlineDebug"})
    public static final class PStringLike<T extends java.lang.Object> extends com.yuyan.imemodule.view.preference.ManagedPreference<T> {
        @org.jetbrains.annotations.NotNull()
        private final com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<T> codec = null;
        
        public PStringLike(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences sharedPreferences, @org.jetbrains.annotations.NotNull()
        java.lang.String key, @org.jetbrains.annotations.NotNull()
        T defaultValue, @org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<T> codec) {
            super(null, null, null);
        }
        
        @java.lang.Override()
        public void setValue(@org.jetbrains.annotations.NotNull()
        T value) {
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public T getValue() {
            return null;
        }
        
        @java.lang.Override()
        public void putValueTo(@org.jetbrains.annotations.NotNull()
        android.content.SharedPreferences.Editor editor) {
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\bf\u0018\u0000*\b\b\u0001\u0010\u0001*\u00020\u00022\u00020\u0002J\u0017\u0010\u0003\u001a\u0004\u0018\u00018\u00012\u0006\u0010\u0004\u001a\u00020\u0005H&\u00a2\u0006\u0002\u0010\u0006J\u0015\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00028\u0001H\u0016\u00a2\u0006\u0002\u0010\t\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "T", "", "decode", "raw", "", "(Ljava/lang/String;)Ljava/lang/Object;", "encode", "x", "(Ljava/lang/Object;)Ljava/lang/String;", "yuyansdk_offlineDebug"})
    public static abstract interface StringLikeCodec<T extends java.lang.Object> {
        
        @org.jetbrains.annotations.NotNull()
        public abstract java.lang.String encode(@org.jetbrains.annotations.NotNull()
        T x);
        
        @org.jetbrains.annotations.Nullable()
        public abstract T decode(@org.jetbrains.annotations.NotNull()
        java.lang.String raw);
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 3, xi = 48)
        public static final class DefaultImpls {
            
            @org.jetbrains.annotations.NotNull()
            public static <T extends java.lang.Object>java.lang.String encode(@org.jetbrains.annotations.NotNull()
            com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<T> $this, @org.jetbrains.annotations.NotNull()
            T x) {
                return null;
            }
        }
    }
}
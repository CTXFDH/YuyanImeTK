package com.yuyan.imemodule.libs.expression.operator;

/**
 * Class representing operators that can be used in an expression
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u0013\n\u0002\b\u0002\b\'\u0018\u0000 \u00142\u00020\u0001:\u0001\u0014B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\tJ\u0014\u0010\u0010\u001a\u00020\u00112\n\u0010\u0012\u001a\u00020\u0013\"\u00020\u0011H&R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\b\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/operator/Operator;", "", "symbol", "", "numOperands", "", "isLeftAssociative", "", "precedence", "(Ljava/lang/String;IZI)V", "()Z", "getNumOperands", "()I", "getPrecedence", "getSymbol", "()Ljava/lang/String;", "apply", "", "args", "", "Companion", "yuyansdk_offlineDebug"})
public abstract class Operator {
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String symbol = null;
    private final int numOperands = 0;
    private final boolean isLeftAssociative = false;
    private final int precedence = 0;
    
    /**
     * The precedence value for the addition operation
     */
    public static final int PRECEDENCE_ADDITION = 500;
    
    /**
     * The precedence value for the multiplication operation
     */
    public static final int PRECEDENCE_MULTIPLICATION = 1000;
    
    /**
     * The precedence value for the division operation
     */
    public static final int PRECEDENCE_DIVISION = 1000;
    
    /**
     * The precedence value for the modulo operation
     */
    public static final int PRECEDENCE_MODULO = 1000;
    
    /**
     * The precedence value for the power operation
     */
    public static final int PRECEDENCE_POWER = 10000;
    
    /**
     * The precedence value for the unary minus operation
     */
    public static final int PRECEDENCE_UNARY_MINUS = 5000;
    
    /**
     * The precedence value for the unary plus operation
     */
    public static final int PRECEDENCE_UNARY_PLUS = 5000;
    
    /**
     * The set of allowed operator chars
     */
    @org.jetbrains.annotations.NotNull()
    private static final char[] ALLOWED_OPERATOR_CHARS = {'+', '-', '*', '/', '%', '^', '!', '#', '\u00a7', '$', '&', ';', ':', '~', '<', '>', '|', '=', '\u00f7', '\u221a', '\u221b', '\u2308', '\u230a'};
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.expression.operator.Operator.Companion Companion = null;
    
    public Operator(@org.jetbrains.annotations.NotNull()
    java.lang.String symbol, int numOperands, boolean isLeftAssociative, int precedence) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getSymbol() {
        return null;
    }
    
    public final int getNumOperands() {
        return 0;
    }
    
    public final boolean isLeftAssociative() {
        return false;
    }
    
    public final int getPrecedence() {
        return 0;
    }
    
    /**
     * Apply the operation on the given operands
     *
     * @param args the operands for the operation
     * @return the calculated result of the operation
     */
    public abstract double apply(@org.jetbrains.annotations.NotNull()
    double... args);
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0019\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\f\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u000e\u0010\u0007\u001a\u00020\bX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\bX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\bX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\bX\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\bX\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0013"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/operator/Operator$Companion;", "", "()V", "ALLOWED_OPERATOR_CHARS", "", "getALLOWED_OPERATOR_CHARS", "()[C", "PRECEDENCE_ADDITION", "", "PRECEDENCE_DIVISION", "PRECEDENCE_MODULO", "PRECEDENCE_MULTIPLICATION", "PRECEDENCE_POWER", "PRECEDENCE_UNARY_MINUS", "PRECEDENCE_UNARY_PLUS", "isAllowedOperatorChar", "", "ch", "", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        /**
         * The set of allowed operator chars
         */
        @org.jetbrains.annotations.NotNull()
        public final char[] getALLOWED_OPERATOR_CHARS() {
            return null;
        }
        
        /**
         * Check if a character is an allowed operator char
         *
         * @param ch the char to check
         * @return true if the char is allowed an an operator symbol, false otherwise
         */
        public final boolean isAllowedOperatorChar(char ch) {
            return false;
        }
    }
}
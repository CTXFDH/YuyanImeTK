package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\'\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0018\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nH\u0004J\u0018\u0010\u000b\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\rH\u0004J\u0018\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u0010H\u0004J\u0018\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u0013H\u0004J\u0018\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\bH\u0004J;\u0010\u0016\u001a\b\u0012\u0004\u0012\u0002H\u00180\u0017\"\b\b\u0000\u0010\u0018*\u00020\u00192\u0006\u0010\u0007\u001a\u00020\b2\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u0002H\u00180\u001b2\u0006\u0010\t\u001a\u0002H\u0018H\u0004\u00a2\u0006\u0002\u0010\u001cR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001d"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceInternal;", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "sharedPreferences", "Landroid/content/SharedPreferences;", "(Landroid/content/SharedPreferences;)V", "bool", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "key", "", "defaultValue", "", "float", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PFloat;", "", "int", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "", "long", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PLong;", "", "string", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PString;", "stringLike", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "T", "", "codec", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "(Ljava/lang/String;Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;Ljava/lang/Object;)Lcom/yuyan/imemodule/view/preference/ManagedPreference$PStringLike;", "yuyansdk_offlineDebug"})
public abstract class ManagedPreferenceInternal extends com.yuyan.imemodule.prefs.ManagedPreferenceProvider {
    @org.jetbrains.annotations.NotNull()
    private final android.content.SharedPreferences sharedPreferences = null;
    
    public ManagedPreferenceInternal(@org.jetbrains.annotations.NotNull()
    android.content.SharedPreferences sharedPreferences) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    protected final com.yuyan.imemodule.view.preference.ManagedPreference.PString string(@org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    java.lang.String defaultValue) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    protected final <T extends java.lang.Object>com.yuyan.imemodule.view.preference.ManagedPreference.PStringLike<T> stringLike(@org.jetbrains.annotations.NotNull()
    java.lang.String key, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<T> codec, @org.jetbrains.annotations.NotNull()
    T defaultValue) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    protected final com.yuyan.imemodule.view.preference.ManagedPreference.PBool bool(@org.jetbrains.annotations.NotNull()
    java.lang.String key, boolean defaultValue) {
        return null;
    }
}
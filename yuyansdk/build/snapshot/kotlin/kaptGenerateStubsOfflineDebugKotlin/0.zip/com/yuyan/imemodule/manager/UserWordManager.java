package com.yuyan.imemodule.manager;

/**
 * 用户自造词管理器：管理自造词词库、自动拼音转换与 Rime custom_phrase.txt 文件同步
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006J\u0006\u0010\b\u001a\u00020\tJ\u0006\u0010\n\u001a\u00020\tJ\u000e\u0010\u000b\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2 = {"Lcom/yuyan/imemodule/manager/UserWordManager;", "", "()V", "noToneFormat", "Lcom/yuyan/imemodule/libs/pinyin4j/format/HanyuPinyinOutputFormat;", "autoGeneratePinyin", "", "word", "importFromCustomPhraseFile", "", "syncCustomPhraseFile", "wordToT9Key", "yuyansdk_offlineDebug"})
public final class UserWordManager {
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.libs.pinyin4j.format.HanyuPinyinOutputFormat noToneFormat = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.manager.UserWordManager INSTANCE = null;
    
    private UserWordManager() {
        super();
    }
    
    /**
     * 将汉字转为全拼（无声调小写）
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String autoGeneratePinyin(@org.jetbrains.annotations.NotNull()
    java.lang.String word) {
        return null;
    }
    
    /**
     * 将英文拼音转为 T9 数字按键序列
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String wordToT9Key(@org.jetbrains.annotations.NotNull()
    java.lang.String word) {
        return null;
    }
    
    /**
     * 将数据库自造词导出/同步到 Rime custom_phrase.txt 文件，并清除 Rime userdb 缓存
     */
    public final void syncCustomPhraseFile() {
    }
    
    /**
     * 从 Rime 磁盘 custom_phrase.txt 中反向导入自造词至数据库（如果存在）
     */
    public final void importFromCustomPhraseFile() {
    }
}
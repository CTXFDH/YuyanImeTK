package com.yuyan.inputmethod.data;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0007\bf\u0018\u00002\u00020\u0001:\u0006\u0002\u0003\u0004\u0005\u0006\u0007\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/inputmethod/data/InputKey;", "", "Apostrophe", "DefaultAction", "PinyinKey", "QwertKey", "SelectPinyinAction", "T9Key", "yuyansdk_offlineDebug"})
public abstract interface InputKey {
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/inputmethod/data/InputKey$Apostrophe;", "Lcom/yuyan/inputmethod/data/InputKey;", "dummy", "", "(Z)V", "getDummy", "()Z", "yuyansdk_offlineDebug"})
    public static final class Apostrophe implements com.yuyan.inputmethod.data.InputKey {
        private final boolean dummy = false;
        
        public Apostrophe(boolean dummy) {
            super();
        }
        
        public final boolean getDummy() {
            return false;
        }
        
        public Apostrophe() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2 = {"Lcom/yuyan/inputmethod/data/InputKey$DefaultAction;", "Lcom/yuyan/inputmethod/data/InputKey;", "()V", "yuyansdk_offlineDebug"})
    public static final class DefaultAction implements com.yuyan.inputmethod.data.InputKey {
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.inputmethod.data.InputKey.DefaultAction INSTANCE = null;
        
        private DefaultAction() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u000e\u0010\r\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0005J\u0006\u0010\u0002\u001a\u00020\u0003J\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fJ\u0006\u0010\u0011\u001a\u00020\u0003R\u0011\u0010\u0007\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010\n\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\f\u0010\t\u00a8\u0006\u0012"}, d2 = {"Lcom/yuyan/inputmethod/data/InputKey$PinyinKey;", "Lcom/yuyan/inputmethod/data/InputKey;", "pinyin", "", "posInInput", "", "(Ljava/lang/String;I)V", "inputKeyLength", "getInputKeyLength", "()I", "pinyinLength", "getPinyinLength", "getPosInInput", "copy", "restoreToT9key", "", "Lcom/yuyan/inputmethod/data/InputKey$T9Key;", "t9Keys", "yuyansdk_offlineDebug"})
    public static final class PinyinKey implements com.yuyan.inputmethod.data.InputKey {
        @org.jetbrains.annotations.NotNull()
        private final java.lang.String pinyin = null;
        private final int posInInput = 0;
        private final int pinyinLength = 0;
        private final int inputKeyLength = 0;
        
        public PinyinKey(@org.jetbrains.annotations.NotNull()
        java.lang.String pinyin, int posInInput) {
            super();
        }
        
        public final int getPosInInput() {
            return 0;
        }
        
        public final int getPinyinLength() {
            return 0;
        }
        
        public final int getInputKeyLength() {
            return 0;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String t9Keys() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.util.List<com.yuyan.inputmethod.data.InputKey.T9Key> restoreToT9key() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.inputmethod.data.InputKey.PinyinKey copy(int posInInput) {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final java.lang.String pinyin() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\f\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004B\r\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J\b\u0010\b\u001a\u00020\tH\u0016R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/inputmethod/data/InputKey$QwertKey;", "Lcom/yuyan/inputmethod/data/InputKey;", "keyCode", "", "(I)V", "keyChar", "", "(C)V", "toString", "", "yuyansdk_offlineDebug"})
    public static final class QwertKey implements com.yuyan.inputmethod.data.InputKey {
        private final char keyChar = '\u0000';
        
        public QwertKey(char keyChar) {
            super();
        }
        
        public QwertKey(int keyCode) {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String toString() {
            return null;
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2 = {"Lcom/yuyan/inputmethod/data/InputKey$SelectPinyinAction;", "Lcom/yuyan/inputmethod/data/InputKey;", "()V", "yuyansdk_offlineDebug"})
    public static final class SelectPinyinAction implements com.yuyan.inputmethod.data.InputKey {
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.inputmethod.data.InputKey.SelectPinyinAction INSTANCE = null;
        
        private SelectPinyinAction() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\f\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004B\u0017\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u00a2\u0006\u0002\u0010\tJ\b\u0010\u000e\u001a\u00020\u000fH\u0016R\u001a\u0010\u0007\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u000b\"\u0004\b\f\u0010\rR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2 = {"Lcom/yuyan/inputmethod/data/InputKey$T9Key;", "Lcom/yuyan/inputmethod/data/InputKey;", "keyCode", "", "(I)V", "keyChar", "", "consumed", "", "(CZ)V", "getConsumed", "()Z", "setConsumed", "(Z)V", "toString", "", "yuyansdk_offlineDebug"})
    public static final class T9Key implements com.yuyan.inputmethod.data.InputKey {
        private final char keyChar = '\u0000';
        private boolean consumed;
        
        public T9Key(char keyChar, boolean consumed) {
            super();
        }
        
        public final boolean getConsumed() {
            return false;
        }
        
        public final void setConsumed(boolean p0) {
        }
        
        public T9Key(int keyCode) {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String toString() {
            return null;
        }
    }
}
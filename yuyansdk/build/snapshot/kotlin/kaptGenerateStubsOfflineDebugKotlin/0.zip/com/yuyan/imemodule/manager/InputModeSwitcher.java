package com.yuyan.imemodule.manager;

/**
 * 输入法模式转换器。设置输入法的软键盘。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\'\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001:\u0001UB\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010@\u001a\u00020A2\u0006\u0010B\u001a\u00020\u0004J\u000e\u0010C\u001a\u00020A2\u0006\u0010D\u001a\u00020EJ\u0006\u0010F\u001a\u00020AJ\u000e\u0010G\u001a\u00020A2\u0006\u0010H\u001a\u00020\u0004J,\u0010I\u001a\u00020A2\u0006\u0010J\u001a\u00020K2\n\b\u0002\u0010L\u001a\u0004\u0018\u00010M2\u0010\b\u0002\u0010N\u001a\n\u0012\u0004\u0012\u00020A\u0018\u00010OJ\u001a\u0010P\u001a\u00020A2\u0012\u0010Q\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020S0RJ\u000e\u0010T\u001a\u00020A2\u0006\u0010B\u001a\u00020\u0004R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\'\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u0011\u0010+\u001a\u00020,8F\u00a2\u0006\u0006\u001a\u0004\b+\u0010-R\u0011\u0010.\u001a\u00020,8F\u00a2\u0006\u0006\u001a\u0004\b.\u0010-R\u0011\u0010/\u001a\u00020,8F\u00a2\u0006\u0006\u001a\u0004\b/\u0010-R\u0011\u00100\u001a\u00020,8F\u00a2\u0006\u0006\u001a\u0004\b0\u0010-R\u0011\u00101\u001a\u00020,8F\u00a2\u0006\u0006\u001a\u0004\b1\u0010-R\u0011\u00102\u001a\u00020,8F\u00a2\u0006\u0006\u001a\u0004\b2\u0010-R\u0011\u00103\u001a\u00020,8F\u00a2\u0006\u0006\u001a\u0004\b3\u0010-R\u0011\u00104\u001a\u00020,8F\u00a2\u0006\u0006\u001a\u0004\b4\u0010-R\u000e\u00105\u001a\u000206X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u00109\u001a\u00020:8\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000R\u0011\u0010;\u001a\u00020\u00048F\u00a2\u0006\u0006\u001a\u0004\b<\u0010=R\u0011\u0010>\u001a\u00020\u00048F\u00a2\u0006\u0006\u001a\u0004\b?\u0010=\u00a8\u0006V"}, d2 = {"Lcom/yuyan/imemodule/manager/InputModeSwitcher;", "", "()V", "MASK_CASE_LOWER", "", "MASK_LANGUAGE", "MASK_LANGUAGE_CN", "MASK_LANGUAGE_EN", "MASK_SKB_LAYOUT", "MASK_SKB_LAYOUT_HANDWRITING", "MASK_SKB_LAYOUT_LX17", "MASK_SKB_LAYOUT_NUMBER", "MASK_SKB_LAYOUT_QWERTY_ABC", "MASK_SKB_LAYOUT_QWERTY_PINYIN", "MASK_SKB_LAYOUT_STROKE", "MASK_SKB_LAYOUT_T9_PINYIN", "MASK_SKB_LAYOUT_TEXTEDIT", "MASK_SKB_LAYOUT_VOICE", "MODE_HANDWRITING_CHINESE", "MODE_SKB_ENGLISH_LOWER", "MODE_T9_CHINESE", "MODE_UNSET", "USER_KEYCODE_CLIPBOARD", "USER_KEYCODE_COMMA_EMOJI", "USER_KEYCODE_COPY", "USER_KEYCODE_CURSOR_DIRECTION", "USER_KEYCODE_CUT", "USER_KEYCODE_EMOJI", "USER_KEYCODE_LANG", "USER_KEYCODE_LEFT_COMMA", "USER_KEYCODE_LEFT_PERIOD", "USER_KEYCODE_LEFT_SYMBOL", "USER_KEYCODE_MOVE_END", "USER_KEYCODE_MOVE_START", "USER_KEYCODE_NUMBER", "USER_KEYCODE_PASTE", "USER_KEYCODE_RETURN", "USER_KEYCODE_SELECTED", "USER_KEYCODE_SELECT_ALL", "USER_KEYCODE_SELECT_MODE", "USER_KEYCODE_STAR", "USER_KEYCODE_SYMBOL", "USER_KEYCODE_TEXTEDIT", "isChinese", "", "()Z", "isChineseHandWriting", "isChineseT9", "isEnglish", "isLower", "isNumberSkb", "isQwert", "isTextEditSkb", "lsatClickTime", "", "mInputMode", "mRecentLauageInputMode", "mToggleStates", "Lcom/yuyan/imemodule/manager/InputModeSwitcher$ToggleStates;", "skbImeLayout", "getSkbImeLayout", "()I", "skbLayout", "getSkbLayout", "processShiftKey", "", "userKey", "requestInputWithSkb", "editorInfo", "Landroid/view/inputmethod/EditorInfo;", "resetCharCase", "saveInputMode", "newInputMode", "showDoublePinyinSchemaDialog", "context", "Landroid/content/Context;", "targetView", "Landroid/view/View;", "onSchemaSelected", "Lkotlin/Function0;", "switchModeForSetting", "value", "Lkotlin/Pair;", "", "switchModeForUserKey", "ToggleStates", "yuyansdk_offlineDebug"})
public final class InputModeSwitcher {
    
    /**
     * User defined key code, used by soft keyboard. 选择候选词按键。
     */
    public static final int USER_KEYCODE_SELECTED = -1;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,语言切换键。
     */
    public static final int USER_KEYCODE_LANG = -2;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,符号键盘切换键。
     */
    public static final int USER_KEYCODE_SYMBOL = -3;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,表情键盘切换键。
     */
    public static final int USER_KEYCODE_EMOJI = -4;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,数字键盘切换键。
     */
    public static final int USER_KEYCODE_NUMBER = -5;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,数字键盘返回按键。
     */
    public static final int USER_KEYCODE_RETURN = -6;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,编辑键盘。
     */
    public static final int USER_KEYCODE_TEXTEDIT = -7;
    
    /**
     * User defined key code, used by soft keyboard. 逗号按钮，长按选择表情。
     */
    public static final int USER_KEYCODE_COMMA_EMOJI = -8;
    
    /**
     * User defined key code, used by soft keyboard. 方向控制。或谷歌键盘的重输按钮
     */
    public static final int USER_KEYCODE_CURSOR_DIRECTION = -9;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,九宫格、手写符号侧栏占位符。
     */
    public static final int USER_KEYCODE_LEFT_SYMBOL = -12;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,逗号（中文：，;英文：,）。
     */
    public static final int USER_KEYCODE_LEFT_COMMA = -13;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,句号（中文：。;英文：.）。
     */
    public static final int USER_KEYCODE_LEFT_PERIOD = -14;
    
    /**
     * User defined key code, used by soft keyboard. 语言键的code,星号（*）。
     */
    public static final int USER_KEYCODE_STAR = -17;
    
    /**
     * User defined key code, used by soft keyboard. 编辑键盘方向
     */
    public static final int USER_KEYCODE_SELECT_MODE = -18;
    public static final int USER_KEYCODE_SELECT_ALL = -19;
    public static final int USER_KEYCODE_CUT = -20;
    public static final int USER_KEYCODE_COPY = -21;
    public static final int USER_KEYCODE_PASTE = -22;
    public static final int USER_KEYCODE_MOVE_START = -23;
    public static final int USER_KEYCODE_MOVE_END = -24;
    public static final int USER_KEYCODE_CLIPBOARD = -25;
    
    /**
     * Bits used to indicate soft keyboard layout. If none bit is set, the
     * current input mode does not require a soft keyboard.
     * 第8位指明软键盘的布局。如果最8位为0，那么就表明当前输入法模式不需要软键盘。
     */
    public static final int MASK_SKB_LAYOUT = 65280;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明标准的传统键盘,拼音
     */
    public static final int MASK_SKB_LAYOUT_QWERTY_PINYIN = 4096;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明九宫格软键盘，拼音
     */
    public static final int MASK_SKB_LAYOUT_T9_PINYIN = 8192;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明手写键
     */
    public static final int MASK_SKB_LAYOUT_HANDWRITING = 12288;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明标准的传统键盘
     */
    public static final int MASK_SKB_LAYOUT_QWERTY_ABC = 16384;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明数字键
     */
    public static final int MASK_SKB_LAYOUT_NUMBER = 20480;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明乱序17
     */
    public static final int MASK_SKB_LAYOUT_LX17 = 24576;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明笔画键盘
     */
    public static final int MASK_SKB_LAYOUT_STROKE = 28672;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明文本编辑键盘
     */
    public static final int MASK_SKB_LAYOUT_TEXTEDIT = 32768;
    
    /**
     * A kind of soft keyboard layout. An input mode should be anded with
     * [.MASK_SKB_LAYOUT] to get its soft keyboard layout. 指明语音输入键盘
     */
    public static final int MASK_SKB_LAYOUT_VOICE = 36864;
    
    /**
     * 第6位指明语言。
     */
    private static final int MASK_LANGUAGE = 240;
    
    /**
     * Used to indicate the current language. An input mode should be anded with
     * [.MASK_LANGUAGE] to get this information. 指明中文语言。
     */
    public static final int MASK_LANGUAGE_CN = 16;
    
    /**
     * Used to indicate the current language. An input mode should be anded with
     * [.MASK_LANGUAGE] to get this information. 指明英文语言。
     */
    private static final int MASK_LANGUAGE_EN = 32;
    
    /**
     * 指明软键盘状态为低（小写）。
     */
    private static final int MASK_CASE_LOWER = 0;
    
    /**
     * Mode for inputing Chinese with soft keyboard. 九宫格软键盘、中文模式
     */
    public static final int MODE_T9_CHINESE = 8208;
    
    /**
     * Mode for inputing Chinese with soft keyboard. 手写软键盘、中文模式
     */
    public static final int MODE_HANDWRITING_CHINESE = 12304;
    
    /**
     * Mode for inputing English lower characters with soft keyboard. 标准软键盘、英文、小写模式
     */
    private static final int MODE_SKB_ENGLISH_LOWER = 16416;
    
    /**
     * Unset mode. 未设置输入法模式。
     */
    private static final int MODE_UNSET = 0;
    
    /**
     * The input mode for the current edit box. 当前输入法的模式
     */
    private static int mInputMode = 0;
    
    /**
     * Used to remember recent mode to input language. 最近的语言输入法模式
     */
    private static int mRecentLauageInputMode = 0;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.manager.InputModeSwitcher.ToggleStates mToggleStates = null;
    private static long lsatClickTime = 0L;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.manager.InputModeSwitcher INSTANCE = null;
    
    private InputModeSwitcher() {
        super();
    }
    
    public final int getSkbImeLayout() {
        return 0;
    }
    
    public final int getSkbLayout() {
        return 0;
    }
    
    /**
     * 根据编辑框的 EditorInfo 信息获取软键盘的输入法模式。
     */
    public final void requestInputWithSkb(@org.jetbrains.annotations.NotNull()
    android.view.inputmethod.EditorInfo editorInfo) {
    }
    
    /**
     * 通过我们定义的软键盘的按键，切换输入法模式。
     */
    public final void switchModeForUserKey(int userKey) {
    }
    
    /**
     * 通过应用内设置，切换输入法模式。
     */
    public final void switchModeForSetting(@org.jetbrains.annotations.NotNull()
    kotlin.Pair<java.lang.Integer, java.lang.String> value) {
    }
    
    public final void processShiftKey(int userKey) {
    }
    
    /**
     * 是否是数字盘输入法模式
     */
    public final boolean isNumberSkb() {
        return false;
    }
    
    public final boolean isTextEditSkb() {
        return false;
    }
    
    /**
     * 是否是中文语言。
     */
    public final boolean isChinese() {
        return false;
    }
    
    /**
     * 是否的9宫格中文语言
     */
    public final boolean isChineseT9() {
        return false;
    }
    
    /**
     * 是否的全键中文语言
     */
    public final boolean isQwert() {
        return false;
    }
    
    /**
     * 手写中文语言
     */
    public final boolean isChineseHandWriting() {
        return false;
    }
    
    /**
     * 是否是软件盘英语模式
     */
    public final boolean isEnglish() {
        return false;
    }
    
    public final boolean isLower() {
        return false;
    }
    
    /**
     * 保存新的输入法模式
     */
    public final void saveInputMode(int newInputMode) {
    }
    
    /**
     * 大写模式下输入任何按键后，Shift按键状态重置一下
     */
    public final void resetCharCase() {
    }
    
    /**
     * 弹出双拼方案选择单选框弹窗
     */
    public final void showDoublePinyinSchemaDialog(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.view.View targetView, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> onSchemaSelected) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002R\u0012\u0010\u0003\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0005\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/manager/InputModeSwitcher$ToggleStates;", "", "()V", "imeAction", "", "modifiers", "yuyansdk_offlineDebug"})
    public static final class ToggleStates {
        @kotlin.jvm.JvmField()
        public int modifiers = 0;
        @kotlin.jvm.JvmField()
        public int imeAction = 0;
        
        public ToggleStates() {
            super();
        }
    }
}
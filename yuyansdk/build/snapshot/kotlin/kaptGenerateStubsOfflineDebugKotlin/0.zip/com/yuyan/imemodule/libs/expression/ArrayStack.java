package com.yuyan.imemodule.libs.expression;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0013\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0000\u0018\u00002\u00020\u0001B\u0011\b\u0007\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\tJ\u0006\u0010\r\u001a\u00020\u0003R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000e"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/ArrayStack;", "", "initialCapacity", "", "(I)V", "data", "", "idx", "pop", "", "push", "", "value", "size", "yuyansdk_offlineDebug"})
public final class ArrayStack {
    @org.jetbrains.annotations.NotNull()
    private double[] data;
    private int idx;
    
    @kotlin.jvm.JvmOverloads()
    public ArrayStack() {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public ArrayStack(int initialCapacity) {
        super();
    }
    
    public final void push(double value) {
    }
    
    public final double pop() {
        return 0.0;
    }
    
    public final int size() {
        return 0;
    }
}
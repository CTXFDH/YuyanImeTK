package com.yuyan.imemodule.libs.cropper;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0000\u0018\u0000 \"2\u00020\u0001:\u0002\"#B\u0015\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u001e\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u000b0\u000e2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0002J\u001e\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u000b0\u000e2\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u000fH\u0002J\u0010\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u0012\u001a\u00020\u0013H\u0002J\u0010\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u0012\u001a\u00020\u0013H\u0002J\u000e\u0010\u001b\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\u000fJ\u0014\u0010\u001c\u001a\u00020\u00002\f\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eJ\"\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u00192\u0006\u0010!\u001a\u00020\u00192\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\bR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\t\u001a\u0010\u0012\f\u0012\n \f*\u0004\u0018\u00010\u000b0\u000b0\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006$"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageIntentChooser;", "", "activity", "Landroidx/activity/ComponentActivity;", "callback", "Lcom/yuyan/imemodule/libs/cropper/CropImageIntentChooser$ResultCallback;", "(Landroidx/activity/ComponentActivity;Lcom/yuyan/imemodule/libs/cropper/CropImageIntentChooser$ResultCallback;)V", "cameraImgUri", "Landroid/net/Uri;", "intentChooser", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "kotlin.jvm.PlatformType", "priorityIntentList", "", "", "title", "getCameraIntents", "context", "Landroid/content/Context;", "packageManager", "Landroid/content/pm/PackageManager;", "getGalleryIntents", "action", "hasCameraPermissionInManifest", "", "isExplicitCameraPermissionRequired", "setIntentChooserTitle", "setupPriorityAppsList", "appsList", "showChooserIntent", "", "includeCamera", "includeGallery", "Companion", "ResultCallback", "yuyansdk_offlineDebug"})
public final class CropImageIntentChooser {
    @org.jetbrains.annotations.NotNull()
    private final androidx.activity.ComponentActivity activity = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.libs.cropper.CropImageIntentChooser.ResultCallback callback = null;
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String GOOGLE_PHOTOS = "com.google.android.apps.photos";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String GOOGLE_PHOTOS_GO = "com.google.android.apps.photosgo";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String SAMSUNG_GALLERY = "com.sec.android.gallery3d";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String ONEPLUS_GALLERY = "com.oneplus.gallery";
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String MIUI_GALLERY = "com.miui.gallery";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String title;
    @org.jetbrains.annotations.NotNull()
    private java.util.List<java.lang.String> priorityIntentList;
    @org.jetbrains.annotations.Nullable()
    private android.net.Uri cameraImgUri;
    @org.jetbrains.annotations.NotNull()
    private final androidx.activity.result.ActivityResultLauncher<android.content.Intent> intentChooser = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.cropper.CropImageIntentChooser.Companion Companion = null;
    
    public CropImageIntentChooser(@org.jetbrains.annotations.NotNull()
    androidx.activity.ComponentActivity activity, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageIntentChooser.ResultCallback callback) {
        super();
    }
    
    /**
     * Create a chooser intent to select the source to get image from.<br></br>
     * The source can be camera's (ACTION_IMAGE_CAPTURE) or gallery's (ACTION_GET_CONTENT).<br></br>
     * All possible sources are added to the intent chooser.
     *
     * [includeCamera] if to include camera intents
     * [includeGallery] if to include Gallery app intents
     * [cameraImgUri] required if includeCamera is set to true
     */
    public final void showChooserIntent(boolean includeCamera, boolean includeGallery, @org.jetbrains.annotations.Nullable()
    android.net.Uri cameraImgUri) {
    }
    
    /**
     * Get all Camera intents for capturing image using device camera apps.
     */
    private final java.util.List<android.content.Intent> getCameraIntents(android.content.Context context, android.content.pm.PackageManager packageManager) {
        return null;
    }
    
    /**
     * Get all Gallery intents for getting image from one of the apps of the device that handle
     * images.
     * Note: It currently gets only the main camera app intent. Still have to figure out
     * how to get multiple camera apps to pick from (if available)
     */
    private final java.util.List<android.content.Intent> getGalleryIntents(android.content.pm.PackageManager packageManager, java.lang.String action) {
        return null;
    }
    
    /**
     * Check if explicitly requesting camera permission is required.<br></br>
     * It is required in Android Marshmallow and above if "CAMERA" permission is requested in the
     * manifest.<br></br>
     * See [StackOverflow
     *    * question](http://stackoverflow.com/questions/32789027/android-m-camera-intent-permission-bug).
     */
    private final boolean isExplicitCameraPermissionRequired(android.content.Context context) {
        return false;
    }
    
    /**
     * Check if the app requests a specific permission in the manifest.
     *
     * [context] the context of your activity to check for permissions
     * @return true - the permission in requested in manifest, false - not.
     */
    private final boolean hasCameraPermissionInManifest(android.content.Context context) {
        return false;
    }
    
    /**
     * Set up a list of apps that you require to show first in the intent chooser
     * Apps will show in the order it is passed
     *
     * [appsList] - pass a list of package names of apps of your choice
     *
     * This overrides the existing apps list
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.CropImageIntentChooser setupPriorityAppsList(@org.jetbrains.annotations.NotNull()
    java.util.List<java.lang.String> appsList) {
        return null;
    }
    
    /**
     * Set the title for the intent chooser
     *
     * [title] - the title for the intent chooser
     */
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.CropImageIntentChooser setIntentChooserTitle(@org.jetbrains.annotations.NotNull()
    java.lang.String title) {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageIntentChooser$Companion;", "", "()V", "GOOGLE_PHOTOS", "", "GOOGLE_PHOTOS_GO", "MIUI_GALLERY", "ONEPLUS_GALLERY", "SAMSUNG_GALLERY", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b`\u0018\u00002\u00020\u0001J\b\u0010\u0002\u001a\u00020\u0003H&J\u0012\u0010\u0004\u001a\u00020\u00032\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H&\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageIntentChooser$ResultCallback;", "", "onCancelled", "", "onSuccess", "uri", "Landroid/net/Uri;", "yuyansdk_offlineDebug"})
    public static abstract interface ResultCallback {
        
        public abstract void onSuccess(@org.jetbrains.annotations.Nullable()
        android.net.Uri uri);
        
        public abstract void onCancelled();
    }
}
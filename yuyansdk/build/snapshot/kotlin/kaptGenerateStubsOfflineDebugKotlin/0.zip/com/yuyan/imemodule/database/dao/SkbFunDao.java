package com.yuyan.imemodule.database.dao;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\bg\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\b\u0010\u0003\u001a\u00020\u0004H\'J\b\u0010\u0005\u001a\u00020\u0004H\'J\u000e\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00020\u0007H\'J\u000e\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00020\u0007H\'J\u0012\u0010\t\u001a\u0004\u0018\u00010\u00022\u0006\u0010\n\u001a\u00020\u000bH\'\u00a8\u0006\f"}, d2 = {"Lcom/yuyan/imemodule/database/dao/SkbFunDao;", "Lcom/yuyan/imemodule/database/BaseDao;", "Lcom/yuyan/imemodule/database/entry/SkbFun;", "deleteAll", "", "deleteAllBarMenu", "getALlBarMenu", "", "getAllMenu", "getBarMenu", "name", "", "yuyansdk_offlineDebug"})
@androidx.room.Dao()
public abstract interface SkbFunDao extends com.yuyan.imemodule.database.BaseDao<com.yuyan.imemodule.database.entry.SkbFun> {
    
    @androidx.room.Query(value = "select * from skbfun  where isKeep = 0 ORDER BY position ASC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.SkbFun> getAllMenu();
    
    @androidx.room.Query(value = "select * from skbfun where isKeep = 1 ORDER BY position ASC")
    @org.jetbrains.annotations.NotNull()
    public abstract java.util.List<com.yuyan.imemodule.database.entry.SkbFun> getALlBarMenu();
    
    @androidx.room.Query(value = "select * from skbfun where name = :name AND isKeep = 1")
    @org.jetbrains.annotations.Nullable()
    public abstract com.yuyan.imemodule.database.entry.SkbFun getBarMenu(@org.jetbrains.annotations.NotNull()
    java.lang.String name);
    
    @androidx.room.Query(value = "delete from skbfun")
    public abstract void deleteAll();
    
    @androidx.room.Query(value = "delete from skbfun where isKeep = 1")
    public abstract void deleteAllBarMenu();
}
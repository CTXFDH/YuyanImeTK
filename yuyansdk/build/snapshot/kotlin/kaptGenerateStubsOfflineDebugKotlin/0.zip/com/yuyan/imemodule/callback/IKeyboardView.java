package com.yuyan.imemodule.callback;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0014\n\u0002\b\u0002\b\'\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\b\u0010\u0005\u001a\u00020\u0006H&J\b\u0010\u0007\u001a\u00020\bH&J\u0018\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH&J0\u0010\u000e\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0012\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u00102\u0006\u0010\u0014\u001a\u00020\u0010H&J\b\u0010\u0015\u001a\u00020\bH&J\b\u0010\u0016\u001a\u00020\bH&J\u0018\u0010\u0017\u001a\u00020\r2\u0006\u0010\u0018\u001a\u00020\u00102\u0006\u0010\u0019\u001a\u00020\u001aH&J\u0010\u0010\u001b\u001a\u00020\r2\u0006\u0010\u0019\u001a\u00020\u001aH&J\u0010\u0010\u001c\u001a\u00020\b2\u0006\u0010\u001d\u001a\u00020\u001eH&J\u001b\u0010\u001f\u001a\u00020\b2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\"0!H&\u00a2\u0006\u0002\u0010#J\u0010\u0010$\u001a\u00020\b2\u0006\u0010%\u001a\u00020&H&J\b\u0010\'\u001a\u00020\bH&\u00a8\u0006("}, d2 = {"Lcom/yuyan/imemodule/callback/IKeyboardView;", "Landroid/widget/RelativeLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "getKeyboardRect", "", "onCandidateChanged", "", "onStartInputView", "editorInfo", "Landroid/view/inputmethod/EditorInfo;", "restarting", "", "onUpdateSelection", "oldSelStart", "", "oldSelEnd", "newSelStart", "newSelEnd", "candidatesEnd", "onWindowHidden", "onWindowShown", "processKeyDown", "keyCode", "event", "Landroid/view/KeyEvent;", "processKeyUp", "setConfiguration", "newConfig", "Landroid/content/res/Configuration;", "showSymbols", "symbols", "", "", "([Ljava/lang/String;)V", "updatePosition", "anchor", "", "updateTheme", "yuyansdk_offlineDebug"})
public abstract class IKeyboardView extends android.widget.RelativeLayout {
    
    public IKeyboardView(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null);
    }
    
    public abstract void onStartInputView(@org.jetbrains.annotations.NotNull()
    android.view.inputmethod.EditorInfo editorInfo, boolean restarting);
    
    public abstract boolean processKeyDown(int keyCode, @org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event);
    
    public abstract boolean processKeyUp(@org.jetbrains.annotations.NotNull()
    android.view.KeyEvent event);
    
    public abstract void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd, int candidatesEnd);
    
    public abstract void onWindowShown();
    
    public abstract void onWindowHidden();
    
    public abstract void updatePosition(@org.jetbrains.annotations.NotNull()
    float[] anchor);
    
    @org.jetbrains.annotations.NotNull()
    public abstract int[] getKeyboardRect();
    
    public abstract void updateTheme();
    
    public abstract void showSymbols(@org.jetbrains.annotations.NotNull()
    java.lang.String[] symbols);
    
    public abstract void setConfiguration(@org.jetbrains.annotations.NotNull()
    android.content.res.Configuration newConfig);
    
    public abstract void onCandidateChanged();
}
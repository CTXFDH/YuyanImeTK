package com.yuyan.imemodule.view.popup;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0016\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00182\u0006\u0010\u0019\u001a\u00020\u001aJ\u000e\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u001c\u001a\u00020\u001dR\u0014\u0010\u0002\u001a\u00020\u0003X\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u001a\u0010\u0007\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u0014\u0010\r\u001a\u00020\u000eX\u0096\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0011\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014\u00a8\u0006\u001e"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupEntryUi;", "Lsplitties/views/dsl/core/Ui;", "ctx", "Landroid/content/Context;", "(Landroid/content/Context;)V", "getCtx", "()Landroid/content/Context;", "lastShowTime", "", "getLastShowTime", "()J", "setLastShowTime", "(J)V", "root", "Landroid/widget/FrameLayout;", "getRoot", "()Landroid/widget/FrameLayout;", "textView", "Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "getTextView", "()Lcom/yuyan/imemodule/view/popup/AutoScaleTextView;", "setBackground", "", "theme", "Lcom/yuyan/imemodule/data/theme/Theme;", "radius", "", "setText", "text", "", "yuyansdk_offlineDebug"})
public final class PopupEntryUi implements splitties.views.dsl.core.Ui {
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context ctx = null;
    private long lastShowTime = -1L;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.view.popup.AutoScaleTextView textView = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.FrameLayout root = null;
    
    public PopupEntryUi(@org.jetbrains.annotations.NotNull()
    android.content.Context ctx) {
        super();
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.content.Context getCtx() {
        return null;
    }
    
    public final long getLastShowTime() {
        return 0L;
    }
    
    public final void setLastShowTime(long p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.view.popup.AutoScaleTextView getTextView() {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public android.widget.FrameLayout getRoot() {
        return null;
    }
    
    public final void setText(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
    }
    
    public final void setBackground(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme, float radius) {
    }
}
package com.yuyan.imemodule.speech;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0006J\u0010\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0005\u001a\u00020\u0006J\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u0006\u00a8\u0006\f"}, d2 = {"Lcom/yuyan/imemodule/speech/AsrBackendFactory;", "", "()V", "create", "Lcom/yuyan/imemodule/speech/AsrBackend;", "context", "Landroid/content/Context;", "getLocalName", "", "releaseModel", "", "warmup", "yuyansdk_offlineDebug"})
public final class AsrBackendFactory {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.speech.AsrBackendFactory INSTANCE = null;
    
    private AsrBackendFactory() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.speech.AsrBackend create(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String getLocalName(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        return null;
    }
    
    public final void warmup(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    public final void releaseModel() {
    }
}
package com.yuyan.imemodule.keyboard.container;

/**
 * 全键盘容器
 *
 * 包含输入键盘[TextKeyboard]。
 *
 * 与九宫格键盘容器[T9TextContainer]相比，全键盘不包含拼音选择栏。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B!\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bJ\b\u0010\n\u001a\u00020\u000bH\u0016R\u000e\u0010\t\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/QwertyContainer;", "Lcom/yuyan/imemodule/keyboard/container/InputBaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "skbValue", "", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;I)V", "mSkbValue", "updateSkbLayout", "", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class QwertyContainer extends com.yuyan.imemodule.keyboard.container.InputBaseContainer {
    private int mSkbValue = 0;
    
    public QwertyContainer(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView, int skbValue) {
        super(null, null);
    }
    
    /**
     * 更新软键盘布局
     */
    @java.lang.Override()
    public void updateSkbLayout() {
    }
}
package com.yuyan.imemodule.data.flower;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\f\b\u0086\u0081\u0002\u0018\u0000 \f2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\fB\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007j\u0002\b\bj\u0002\b\tj\u0002\b\nj\u0002\b\u000b\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/data/flower/FlowerTypefaceMode;", "", "(Ljava/lang/String;I)V", "Mars", "FlowerVine", "Messy", "Germinate", "Fog", "ProhibitAccess", "Grass", "Wind", "Disabled", "Companion", "yuyansdk_offlineDebug"})
public enum FlowerTypefaceMode {
    /*public static final*/ Mars /* = new Mars() */,
    /*public static final*/ FlowerVine /* = new FlowerVine() */,
    /*public static final*/ Messy /* = new Messy() */,
    /*public static final*/ Germinate /* = new Germinate() */,
    /*public static final*/ Fog /* = new Fog() */,
    /*public static final*/ ProhibitAccess /* = new ProhibitAccess() */,
    /*public static final*/ Grass /* = new Grass() */,
    /*public static final*/ Wind /* = new Wind() */,
    /*public static final*/ Disabled /* = new Disabled() */;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.flower.FlowerTypefaceMode.Companion Companion = null;
    
    FlowerTypefaceMode() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public static kotlin.enums.EnumEntries<com.yuyan.imemodule.data.flower.FlowerTypefaceMode> getEntries() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0006H\u0016\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/data/flower/FlowerTypefaceMode$Companion;", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$StringLikeCodec;", "Lcom/yuyan/imemodule/data/flower/FlowerTypefaceMode;", "()V", "decode", "raw", "", "yuyansdk_offlineDebug"})
    public static final class Companion implements com.yuyan.imemodule.view.preference.ManagedPreference.StringLikeCodec<com.yuyan.imemodule.data.flower.FlowerTypefaceMode> {
        
        private Companion() {
            super();
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public com.yuyan.imemodule.data.flower.FlowerTypefaceMode decode(@org.jetbrains.annotations.NotNull()
        java.lang.String raw) {
            return null;
        }
        
        @java.lang.Override()
        @org.jetbrains.annotations.NotNull()
        public java.lang.String encode(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.data.flower.FlowerTypefaceMode x) {
            return null;
        }
    }
}
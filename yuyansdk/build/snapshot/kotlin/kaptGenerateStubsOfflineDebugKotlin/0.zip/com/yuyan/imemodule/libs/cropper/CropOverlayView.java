package com.yuyan.imemodule.libs.cropper;

/**
 * A custom View representing the crop window and the shaded background outside the crop window.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u00a8\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0014\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0018\u0002\n\u0002\b\u0016\b\u0000\u0018\u0000 \u008c\u00012\u00020\u0001:\u0006\u008c\u0001\u008d\u0001\u008e\u0001B\u001b\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006J\u0010\u0010^\u001a\u00020.2\u0006\u0010\u001c\u001a\u00020\u001dH\u0002J\u0010\u0010_\u001a\u00020`2\u0006\u0010a\u001a\u00020bH\u0002J\u0010\u0010c\u001a\u00020`2\u0006\u0010a\u001a\u00020bH\u0002J(\u0010d\u001a\u00020`2\u0006\u0010a\u001a\u00020b2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010e\u001a\u00020\u00162\u0006\u0010f\u001a\u00020\u0016H\u0002J(\u0010g\u001a\u00020`2\u0006\u0010a\u001a\u00020b2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010h\u001a\u00020\u00162\u0006\u0010e\u001a\u00020\u0016H\u0002J0\u0010i\u001a\u00020`2\u0006\u0010a\u001a\u00020b2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010h\u001a\u00020\u00162\u0006\u0010e\u001a\u00020\u00162\u0006\u0010f\u001a\u00020\u0016H\u0002J\u0010\u0010j\u001a\u00020`2\u0006\u0010a\u001a\u00020bH\u0002J\u0010\u0010k\u001a\u00020`2\u0006\u0010a\u001a\u00020bH\u0002J\u0010\u0010l\u001a\u00020`2\u0006\u0010a\u001a\u00020bH\u0002J(\u0010m\u001a\u00020`2\u0006\u0010a\u001a\u00020b2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010h\u001a\u00020\u00162\u0006\u0010e\u001a\u00020\u0016H\u0002J\u0010\u0010n\u001a\u00020`2\u0006\u0010\u001c\u001a\u00020\u001dH\u0002J\u0006\u0010o\u001a\u00020`J\b\u0010p\u001a\u00020`H\u0002J\u0018\u0010q\u001a\u00020`2\u0006\u0010r\u001a\u00020\u00162\u0006\u0010s\u001a\u00020\u0016H\u0002J\u0018\u0010t\u001a\u00020`2\u0006\u0010r\u001a\u00020\u00162\u0006\u0010s\u001a\u00020\u0016H\u0002J\b\u0010u\u001a\u00020`H\u0002J\u0010\u0010v\u001a\u00020`2\u0006\u0010a\u001a\u00020bH\u0014J\u0010\u0010w\u001a\u00020.2\u0006\u0010x\u001a\u00020yH\u0017J\u0006\u0010z\u001a\u00020`J \u0010{\u001a\u00020`2\b\u0010|\u001a\u0004\u0018\u00010<2\u0006\u0010}\u001a\u00020\b2\u0006\u0010~\u001a\u00020\bJ\u000e\u0010\u007f\u001a\u00020`2\u0006\u0010\u0019\u001a\u00020\u0018J\u0012\u0010\u0080\u0001\u001a\u00020`2\t\u0010\u0081\u0001\u001a\u0004\u0018\u00010BJ+\u0010\u0082\u0001\u001a\u00020`2\u0007\u0010\u0083\u0001\u001a\u00020\u00162\u0007\u0010\u0084\u0001\u001a\u00020\u00162\u0007\u0010\u0085\u0001\u001a\u00020\u00162\u0007\u0010\u0086\u0001\u001a\u00020\u0016J\u0010\u0010\u0087\u0001\u001a\u00020`2\u0007\u0010\u0088\u0001\u001a\u00020.J\u0010\u0010\u0089\u0001\u001a\u00020`2\u0007\u0010\u008a\u0001\u001a\u00020RJ\t\u0010\u008b\u0001\u001a\u00020`H\u0003R$\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00020\b8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR$\u0010\r\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\b8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\u000e\u0010\n\"\u0004\b\u000f\u0010\fR\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\"\u0010\u0019\u001a\u0004\u0018\u00010\u00182\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR$\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001c\u001a\u00020\u001d8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b\u001f\u0010 \"\u0004\b!\u0010\"R\u0012\u0010#\u001a\u0004\u0018\u00010\bX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010$R\u0010\u0010%\u001a\u0004\u0018\u00010&X\u0082\u000e\u00a2\u0006\u0002\n\u0000R(\u0010(\u001a\u0004\u0018\u00010\'2\b\u0010\u001c\u001a\u0004\u0018\u00010\'8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b)\u0010*\"\u0004\b+\u0010,R\u000e\u0010-\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010/\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001e\u00100\u001a\u00020.2\u0006\u0010\u0017\u001a\u00020.@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u00101R\u0014\u00102\u001a\u00020.8BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b2\u00101R\u000e\u00103\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00104\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u00105\u001a\u0004\u0018\u000106X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u00108\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u00109\u001a\u0004\u0018\u000106X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010:\u001a\u0004\u0018\u000106X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010;\u001a\u00020<X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010=\u001a\u00020\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010>\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010?\u001a\u0004\u0018\u00010\bX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010$R\u000e\u0010@\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010A\u001a\u0004\u0018\u00010BX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010C\u001a\u00020DX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001b\u0010E\u001a\u0002068BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\bH\u0010I\u001a\u0004\bF\u0010GR\u000e\u0010J\u001a\u00020\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010K\u001a\u0004\u0018\u000106X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010L\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010M\u001a\u00020\'X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010N\u001a\u0004\u0018\u00010OX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010P\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010Q\u001a\u0004\u0018\u00010RX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010S\u001a\u00020TX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010U\u001a\u0004\u0018\u00010VX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010W\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010X\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010Y\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010Z\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010[\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\\\u001a\u00020\u0016X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010]\u001a\u0004\u0018\u000106X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u008f\u0001"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropOverlayView;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "aspectRatioX", "", "getAspectRatioX", "()I", "setAspectRatioX", "(I)V", "aspectRatioY", "getAspectRatioY", "setAspectRatioY", "cornerShape", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropCornerShape;", "cropLabelText", "", "cropLabelTextColor", "cropLabelTextSize", "", "<set-?>", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropShape;", "cropShape", "getCropShape", "()Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropShape;", "rect", "Landroid/graphics/RectF;", "cropWindowRect", "getCropWindowRect", "()Landroid/graphics/RectF;", "setCropWindowRect", "(Landroid/graphics/RectF;)V", "currentPointerId", "Ljava/lang/Integer;", "guidelines", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$Guidelines;", "Landroid/graphics/Rect;", "initialCropWindowRect", "getInitialCropWindowRect", "()Landroid/graphics/Rect;", "setInitialCropWindowRect", "(Landroid/graphics/Rect;)V", "initializedCropWindow", "", "isCropLabelEnabled", "isFixAspectRatio", "()Z", "isNonStraightAngleRotated", "mAspectRatioX", "mAspectRatioY", "mBackgroundPaint", "Landroid/graphics/Paint;", "mBorderCornerLength", "mBorderCornerOffset", "mBorderCornerPaint", "mBorderPaint", "mBoundsPoints", "", "mCalcBounds", "mCenterMoveEnabled", "mCircleCornerFillColor", "mCropCornerRadius", "mCropWindowChangeListener", "Lcom/yuyan/imemodule/libs/cropper/CropOverlayView$CropWindowChangeListener;", "mCropWindowHandler", "Lcom/yuyan/imemodule/libs/cropper/CropWindowHandler;", "mDashedBorderPaint", "getMDashedBorderPaint", "()Landroid/graphics/Paint;", "mDashedBorderPaint$delegate", "Lkotlin/Lazy;", "mDrawRect", "mGuidelinePaint", "mInitialCropWindowPaddingRatio", "mInitialCropWindowRect", "mMoveHandler", "Lcom/yuyan/imemodule/libs/cropper/CropWindowMoveHandler;", "mMultiTouchEnabled", "mOptions", "Lcom/yuyan/imemodule/libs/cropper/CropImageOptions;", "mPath", "Landroid/graphics/Path;", "mScaleDetector", "Landroid/view/ScaleGestureDetector;", "mSnapRadius", "mTargetAspectRatio", "mTouchRadius", "mViewHeight", "mViewWidth", "maxVerticalGestureExclusion", "textLabelPaint", "calculateBounds", "drawBackground", "", "canvas", "Landroid/graphics/Canvas;", "drawBorders", "drawCircleShape", "cornerExtension", "radius", "drawCornerBasedOnShape", "cornerOffset", "drawCornerShape", "drawCorners", "drawCropLabelText", "drawGuidelines", "drawLineShape", "fixCropWindowRectByRules", "fixCurrentCropWindowRect", "initCropWindow", "onActionDown", "x", "y", "onActionMove", "onActionUp", "onDraw", "onTouchEvent", "event", "Landroid/view/MotionEvent;", "resetCropOverlayView", "setBounds", "boundsPoints", "viewWidth", "viewHeight", "setCropShape", "setCropWindowChangeListener", "listener", "setCropWindowLimits", "maxWidth", "maxHeight", "scaleFactorWidth", "scaleFactorHeight", "setCropperTextLabelVisibility", "isEnabled", "setInitialAttributeValues", "options", "setSystemGestureExclusionRects", "Companion", "CropWindowChangeListener", "ScaleListener", "yuyansdk_offlineDebug"})
public final class CropOverlayView extends android.view.View {
    private float mCropCornerRadius = 0.0F;
    @org.jetbrains.annotations.Nullable()
    private java.lang.Integer mCircleCornerFillColor;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageOptions mOptions;
    
    /**
     * Gesture detector used for multitouch box scaling.
     */
    @org.jetbrains.annotations.Nullable()
    private android.view.ScaleGestureDetector mScaleDetector;
    
    /**
     * Boolean to see if multitouch is enabled for the crop rectangle.
     */
    private boolean mMultiTouchEnabled = false;
    
    /**
     * Boolean to see if movement via dragging center is enabled for the crop rectangle.
     */
    private boolean mCenterMoveEnabled = true;
    
    /**
     * Handler from crop window stuff, moving and knowing position.
     */
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.libs.cropper.CropWindowHandler mCropWindowHandler = null;
    
    /**
     * Listener to public crop window changes.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropOverlayView.CropWindowChangeListener mCropWindowChangeListener;
    
    /**
     * Rectangle used for drawing.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.RectF mDrawRect = null;
    
    /**
     * The Paint used to draw the white rectangle around the crop area.
     */
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Paint mBorderPaint;
    
    /**
     * The Paint used to draw the corners of the Border.
     */
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Paint mBorderCornerPaint;
    
    /**
     * The Paint used to draw the guidelines within the crop area when pressed.
     */
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Paint mGuidelinePaint;
    
    /**
     * The Paint used to darken the surrounding areas outside the crop area.
     */
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Paint mBackgroundPaint;
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Paint textLabelPaint;
    
    /**
     * Currently moving pointer used to stop movement event
     * when initial pointer was released
     * (to avoid crop overlay jumps)
     */
    @org.jetbrains.annotations.Nullable()
    private java.lang.Integer currentPointerId;
    
    /**
     * Used for oval crop window shape or non-straight rotation drawing.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Path mPath = null;
    
    /**
     * The bounding box around the Bitmap that we are cropping.
     */
    @org.jetbrains.annotations.NotNull()
    private final float[] mBoundsPoints = null;
    
    /**
     * The bounding box around the Bitmap that we are cropping.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.RectF mCalcBounds = null;
    
    /**
     * The bounding image view width used to know the crop overlay is at view edges.
     */
    private int mViewWidth = 0;
    
    /**
     * The bounding image view height used to know the crop overlay is at view edges.
     */
    private int mViewHeight = 0;
    
    /**
     * The offset to draw the border corner from the border.
     */
    private float mBorderCornerOffset = 0.0F;
    
    /**
     * The length of the border corner to draw.
     */
    private float mBorderCornerLength = 0.0F;
    
    /**
     * The initial crop window padding from image borders.
     */
    private float mInitialCropWindowPaddingRatio = 0.0F;
    
    /**
     * The radius of the touch zone (in pixels) around a given Handle.
     */
    private float mTouchRadius = 0.0F;
    
    /**
     * An edge of the crop window will snap to the corresponding edge of a specified bounding box when
     * the crop window edge is less than or equal to this distance (in pixels) away from the bounding
     * box edge.
     */
    private float mSnapRadius = 0.0F;
    
    /**
     * The Handle that is currently pressed; null if no Handle is pressed.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropWindowMoveHandler mMoveHandler;
    
    /**
     * Flag indicating if the crop area should always be a certain aspect ratio (indicated by
     * mTargetAspectRatio).
     */
    private boolean isFixAspectRatio = false;
    
    /**
     * Save the current aspect ratio of the image.
     */
    private int mAspectRatioX = 0;
    
    /**
     * Save the current aspect ratio of the image.
     */
    private int mAspectRatioY = 0;
    
    /**
     * The aspect ratio that the crop area should maintain; this variable is only used when
     * mMaintainAspectRatio is true.
     */
    private float mTargetAspectRatio;
    
    /**
     * Instance variables for customizable attributes.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines;
    
    /**
     * The shape of the cropping area - rectangle/circular.
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape;
    
    /**
     * The shape of the crop corner
     */
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape;
    
    /**
     * To show the text label over crop overlay
     */
    private boolean isCropLabelEnabled = false;
    
    /**
     * Text to show over text label over crop overlay.
     */
    @org.jetbrains.annotations.NotNull()
    private java.lang.String cropLabelText = "";
    
    /**
     * Text color to apply over text label over crop overlay.
     */
    private float cropLabelTextSize = 20.0F;
    
    /**
     * Text color to apply over text label over crop overlay.
     */
    private int cropLabelTextColor = android.graphics.Color.WHITE;
    
    /**
     * The initial crop window rectangle to set.
     */
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Rect mInitialCropWindowRect = null;
    
    /**
     * Whether the Crop View has been initialized for the first time.
     */
    private boolean initializedCropWindow = false;
    
    /**
     * The maximum vertical gesture exclusion allowed by Android (200dp) in px.
     */
    private final float maxVerticalGestureExclusion = 0.0F;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy mDashedBorderPaint$delegate = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.cropper.CropOverlayView.Companion Companion = null;
    
    @kotlin.jvm.JvmOverloads()
    public CropOverlayView(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null);
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropOverlayView(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null);
    }
    
    /**
     * Flag indicating if the crop area should always be a certain aspect ratio (indicated by
     * mTargetAspectRatio).
     */
    public final boolean isFixAspectRatio() {
        return false;
    }
    
    /**
     * The shape of the cropping area - rectangle/circular.
     */
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.libs.cropper.CropImageView.CropShape getCropShape() {
        return null;
    }
    
    /**
     * Set the crop window change listener.
     */
    public final void setCropWindowChangeListener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.libs.cropper.CropOverlayView.CropWindowChangeListener listener) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.RectF getCropWindowRect() {
        return null;
    }
    
    public final void setCropWindowRect(@org.jetbrains.annotations.NotNull()
    android.graphics.RectF rect) {
    }
    
    /**
     * Fix the current crop window rectangle if it is outside of cropping image or view bounds.
     */
    public final void fixCurrentCropWindowRect() {
    }
    
    /**
     * Informs the CropOverlayView of the image's position relative to the ImageView. This is
     * necessary to call in order to draw the crop window.
     *
     * [boundsPoints] the image's bounding points
     * [viewWidth] The bounding image view width.
     * [viewHeight] The bounding image view height.
     */
    public final void setBounds(@org.jetbrains.annotations.Nullable()
    float[] boundsPoints, int viewWidth, int viewHeight) {
    }
    
    /**
     * Resets the crop overlay view.
     */
    public final void resetCropOverlayView() {
    }
    
    /**
     * The shape of the cropping area - rectangle/circular.
     */
    public final void setCropShape(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape) {
    }
    
    /**
     * Sets the cropper label if it is enabled
     */
    public final void setCropperTextLabelVisibility(boolean isEnabled) {
    }
    
    public final int getAspectRatioX() {
        return 0;
    }
    
    public final void setAspectRatioX(int aspectRatioX) {
    }
    
    public final int getAspectRatioY() {
        return 0;
    }
    
    public final void setAspectRatioY(int aspectRatioY) {
    }
    
    /**
     * set the max width/height and scale factor of the shown image to original image to scale the
     * limits appropriately.
     */
    public final void setCropWindowLimits(float maxWidth, float maxHeight, float scaleFactorWidth, float scaleFactorHeight) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final android.graphics.Rect getInitialCropWindowRect() {
        return null;
    }
    
    public final void setInitialCropWindowRect(@org.jetbrains.annotations.Nullable()
    android.graphics.Rect rect) {
    }
    
    /**
     * Sets all initial values, but does not call initCropWindow to reset the views.<br></br>
     * Used once at the very start to initialize the attributes.
     */
    public final void setInitialAttributeValues(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageOptions options) {
    }
    
    /**
     * Set the initial crop window size and position. This is dependent on the size and position of
     * the image being cropped.
     */
    private final void initCropWindow() {
    }
    
    /**
     * Fix the given rect to fit into bitmap rect and follow min, max and aspect ratio rules.
     */
    private final void fixCropWindowRectByRules(android.graphics.RectF rect) {
    }
    
    /**
     * Draw crop overview by drawing background over image not in the cropping area, then borders and
     * guidelines.
     */
    @java.lang.Override()
    protected void onDraw(@org.jetbrains.annotations.NotNull()
    android.graphics.Canvas canvas) {
    }
    
    /**
     * Newer Android phones let you go back by swiping from the left or right edge of the screen inwards.
     * When the crop window is near the edge it's easy to accidentally swipe back when trying to resize it.
     * This can be prevented by setting systemGestureExclusionRects. However, Android lets you only exclude max 200dp in total vertically.
     * Therefore, a top, middle and bottom strip are used so at least the corners and the vertical middle of the crop window are covered.
     */
    @androidx.annotation.RequiresApi(value = android.os.Build.VERSION_CODES.Q)
    private final void setSystemGestureExclusionRects() {
    }
    
    /**
     * Draws a text label (which can acts an helper text) on top of crop overlay
     */
    private final void drawCropLabelText(android.graphics.Canvas canvas) {
    }
    
    /**
     * Draw shadow background over the image not including the crop area.
     */
    private final void drawBackground(android.graphics.Canvas canvas) {
    }
    
    /**
     * Draw 2 vertical and 2 horizontal guidelines inside the cropping area to split it into 9 equal
     * parts.
     */
    private final void drawGuidelines(android.graphics.Canvas canvas) {
    }
    
    private final android.graphics.Paint getMDashedBorderPaint() {
        return null;
    }
    
    /**
     * Draw borders of the crop area.
     */
    private final void drawBorders(android.graphics.Canvas canvas) {
    }
    
    /**
     * Draw the corner of crop overlay.
     */
    private final void drawCorners(android.graphics.Canvas canvas) {
    }
    
    /**
     * Draw corners of crop overlay based on crop shape.
     * In case of RECTANGLE crop shape call [drawCornerShape], to handle the corner draw based on
     * crop corner shape.
     */
    private final void drawCornerBasedOnShape(android.graphics.Canvas canvas, android.graphics.RectF rect, float cornerOffset, float cornerExtension) {
    }
    
    /**
     * Draws rectangle shape corners
     */
    private final void drawLineShape(android.graphics.Canvas canvas, android.graphics.RectF rect, float cornerOffset, float cornerExtension) {
    }
    
    /**
     * Based on corner shape calls either [drawCircleShape] or [drawLineShape]
     */
    private final void drawCornerShape(android.graphics.Canvas canvas, android.graphics.RectF rect, float cornerOffset, float cornerExtension, float radius) {
    }
    
    /**
     * Draws circle shape corners
     */
    private final void drawCircleShape(android.graphics.Canvas canvas, android.graphics.RectF rect, float cornerExtension, float radius) {
    }
    
    @java.lang.Override()
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public boolean onTouchEvent(@org.jetbrains.annotations.NotNull()
    android.view.MotionEvent event) {
        return false;
    }
    
    /**
     * On press down start crop window movement depending on the location of the press.<br></br>
     * if press is far from crop window then no move handler is returned (null).
     */
    private final void onActionDown(float x, float y) {
    }
    
    /**
     * Clear move handler starting in [onActionDown] if exists.
     */
    private final void onActionUp() {
    }
    
    /**
     * Handle move of crop window using the move handler created in [onActionDown].<br></br>
     * The move handler will do the proper move/resize of the crop window.
     */
    private final void onActionMove(float x, float y) {
    }
    
    /**
     * Calculate the bounding rectangle for current crop window, handle non-straight rotation angles.
     * <br></br>
     * If the rotation angle is straight then the bounds rectangle is the bitmap rectangle, otherwise
     * we find the max rectangle that is within the image bounds starting from the crop window
     * rectangle.
     *
     * [rect] the crop window rectangle to start finsing bounded rectangle from
     * @return true - non-straight rotation in place, false - otherwise.
     */
    private final boolean calculateBounds(android.graphics.RectF rect) {
        return false;
    }
    
    private final boolean isNonStraightAngleRotated() {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0080\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0015\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0000\u00a2\u0006\u0002\b\u0007J\u001f\u0010\b\u001a\u0004\u0018\u00010\u00042\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u0006H\u0000\u00a2\u0006\u0002\b\u000bJ\u0015\u0010\f\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0000\u00a2\u0006\u0002\b\rJ\u0015\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u0010H\u0000\u00a2\u0006\u0002\b\u0011\u00a8\u0006\u0012"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropOverlayView$Companion;", "", "()V", "getNewPaint", "Landroid/graphics/Paint;", "color", "", "getNewPaint$yuyansdk_offlineDebug", "getNewPaintOrNull", "thickness", "", "getNewPaintOrNull$yuyansdk_offlineDebug", "getNewPaintWithFill", "getNewPaintWithFill$yuyansdk_offlineDebug", "getTextPaint", "options", "Lcom/yuyan/imemodule/libs/cropper/CropImageOptions;", "getTextPaint$yuyansdk_offlineDebug", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        /**
         * Creates the paint object for drawing text label over crop overlay.
         */
        @org.jetbrains.annotations.NotNull()
        public final android.graphics.Paint getTextPaint$yuyansdk_offlineDebug(@org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.libs.cropper.CropImageOptions options) {
            return null;
        }
        
        /**
         * Creates the Paint object for drawing.
         */
        @org.jetbrains.annotations.NotNull()
        public final android.graphics.Paint getNewPaint$yuyansdk_offlineDebug(int color) {
            return null;
        }
        
        /**
         * Creates the Paint object for given thickness and color, if thickness < 0 return null.
         */
        @org.jetbrains.annotations.Nullable()
        public final android.graphics.Paint getNewPaintOrNull$yuyansdk_offlineDebug(float thickness, int color) {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final android.graphics.Paint getNewPaintWithFill$yuyansdk_offlineDebug(int color) {
            return null;
        }
    }
    
    /**
     * Interface definition for a callback to be invoked when crop window rectangle is changing.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u00e0\u0080\u0001\u0018\u00002\u00020\u0001J\u0010\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H&\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropOverlayView$CropWindowChangeListener;", "", "onCropWindowChanged", "", "inProgress", "", "yuyansdk_offlineDebug"})
    public static abstract interface CropWindowChangeListener {
        
        /**
         * Called after a change in crop window rectangle.
         *
         * [inProgress] if the crop window change operation is still in progress by user touch
         */
        public abstract void onCropWindowChanged(boolean inProgress);
    }
    
    /**
     * Handle scaling the rectangle based on two finger input.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0016\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropOverlayView$ScaleListener;", "Landroid/view/ScaleGestureDetector$SimpleOnScaleGestureListener;", "(Lcom/yuyan/imemodule/libs/cropper/CropOverlayView;)V", "onScale", "", "detector", "Landroid/view/ScaleGestureDetector;", "yuyansdk_offlineDebug"})
    final class ScaleListener extends android.view.ScaleGestureDetector.SimpleOnScaleGestureListener {
        
        public ScaleListener() {
            super();
        }
        
        @java.lang.Override()
        public boolean onScale(@org.jetbrains.annotations.NotNull()
        android.view.ScaleGestureDetector detector) {
            return false;
        }
    }
}
package com.yuyan.imemodule.adapter;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\b\u0007\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0003,-.B\u001d\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\u0002\u0010\bJ\b\u0010\u001d\u001a\u00020\u001cH\u0016J\u0010\u0010\u001e\u001a\u00020\u001f2\u0006\u0010\u0005\u001a\u00020\u0007H\u0002J\u001c\u0010 \u001a\u00020!2\n\u0010\"\u001a\u00060\u0002R\u00020\u00002\u0006\u0010#\u001a\u00020\u001cH\u0017J\u001c\u0010$\u001a\u00060\u0002R\u00020\u00002\u0006\u0010%\u001a\u00020&2\u0006\u0010\'\u001a\u00020\u001cH\u0016J\u0010\u0010(\u001a\u00020!2\b\u0010)\u001a\u0004\u0018\u00010\u0016J\u0010\u0010*\u001a\u00020!2\b\u0010+\u001a\u0004\u0018\u00010\u0018R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u001c\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006/"}, d2 = {"Lcom/yuyan/imemodule/adapter/MenuAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/adapter/MenuAdapter$SymbolHolder;", "context", "Landroid/content/Context;", "data", "", "Lcom/yuyan/imemodule/entity/SkbFunItem;", "(Landroid/content/Context;Ljava/util/List;)V", "background", "Landroid/graphics/drawable/GradientDrawable;", "getData", "()Ljava/util/List;", "dragOverListener", "Lcom/yuyan/imemodule/adapter/MenuAdapter$DragOverListener;", "getDragOverListener", "()Lcom/yuyan/imemodule/adapter/MenuAdapter$DragOverListener;", "setDragOverListener", "(Lcom/yuyan/imemodule/adapter/MenuAdapter$DragOverListener;)V", "inflater", "Landroid/view/LayoutInflater;", "mOnItemClickListener", "Lcom/yuyan/imemodule/callback/OnRecyclerItemClickListener;", "mOnItemLongClickListener", "Lcom/yuyan/imemodule/adapter/MenuAdapter$OnRecyclerItemLongClickListener;", "mTheme", "Lcom/yuyan/imemodule/data/theme/Theme;", "textColor", "", "getItemCount", "isSettingsMenuSelect", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setOnItemClickLitener", "mOnItemClickLitener", "setOnItemLongClickListener", "listener", "DragOverListener", "OnRecyclerItemLongClickListener", "SymbolHolder", "yuyansdk_offlineDebug"})
public final class MenuAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.adapter.MenuAdapter.SymbolHolder> {
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> data = null;
    @org.jetbrains.annotations.NotNull()
    private final android.view.LayoutInflater inflater = null;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.callback.OnRecyclerItemClickListener mOnItemClickListener;
    private final int textColor = 0;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.data.theme.Theme mTheme;
    @org.jetbrains.annotations.NotNull()
    private android.graphics.drawable.GradientDrawable background;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.adapter.MenuAdapter.OnRecyclerItemLongClickListener mOnItemLongClickListener;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.adapter.MenuAdapter.DragOverListener dragOverListener;
    
    public MenuAdapter(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    java.util.List<com.yuyan.imemodule.entity.SkbFunItem> data) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.entity.SkbFunItem> getData() {
        return null;
    }
    
    public final void setOnItemClickLitener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.callback.OnRecyclerItemClickListener mOnItemClickLitener) {
    }
    
    public final void setOnItemLongClickListener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.adapter.MenuAdapter.OnRecyclerItemLongClickListener listener) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.adapter.MenuAdapter.DragOverListener getDragOverListener() {
        return null;
    }
    
    public final void setDragOverListener(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.adapter.MenuAdapter.DragOverListener p0) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.adapter.MenuAdapter.SymbolHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    @java.lang.Override()
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.adapter.MenuAdapter.SymbolHolder holder, int position) {
    }
    
    private final boolean isSettingsMenuSelect(com.yuyan.imemodule.entity.SkbFunItem data) {
        return false;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J&\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH&J\u0010\u0010\n\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\fH&\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/adapter/MenuAdapter$DragOverListener;", "", "onOptionClick", "", "parent", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "v", "Lcom/yuyan/imemodule/entity/SkbFunItem;", "position", "", "startDragItem", "holder", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "yuyansdk_offlineDebug"})
    public static abstract interface DragOverListener {
        
        public abstract void startDragItem(@org.jetbrains.annotations.NotNull()
        androidx.recyclerview.widget.RecyclerView.ViewHolder holder);
        
        public abstract void onOptionClick(@org.jetbrains.annotations.Nullable()
        androidx.recyclerview.widget.RecyclerView.Adapter<?> parent, @org.jetbrains.annotations.NotNull()
        com.yuyan.imemodule.entity.SkbFunItem v, int position);
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u00e6\u0080\u0001\u0018\u00002\u00020\u0001J(\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0002\b\u0003\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\tH&\u00a8\u0006\n"}, d2 = {"Lcom/yuyan/imemodule/adapter/MenuAdapter$OnRecyclerItemLongClickListener;", "", "onItemLongClick", "", "parent", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "view", "Landroid/view/View;", "position", "", "yuyansdk_offlineDebug"})
    public static abstract interface OnRecyclerItemLongClickListener {
        
        public abstract boolean onItemLongClick(@org.jetbrains.annotations.Nullable()
        androidx.recyclerview.widget.RecyclerView.Adapter<?> parent, @org.jetbrains.annotations.Nullable()
        android.view.View view, int position);
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u001c\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0007\u0010\b\"\u0004\b\t\u0010\nR\u001c\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010R\u001c\u0010\u0011\u001a\u0004\u0018\u00010\u0006X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\b\"\u0004\b\u0013\u0010\n\u00a8\u0006\u0014"}, d2 = {"Lcom/yuyan/imemodule/adapter/MenuAdapter$SymbolHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "view", "Landroid/view/View;", "(Lcom/yuyan/imemodule/adapter/MenuAdapter;Landroid/view/View;)V", "entranceIconImageView", "Landroid/widget/ImageView;", "getEntranceIconImageView", "()Landroid/widget/ImageView;", "setEntranceIconImageView", "(Landroid/widget/ImageView;)V", "entranceNameTextView", "Landroid/widget/TextView;", "getEntranceNameTextView", "()Landroid/widget/TextView;", "setEntranceNameTextView", "(Landroid/widget/TextView;)V", "entranceOption", "getEntranceOption", "setEntranceOption", "yuyansdk_offlineDebug"})
    public final class SymbolHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.Nullable()
        private android.widget.TextView entranceNameTextView;
        @org.jetbrains.annotations.Nullable()
        private android.widget.ImageView entranceIconImageView;
        @org.jetbrains.annotations.Nullable()
        private android.widget.ImageView entranceOption;
        
        public SymbolHolder(@org.jetbrains.annotations.NotNull()
        android.view.View view) {
            super(null);
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.widget.TextView getEntranceNameTextView() {
            return null;
        }
        
        public final void setEntranceNameTextView(@org.jetbrains.annotations.Nullable()
        android.widget.TextView p0) {
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.widget.ImageView getEntranceIconImageView() {
            return null;
        }
        
        public final void setEntranceIconImageView(@org.jetbrains.annotations.Nullable()
        android.widget.ImageView p0) {
        }
        
        @org.jetbrains.annotations.Nullable()
        public final android.widget.ImageView getEntranceOption() {
            return null;
        }
        
        public final void setEntranceOption(@org.jetbrains.annotations.Nullable()
        android.widget.ImageView p0) {
        }
    }
}
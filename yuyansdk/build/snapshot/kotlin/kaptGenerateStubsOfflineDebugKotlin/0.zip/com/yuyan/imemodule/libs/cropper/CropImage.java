package com.yuyan.imemodule.libs.cropper;

/**
 * Helper to simplify crop image work like starting pick-image activity and handling camera/gallery
 * intents.<br></br>
 * The goal of the helper is to simplify the starting and most-common usage of image cropping and
 * not all-purpose all possible scenario one-to-rule-them-all code base. So feel free to use it as
 * is and as a wiki to make your own.<br></br>
 * Added value you get out-of-the-box is some edge case handling that you may miss otherwise, like
 * the stupid-ass Android camera result URI that may differ from version to version and from device
 * to device.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\b\u00c7\u0002\u0018\u00002\u00020\u0001:\u0002\n\u000bB\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImage;", "", "()V", "CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE", "", "CROP_IMAGE_EXTRA_BUNDLE", "", "CROP_IMAGE_EXTRA_OPTIONS", "CROP_IMAGE_EXTRA_RESULT", "CROP_IMAGE_EXTRA_SOURCE", "ActivityResult", "CancelledResult", "yuyansdk_offlineDebug"})
public final class CropImage {
    
    /**
     * The key used to pass crop image source URI to [CropImageActivity].
     */
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String CROP_IMAGE_EXTRA_SOURCE = "CROP_IMAGE_EXTRA_SOURCE";
    
    /**
     * The key used to pass crop image options to [CropImageActivity].
     */
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String CROP_IMAGE_EXTRA_OPTIONS = "CROP_IMAGE_EXTRA_OPTIONS";
    
    /**
     * The key used to pass crop image bundle data to [CropImageActivity].
     */
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String CROP_IMAGE_EXTRA_BUNDLE = "CROP_IMAGE_EXTRA_BUNDLE";
    
    /**
     * The key used to pass crop image result data back from [CropImageActivity].
     */
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String CROP_IMAGE_EXTRA_RESULT = "CROP_IMAGE_EXTRA_RESULT";
    
    /**
     * The result code used to return error from [CropImageActivity].
     */
    public static final int CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE = 204;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.cropper.CropImage INSTANCE = null;
    
    private CropImage() {
        super();
    }
    
    /**
     * Result data of Crop Image Activity.
     */
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0017\u0018\u0000 \u001a2\u00020\u00012\u00020\u0002:\u0001\u001aBY\b\u0016\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u000e\u0010\u0006\u001a\n\u0018\u00010\u0007j\u0004\u0018\u0001`\b\u0012\b\u0010\t\u001a\u0004\u0018\u00010\n\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\f\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\f\u0012\u0006\u0010\u0010\u001a\u00020\u000e\u00a2\u0006\u0002\u0010\u0011B\u000f\b\u0014\u0012\u0006\u0010\u0012\u001a\u00020\u0013\u00a2\u0006\u0002\u0010\u0014J\b\u0010\u0015\u001a\u00020\u000eH\u0016J\u0018\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u000eH\u0016\u00a8\u0006\u001b"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImage$ActivityResult;", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropResult;", "Landroid/os/Parcelable;", "originalUri", "Landroid/net/Uri;", "uriContent", "error", "Ljava/lang/Exception;", "Lkotlin/Exception;", "cropPoints", "", "cropRect", "Landroid/graphics/Rect;", "rotation", "", "wholeImageRect", "sampleSize", "(Landroid/net/Uri;Landroid/net/Uri;Ljava/lang/Exception;[FLandroid/graphics/Rect;ILandroid/graphics/Rect;I)V", "in", "Landroid/os/Parcel;", "(Landroid/os/Parcel;)V", "describeContents", "writeToParcel", "", "dest", "flags", "Companion", "yuyansdk_offlineDebug"})
    public static class ActivityResult extends com.yuyan.imemodule.libs.cropper.CropImageView.CropResult implements android.os.Parcelable {
        @kotlin.jvm.JvmField()
        @org.jetbrains.annotations.NotNull()
        public static final android.os.Parcelable.Creator<com.yuyan.imemodule.libs.cropper.CropImage.ActivityResult> CREATOR = null;
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.libs.cropper.CropImage.ActivityResult.Companion Companion = null;
        
        public ActivityResult(@org.jetbrains.annotations.Nullable()
        android.net.Uri originalUri, @org.jetbrains.annotations.Nullable()
        android.net.Uri uriContent, @org.jetbrains.annotations.Nullable()
        java.lang.Exception error, @org.jetbrains.annotations.Nullable()
        float[] cropPoints, @org.jetbrains.annotations.Nullable()
        android.graphics.Rect cropRect, int rotation, @org.jetbrains.annotations.Nullable()
        android.graphics.Rect wholeImageRect, int sampleSize) {
            super(null, null, null, null, null, null, null, 0, 0);
        }
        
        @kotlin.Suppress(names = {"DEPRECATION"})
        protected ActivityResult(@org.jetbrains.annotations.NotNull()
        android.os.Parcel in) {
            super(null, null, null, null, null, null, null, 0, 0);
        }
        
        @java.lang.Override()
        public void writeToParcel(@org.jetbrains.annotations.NotNull()
        android.os.Parcel dest, int flags) {
        }
        
        @java.lang.Override()
        public int describeContents() {
            return 0;
        }
        
        @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0018\u0010\u0003\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u00048\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImage$ActivityResult$Companion;", "", "()V", "CREATOR", "Landroid/os/Parcelable$Creator;", "Lcom/yuyan/imemodule/libs/cropper/CropImage$ActivityResult;", "yuyansdk_offlineDebug"})
        public static final class Companion {
            
            private Companion() {
                super();
            }
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImage$CancelledResult;", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropResult;", "()V", "yuyansdk_offlineDebug"})
    public static final class CancelledResult extends com.yuyan.imemodule.libs.cropper.CropImageView.CropResult {
        @org.jetbrains.annotations.NotNull()
        public static final com.yuyan.imemodule.libs.cropper.CropImage.CancelledResult INSTANCE = null;
        
        private CancelledResult() {
            super(null, null, null, null, null, null, null, 0, 0);
        }
    }
}
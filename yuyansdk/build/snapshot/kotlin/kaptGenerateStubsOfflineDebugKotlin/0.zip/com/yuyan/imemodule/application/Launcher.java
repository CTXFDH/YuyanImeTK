package com.yuyan.imemodule.application;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000 \f2\u00020\u0001:\u0001\fB\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\b\u001a\u00020\tH\u0002J\u000e\u0010\n\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u0004J\b\u0010\u000b\u001a\u00020\tH\u0002R\u001e\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0004@BX\u0086.\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/application/Launcher;", "", "()V", "<set-?>", "Landroid/content/Context;", "context", "getContext", "()Landroid/content/Context;", "currentInit", "", "initData", "onInitDataChildThread", "Companion", "yuyansdk_offlineDebug"})
public final class Launcher {
    private android.content.Context context;
    @android.annotation.SuppressLint(value = {"StaticFieldLeak"})
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.application.Launcher instance = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.application.Launcher.Companion Companion = null;
    
    public Launcher() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.content.Context getContext() {
        return null;
    }
    
    public final void initData(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    private final void currentInit() {
    }
    
    /**
     * 可以在子线程初始化的操作
     */
    private final void onInitDataChildThread() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0016\u0010\u0003\u001a\u00020\u00048\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/application/Launcher$Companion;", "", "()V", "instance", "Lcom/yuyan/imemodule/application/Launcher;", "getInstance", "()Lcom/yuyan/imemodule/application/Launcher;", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.application.Launcher getInstance() {
            return null;
        }
    }
}
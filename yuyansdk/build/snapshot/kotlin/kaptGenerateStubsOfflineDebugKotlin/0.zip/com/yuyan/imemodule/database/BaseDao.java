package com.yuyan.imemodule.database;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0002\bg\u0018\u0000*\u0004\b\u0000\u0010\u00012\u00020\u0002J\u0015\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00028\u0000H\'\u00a2\u0006\u0002\u0010\u0006J\u0015\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00028\u0000H\'\u00a2\u0006\u0002\u0010\u0006J\u0016\u0010\b\u001a\u00020\u00042\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00000\tH\'J\u0015\u0010\n\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00028\u0000H\'\u00a2\u0006\u0002\u0010\u0006\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/database/BaseDao;", "T", "", "delete", "", "bean", "(Ljava/lang/Object;)V", "insert", "insertAll", "", "update", "yuyansdk_offlineDebug"})
@androidx.room.Dao()
public abstract interface BaseDao<T extends java.lang.Object> {
    
    @androidx.room.Insert(onConflict = 1)
    public abstract void insert(T bean);
    
    @androidx.room.Insert(onConflict = 1)
    public abstract void insertAll(@org.jetbrains.annotations.NotNull()
    java.util.List<? extends T> bean);
    
    @androidx.room.Delete()
    public abstract void delete(T bean);
    
    @androidx.room.Update()
    public abstract void update(T bean);
}
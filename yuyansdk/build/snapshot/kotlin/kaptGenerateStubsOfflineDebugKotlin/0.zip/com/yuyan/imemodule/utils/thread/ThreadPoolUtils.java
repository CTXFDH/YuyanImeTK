package com.yuyan.imemodule.utils.thread;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0007\u0018\u0000 \u00032\u00020\u0001:\u0001\u0003B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0004"}, d2 = {"Lcom/yuyan/imemodule/utils/thread/ThreadPoolUtils;", "", "()V", "Companion", "yuyansdk_offlineDebug"})
public final class ThreadPoolUtils {
    
    /**
     * 默认线程池
     */
    @org.jetbrains.annotations.Nullable()
    private static java.util.concurrent.ThreadPoolExecutor DEFAULT_EXECUTOR;
    
    /**
     * 单线程线程池
     */
    @org.jetbrains.annotations.Nullable()
    private static java.util.concurrent.ThreadPoolExecutor SINGLETON_EXECUTOR;
    
    /**
     * 定时任务线程池
     */
    @org.jetbrains.annotations.Nullable()
    private static java.util.concurrent.ScheduledThreadPoolExecutor SCHEDULED_EXECUTOR;
    
    /**
     * 定时任务线程池 (创建守护线程执行)
     */
    @org.jetbrains.annotations.Nullable()
    private static java.util.concurrent.ScheduledThreadPoolExecutor SCHEDULED_DAEMON_EXECUTOR;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.thread.ThreadPoolUtils.Companion Companion = null;
    
    private ThreadPoolUtils() {
        super();
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0012\u0010\t\u001a\u00020\n2\n\u0010\u000b\u001a\u0006\u0012\u0002\b\u00030\fJ\u0010\u0010\r\u001a\u00020\n2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fJ\u0010\u0010\u0010\u001a\u00020\n2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000fJ\u0018\u0010\u0011\u001a\u00020\u00062\b\u0010\u0012\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0014\u001a\u00020\u0015J\u0010\u0010\u0016\u001a\u00020\u00042\b\u0010\u0012\u001a\u0004\u0018\u00010\u0013J&\u0010\u0017\u001a\u0006\u0012\u0002\b\u00030\u00182\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cJ.\u0010\u001d\u001a\u0006\u0012\u0002\b\u00030\u00182\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u001e\u001a\u00020\u001a2\u0006\u0010\u001f\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cJ.\u0010 \u001a\u0006\u0012\u0002\b\u00030\u00182\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u001e\u001a\u00020\u001a2\u0006\u0010\u001f\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cJ&\u0010!\u001a\u0006\u0012\u0002\b\u00030\u00182\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u001cR\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\""}, d2 = {"Lcom/yuyan/imemodule/utils/thread/ThreadPoolUtils$Companion;", "", "()V", "DEFAULT_EXECUTOR", "Ljava/util/concurrent/ThreadPoolExecutor;", "SCHEDULED_DAEMON_EXECUTOR", "Ljava/util/concurrent/ScheduledThreadPoolExecutor;", "SCHEDULED_EXECUTOR", "SINGLETON_EXECUTOR", "cancel", "", "future", "Ljava/util/concurrent/Future;", "execute", "runnable", "Ljava/lang/Runnable;", "executeSingleton", "newScheduledExecutor", "threadPoolName", "", "daemon", "", "newSingletonExecutor", "schedule", "Ljava/util/concurrent/ScheduledFuture;", "delay", "", "unit", "Ljava/util/concurrent/TimeUnit;", "scheduleAtFixedRate", "initialDelay", "period", "scheduleAtFixedRateInDaemon", "scheduleInDaemon", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        public final void execute(@org.jetbrains.annotations.Nullable()
        java.lang.Runnable runnable) {
        }
        
        public final void executeSingleton(@org.jetbrains.annotations.Nullable()
        java.lang.Runnable runnable) {
        }
        
        /**
         * 调用线程池执行定时任务
         *
         * @param runnable 任务
         * @param delay    启动延迟
         * @param unit     启动延迟的时间单位
         */
        @org.jetbrains.annotations.NotNull()
        public final java.util.concurrent.ScheduledFuture<?> schedule(@org.jetbrains.annotations.Nullable()
        java.lang.Runnable runnable, long delay, @org.jetbrains.annotations.Nullable()
        java.util.concurrent.TimeUnit unit) {
            return null;
        }
        
        /**
         * 调用线程池执行定时的周期任务
         *
         * @param runnable     任务
         * @param initialDelay 启动延迟, millseconds
         * @param period       执行周期
         * @param unit         执行周期时间单位
         */
        @org.jetbrains.annotations.NotNull()
        public final java.util.concurrent.ScheduledFuture<?> scheduleAtFixedRate(@org.jetbrains.annotations.Nullable()
        java.lang.Runnable runnable, long initialDelay, long period, @org.jetbrains.annotations.Nullable()
        java.util.concurrent.TimeUnit unit) {
            return null;
        }
        
        /**
         * 调用线程池执行定时任务 (在守护线程中执行)
         *
         * @param runnable 任务
         * @param delay    启动延迟
         * @param unit     启动延迟的时间单位
         */
        @org.jetbrains.annotations.NotNull()
        public final java.util.concurrent.ScheduledFuture<?> scheduleInDaemon(@org.jetbrains.annotations.Nullable()
        java.lang.Runnable runnable, long delay, @org.jetbrains.annotations.Nullable()
        java.util.concurrent.TimeUnit unit) {
            return null;
        }
        
        /**
         * 调用线程池执行定时的周期任务 (在守护线程中执行)
         *
         * @param runnable     任务
         * @param initialDelay 启动延迟, millseconds
         * @param period       执行周期
         * @param unit         执行周期时间单位
         */
        @org.jetbrains.annotations.NotNull()
        public final java.util.concurrent.ScheduledFuture<?> scheduleAtFixedRateInDaemon(@org.jetbrains.annotations.Nullable()
        java.lang.Runnable runnable, long initialDelay, long period, @org.jetbrains.annotations.Nullable()
        java.util.concurrent.TimeUnit unit) {
            return null;
        }
        
        /**
         * 创建一个单线程线程池
         *
         * @param threadPoolName 线程池名称
         * @return 新创建的单线程线程池
         */
        @org.jetbrains.annotations.NotNull()
        public final java.util.concurrent.ThreadPoolExecutor newSingletonExecutor(@org.jetbrains.annotations.Nullable()
        java.lang.String threadPoolName) {
            return null;
        }
        
        /**
         * 创建一个定时任务程线程池
         *
         * @param threadPoolName 线程池名称
         * @param daemon         是否为守护线程
         * @return 新创建的定时任务线程池
         */
        @org.jetbrains.annotations.NotNull()
        public final java.util.concurrent.ScheduledThreadPoolExecutor newScheduledExecutor(@org.jetbrains.annotations.Nullable()
        java.lang.String threadPoolName, boolean daemon) {
            return null;
        }
        
        /**
         * 取消任务
         *
         * @param future 待取消任务
         */
        public final void cancel(@org.jetbrains.annotations.NotNull()
        java.util.concurrent.Future<?> future) {
        }
    }
}
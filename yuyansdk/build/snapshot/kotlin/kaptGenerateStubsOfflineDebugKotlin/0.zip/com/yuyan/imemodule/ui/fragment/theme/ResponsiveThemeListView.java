package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\r\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0010\u0010\u0013\u001a\u00020\b2\u0006\u0010\u0014\u001a\u00020\bH\u0002J(\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\b2\u0006\u0010\u0018\u001a\u00020\b2\u0006\u0010\u0019\u001a\u00020\b2\u0006\u0010\u001a\u001a\u00020\bH\u0014R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001a\u0010\r\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\n\"\u0004\b\u000f\u0010\fR\u001a\u0010\u0010\u001a\u00020\bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0011\u0010\n\"\u0004\b\u0012\u0010\f\u00a8\u0006\u001b"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ResponsiveThemeListView;", "Landroidx/recyclerview/widget/RecyclerView;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "grid", "Landroidx/recyclerview/widget/GridLayoutManager;", "itemHeight", "", "getItemHeight", "()I", "setItemHeight", "(I)V", "itemWidth", "getItemWidth", "setItemWidth", "minMargin", "getMinMargin", "setMinMargin", "estimateSpanCount", "width", "onSizeChanged", "", "w", "h", "oldw", "oldh", "yuyansdk_offlineDebug"})
public final class ResponsiveThemeListView extends androidx.recyclerview.widget.RecyclerView {
    private int itemWidth;
    private int itemHeight;
    private int minMargin;
    private androidx.recyclerview.widget.GridLayoutManager grid;
    
    public ResponsiveThemeListView(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null);
    }
    
    public final int getItemWidth() {
        return 0;
    }
    
    public final void setItemWidth(int p0) {
    }
    
    public final int getItemHeight() {
        return 0;
    }
    
    public final void setItemHeight(int p0) {
    }
    
    public final int getMinMargin() {
        return 0;
    }
    
    public final void setMinMargin(int p0) {
    }
    
    @java.lang.Override()
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
    }
    
    private final int estimateSpanCount(int width) {
        return 0;
    }
}
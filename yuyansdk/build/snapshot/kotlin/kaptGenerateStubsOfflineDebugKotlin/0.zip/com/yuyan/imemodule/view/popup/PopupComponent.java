package com.yuyan.imemodule.view.popup;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u0000 32\u00020\u0001:\u00013B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0016\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00072\u0006\u0010\u0017\u001a\u00020\u0007J\u0006\u0010\u0018\u001a\u00020\u0019J\b\u0010\u001a\u001a\u00020\u0019H\u0002J\u000e\u0010\u001b\u001a\u00020\u00192\u0006\u0010\u001c\u001a\u00020\u0007J,\u0010\u001d\u001a\u00020\u00192\u0012\u0010\u001e\u001a\u000e\u0012\u0004\u0012\u00020 \u0012\u0004\u0012\u00020!0\u001f2\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020\u0015H\u0002J#\u0010%\u001a\u00020\u00192\f\u0010&\u001a\b\u0012\u0004\u0012\u00020!0\'2\u0006\u0010\"\u001a\u00020#H\u0002\u00a2\u0006\u0002\u0010(J\u001e\u0010)\u001a\u00020\u00192\u0006\u0010*\u001a\u00020!2\u0006\u0010+\u001a\u00020!2\u0006\u0010\"\u001a\u00020#J\u001e\u0010,\u001a\u00020\u00192\u0006\u0010-\u001a\u00020.2\u0006\u0010\"\u001a\u00020#2\u0006\u0010/\u001a\u00020\u0007J\u0016\u00100\u001a\u00020\u00192\u0006\u00101\u001a\u00020!2\u0006\u0010\"\u001a\u00020#J\u0012\u00102\u001a\u000e\u0012\u0004\u0012\u00020 \u0012\u0004\u0012\u00020!0\u001fR\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001b\u0010\u0006\u001a\u00020\u00078BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\n\u0010\u000b\u001a\u0004\b\b\u0010\tR\u001b\u0010\f\u001a\u00020\r8FX\u0086\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0010\u0010\u000b\u001a\u0004\b\u000e\u0010\u000fR\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00064"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupComponent;", "", "()V", "freeEntryUi", "Ljava/util/LinkedList;", "Lcom/yuyan/imemodule/view/popup/PopupEntryUi;", "popupRadius", "", "getPopupRadius", "()F", "popupRadius$delegate", "Lkotlin/Lazy;", "root", "Landroid/widget/FrameLayout;", "getRoot", "()Landroid/widget/FrameLayout;", "root$delegate", "showingContainerUi", "Lcom/yuyan/imemodule/view/popup/PopupContainerUi;", "showingEntryUi", "changeFocus", "", "x", "y", "dismissPopup", "", "dismissPopupContainer", "onGestureEvent", "distance", "reallyMenuKeyboard", "key", "Lkotlin/Pair;", "Lcom/yuyan/imemodule/prefs/behavior/PopupMenuMode;", "", "bounds", "Landroid/graphics/Rect;", "isSelect", "reallyShowKeyboard", "keys", "", "([Ljava/lang/String;Landroid/graphics/Rect;)V", "showKeyboard", "label", "labelSmall", "showKeyboardMenu", "mCurrentKey", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "distanceY", "showPopup", "content", "triggerFocused", "Companion", "yuyansdk_offlineDebug"})
public final class PopupComponent {
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.view.popup.PopupEntryUi showingEntryUi;
    @org.jetbrains.annotations.NotNull()
    private final java.util.LinkedList<com.yuyan.imemodule.view.popup.PopupEntryUi> freeEntryUi = null;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.view.popup.PopupContainerUi showingContainerUi;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy popupRadius$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.Lazy root$delegate = null;
    @org.jetbrains.annotations.Nullable()
    private static com.yuyan.imemodule.view.popup.PopupComponent instance;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.view.popup.PopupComponent.Companion Companion = null;
    
    private PopupComponent() {
        super();
    }
    
    private final float getPopupRadius() {
        return 0.0F;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.widget.FrameLayout getRoot() {
        return null;
    }
    
    public final void showPopup(@org.jetbrains.annotations.NotNull()
    java.lang.String content, @org.jetbrains.annotations.NotNull()
    android.graphics.Rect bounds) {
    }
    
    public final void showKeyboard(@org.jetbrains.annotations.NotNull()
    java.lang.String label, @org.jetbrains.annotations.NotNull()
    java.lang.String labelSmall, @org.jetbrains.annotations.NotNull()
    android.graphics.Rect bounds) {
    }
    
    public final void showKeyboardMenu(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.entity.keyboard.SoftKey mCurrentKey, @org.jetbrains.annotations.NotNull()
    android.graphics.Rect bounds, float distanceY) {
    }
    
    public final void onGestureEvent(float distance) {
    }
    
    private final void reallyMenuKeyboard(kotlin.Pair<? extends com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> key, android.graphics.Rect bounds, boolean isSelect) {
    }
    
    private final void reallyShowKeyboard(java.lang.String[] keys, android.graphics.Rect bounds) {
    }
    
    public final boolean changeFocus(float x, float y) {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final kotlin.Pair<com.yuyan.imemodule.prefs.behavior.PopupMenuMode, java.lang.String> triggerFocused() {
        return null;
    }
    
    public final void dismissPopup() {
    }
    
    private final void dismissPopupContainer() {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0007\u001a\u00020\u0004R\u0018\u0010\u0003\u001a\u0004\u0018\u00010\u00048BX\u0082\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\b"}, d2 = {"Lcom/yuyan/imemodule/view/popup/PopupComponent$Companion;", "", "()V", "instance", "Lcom/yuyan/imemodule/view/popup/PopupComponent;", "getInstance", "()Lcom/yuyan/imemodule/view/popup/PopupComponent;", "get", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        private final com.yuyan.imemodule.view.popup.PopupComponent getInstance() {
            return null;
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.view.popup.PopupComponent get() {
            return null;
        }
    }
}
package com.yuyan.imemodule.libs.expression.tokenizer;

/**
 * Represents closed parentheses
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/CloseParenthesesToken;", "Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "()V", "yuyansdk_offlineDebug"})
public final class CloseParenthesesToken extends com.yuyan.imemodule.libs.expression.tokenizer.Token {
    
    public CloseParenthesesToken() {
        super(0);
    }
}
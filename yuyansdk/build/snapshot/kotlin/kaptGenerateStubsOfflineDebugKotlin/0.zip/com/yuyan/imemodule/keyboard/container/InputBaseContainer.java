package com.yuyan.imemodule.keyboard.container;

/**
 * 输入键盘容器父类，用于进行输入键盘相关处理（判断）。
 *
 * 与基类不同的是，该类内置输入键盘[TextKeyboard],用于键盘更新、按键响应操作。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\b\u0017\u0018\u00002\u00020\u0001B\u0017\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\b\u0010\t\u001a\u00020\nH\u0016R\u0014\u0010\u0007\u001a\u0004\u0018\u00010\b8\u0004@\u0004X\u0085\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/InputBaseContainer;", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "mMajorView", "Lcom/yuyan/imemodule/keyboard/TextKeyboard;", "updateStates", "", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public class InputBaseContainer extends com.yuyan.imemodule.keyboard.container.BaseContainer {
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    protected com.yuyan.imemodule.keyboard.TextKeyboard mMajorView;
    
    public InputBaseContainer(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    /**
     * 刷新按键状态，当前主要解决切换键盘时enter键状态切换
     */
    public void updateStates() {
    }
}
package com.yuyan.imemodule.keyboard.container;

/**
 * 输入键盘容器父类，用于进行输入键盘相关处理（判断）。
 *
 * 与基类不同的是，该类内置输入键盘[TextKeyboard],用于键盘更新、按键响应操作。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\b\u0017\u0018\u00002\u00020\u0001B\u0017\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\b\u0010!\u001a\u00020\u001aH\u0016J\b\u0010\"\u001a\u00020#H\u0016J\b\u0010$\u001a\u00020#H\u0016J\b\u0010%\u001a\u00020#H\u0014J\b\u0010&\u001a\u00020#H\u0016R\u001c\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\t\u0010\n\"\u0004\b\u000b\u0010\fR\u001c\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u001c\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R\u001a\u0010\u0019\u001a\u00020\u001aX\u0084\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001b\u0010\u001c\"\u0004\b\u001d\u0010\u001eR\u0014\u0010\u001f\u001a\u0004\u0018\u00010 8\u0004@\u0004X\u0085\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\'"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/InputBaseContainer;", "Lcom/yuyan/imemodule/keyboard/container/BaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "mCandidatesAdapter", "Lcom/yuyan/imemodule/adapter/CandidatesAdapter;", "getMCandidatesAdapter", "()Lcom/yuyan/imemodule/adapter/CandidatesAdapter;", "setMCandidatesAdapter", "(Lcom/yuyan/imemodule/adapter/CandidatesAdapter;)V", "mCandidatesGridOverlay", "Lcom/yuyan/imemodule/libs/recyclerview/SwipeRecyclerView;", "getMCandidatesGridOverlay", "()Lcom/yuyan/imemodule/libs/recyclerview/SwipeRecyclerView;", "setMCandidatesGridOverlay", "(Lcom/yuyan/imemodule/libs/recyclerview/SwipeRecyclerView;)V", "mDeleteButton", "Landroid/widget/ImageView;", "getMDeleteButton", "()Landroid/widget/ImageView;", "setMDeleteButton", "(Landroid/widget/ImageView;)V", "mIsExpanded", "", "getMIsExpanded", "()Z", "setMIsExpanded", "(Z)V", "mMajorView", "Lcom/yuyan/imemodule/keyboard/TextKeyboard;", "isCandidatesExpanded", "onCandidateChanged", "", "toggleCandidatesMore", "updateCandidatesOverlayState", "updateStates", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public class InputBaseContainer extends com.yuyan.imemodule.keyboard.container.BaseContainer {
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    protected com.yuyan.imemodule.keyboard.TextKeyboard mMajorView;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView mCandidatesGridOverlay;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.adapter.CandidatesAdapter mCandidatesAdapter;
    @org.jetbrains.annotations.Nullable()
    private android.widget.ImageView mDeleteButton;
    private boolean mIsExpanded = false;
    
    public InputBaseContainer(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    @org.jetbrains.annotations.Nullable()
    protected final com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView getMCandidatesGridOverlay() {
        return null;
    }
    
    protected final void setMCandidatesGridOverlay(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    protected final com.yuyan.imemodule.adapter.CandidatesAdapter getMCandidatesAdapter() {
        return null;
    }
    
    protected final void setMCandidatesAdapter(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.adapter.CandidatesAdapter p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    protected final android.widget.ImageView getMDeleteButton() {
        return null;
    }
    
    protected final void setMDeleteButton(@org.jetbrains.annotations.Nullable()
    android.widget.ImageView p0) {
    }
    
    protected final boolean getMIsExpanded() {
        return false;
    }
    
    protected final void setMIsExpanded(boolean p0) {
    }
    
    public void toggleCandidatesMore() {
    }
    
    public boolean isCandidatesExpanded() {
        return false;
    }
    
    public void onCandidateChanged() {
    }
    
    protected void updateCandidatesOverlayState() {
    }
    
    /**
     * 刷新按键状态，当前主要解决切换键盘时enter键状态切换
     */
    public void updateStates() {
    }
}
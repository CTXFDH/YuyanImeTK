package com.yuyan.inputmethod.core;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001BG\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003\u0012\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u00a2\u0006\u0002\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0017\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0018\u001a\u00020\u0006H\u00c6\u0003J\t\u0010\u0019\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u001a\u001a\u00020\u0003H\u00c6\u0003J\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u00c6\u0003\u00a2\u0006\u0002\u0010\u000eJP\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\nH\u00c6\u0001\u00a2\u0006\u0002\u0010\u001dJ\u0013\u0010\u001e\u001a\u00020\u00062\b\u0010\u001f\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\b\u0010 \u001a\u00020\u0003H\u0016J\t\u0010!\u001a\u00020\"H\u00d6\u0001R\u0019\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u00a2\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0012R\u0011\u0010\b\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0011R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0011\u00a8\u0006#"}, d2 = {"Lcom/yuyan/inputmethod/core/RimeMenu;", "", "pageSize", "", "pageNo", "isLastPage", "", "highlightedCandidateIndex", "numCandidates", "candidates", "", "Lcom/yuyan/inputmethod/core/CandidateListItem;", "(IIZII[Lcom/yuyan/inputmethod/core/CandidateListItem;)V", "getCandidates", "()[Lcom/yuyan/inputmethod/core/CandidateListItem;", "[Lcom/yuyan/inputmethod/core/CandidateListItem;", "getHighlightedCandidateIndex", "()I", "()Z", "getNumCandidates", "getPageNo", "getPageSize", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "(IIZII[Lcom/yuyan/inputmethod/core/CandidateListItem;)Lcom/yuyan/inputmethod/core/RimeMenu;", "equals", "other", "hashCode", "toString", "", "yuyansdk_offlineDebug"})
@androidx.annotation.Keep()
public final class RimeMenu {
    private final int pageSize = 0;
    private final int pageNo = 0;
    private final boolean isLastPage = false;
    private final int highlightedCandidateIndex = 0;
    private final int numCandidates = 0;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.inputmethod.core.CandidateListItem[] candidates = null;
    
    public RimeMenu(int pageSize, int pageNo, boolean isLastPage, int highlightedCandidateIndex, int numCandidates, @org.jetbrains.annotations.NotNull()
    com.yuyan.inputmethod.core.CandidateListItem[] candidates) {
        super();
    }
    
    public final int getPageSize() {
        return 0;
    }
    
    public final int getPageNo() {
        return 0;
    }
    
    public final boolean isLastPage() {
        return false;
    }
    
    public final int getHighlightedCandidateIndex() {
        return 0;
    }
    
    public final int getNumCandidates() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.inputmethod.core.CandidateListItem[] getCandidates() {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    public RimeMenu() {
        super();
    }
    
    public final int component1() {
        return 0;
    }
    
    public final int component2() {
        return 0;
    }
    
    public final boolean component3() {
        return false;
    }
    
    public final int component4() {
        return 0;
    }
    
    public final int component5() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.inputmethod.core.CandidateListItem[] component6() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.inputmethod.core.RimeMenu copy(int pageSize, int pageNo, boolean isLastPage, int highlightedCandidateIndex, int numCandidates, @org.jetbrains.annotations.NotNull()
    com.yuyan.inputmethod.core.CandidateListItem[] candidates) {
        return null;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}
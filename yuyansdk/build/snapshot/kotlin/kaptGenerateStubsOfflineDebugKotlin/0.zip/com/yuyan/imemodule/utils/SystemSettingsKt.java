package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\u001a\u0010\u0010\u0000\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0002\u001a\u00020\u0001\u00a8\u0006\u0003"}, d2 = {"getSecureSettings", "", "name", "yuyansdk_offlineDebug"})
public final class SystemSettingsKt {
    
    @org.jetbrains.annotations.Nullable()
    public static final java.lang.String getSecureSettings(@org.jetbrains.annotations.NotNull()
    java.lang.String name) {
        return null;
    }
}
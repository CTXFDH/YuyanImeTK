package com.yuyan.imemodule.ui.fragment;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u001c\u0010\u0003\u001a\u00020\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\bH\u0016J\b\u0010\t\u001a\u00020\u0004H\u0016J\u0014\u0010\n\u001a\u00020\u00042\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\fH\u0002J\u0010\u0010\r\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\fH\u0002\u00a8\u0006\u000f"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/PhrasesSettingsFragment;", "Landroidx/preference/PreferenceFragmentCompat;", "()V", "onCreatePreferences", "", "savedInstanceState", "Landroid/os/Bundle;", "rootKey", "", "onResume", "showAddPhraseDialog", "existingPhrase", "Lcom/yuyan/imemodule/database/entry/Phrase;", "showEditOrDeleteDialog", "phrase", "yuyansdk_offlineDebug"})
public final class PhrasesSettingsFragment extends androidx.preference.PreferenceFragmentCompat {
    
    public PhrasesSettingsFragment() {
        super();
    }
    
    @java.lang.Override()
    public void onResume() {
    }
    
    @java.lang.Override()
    public void onCreatePreferences(@org.jetbrains.annotations.Nullable()
    android.os.Bundle savedInstanceState, @org.jetbrains.annotations.Nullable()
    java.lang.String rootKey) {
    }
    
    private final void showAddPhraseDialog(com.yuyan.imemodule.database.entry.Phrase existingPhrase) {
    }
    
    private final void showEditOrDeleteDialog(com.yuyan.imemodule.database.entry.Phrase phrase) {
    }
}
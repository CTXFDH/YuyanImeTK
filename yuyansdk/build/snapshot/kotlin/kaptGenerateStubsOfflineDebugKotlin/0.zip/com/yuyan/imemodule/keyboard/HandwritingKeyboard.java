package com.yuyan.imemodule.keyboard;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0086\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\n\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u00a2\u0006\u0002\u0010\u0004J \u0010#\u001a\u00020$2\u0006\u0010%\u001a\u00020&2\u0006\u0010\'\u001a\u00020\n2\u0006\u0010(\u001a\u00020\nH\u0002J\u0012\u0010)\u001a\u00020$2\b\u0010*\u001a\u0004\u0018\u00010\u0013H\u0002J \u0010+\u001a\u00020\u00062\u0006\u0010,\u001a\u00020\u00132\u0006\u0010-\u001a\u00020\u00132\u0006\u0010.\u001a\u00020\u0013H\u0002J\u0006\u0010/\u001a\u00020$J\u0010\u00100\u001a\u00020\r2\u0006\u00101\u001a\u00020\nH\u0002J\b\u00102\u001a\u00020$H\u0002J\u001a\u00103\u001a\u0004\u0018\u00010\u00132\u0006\u00104\u001a\u00020\n2\u0006\u00105\u001a\u00020\nH\u0002J\u0010\u00106\u001a\u00020$2\u0006\u00107\u001a\u00020\u001aH\u0014J\u001a\u00108\u001a\u0004\u0018\u0001092\u0006\u00104\u001a\u00020\r2\u0006\u00105\u001a\u00020\rH\u0002J\u0010\u0010:\u001a\u00020;2\u0006\u0010<\u001a\u00020=H\u0017J\b\u0010>\u001a\u00020$H\u0002J\u0012\u0010?\u001a\u00020$2\b\u0010@\u001a\u0004\u0018\u00010\u0013H\u0002J\u0010\u0010A\u001a\u00020$2\u0006\u0010B\u001a\u00020CH\u0016J\u0010\u0010D\u001a\u00020\n2\u0006\u0010E\u001a\u00020\nH\u0002J\u0006\u0010F\u001a\u00020$R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0015\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00160\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u001c\u001a\u00020\u001dX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u000e\u0010\"\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006G"}, d2 = {"Lcom/yuyan/imemodule/keyboard/HandwritingKeyboard;", "Lcom/yuyan/imemodule/keyboard/TextKeyboard;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "mControlTimedPointsCached", "Lcom/yuyan/imemodule/entity/handwriting/ControlTimedPoints;", "mLastUpTime", "", "mLastVelocity", "", "mLastWidth", "mMaxWidth", "", "mMinWidth", "mPaint", "Landroid/graphics/Paint;", "mPoints", "", "Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;", "mPointsCache", "mSBPoint", "", "mSignatureBitmap", "Landroid/graphics/Bitmap;", "mSignatureBitmapCanvas", "Landroid/graphics/Canvas;", "mVelocityFilterWeight", "runnable", "Ljava/lang/Runnable;", "getRunnable", "()Ljava/lang/Runnable;", "setRunnable", "(Ljava/lang/Runnable;)V", "times", "addBezier", "", "curve", "Lcom/yuyan/imemodule/entity/handwriting/Bezier;", "startWidth", "endWidth", "addPoint", "newPoint", "calculateCurveControlPoints", "s1", "s2", "s3", "clear", "convertDpToPx", "dp", "ensureSignatureBitmap", "getNewPoint", "x", "y", "onDraw", "canvas", "onKeyPressHandwriting", "Lcom/yuyan/imemodule/entity/keyboard/SoftKey;", "onTouchEvent", "", "me", "Landroid/view/MotionEvent;", "recognitionData", "recyclePoint", "point", "setTheme", "theme", "Lcom/yuyan/imemodule/data/theme/Theme;", "strokeWidth", "velocity", "updatePathDelayed", "yuyansdk_offlineDebug"})
public final class HandwritingKeyboard extends com.yuyan.imemodule.keyboard.TextKeyboard {
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.entity.handwriting.TimedPoint> mPointsCache = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.entity.handwriting.ControlTimedPoints mControlTimedPointsCached = null;
    private long mLastUpTime = 0L;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<java.lang.Short> mSBPoint = null;
    @org.jetbrains.annotations.NotNull()
    private java.util.List<com.yuyan.imemodule.entity.handwriting.TimedPoint> mPoints;
    private float mLastVelocity = 0.0F;
    private float mLastWidth = 0.0F;
    private int mMaxWidth;
    private int mMinWidth;
    private float mVelocityFilterWeight = 0.7F;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.Paint mPaint = null;
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Bitmap mSignatureBitmap;
    @org.jetbrains.annotations.Nullable()
    private android.graphics.Canvas mSignatureBitmapCanvas;
    private final long times = 0L;
    @org.jetbrains.annotations.NotNull()
    private java.lang.Runnable runnable;
    
    public HandwritingKeyboard(@org.jetbrains.annotations.Nullable()
    android.content.Context context) {
        super(null);
    }
    
    @java.lang.Override()
    public void setTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    public final void clear() {
    }
    
    @java.lang.Override()
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public boolean onTouchEvent(@org.jetbrains.annotations.NotNull()
    android.view.MotionEvent me) {
        return false;
    }
    
    @java.lang.Override()
    protected void onDraw(@org.jetbrains.annotations.NotNull()
    android.graphics.Canvas canvas) {
    }
    
    private final com.yuyan.imemodule.entity.handwriting.TimedPoint getNewPoint(float x, float y) {
        return null;
    }
    
    private final void recyclePoint(com.yuyan.imemodule.entity.handwriting.TimedPoint point) {
    }
    
    private final void addPoint(com.yuyan.imemodule.entity.handwriting.TimedPoint newPoint) {
    }
    
    private final void addBezier(com.yuyan.imemodule.entity.handwriting.Bezier curve, float startWidth, float endWidth) {
    }
    
    private final com.yuyan.imemodule.entity.handwriting.ControlTimedPoints calculateCurveControlPoints(com.yuyan.imemodule.entity.handwriting.TimedPoint s1, com.yuyan.imemodule.entity.handwriting.TimedPoint s2, com.yuyan.imemodule.entity.handwriting.TimedPoint s3) {
        return null;
    }
    
    private final float strokeWidth(float velocity) {
        return 0.0F;
    }
    
    private final void ensureSignatureBitmap() {
    }
    
    private final int convertDpToPx(float dp) {
        return 0;
    }
    
    /**
     * 手写键盘获取按下按键
     */
    private final com.yuyan.imemodule.entity.keyboard.SoftKey onKeyPressHandwriting(int x, int y) {
        return null;
    }
    
    private final void recognitionData() {
    }
    
    public final void updatePathDelayed() {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.Runnable getRunnable() {
        return null;
    }
    
    public final void setRunnable(@org.jetbrains.annotations.NotNull()
    java.lang.Runnable p0) {
    }
}
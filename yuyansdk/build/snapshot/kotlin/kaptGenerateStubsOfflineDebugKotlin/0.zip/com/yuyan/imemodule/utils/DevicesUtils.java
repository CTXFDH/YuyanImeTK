package com.yuyan.imemodule.utils;

/**
 * 设备相关工具类
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0007J\u0010\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u0004H\u0007J\u0010\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0004H\u0007J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u0004H\u0007J\u0012\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u0004H\u0007J\u001c\u0010\u0010\u001a\u00020\u000e2\b\u0010\u0011\u001a\u0004\u0018\u00010\u00122\b\b\u0002\u0010\u0013\u001a\u00020\u0014H\u0007\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/utils/DevicesUtils;", "", "()V", "dip2px", "", "dpValue", "", "px2dip", "pxValue", "px2sp", "px", "sp2px", "sp", "tryPlayKeyDown", "", "code", "tryVibrate", "view", "Landroid/view/View;", "isRelease", "", "yuyansdk_offlineDebug"})
public final class DevicesUtils {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.DevicesUtils INSTANCE = null;
    
    private DevicesUtils() {
        super();
    }
    
    /**
     * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
     */
    @kotlin.jvm.JvmStatic()
    public static final int dip2px(float dpValue) {
        return 0;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final int dip2px(int dpValue) {
        return 0;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final float px2sp(int px) {
        return 0.0F;
    }
    
    /**
     * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
     */
    @kotlin.jvm.JvmStatic()
    public static final float px2dip(int pxValue) {
        return 0.0F;
    }
    
    @kotlin.jvm.JvmStatic()
    public static final int sp2px(int sp) {
        return 0;
    }
    
    /**
     * 震动
     */
    @kotlin.jvm.JvmStatic()
    @kotlin.jvm.JvmOverloads()
    public static final void tryVibrate(@org.jetbrains.annotations.Nullable()
    android.view.View view) {
    }
    
    /**
     * 震动
     */
    @kotlin.jvm.JvmStatic()
    @kotlin.jvm.JvmOverloads()
    public static final void tryVibrate(@org.jetbrains.annotations.Nullable()
    android.view.View view, boolean isRelease) {
    }
    
    /**
     * 播放按键按下的声音
     */
    @kotlin.jvm.JvmStatic()
    public static final void tryPlayKeyDown(int code) {
    }
}
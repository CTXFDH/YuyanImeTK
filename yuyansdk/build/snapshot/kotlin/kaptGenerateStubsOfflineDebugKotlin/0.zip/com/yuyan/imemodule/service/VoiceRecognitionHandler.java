package com.yuyan.imemodule.service;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000|\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\r\n\u0002\u0010\b\n\u0002\b\u001a\n\u0002\u0018\u0002\n\u0002\b\u0016\b\u0007\u0018\u0000 `2\u00020\u0001:\u0001`B\u00ab\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0012\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00060\t\u0012\u000e\u0010\n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\t\u0012\u000e\b\u0002\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00070\t\u0012\u0014\b\u0002\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u00070\u0005\u0012\u0014\b\u0002\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00070\u0005\u0012\u000e\b\u0002\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00070\t\u0012\u0014\b\u0002\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00130\u0005\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0015\u00a2\u0006\u0002\u0010\u0016J\u0006\u00106\u001a\u00020\u0007J\u0010\u00107\u001a\u00020\u00182\u0006\u00108\u001a\u00020\u0018H\u0002J\u0006\u00109\u001a\u00020\u0007J \u0010:\u001a\u00020\u00072\u0006\u0010;\u001a\u00020\u000b2\u0006\u0010<\u001a\u00020\u00182\u0006\u0010=\u001a\u00020\u0018H\u0002J\u0006\u0010>\u001a\u00020\u0007J\u0006\u0010?\u001a\u00020\u0007J\u0010\u0010@\u001a\u00020\u00072\u0006\u0010A\u001a\u00020\u000eH\u0002J\u0010\u0010B\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0018H\u0002J\u0010\u0010C\u001a\u00020\u00072\u0006\u0010D\u001a\u00020\u0010H\u0002J\u0018\u0010E\u001a\u00020\u00072\u0006\u0010F\u001a\u00020\u00182\u0006\u0010G\u001a\u00020\u001fH\u0002J\u0010\u0010H\u001a\u00020\u00072\u0006\u00108\u001a\u00020\u0018H\u0002J\u0010\u0010I\u001a\u00020\u00072\u0006\u0010J\u001a\u00020KH\u0002J\u0010\u0010L\u001a\u00020\u00182\u0006\u00108\u001a\u00020\u0018H\u0002J\u0010\u0010M\u001a\u00020\u00182\u0006\u00108\u001a\u00020\u0018H\u0002J\u0006\u0010N\u001a\u00020\u0007J\u0006\u0010O\u001a\u00020\u001fJ\u0015\u0010P\u001a\u00020\u00182\u0006\u00108\u001a\u00020\u0018H\u0000\u00a2\u0006\u0002\bQJ\b\u0010R\u001a\u00020\u0007H\u0002J\u0010\u0010S\u001a\u00020\u00072\u0006\u0010;\u001a\u00020\u000bH\u0002J\u0006\u0010T\u001a\u00020\u0007J\b\u0010U\u001a\u00020\u0007H\u0002J\b\u0010V\u001a\u00020\u0018H\u0002J\u0006\u0010W\u001a\u00020\u0007J\u0010\u0010X\u001a\u00020\u00072\b\b\u0002\u0010Y\u001a\u00020\"J\b\u0010Z\u001a\u00020\u0007H\u0007J\u0006\u0010[\u001a\u00020\u0007J\u0018\u0010\\\u001a\u00020\u00072\u0006\u0010;\u001a\u00020\u000b2\u0006\u0010]\u001a\u00020\u0018H\u0002J\u0010\u0010^\u001a\u00020\u00182\u0006\u0010_\u001a\u00020\u0018H\u0002R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u001aX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u001b\u001a\u0004\u0018\u00010\u001cX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001aX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00060\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\"X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010$\u001a\u00020\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00130\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00070\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0004\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00070\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00070\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010%\u001a\u00020\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\'\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0013X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010*\u001a\u00020\u0018X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b+\u0010,\"\u0004\b-\u0010.R\u001a\u0010/\u001a\u000200X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b1\u00102\"\u0004\b3\u00104R\u000e\u00105\u001a\u00020\u001fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006a"}, d2 = {"Lcom/yuyan/imemodule/service/VoiceRecognitionHandler;", "", "context", "Landroid/content/Context;", "onStateChanged", "Lkotlin/Function1;", "Lcom/yuyan/imemodule/service/VoiceState;", "", "getState", "Lkotlin/Function0;", "getInputConnection", "Landroid/view/inputmethod/InputConnection;", "onVoiceComplete", "onAmplitudeChanged", "", "onSpectrumChanged", "", "onComposingWritten", "managerFactory", "Lcom/yuyan/imemodule/speech/SpeechRecognitionManager;", "mainHandler", "Landroid/os/Handler;", "(Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroid/os/Handler;)V", "consumedEnginePrefix", "", "delayedPreStartRunnable", "Ljava/lang/Runnable;", "errorToast", "Landroid/widget/Toast;", "finishTimeoutRunnable", "finishing", "", "inputBoxEchoProbed", "lastAmplitudeUpdate", "", "lastPartialText", "lastWrittenText", "sessionAbandoned", "smoothedAmplitude", "smoothedSpectrum", "speechRecognitionManager", "suppressDuplicateFinal", "textBeforeVoiceInput", "getTextBeforeVoiceInput", "()Ljava/lang/String;", "setTextBeforeVoiceInput", "(Ljava/lang/String;)V", "textLengthBeforeVoiceInput", "", "getTextLengthBeforeVoiceInput", "()I", "setTextLengthBeforeVoiceInput", "(I)V", "writtenTextVerified", "abandonSession", "addPunctuation", "text", "cancelPreStart", "commitFinal", "ic", "finalText", "partial", "commitPendingOnRelease", "finishRecognition", "handleAmplitudeUpdate", "amplitude", "handlePartialResult", "handleSpectrumUpdate", "spectrum", "handleSpeechError", "error", "userVisible", "handleSpeechResult", "handleSpeechStateChange", "state", "Lcom/yuyan/imemodule/speech/RecognitionState;", "heuristicLatinPunctuation", "heuristicPunctuation", "initialize", "isInitialized", "normalizeAsrText", "normalizeAsrText$yuyansdk_offlineDebug", "onFinishTimeout", "reconcileWithInputBox", "release", "resetInputBoxBookkeeping", "resolveProviderName", "sealPendingForSend", "startDelayedPreStart", "delayMs", "startRecognition", "stopRecognition", "verifyInputBoxEcho", "written", "visibleEngineText", "engineText", "Companion", "yuyansdk_offlineDebug"})
public final class VoiceRecognitionHandler {
    @org.jetbrains.annotations.NotNull()
    private final android.content.Context context = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function1<com.yuyan.imemodule.service.VoiceState, kotlin.Unit> onStateChanged = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function0<com.yuyan.imemodule.service.VoiceState> getState = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function0<android.view.inputmethod.InputConnection> getInputConnection = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function0<kotlin.Unit> onVoiceComplete = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function1<java.lang.Float, kotlin.Unit> onAmplitudeChanged = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function1<float[], kotlin.Unit> onSpectrumChanged = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function0<kotlin.Unit> onComposingWritten = null;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.jvm.functions.Function1<android.content.Context, com.yuyan.imemodule.speech.SpeechRecognitionManager> managerFactory = null;
    @org.jetbrains.annotations.NotNull()
    private final android.os.Handler mainHandler = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String TAG = "VoiceRecognition";
    private static final long FINISH_TIMEOUT_MS = 3000L;
    @org.jetbrains.annotations.NotNull()
    private static final java.lang.String CJK_CHAR = "\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u309f\u30a0-\u30ff";
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.text.Regex MULTI_SPACE_REGEX = null;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.text.Regex CJK_SPACE_REGEX = null;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.text.Regex CJK_PUNCT_SPACE_REGEX = null;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.text.Regex SPACE_BEFORE_PUNCT_REGEX = null;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.text.Regex ASCII_PUNCT_FOLLOWED_LATIN_REGEX = null;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.text.Regex PERIOD_FOLLOWED_UPPER_REGEX = null;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.text.Regex CJK_CHAR_REGEX = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Set<java.lang.String> LATIN_QUESTION_STARTERS = null;
    private com.yuyan.imemodule.speech.SpeechRecognitionManager speechRecognitionManager;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String textBeforeVoiceInput = "";
    private int textLengthBeforeVoiceInput = 0;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.Runnable delayedPreStartRunnable = null;
    @org.jetbrains.annotations.NotNull()
    private java.lang.String lastPartialText = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String lastWrittenText = "";
    @org.jetbrains.annotations.NotNull()
    private java.lang.String consumedEnginePrefix = "";
    private boolean writtenTextVerified = false;
    private boolean inputBoxEchoProbed = false;
    private long lastAmplitudeUpdate = 0L;
    private float smoothedAmplitude = 0.0F;
    @org.jetbrains.annotations.NotNull()
    private float[] smoothedSpectrum;
    private boolean suppressDuplicateFinal = false;
    @kotlin.jvm.Volatile()
    private volatile boolean finishing = false;
    private boolean sessionAbandoned = false;
    @org.jetbrains.annotations.Nullable()
    private android.widget.Toast errorToast;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.Runnable finishTimeoutRunnable = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.service.VoiceRecognitionHandler.Companion Companion = null;
    
    public VoiceRecognitionHandler(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super com.yuyan.imemodule.service.VoiceState, kotlin.Unit> onStateChanged, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function0<com.yuyan.imemodule.service.VoiceState> getState, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function0<? extends android.view.inputmethod.InputConnection> getInputConnection, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function0<kotlin.Unit> onVoiceComplete, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super java.lang.Float, kotlin.Unit> onAmplitudeChanged, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super float[], kotlin.Unit> onSpectrumChanged, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function0<kotlin.Unit> onComposingWritten, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super android.content.Context, com.yuyan.imemodule.speech.SpeechRecognitionManager> managerFactory, @org.jetbrains.annotations.NotNull()
    android.os.Handler mainHandler) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getTextBeforeVoiceInput() {
        return null;
    }
    
    public final void setTextBeforeVoiceInput(@org.jetbrains.annotations.NotNull()
    java.lang.String p0) {
    }
    
    public final int getTextLengthBeforeVoiceInput() {
        return 0;
    }
    
    public final void setTextLengthBeforeVoiceInput(int p0) {
    }
    
    public final void initialize() {
    }
    
    public final void startDelayedPreStart(long delayMs) {
    }
    
    public final void cancelPreStart() {
    }
    
    @android.annotation.SuppressLint(value = {"MissingPermission"})
    public final void startRecognition() {
    }
    
    public final void stopRecognition() {
    }
    
    public final void release() {
    }
    
    public final boolean isInitialized() {
        return false;
    }
    
    private final java.lang.String resolveProviderName() {
        return null;
    }
    
    public final void abandonSession() {
    }
    
    public final void sealPendingForSend() {
    }
    
    public final void commitPendingOnRelease() {
    }
    
    public final void finishRecognition() {
    }
    
    private final void onFinishTimeout() {
    }
    
    private final void handleSpeechResult(java.lang.String text) {
    }
    
    private final void commitFinal(android.view.inputmethod.InputConnection ic, java.lang.String finalText, java.lang.String partial) {
    }
    
    private final void resetInputBoxBookkeeping() {
    }
    
    private final void verifyInputBoxEcho(android.view.inputmethod.InputConnection ic, java.lang.String written) {
    }
    
    private final void reconcileWithInputBox(android.view.inputmethod.InputConnection ic) {
    }
    
    private final java.lang.String visibleEngineText(java.lang.String engineText) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String normalizeAsrText$yuyansdk_offlineDebug(@org.jetbrains.annotations.NotNull()
    java.lang.String text) {
        return null;
    }
    
    private final java.lang.String addPunctuation(java.lang.String text) {
        return null;
    }
    
    private final java.lang.String heuristicPunctuation(java.lang.String text) {
        return null;
    }
    
    private final java.lang.String heuristicLatinPunctuation(java.lang.String text) {
        return null;
    }
    
    private final void handlePartialResult(java.lang.String text) {
    }
    
    private final void handleSpeechStateChange(com.yuyan.imemodule.speech.RecognitionState state) {
    }
    
    private final void handleSpeechError(java.lang.String error, boolean userVisible) {
    }
    
    private final void handleAmplitudeUpdate(float amplitude) {
    }
    
    private final void handleSpectrumUpdate(float[] spectrum) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0000\n\u0002\u0010\"\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082T\u00a2\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00060\rX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0006X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0012"}, d2 = {"Lcom/yuyan/imemodule/service/VoiceRecognitionHandler$Companion;", "", "()V", "ASCII_PUNCT_FOLLOWED_LATIN_REGEX", "Lkotlin/text/Regex;", "CJK_CHAR", "", "CJK_CHAR_REGEX", "CJK_PUNCT_SPACE_REGEX", "CJK_SPACE_REGEX", "FINISH_TIMEOUT_MS", "", "LATIN_QUESTION_STARTERS", "", "MULTI_SPACE_REGEX", "PERIOD_FOLLOWED_UPPER_REGEX", "SPACE_BEFORE_PUNCT_REGEX", "TAG", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
}
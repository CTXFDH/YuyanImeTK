package com.yuyan.imemodule.keyboard;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010$\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u001f\u0010\u0000\u001a\u0010\u0012\u0004\u0012\u00020\u0002\u0012\u0006\u0012\u0004\u0018\u00010\u00030\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005\u00a8\u0006\u0006"}, d2 = {"keyIconRecords", "", "", "Landroid/graphics/drawable/Drawable;", "getKeyIconRecords", "()Ljava/util/Map;", "yuyansdk_offlineDebug"})
public final class KeyIconPresetKt {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, android.graphics.drawable.Drawable> keyIconRecords = null;
    
    @org.jetbrains.annotations.NotNull()
    public static final java.util.Map<java.lang.Integer, android.graphics.drawable.Drawable> getKeyIconRecords() {
        return null;
    }
}
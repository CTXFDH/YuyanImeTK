package com.yuyan.imemodule.service;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u000f\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B-\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u00a2\u0006\u0002\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0011\u001a\u00020\u0005H\u00c6\u0003J\t\u0010\u0012\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\u0013\u001a\u00020\bH\u00c6\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\bH\u00c6\u0001J\u0013\u0010\u0015\u001a\u00020\b2\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010\u0017\u001a\u00020\u0018H\u00d6\u0001J\t\u0010\u0019\u001a\u00020\u0003H\u00d6\u0001R\u0011\u0010\u0007\u001a\u00020\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\nR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\f\u00a8\u0006\u001a"}, d2 = {"Lcom/yuyan/imemodule/service/VoiceState;", "", "voicePluginName", "", "voiceRecognitionState", "Lcom/yuyan/imemodule/speech/RecognitionState;", "voiceRecognizedText", "isVoiceMode", "", "(Ljava/lang/String;Lcom/yuyan/imemodule/speech/RecognitionState;Ljava/lang/String;Z)V", "()Z", "getVoicePluginName", "()Ljava/lang/String;", "getVoiceRecognitionState", "()Lcom/yuyan/imemodule/speech/RecognitionState;", "getVoiceRecognizedText", "component1", "component2", "component3", "component4", "copy", "equals", "other", "hashCode", "", "toString", "yuyansdk_offlineDebug"})
public final class VoiceState {
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String voicePluginName = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.speech.RecognitionState voiceRecognitionState = null;
    @org.jetbrains.annotations.NotNull()
    private final java.lang.String voiceRecognizedText = null;
    private final boolean isVoiceMode = false;
    
    public VoiceState(@org.jetbrains.annotations.NotNull()
    java.lang.String voicePluginName, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.speech.RecognitionState voiceRecognitionState, @org.jetbrains.annotations.NotNull()
    java.lang.String voiceRecognizedText, boolean isVoiceMode) {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getVoicePluginName() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.speech.RecognitionState getVoiceRecognitionState() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getVoiceRecognizedText() {
        return null;
    }
    
    public final boolean isVoiceMode() {
        return false;
    }
    
    public VoiceState() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String component1() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.speech.RecognitionState component2() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String component3() {
        return null;
    }
    
    public final boolean component4() {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.service.VoiceState copy(@org.jetbrains.annotations.NotNull()
    java.lang.String voicePluginName, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.speech.RecognitionState voiceRecognitionState, @org.jetbrains.annotations.NotNull()
    java.lang.String voiceRecognizedText, boolean isVoiceMode) {
        return null;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
}
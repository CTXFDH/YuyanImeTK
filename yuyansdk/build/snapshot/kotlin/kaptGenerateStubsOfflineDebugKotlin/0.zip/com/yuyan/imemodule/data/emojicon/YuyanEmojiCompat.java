package com.yuyan.imemodule.data.emojicon;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u00c7\u0002\u0018\u00002\u00020\u0001:\u0001*B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u001a\u001a\u00020\u001bJ\u001a\u0010\u001c\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001e0\u001d2\b\b\u0002\u0010\u001f\u001a\u00020\u0007H\u0007J\u0018\u0010 \u001a\u00020\u00072\b\u0010!\u001a\u0004\u0018\u00010\u001e2\u0006\u0010\"\u001a\u00020#J\u000e\u0010$\u001a\u00020\u001b2\u0006\u0010%\u001a\u00020&J\u0012\u0010\u0006\u001a\u00020\u00072\b\u0010\'\u001a\u0004\u0018\u00010\u000eH\u0002J\u0012\u0010(\u001a\u00020\u00072\b\u0010\'\u001a\u0004\u0018\u00010\u000eH\u0002J\u0010\u0010)\u001a\u00020\u001b2\b\u0010\'\u001a\u0004\u0018\u00010\u000eR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082.\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\b\"\u0004\b\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u0007X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\b\"\u0004\b\f\u0010\nR\u001c\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006+"}, d2 = {"Lcom/yuyan/imemodule/data/emojicon/YuyanEmojiCompat;", "", "()V", "instanceNoReplace", "Lcom/yuyan/imemodule/data/emojicon/YuyanEmojiCompat$InstanceHandler;", "instanceReplaceAll", "isQQChatInput", "", "()Z", "setQQChatInput", "(Z)V", "isWeChatInput", "setWeChatInput", "mEditorInfo", "Landroid/view/inputmethod/EditorInfo;", "getMEditorInfo", "()Landroid/view/inputmethod/EditorInfo;", "setMEditorInfo", "(Landroid/view/inputmethod/EditorInfo;)V", "metadataVersion", "", "replaceAll", "scope", "Lkotlinx/coroutines/CoroutineScope;", "systemFontPaint", "Landroid/graphics/Paint;", "clearEditorInfo", "", "getAsFlow", "Lkotlinx/coroutines/flow/StateFlow;", "Landroidx/emoji2/text/EmojiCompat;", "setAsDefaultInstance", "getEmojiMatch", "emojiCompat", "emoji", "", "init", "context", "Landroid/content/Context;", "editorInfo", "isWechatInput", "setEditorInfo", "InstanceHandler", "yuyansdk_offlineDebug"})
public final class YuyanEmojiCompat {
    @org.jetbrains.annotations.Nullable()
    private static android.view.inputmethod.EditorInfo mEditorInfo;
    private static int metadataVersion = 0;
    private static boolean replaceAll = false;
    private static boolean isWeChatInput = false;
    private static boolean isQQChatInput = false;
    private static android.graphics.Paint systemFontPaint;
    private static com.yuyan.imemodule.data.emojicon.YuyanEmojiCompat.InstanceHandler instanceNoReplace;
    private static com.yuyan.imemodule.data.emojicon.YuyanEmojiCompat.InstanceHandler instanceReplaceAll;
    @org.jetbrains.annotations.NotNull()
    private static final kotlinx.coroutines.CoroutineScope scope = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.emojicon.YuyanEmojiCompat INSTANCE = null;
    
    private YuyanEmojiCompat() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final android.view.inputmethod.EditorInfo getMEditorInfo() {
        return null;
    }
    
    public final void setMEditorInfo(@org.jetbrains.annotations.Nullable()
    android.view.inputmethod.EditorInfo p0) {
    }
    
    public final boolean isWeChatInput() {
        return false;
    }
    
    public final void setWeChatInput(boolean p0) {
    }
    
    public final boolean isQQChatInput() {
        return false;
    }
    
    public final void setQQChatInput(boolean p0) {
    }
    
    /**
     * Initialize this helper and its EmojiCompat instances with given [context]. Immediately begins loading the emoji
     * metadata in a background thread. After this method has been called, it is safe to call [getAsFlow].
     */
    public final void init(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    public final void setEditorInfo(@org.jetbrains.annotations.Nullable()
    android.view.inputmethod.EditorInfo editorInfo) {
    }
    
    public final void clearEditorInfo() {
    }
    
    private final boolean isWechatInput(android.view.inputmethod.EditorInfo editorInfo) {
        return false;
    }
    
    private final boolean isQQChatInput(android.view.inputmethod.EditorInfo editorInfo) {
        return false;
    }
    
    public final boolean getEmojiMatch(@org.jetbrains.annotations.Nullable()
    androidx.emoji2.text.EmojiCompat emojiCompat, @org.jetbrains.annotations.NotNull()
    java.lang.String emoji) {
        return false;
    }
    
    /**
     * Gets the current EmojiCompat instance based on [replaceAll] and sets it as the default instance if
     * [setAsDefaultInstance] is true. Calling this method before [init] will cause an exception to be thrown.
     *
     * @return A state flow providing the latest EmojiCompat instance for given args. The flow may provide null if
     * EmojiCompat is still loading or if it has failed.
     */
    @android.annotation.SuppressLint(value = {"RestrictedApi"})
    @org.jetbrains.annotations.NotNull()
    public final kotlinx.coroutines.flow.StateFlow<androidx.emoji2.text.EmojiCompat> getAsFlow(boolean setAsDefaultInstance) {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0006\u0010\u0011\u001a\u00020\u0012R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0019\u0010\r\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010\u00a8\u0006\u0013"}, d2 = {"Lcom/yuyan/imemodule/data/emojicon/YuyanEmojiCompat$InstanceHandler;", "", "context", "Landroid/content/Context;", "replaceAll", "", "(Landroid/content/Context;Z)V", "config", "Landroidx/emoji2/text/EmojiCompat$Config;", "initCallback", "Landroidx/emoji2/text/EmojiCompat$InitCallback;", "instance", "Landroidx/emoji2/text/EmojiCompat;", "publishedInstanceFlow", "Lkotlinx/coroutines/flow/MutableStateFlow;", "getPublishedInstanceFlow", "()Lkotlinx/coroutines/flow/MutableStateFlow;", "load", "", "yuyansdk_offlineDebug"})
    static final class InstanceHandler {
        @org.jetbrains.annotations.NotNull()
        private final androidx.emoji2.text.EmojiCompat.InitCallback initCallback = null;
        @org.jetbrains.annotations.Nullable()
        private final androidx.emoji2.text.EmojiCompat.Config config = null;
        @org.jetbrains.annotations.Nullable()
        private final androidx.emoji2.text.EmojiCompat instance = null;
        @org.jetbrains.annotations.NotNull()
        private final kotlinx.coroutines.flow.MutableStateFlow<androidx.emoji2.text.EmojiCompat> publishedInstanceFlow = null;
        
        public InstanceHandler(@org.jetbrains.annotations.NotNull()
        android.content.Context context, boolean replaceAll) {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final kotlinx.coroutines.flow.MutableStateFlow<androidx.emoji2.text.EmojiCompat> getPublishedInstanceFlow() {
            return null;
        }
        
        /**
         * Manually loads the EmojiCompat instance. Call this method on a background thread to avoid blocking main.
         *
         * @see EmojiCompat.load
         */
        public final void load() {
        }
    }
}
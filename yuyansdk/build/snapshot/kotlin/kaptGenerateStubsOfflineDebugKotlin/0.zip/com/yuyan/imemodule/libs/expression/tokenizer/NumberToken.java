package com.yuyan.imemodule.libs.expression.tokenizer;

/**
 * Represents a number in the expression
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0019\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B!\b\u0010\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0007B\r\u0012\u0006\u0010\b\u001a\u00020\t\u00a2\u0006\u0002\u0010\nR\u0010\u0010\b\u001a\u00020\t8\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/NumberToken;", "Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "expression", "", "offset", "", "len", "([CII)V", "value", "", "(D)V", "yuyansdk_offlineDebug"})
public final class NumberToken extends com.yuyan.imemodule.libs.expression.tokenizer.Token {
    @kotlin.jvm.JvmField()
    public final double value = 0.0;
    
    public NumberToken(double value) {
        super(0);
    }
    
    public NumberToken(@org.jetbrains.annotations.Nullable()
    char[] expression, int offset, int len) {
        super(0);
    }
}
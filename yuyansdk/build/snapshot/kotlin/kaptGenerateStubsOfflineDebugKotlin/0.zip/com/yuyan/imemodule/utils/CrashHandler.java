package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 \u00192\u00020\u0001:\u0001\u0019B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0012\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u0004H\u0002J\u0012\u0010\u000e\u001a\u00020\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0002J\u000e\u0010\u0012\u001a\u00020\f2\u0006\u0010\u0013\u001a\u00020\u0004J\u0012\u0010\u0014\u001a\u0004\u0018\u00010\n2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J\u0018\u0010\u0015\u001a\u00020\f2\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0011H\u0016R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0001X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001a"}, d2 = {"Lcom/yuyan/imemodule/utils/CrashHandler;", "Ljava/lang/Thread$UncaughtExceptionHandler;", "()V", "mContext", "Landroid/content/Context;", "mDefaultHandler", "mFormatter", "Ljava/text/SimpleDateFormat;", "mInfoMap", "Ljava/util/HashMap;", "", "collectDeviceInfo", "", "ctx", "handleException", "", "ex", "", "init", "context", "saveCrashInfoToFile", "uncaughtException", "thread", "Ljava/lang/Thread;", "throwable", "Companion", "yuyansdk_offlineDebug"})
public final class CrashHandler implements java.lang.Thread.UncaughtExceptionHandler {
    @org.jetbrains.annotations.Nullable()
    private android.content.Context mContext;
    @org.jetbrains.annotations.NotNull()
    private final java.util.HashMap<java.lang.String, java.lang.String> mInfoMap = null;
    @org.jetbrains.annotations.NotNull()
    private final java.text.SimpleDateFormat mFormatter = null;
    @org.jetbrains.annotations.Nullable()
    private java.lang.Thread.UncaughtExceptionHandler mDefaultHandler;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.Lazy<?> instance$delegate = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.CrashHandler.Companion Companion = null;
    
    private CrashHandler() {
        super();
    }
    
    public final void init(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    @java.lang.Override()
    public void uncaughtException(@org.jetbrains.annotations.NotNull()
    java.lang.Thread thread, @org.jetbrains.annotations.NotNull()
    java.lang.Throwable throwable) {
    }
    
    private final boolean handleException(java.lang.Throwable ex) {
        return false;
    }
    
    private final void collectDeviceInfo(android.content.Context ctx) {
    }
    
    private final java.lang.String saveCrashInfoToFile(java.lang.Throwable ex) {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u001b\u0010\u0003\u001a\u00020\u00048FX\u0086\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/utils/CrashHandler$Companion;", "", "()V", "instance", "Lcom/yuyan/imemodule/utils/CrashHandler;", "getInstance", "()Lcom/yuyan/imemodule/utils/CrashHandler;", "instance$delegate", "Lkotlin/Lazy;", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.utils.CrashHandler getInstance() {
            return null;
        }
    }
}
package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010\u0003\u001a\u00020\u0004J&\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00072\b\b\u0001\u0010\b\u001a\u00020\t2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u000bH\u0002J\u000e\u0010\f\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\r\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007J\u001a\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00072\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u000bJ\u0018\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\u0012\u001a\u00020\tJ\u000e\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0014\u001a\u00020\u0007\u00a8\u0006\u0015"}, d2 = {"Lcom/yuyan/imemodule/utils/AppUtil;", "", "()V", "exit", "", "launchMainToDest", "context", "Landroid/content/Context;", "dest", "", "arguments", "Landroid/os/Bundle;", "launchMarketforYuyan", "launchSettings", "launchSettingsToInput", "launchSettingsToKeyboard", "launchSettingsToPrefix", "launchSettingsToTheme", "initialTab", "showRestartNotification", "ctx", "yuyansdk_offlineDebug"})
public final class AppUtil {
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.utils.AppUtil INSTANCE = null;
    
    private AppUtil() {
        super();
    }
    
    public final void launchSettings(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    private final void launchMainToDest(android.content.Context context, @androidx.annotation.IdRes()
    int dest, android.os.Bundle arguments) {
    }
    
    public final void launchSettingsToInput(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    public final void launchSettingsToTheme(@org.jetbrains.annotations.NotNull()
    android.content.Context context, int initialTab) {
    }
    
    public final void launchSettingsToKeyboard(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    public final void launchSettingsToPrefix(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.os.Bundle arguments) {
    }
    
    public final void launchMarketforYuyan(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
    }
    
    public final void exit() {
    }
    
    public final void showRestartNotification(@org.jetbrains.annotations.NotNull()
    android.content.Context ctx) {
    }
}
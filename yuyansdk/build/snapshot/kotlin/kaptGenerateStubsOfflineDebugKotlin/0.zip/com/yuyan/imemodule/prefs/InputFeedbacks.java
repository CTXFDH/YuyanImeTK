package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010%\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001:\u0001;B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0018\u0010-\u001a\u00020.2\u0006\u0010/\u001a\u0002002\b\b\u0002\u00101\u001a\u00020\u0006J\b\u00102\u001a\u00020\u0006H\u0002J\u0010\u00103\u001a\u00020\u00142\u0006\u00104\u001a\u00020\rH\u0002J\u0012\u00105\u001a\u0004\u0018\u00010\r2\u0006\u00106\u001a\u00020\rH\u0002J\u0006\u00107\u001a\u00020.J\u000e\u00108\u001a\u00020.2\u0006\u00109\u001a\u00020:R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001b\u0010\f\u001a\u00020\r8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u000e\u0010\u000fR\u001a\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00140\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001b\u0010\u0015\u001a\u00020\u00148BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u0018\u0010\u0019\u001a\u0004\b\u0016\u0010\u0017R\u001b\u0010\u001a\u001a\u00020\u001b8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b\u001c\u0010\u001dR\u001b\u0010 \u001a\u00020\r8BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b\"\u0010\u0011\u001a\u0004\b!\u0010\u000fR\u001b\u0010#\u001a\u00020\u00068BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b&\u0010\'\u001a\u0004\b$\u0010%R\u001b\u0010(\u001a\u00020\u00148BX\u0082\u0084\u0002\u00a2\u0006\f\n\u0004\b*\u0010\u0019\u001a\u0004\b)\u0010\u0017R\u000e\u0010+\u001a\u00020,X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006<"}, d2 = {"Lcom/yuyan/imemodule/prefs/InputFeedbacks;", "", "()V", "audioManager", "Landroid/media/AudioManager;", "hasAmplitudeControl", "", "soundEffectDeletePref", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PString;", "soundEffectReturnPref", "soundEffectSpaceBarPref", "soundEffectStandardPref", "soundEndTime", "", "getSoundEndTime", "()Ljava/lang/String;", "soundEndTime$delegate", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PString;", "soundMap", "", "", "soundOnKeyPress", "getSoundOnKeyPress", "()I", "soundOnKeyPress$delegate", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PInt;", "soundPool", "Landroid/media/SoundPool;", "getSoundPool", "()Landroid/media/SoundPool;", "soundPool$delegate", "Lkotlin/Lazy;", "soundStartTime", "getSoundStartTime", "soundStartTime$delegate", "soundTimeRangeEnable", "getSoundTimeRangeEnable", "()Z", "soundTimeRangeEnable$delegate", "Lcom/yuyan/imemodule/view/preference/ManagedPreference$PBool;", "vibrationAmplitude", "getVibrationAmplitude", "vibrationAmplitude$delegate", "vibrator", "Landroid/os/Vibrator;", "hapticFeedback", "", "view", "Landroid/view/View;", "isRelease", "isCurrentTimeInSoundRange", "loadSoundFromAssets", "fileName", "mapChoiceToFileName", "choice", "preloadCurrentSounds", "soundEffect", "effect", "Lcom/yuyan/imemodule/prefs/InputFeedbacks$SoundEffect;", "SoundEffect", "yuyansdk_offlineDebug"})
public final class InputFeedbacks {
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PInt soundOnKeyPress$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PInt vibrationAmplitude$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PBool soundTimeRangeEnable$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundStartTime$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEndTime$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEffectStandardPref = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEffectSpaceBarPref = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEffectDeletePref = null;
    @org.jetbrains.annotations.NotNull()
    private static final com.yuyan.imemodule.view.preference.ManagedPreference.PString soundEffectReturnPref = null;
    @org.jetbrains.annotations.NotNull()
    private static final android.os.Vibrator vibrator = null;
    private static final boolean hasAmplitudeControl = false;
    @org.jetbrains.annotations.NotNull()
    private static final android.media.AudioManager audioManager = null;
    @org.jetbrains.annotations.NotNull()
    private static final kotlin.Lazy soundPool$delegate = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.String, java.lang.Integer> soundMap = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.prefs.InputFeedbacks INSTANCE = null;
    
    private InputFeedbacks() {
        super();
    }
    
    private final int getSoundOnKeyPress() {
        return 0;
    }
    
    private final int getVibrationAmplitude() {
        return 0;
    }
    
    private final boolean getSoundTimeRangeEnable() {
        return false;
    }
    
    private final java.lang.String getSoundStartTime() {
        return null;
    }
    
    private final java.lang.String getSoundEndTime() {
        return null;
    }
    
    private final boolean isCurrentTimeInSoundRange() {
        return false;
    }
    
    private final android.media.SoundPool getSoundPool() {
        return null;
    }
    
    private final int loadSoundFromAssets(java.lang.String fileName) {
        return 0;
    }
    
    /**
     * 预加载当前选中的音频文件，解决 SoundPool 首次异步加载导致的首击无声音延迟问题
     */
    public final void preloadCurrentSounds() {
    }
    
    private final java.lang.String mapChoiceToFileName(java.lang.String choice) {
        return null;
    }
    
    public final void hapticFeedback(@org.jetbrains.annotations.NotNull()
    android.view.View view, boolean isRelease) {
    }
    
    public final void soundEffect(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.InputFeedbacks.SoundEffect effect) {
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0006\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002j\u0002\b\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/prefs/InputFeedbacks$SoundEffect;", "", "(Ljava/lang/String;I)V", "Standard", "SpaceBar", "Delete", "Return", "yuyansdk_offlineDebug"})
    public static enum SoundEffect {
        /*public static final*/ Standard /* = new Standard() */,
        /*public static final*/ SpaceBar /* = new SpaceBar() */,
        /*public static final*/ Delete /* = new Delete() */,
        /*public static final*/ Return /* = new Return() */;
        
        SoundEffect() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public static kotlin.enums.EnumEntries<com.yuyan.imemodule.prefs.InputFeedbacks.SoundEffect> getEntries() {
            return null;
        }
    }
}
package com.yuyan.inputmethod.util;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0010\f\n\u0002\b\b\n\u0002\u0010\u0011\n\u0002\b\u0003\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0016\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u0005J\u0010\u0010\f\u001a\u00020\u00052\b\u0010\r\u001a\u0004\u0018\u00010\u0005J\u000e\u0010\u000e\u001a\u00020\b2\u0006\u0010\u000f\u001a\u00020\bJ\u001b\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00050\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0013R\u001a\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0014"}, d2 = {"Lcom/yuyan/inputmethod/util/T9PinYinUtils;", "", "()V", "pinyinMap", "Ljava/util/HashMap;", "", "t9KeyMap", "", "", "getT9Composition", "composition", "comment", "pinyin2Key", "sequence", "pinyin2T9Key", "pinyin", "t9KeyToPinyin", "", "t9Sequence", "(Ljava/lang/String;)[Ljava/lang/String;", "yuyansdk_offlineDebug"})
public final class T9PinYinUtils {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Character, java.lang.Character> t9KeyMap = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.HashMap<java.lang.String, java.lang.String> pinyinMap = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.util.T9PinYinUtils INSTANCE = null;
    
    private T9PinYinUtils() {
        super();
    }
    
    /**
     * 获取T9键码对应的拼音组合
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[] t9KeyToPinyin(@org.jetbrains.annotations.Nullable()
    java.lang.String t9Sequence) {
        return null;
    }
    
    /**
     * 获取拼音对应的键码
     */
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String pinyin2Key(@org.jetbrains.annotations.Nullable()
    java.lang.String sequence) {
        return null;
    }
    
    public final char pinyin2T9Key(char pinyin) {
        return '\u0000';
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String getT9Composition(@org.jetbrains.annotations.NotNull()
    java.lang.String composition, @org.jetbrains.annotations.NotNull()
    java.lang.String comment) {
        return null;
    }
}
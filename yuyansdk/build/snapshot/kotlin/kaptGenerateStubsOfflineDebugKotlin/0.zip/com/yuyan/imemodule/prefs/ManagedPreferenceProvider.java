package com.yuyan.imemodule.prefs;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010%\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\'\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0016J\u000e\u0010\u0016\u001a\u00020\u0013*\u0006\u0012\u0002\b\u00030\u0006J\u000e\u0010\u0017\u001a\u00020\u0013*\u0006\u0012\u0002\b\u00030\tR\u001e\u0010\u0003\u001a\u0012\u0012\u0004\u0012\u00020\u0005\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0018\u0010\u0007\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\t0\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R!\u0010\n\u001a\u0012\u0012\u0004\u0012\u00020\u0005\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u000b8F\u00a2\u0006\u0006\u001a\u0004\b\f\u0010\rR\u001b\u0010\u000e\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\t0\u000f8F\u00a2\u0006\u0006\u001a\u0004\b\u0010\u0010\u0011\u00a8\u0006\u0018"}, d2 = {"Lcom/yuyan/imemodule/prefs/ManagedPreferenceProvider;", "", "()V", "_managedPreferences", "", "", "Lcom/yuyan/imemodule/view/preference/ManagedPreference;", "_managedPreferencesUi", "", "Lcom/yuyan/imemodule/prefs/ManagedPreferenceUi;", "managedPreferences", "", "getManagedPreferences", "()Ljava/util/Map;", "managedPreferencesUi", "", "getManagedPreferencesUi", "()Ljava/util/List;", "createUi", "", "screen", "Landroidx/preference/PreferenceScreen;", "register", "registerUi", "yuyansdk_offlineDebug"})
public abstract class ManagedPreferenceProvider {
    @org.jetbrains.annotations.NotNull()
    private final java.util.Map<java.lang.String, com.yuyan.imemodule.view.preference.ManagedPreference<?>> _managedPreferences = null;
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.prefs.ManagedPreferenceUi<?>> _managedPreferencesUi = null;
    
    public ManagedPreferenceProvider() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.String, com.yuyan.imemodule.view.preference.ManagedPreference<?>> getManagedPreferences() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.prefs.ManagedPreferenceUi<?>> getManagedPreferencesUi() {
        return null;
    }
    
    public void createUi(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceScreen screen) {
    }
    
    public final void registerUi(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.prefs.ManagedPreferenceUi<?> $this$registerUi) {
    }
    
    public final void register(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.view.preference.ManagedPreference<?> $this$register) {
    }
}
package com.yuyan.imemodule.libs.cropper;

/**
 * Animation to handle smooth cropping image matrix transformation change, specifically for
 * zoom-in/out.
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0000\u0018\u00002\u00020\u00012\u00020\u0002B\u0015\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J\u0018\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0015H\u0014J\u0010\u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u0001H\u0016J\u0010\u0010\u0018\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u0001H\u0016J\u0010\u0010\u0019\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u0001H\u0016J\u0016\u0010\u001a\u001a\u00020\u00112\u0006\u0010\u001b\u001a\u00020\t2\u0006\u0010\u001c\u001a\u00020\u001dJ\u0016\u0010\u001e\u001a\u00020\u00112\u0006\u0010\u001b\u001a\u00020\t2\u0006\u0010\u001c\u001a\u00020\u001dR\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageAnimation;", "Landroid/view/animation/Animation;", "Landroid/view/animation/Animation$AnimationListener;", "imageView", "Landroid/widget/ImageView;", "cropOverlayView", "Lcom/yuyan/imemodule/libs/cropper/CropOverlayView;", "(Landroid/widget/ImageView;Lcom/yuyan/imemodule/libs/cropper/CropOverlayView;)V", "endBoundPoints", "", "endCropWindowRect", "Landroid/graphics/RectF;", "endImageMatrix", "startBoundPoints", "startCropWindowRect", "startImageMatrix", "applyTransformation", "", "interpolatedTime", "", "t", "Landroid/view/animation/Transformation;", "onAnimationEnd", "animation", "onAnimationRepeat", "onAnimationStart", "setEndState", "boundPoints", "imageMatrix", "Landroid/graphics/Matrix;", "setStartState", "yuyansdk_offlineDebug"})
public final class CropImageAnimation extends android.view.animation.Animation implements android.view.animation.Animation.AnimationListener {
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ImageView imageView = null;
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.libs.cropper.CropOverlayView cropOverlayView = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] startBoundPoints = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] endBoundPoints = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.RectF startCropWindowRect = null;
    @org.jetbrains.annotations.NotNull()
    private final android.graphics.RectF endCropWindowRect = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] startImageMatrix = null;
    @org.jetbrains.annotations.NotNull()
    private final float[] endImageMatrix = null;
    
    public CropImageAnimation(@org.jetbrains.annotations.NotNull()
    android.widget.ImageView imageView, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropOverlayView cropOverlayView) {
        super();
    }
    
    public final void setStartState(@org.jetbrains.annotations.NotNull()
    float[] boundPoints, @org.jetbrains.annotations.NotNull()
    android.graphics.Matrix imageMatrix) {
    }
    
    public final void setEndState(@org.jetbrains.annotations.NotNull()
    float[] boundPoints, @org.jetbrains.annotations.NotNull()
    android.graphics.Matrix imageMatrix) {
    }
    
    @java.lang.Override()
    protected void applyTransformation(float interpolatedTime, @org.jetbrains.annotations.NotNull()
    android.view.animation.Transformation t) {
    }
    
    @java.lang.Override()
    public void onAnimationStart(@org.jetbrains.annotations.NotNull()
    android.view.animation.Animation animation) {
    }
    
    @java.lang.Override()
    public void onAnimationEnd(@org.jetbrains.annotations.NotNull()
    android.view.animation.Animation animation) {
    }
    
    @java.lang.Override()
    public void onAnimationRepeat(@org.jetbrains.annotations.NotNull()
    android.view.animation.Animation animation) {
    }
}
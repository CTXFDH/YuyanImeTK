package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000<\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0003\u001a-\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\b\b\u0001\u0010\u0003\u001a\u00020\u00042\u0017\u0010\u0005\u001a\u0013\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00010\u0006\u00a2\u0006\u0002\b\b\u001a+\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\t2\u0017\u0010\u0005\u001a\u0013\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u00010\u0006\u00a2\u0006\u0002\b\b\u001aC\u0010\n\u001a\u00020\u0001*\u00020\u000b2\b\b\u0001\u0010\u0003\u001a\u00020\u00042\n\b\u0003\u0010\f\u001a\u0004\u0018\u00010\u00042\n\b\u0003\u0010\r\u001a\u0004\u0018\u00010\u00042\u0010\b\u0002\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u000f\u00a2\u0006\u0002\u0010\u0010\u001a?\u0010\n\u001a\u00020\u0001*\u00020\u000b2\b\b\u0001\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\t2\n\b\u0003\u0010\r\u001a\u0004\u0018\u00010\u00042\u0010\b\u0002\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u000f\u00a2\u0006\u0002\u0010\u0012\u001aA\u0010\n\u001a\u00020\u0001*\u00020\u000b2\u0006\u0010\u0003\u001a\u00020\t2\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\t2\n\b\u0003\u0010\r\u001a\u0004\u0018\u00010\u00042\u0010\b\u0002\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u000f\u00a2\u0006\u0002\u0010\u0014\u001aY\u0010\u0015\u001a\u00020\u0001*\u00020\u000b2\u0006\u0010\u0003\u001a\u00020\t2\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\t2\u0006\u0010\u0016\u001a\u00020\t2\b\b\u0002\u0010\u0017\u001a\u00020\u00182\n\b\u0003\u0010\r\u001a\u0004\u0018\u00010\u00042\u0016\b\u0002\u0010\u0019\u001a\u0010\u0012\u0004\u0012\u00020\u0018\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u0006\u00a2\u0006\u0002\u0010\u001a\u00a8\u0006\u001b"}, d2 = {"addCategory", "", "Landroidx/preference/PreferenceScreen;", "title", "", "block", "Lkotlin/Function1;", "Landroidx/preference/PreferenceCategory;", "Lkotlin/ExtensionFunctionType;", "", "addPreference", "Landroidx/preference/PreferenceGroup;", "summaryRes", "icon", "onClick", "Lkotlin/Function0;", "(Landroidx/preference/PreferenceGroup;ILjava/lang/Integer;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)V", "summaryStr", "(Landroidx/preference/PreferenceGroup;ILjava/lang/String;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)V", "summary", "(Landroidx/preference/PreferenceGroup;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Lkotlin/jvm/functions/Function0;)V", "addSwitchPreference", "key", "defaultValue", "", "onChange", "(Landroidx/preference/PreferenceGroup;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function1;)V", "yuyansdk_offlineDebug"})
public final class PreferenceScreenKt {
    
    public static final void addCategory(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceScreen $this$addCategory, @org.jetbrains.annotations.NotNull()
    java.lang.String title, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super androidx.preference.PreferenceCategory, kotlin.Unit> block) {
    }
    
    public static final void addCategory(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceScreen $this$addCategory, @androidx.annotation.StringRes()
    int title, @org.jetbrains.annotations.NotNull()
    kotlin.jvm.functions.Function1<? super androidx.preference.PreferenceCategory, kotlin.Unit> block) {
    }
    
    public static final void addPreference(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceGroup $this$addPreference, @org.jetbrains.annotations.NotNull()
    java.lang.String title, @org.jetbrains.annotations.Nullable()
    java.lang.String summary, @androidx.annotation.DrawableRes()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer icon, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> onClick) {
    }
    
    public static final void addPreference(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceGroup $this$addPreference, @androidx.annotation.StringRes()
    int title, @org.jetbrains.annotations.NotNull()
    java.lang.String summaryStr, @androidx.annotation.DrawableRes()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer icon, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> onClick) {
    }
    
    public static final void addPreference(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceGroup $this$addPreference, @androidx.annotation.StringRes()
    int title, @androidx.annotation.StringRes()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer summaryRes, @androidx.annotation.DrawableRes()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer icon, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function0<kotlin.Unit> onClick) {
    }
    
    public static final void addSwitchPreference(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceGroup $this$addSwitchPreference, @org.jetbrains.annotations.NotNull()
    java.lang.String title, @org.jetbrains.annotations.Nullable()
    java.lang.String summary, @org.jetbrains.annotations.NotNull()
    java.lang.String key, boolean defaultValue, @androidx.annotation.DrawableRes()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer icon, @org.jetbrains.annotations.Nullable()
    kotlin.jvm.functions.Function1<? super java.lang.Boolean, kotlin.Unit> onChange) {
    }
}
package com.yuyan.imemodule.utils;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000.\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\"\u0015\u0010\u0000\u001a\u00020\u0001*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u0003\u0010\u0004\"\u0015\u0010\u0005\u001a\u00020\u0006*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u0007\u0010\b\"\u0015\u0010\t\u001a\u00020\n*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u000b\u0010\f\"\u0015\u0010\r\u001a\u00020\u000e*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u000f\u0010\u0010\"\u0015\u0010\u0011\u001a\u00020\u0012*\u00020\u00028F\u00a2\u0006\u0006\u001a\u0004\b\u0013\u0010\u0014\u00a8\u0006\u0015"}, d2 = {"audioManager", "Landroid/media/AudioManager;", "Landroid/content/Context;", "getAudioManager", "(Landroid/content/Context;)Landroid/media/AudioManager;", "clipboardManager", "Landroid/content/ClipboardManager;", "getClipboardManager", "(Landroid/content/Context;)Landroid/content/ClipboardManager;", "inputMethodManager", "Landroid/view/inputmethod/InputMethodManager;", "getInputMethodManager", "(Landroid/content/Context;)Landroid/view/inputmethod/InputMethodManager;", "notificationManager", "Landroid/app/NotificationManager;", "getNotificationManager", "(Landroid/content/Context;)Landroid/app/NotificationManager;", "vibrator", "Landroid/os/Vibrator;", "getVibrator", "(Landroid/content/Context;)Landroid/os/Vibrator;", "yuyansdk_offlineDebug"})
public final class SystemServiceKt {
    
    @org.jetbrains.annotations.NotNull()
    public static final android.media.AudioManager getAudioManager(@org.jetbrains.annotations.NotNull()
    android.content.Context $this$audioManager) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final android.content.ClipboardManager getClipboardManager(@org.jetbrains.annotations.NotNull()
    android.content.Context $this$clipboardManager) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final android.view.inputmethod.InputMethodManager getInputMethodManager(@org.jetbrains.annotations.NotNull()
    android.content.Context $this$inputMethodManager) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final android.app.NotificationManager getNotificationManager(@org.jetbrains.annotations.NotNull()
    android.content.Context $this$notificationManager) {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final android.os.Vibrator getVibrator(@org.jetbrains.annotations.NotNull()
    android.content.Context $this$vibrator) {
        return null;
    }
}
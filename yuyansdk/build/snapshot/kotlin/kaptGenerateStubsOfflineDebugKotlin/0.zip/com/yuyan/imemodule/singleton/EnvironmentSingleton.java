package com.yuyan.imemodule.singleton;

/**
 * Global environment configurations for showing soft keyboard and candidate
 * view. All original dimension values are defined in float, and the real size
 * is calculated from the float values of and screen size. In this way, this
 * input method can work even when screen size is changed.
 * 该类保存布局的一些尺寸。比如：屏幕的宽度、屏幕的高度
 * 、按键的高度、候选词区域的高度、按键气泡宽度比按键宽度大的差值、按键气泡高度比按键高度大的差值、正常按键中文本的大小
 * 、功能按键中文本的大小、正常按键气泡中文本的大小、功能按键气泡中文本的大小。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u001a\n\u0002\u0010\u000b\n\u0002\b)\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 W2\u00020\u0001:\u0001WB\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u001c\u0010Q\u001a\u00020R2\b\b\u0002\u0010S\u001a\u00020T2\n\b\u0002\u0010U\u001a\u0004\u0018\u00010VR\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001a\u0010\t\u001a\u00020\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR\u001a\u0010\f\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000e\u0010\u000f\"\u0004\b\u0010\u0010\u0011R\u001a\u0010\u0012\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010\u000f\"\u0004\b\u0014\u0010\u0011R\u001a\u0010\u0015\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0016\u0010\u000f\"\u0004\b\u0017\u0010\u0011R\u001a\u0010\u0018\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0019\u0010\u000f\"\u0004\b\u001a\u0010\u0011R\u001a\u0010\u001b\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u001c\u0010\u000f\"\u0004\b\u001d\u0010\u0011R\u001e\u0010\u001f\u001a\u00020\r2\u0006\u0010\u001e\u001a\u00020\r@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\u000fR\u001a\u0010!\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\"\u0010\u000f\"\u0004\b#\u0010\u0011R\u001a\u0010$\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b%\u0010\u000f\"\u0004\b&\u0010\u0011R\u001a\u0010\'\u001a\u00020(X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\'\u0010)\"\u0004\b*\u0010+R$\u0010,\u001a\u00020\u00042\u0006\u0010,\u001a\u00020\u00048F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b-\u0010\u0006\"\u0004\b.\u0010\bR\u001a\u0010/\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b0\u0010\u000f\"\u0004\b1\u0010\u0011R\u001a\u00102\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b3\u0010\u000f\"\u0004\b4\u0010\u0011R\u001a\u00105\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b6\u0010\u000f\"\u0004\b7\u0010\u0011R\u001a\u00108\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b9\u0010\u000f\"\u0004\b:\u0010\u0011R\u000e\u0010;\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R$\u0010=\u001a\u00020(2\u0006\u0010<\u001a\u00020(8F@FX\u0086\u000e\u00a2\u0006\f\u001a\u0004\b>\u0010)\"\u0004\b?\u0010+R\u0011\u0010@\u001a\u00020\r8F\u00a2\u0006\u0006\u001a\u0004\bA\u0010\u000fR\u001a\u0010B\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bC\u0010\u000f\"\u0004\bD\u0010\u0011R\u001a\u0010E\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bF\u0010\u000f\"\u0004\bG\u0010\u0011R\u0011\u0010H\u001a\u00020\r8F\u00a2\u0006\u0006\u001a\u0004\bI\u0010\u000fR\u001e\u0010J\u001a\u00020\r2\u0006\u0010\u001e\u001a\u00020\r@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\bK\u0010\u000fR\u001e\u0010L\u001a\u00020\r2\u0006\u0010\u001e\u001a\u00020\r@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\bM\u0010\u000fR\u001a\u0010N\u001a\u00020\rX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\bO\u0010\u000f\"\u0004\bP\u0010\u0011\u00a8\u0006X"}, d2 = {"Lcom/yuyan/imemodule/singleton/EnvironmentSingleton;", "", "()V", "candidateTextSize", "", "getCandidateTextSize", "()F", "setCandidateTextSize", "(F)V", "composingTextSize", "getComposingTextSize", "setComposingTextSize", "heightForCandidates", "", "getHeightForCandidates", "()I", "setHeightForCandidates", "(I)V", "heightForCandidatesArea", "getHeightForCandidatesArea", "setHeightForCandidatesArea", "heightForFullDisplayBar", "getHeightForFullDisplayBar", "setHeightForFullDisplayBar", "heightForKeyboardMove", "getHeightForKeyboardMove", "setHeightForKeyboardMove", "heightForcomposing", "getHeightForcomposing", "setHeightForcomposing", "<set-?>", "holderWidth", "getHolderWidth", "inputAreaHeight", "getInputAreaHeight", "setInputAreaHeight", "inputAreaWidth", "getInputAreaWidth", "setInputAreaWidth", "isLandscape", "", "()Z", "setLandscape", "(Z)V", "keyBoardHeightRatio", "getKeyBoardHeightRatio", "setKeyBoardHeightRatio", "keyTextSize", "getKeyTextSize", "setKeyTextSize", "keyTextSmallSize", "getKeyTextSmallSize", "setKeyTextSmallSize", "keyXMargin", "getKeyXMargin", "setKeyXMargin", "keyYMargin", "getKeyYMargin", "setKeyYMargin", "keyboardHeightRatio", "isFloatMode", "keyboardModeFloat", "getKeyboardModeFloat", "setKeyboardModeFloat", "leftMarginWidth", "getLeftMarginWidth", "mScreenHeight", "getMScreenHeight", "setMScreenHeight", "mScreenWidth", "getMScreenWidth", "setMScreenWidth", "skbAreaHeight", "getSkbAreaHeight", "skbHeight", "getSkbHeight", "skbWidth", "getSkbWidth", "systemNavbarWindowsBottom", "getSystemNavbarWindowsBottom", "setSystemNavbarWindowsBottom", "initData", "", "context", "Landroid/content/Context;", "config", "Landroid/content/res/Configuration;", "Companion", "yuyansdk_offlineDebug"})
public final class EnvironmentSingleton {
    private int systemNavbarWindowsBottom = 0;
    private int mScreenWidth = 0;
    private int mScreenHeight = 0;
    private int inputAreaHeight = 0;
    private int inputAreaWidth = 0;
    private int skbWidth = 0;
    private int skbHeight = 0;
    private int holderWidth = 0;
    private int heightForCandidatesArea = 0;
    private int heightForcomposing = 0;
    private int heightForCandidates = 0;
    private int heightForFullDisplayBar = 0;
    private int heightForKeyboardMove = 0;
    private int keyTextSize = 0;
    private int keyTextSmallSize = 0;
    private float candidateTextSize = 0.0F;
    private float composingTextSize = 0.0F;
    private boolean isLandscape = false;
    private int keyXMargin = 0;
    private int keyYMargin = 0;
    private float keyboardHeightRatio = 0.0F;
    @org.jetbrains.annotations.Nullable()
    private static com.yuyan.imemodule.singleton.EnvironmentSingleton mInstance;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.singleton.EnvironmentSingleton.Companion Companion = null;
    
    private EnvironmentSingleton() {
        super();
    }
    
    public final int getSystemNavbarWindowsBottom() {
        return 0;
    }
    
    public final void setSystemNavbarWindowsBottom(int p0) {
    }
    
    public final int getMScreenWidth() {
        return 0;
    }
    
    public final void setMScreenWidth(int p0) {
    }
    
    public final int getMScreenHeight() {
        return 0;
    }
    
    public final void setMScreenHeight(int p0) {
    }
    
    public final int getInputAreaHeight() {
        return 0;
    }
    
    public final void setInputAreaHeight(int p0) {
    }
    
    public final int getInputAreaWidth() {
        return 0;
    }
    
    public final void setInputAreaWidth(int p0) {
    }
    
    public final int getSkbWidth() {
        return 0;
    }
    
    public final int getSkbHeight() {
        return 0;
    }
    
    public final int getHolderWidth() {
        return 0;
    }
    
    public final int getHeightForCandidatesArea() {
        return 0;
    }
    
    public final void setHeightForCandidatesArea(int p0) {
    }
    
    public final int getHeightForcomposing() {
        return 0;
    }
    
    public final void setHeightForcomposing(int p0) {
    }
    
    public final int getHeightForCandidates() {
        return 0;
    }
    
    public final void setHeightForCandidates(int p0) {
    }
    
    public final int getHeightForFullDisplayBar() {
        return 0;
    }
    
    public final void setHeightForFullDisplayBar(int p0) {
    }
    
    public final int getHeightForKeyboardMove() {
        return 0;
    }
    
    public final void setHeightForKeyboardMove(int p0) {
    }
    
    public final int getKeyTextSize() {
        return 0;
    }
    
    public final void setKeyTextSize(int p0) {
    }
    
    public final int getKeyTextSmallSize() {
        return 0;
    }
    
    public final void setKeyTextSmallSize(int p0) {
    }
    
    public final float getCandidateTextSize() {
        return 0.0F;
    }
    
    public final void setCandidateTextSize(float p0) {
    }
    
    public final float getComposingTextSize() {
        return 0.0F;
    }
    
    public final void setComposingTextSize(float p0) {
    }
    
    public final boolean isLandscape() {
        return false;
    }
    
    public final void setLandscape(boolean p0) {
    }
    
    public final int getKeyXMargin() {
        return 0;
    }
    
    public final void setKeyXMargin(int p0) {
    }
    
    public final int getKeyYMargin() {
        return 0;
    }
    
    public final void setKeyYMargin(int p0) {
    }
    
    public final void initData(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.content.res.Configuration config) {
    }
    
    /**
     * 获取键盘高度比例：相对于屏幕宽度
     */
    public final float getKeyBoardHeightRatio() {
        return 0.0F;
    }
    
    /**
     * 设置键盘高度比例：相对于屏幕宽度
     */
    public final void setKeyBoardHeightRatio(float keyBoardHeightRatio) {
    }
    
    public final boolean getKeyboardModeFloat() {
        return false;
    }
    
    public final void setKeyboardModeFloat(boolean isFloatMode) {
    }
    
    public final int getSkbAreaHeight() {
        return 0;
    }
    
    public final int getLeftMarginWidth() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.singleton.EnvironmentSingleton getInstance() {
        return null;
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u001a\u0010\u0003\u001a\u00020\u00048FX\u0087\u0004\u00a2\u0006\f\u0012\u0004\b\u0005\u0010\u0002\u001a\u0004\b\u0006\u0010\u0007R\u0010\u0010\b\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/singleton/EnvironmentSingleton$Companion;", "", "()V", "instance", "Lcom/yuyan/imemodule/singleton/EnvironmentSingleton;", "getInstance$annotations", "getInstance", "()Lcom/yuyan/imemodule/singleton/EnvironmentSingleton;", "mInstance", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
        
        @kotlin.jvm.JvmStatic()
        @java.lang.Deprecated()
        public static void getInstance$annotations() {
        }
        
        @org.jetbrains.annotations.NotNull()
        public final com.yuyan.imemodule.singleton.EnvironmentSingleton getInstance() {
            return null;
        }
    }
}
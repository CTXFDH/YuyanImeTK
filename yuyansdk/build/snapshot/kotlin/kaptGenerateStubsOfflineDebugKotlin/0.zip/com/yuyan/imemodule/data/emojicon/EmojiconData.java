package com.yuyan.imemodule.data.emojicon;

/**
 * Emoji表情实体类
 * @author Hieu Rocker (rockerhieu@gmail.com)
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\u0010 \n\u0002\b\u0006\n\u0002\u0010\u0011\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u001d\u0010\u0003\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R#\u0010\b\u001a\u0014\u0012\u0004\u0012\u00020\t\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\n0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\u0007R#\u0010\f\u001a\u0014\u0012\u0004\u0012\u00020\t\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\n0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u0007R#\u0010\u000e\u001a\u0014\u0012\u0004\u0012\u00020\t\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\n0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0007R)\u0010\u0010\u001a\u001a\u0012\u0004\u0012\u00020\u0005\u0012\u0010\u0012\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00110\n0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0007\u00a8\u0006\u0013"}, d2 = {"Lcom/yuyan/imemodule/data/emojicon/EmojiconData;", "", "()V", "SymbolPreset", "", "", "getSymbolPreset", "()Ljava/util/Map;", "emojiconData", "", "", "getEmojiconData", "emoticonData", "getEmoticonData", "symbolData", "getSymbolData", "wechatEmojiconData", "", "getWechatEmojiconData", "yuyansdk_offlineDebug"})
public final class EmojiconData {
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.util.List<java.lang.String>> symbolData = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.util.List<java.lang.String>> emoticonData = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.Integer, java.util.List<java.lang.String>> emojiconData = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.String, java.util.List<java.lang.String[]>> wechatEmojiconData = null;
    @org.jetbrains.annotations.NotNull()
    private static final java.util.Map<java.lang.String, java.lang.String> SymbolPreset = null;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.data.emojicon.EmojiconData INSTANCE = null;
    
    private EmojiconData() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.Integer, java.util.List<java.lang.String>> getSymbolData() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.Integer, java.util.List<java.lang.String>> getEmoticonData() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.Integer, java.util.List<java.lang.String>> getEmojiconData() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.String, java.util.List<java.lang.String[]>> getWechatEmojiconData() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.Map<java.lang.String, java.lang.String> getSymbolPreset() {
        return null;
    }
}
package com.yuyan.imemodule.ui.fragment.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000e\n\u0002\b\u000b\n\u0002\u0010 \n\u0002\b\u0003\b\'\u0018\u0000 22\b\u0012\u0004\u0012\u00020\u00020\u0001:\u000223B\u0005\u00a2\u0006\u0002\u0010\u0003J\u0012\u0010\r\u001a\u0004\u0018\u00010\t2\u0006\u0010\u000e\u001a\u00020\u0005H\u0002J\b\u0010\u000f\u001a\u00020\u0005H\u0016J\u0010\u0010\u0010\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u0005H\u0016J\b\u0010\u0011\u001a\u00020\u0012H&J\u0018\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\u0005H\u0016J\u0018\u0010\u0015\u001a\u00020\u00022\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0005H\u0016J\u0010\u0010\u0019\u001a\u00020\u00122\u0006\u0010\u001a\u001a\u00020\u001bH&J\u0010\u0010\u001c\u001a\u00020\u00122\u0006\u0010\u001a\u001a\u00020\u001bH&J\u0010\u0010\u001d\u001a\u00020\u00122\u0006\u0010\u001a\u001a\u00020\tH&J\u0014\u0010\u001e\u001a\u00020\u00052\n\b\u0002\u0010\u001a\u001a\u0004\u0018\u00010\tH\u0002J\u0010\u0010\u001f\u001a\u00020\u00052\u0006\u0010 \u001a\u00020\u0005H\u0002J\u000e\u0010!\u001a\u00020\u00122\u0006\u0010\"\u001a\u00020\tJ\u000e\u0010#\u001a\u00020\u00122\u0006\u0010$\u001a\u00020%J\u0018\u0010&\u001a\u00020\u00052\u0006\u0010\'\u001a\u00020\u00052\u0006\u0010 \u001a\u00020\u0005H\u0002J\u0018\u0010(\u001a\u00020\u00052\u0006\u0010)\u001a\u00020\u00052\u0006\u0010 \u001a\u00020\u0005H\u0002J\u000e\u0010*\u001a\u00020\u00122\u0006\u0010\u001a\u001a\u00020\tJ&\u0010+\u001a\u00020\u00122\u0006\u0010,\u001a\u00020\t2\n\b\u0002\u0010-\u001a\u0004\u0018\u00010\t2\n\b\u0002\u0010.\u001a\u0004\u0018\u00010\tJ\u0014\u0010/\u001a\u00020\u00122\f\u00100\u001a\b\u0012\u0004\u0012\u00020\t01R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u000e\u0010\f\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00064"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ThemeListAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/yuyan/imemodule/ui/fragment/theme/ThemeListAdapter$ViewHolder;", "()V", "activeIndex", "", "darkIndex", "entries", "", "Lcom/yuyan/imemodule/data/theme/Theme;", "getEntries", "()Ljava/util/List;", "lightIndex", "entryAt", "position", "getItemCount", "getItemViewType", "onAddNewTheme", "", "onBindViewHolder", "holder", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "onEditTheme", "theme", "Lcom/yuyan/imemodule/data/theme/Theme$Custom;", "onExportTheme", "onSelectTheme", "positionOf", "prependOffset", "index", "prependTheme", "it", "removeTheme", "name", "", "removedOffset", "removedIndex", "replaceIndex", "replacedIndex", "replaceTheme", "setSelectedThemes", "active", "light", "dark", "setThemes", "themes", "", "Companion", "ViewHolder", "yuyansdk_offlineDebug"})
public abstract class ThemeListAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<com.yuyan.imemodule.ui.fragment.theme.ThemeListAdapter.ViewHolder> {
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.data.theme.Theme> entries = null;
    private int activeIndex = -1;
    private int lightIndex = -1;
    private int darkIndex = -1;
    public static final int OFFSET = 1;
    public static final int ADD_THEME = 0;
    public static final int THEME = 1;
    @org.jetbrains.annotations.NotNull()
    public static final java.lang.String INVALID_TYPE = "Invalid ItemView Type: ";
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.ui.fragment.theme.ThemeListAdapter.Companion Companion = null;
    
    public ThemeListAdapter() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.util.List<com.yuyan.imemodule.data.theme.Theme> getEntries() {
        return null;
    }
    
    private final com.yuyan.imemodule.data.theme.Theme entryAt(int position) {
        return null;
    }
    
    private final int positionOf(com.yuyan.imemodule.data.theme.Theme theme) {
        return 0;
    }
    
    public final void setThemes(@org.jetbrains.annotations.NotNull()
    java.util.List<? extends com.yuyan.imemodule.data.theme.Theme> themes) {
    }
    
    public final void setSelectedThemes(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme active, @org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.data.theme.Theme light, @org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.data.theme.Theme dark) {
    }
    
    private final int prependOffset(int index) {
        return 0;
    }
    
    public final void prependTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme it) {
    }
    
    private final int removedOffset(int removedIndex, int index) {
        return 0;
    }
    
    public final void removeTheme(@org.jetbrains.annotations.NotNull()
    java.lang.String name) {
    }
    
    private final int replaceIndex(int replacedIndex, int index) {
        return 0;
    }
    
    public final void replaceTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme) {
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.ui.fragment.theme.ThemeListAdapter.ViewHolder onCreateViewHolder(@org.jetbrains.annotations.NotNull()
    android.view.ViewGroup parent, int viewType) {
        return null;
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.ui.fragment.theme.ThemeListAdapter.ViewHolder holder, int position) {
    }
    
    @java.lang.Override()
    public int getItemCount() {
        return 0;
    }
    
    @java.lang.Override()
    public int getItemViewType(int position) {
        return 0;
    }
    
    public abstract void onAddNewTheme();
    
    public abstract void onSelectTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme theme);
    
    public abstract void onEditTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme.Custom theme);
    
    public abstract void onExportTheme(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.data.theme.Theme.Custom theme);
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\t"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ThemeListAdapter$Companion;", "", "()V", "ADD_THEME", "", "INVALID_TYPE", "", "OFFSET", "THEME", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006\u00a8\u0006\u0007"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/theme/ThemeListAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "ui", "Lsplitties/views/dsl/core/Ui;", "(Lsplitties/views/dsl/core/Ui;)V", "getUi", "()Lsplitties/views/dsl/core/Ui;", "yuyansdk_offlineDebug"})
    public static final class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        @org.jetbrains.annotations.NotNull()
        private final splitties.views.dsl.core.Ui ui = null;
        
        public ViewHolder(@org.jetbrains.annotations.NotNull()
        splitties.views.dsl.core.Ui ui) {
            super(null);
        }
        
        @org.jetbrains.annotations.NotNull()
        public final splitties.views.dsl.core.Ui getUi() {
            return null;
        }
    }
}
package com.yuyan.imemodule.entity.handwriting;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u001a\u0010\f\u001a\u00020\u00002\b\u0010\u0003\u001a\u0004\u0018\u00010\u00042\b\u0010\t\u001a\u0004\u0018\u00010\u0004R\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\u001c\u0010\t\u001a\u0004\u0018\u00010\u0004X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\b\u00a8\u0006\r"}, d2 = {"Lcom/yuyan/imemodule/entity/handwriting/ControlTimedPoints;", "", "()V", "c1", "Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;", "getC1", "()Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;", "setC1", "(Lcom/yuyan/imemodule/entity/handwriting/TimedPoint;)V", "c2", "getC2", "setC2", "set", "yuyansdk_offlineDebug"})
public final class ControlTimedPoints {
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.entity.handwriting.TimedPoint c1;
    @org.jetbrains.annotations.Nullable()
    private com.yuyan.imemodule.entity.handwriting.TimedPoint c2;
    
    public ControlTimedPoints() {
        super();
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.entity.handwriting.TimedPoint getC1() {
        return null;
    }
    
    public final void setC1(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.handwriting.TimedPoint p0) {
    }
    
    @org.jetbrains.annotations.Nullable()
    public final com.yuyan.imemodule.entity.handwriting.TimedPoint getC2() {
        return null;
    }
    
    public final void setC2(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.handwriting.TimedPoint p0) {
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.entity.handwriting.ControlTimedPoints set(@org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.handwriting.TimedPoint c1, @org.jetbrains.annotations.Nullable()
    com.yuyan.imemodule.entity.handwriting.TimedPoint c2) {
        return null;
    }
}
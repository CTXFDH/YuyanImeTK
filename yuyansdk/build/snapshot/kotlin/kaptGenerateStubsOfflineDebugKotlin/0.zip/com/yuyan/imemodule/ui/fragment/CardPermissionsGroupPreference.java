package com.yuyan.imemodule.ui.fragment;

/**
 * 将 4 项权限（剪切板、设备运动与方向、媒体音量控制、麦克风）包裹在同一个圆角矩形卡片内的自定义 Preference
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u00012\u00020\u0002B\r\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0002\u0010\u0005J\u0010\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0016R\u001a\u0010\u0006\u001a\u00020\u0007X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0006\u0010\b\"\u0004\b\t\u0010\nR\u001a\u0010\u000b\u001a\u00020\u0007X\u0096\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\b\"\u0004\b\f\u0010\n\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/ui/fragment/CardPermissionsGroupPreference;", "Landroidx/preference/Preference;", "Lcom/yuyan/imemodule/utils/ICardPreferenceItem;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "isFirstInGroup", "", "()Z", "setFirstInGroup", "(Z)V", "isLastInGroup", "setLastInGroup", "onBindViewHolder", "", "holder", "Landroidx/preference/PreferenceViewHolder;", "yuyansdk_offlineDebug"})
public final class CardPermissionsGroupPreference extends androidx.preference.Preference implements com.yuyan.imemodule.utils.ICardPreferenceItem {
    private boolean isFirstInGroup = false;
    private boolean isLastInGroup = false;
    
    public CardPermissionsGroupPreference(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        super(null, null, 0, 0);
    }
    
    @java.lang.Override()
    public boolean isFirstInGroup() {
        return false;
    }
    
    @java.lang.Override()
    public void setFirstInGroup(boolean p0) {
    }
    
    @java.lang.Override()
    public boolean isLastInGroup() {
        return false;
    }
    
    @java.lang.Override()
    public void setLastInGroup(boolean p0) {
    }
    
    @java.lang.Override()
    public void onBindViewHolder(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceViewHolder holder) {
    }
    
    @java.lang.Override()
    @android.annotation.SuppressLint(value = {"RestrictedApi"})
    public void bindCardViewHolder(@org.jetbrains.annotations.NotNull()
    androidx.preference.PreferenceViewHolder holder, @org.jetbrains.annotations.NotNull()
    androidx.preference.Preference pref) {
    }
}
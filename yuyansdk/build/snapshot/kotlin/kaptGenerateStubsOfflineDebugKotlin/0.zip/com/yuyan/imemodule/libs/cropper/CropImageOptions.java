package com.yuyan.imemodule.libs.cropper;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0086\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u001a\n\u0002\u0010\r\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\bV\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u00df\u0005\b\u0007\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0003\u0010\t\u001a\u00020\n\u0012\b\b\u0003\u0010\u000b\u001a\u00020\n\u0012\b\b\u0003\u0010\f\u001a\u00020\n\u0012\b\b\u0002\u0010\r\u001a\u00020\u000e\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0010\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0003\u0012\b\b\u0003\u0010\u0014\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u0016\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0017\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0018\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0019\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u001a\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u001b\u001a\u00020\n\u0012\b\b\u0002\u0010\u001c\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u001d\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u001e\u001a\u00020\u0015\u0012\b\b\u0003\u0010\u001f\u001a\u00020\n\u0012\b\b\u0003\u0010 \u001a\u00020\u0015\u0012\b\b\u0003\u0010!\u001a\u00020\n\u0012\b\b\u0003\u0010\"\u001a\u00020\n\u0012\b\b\u0003\u0010#\u001a\u00020\n\u0012\b\b\u0003\u0010$\u001a\u00020\u0015\u0012\b\b\u0003\u0010%\u001a\u00020\u0015\u0012\b\b\u0003\u0010&\u001a\u00020\n\u0012\b\b\u0003\u0010\'\u001a\u00020\u0015\u0012\b\b\u0003\u0010(\u001a\u00020\u0015\u0012\b\b\u0003\u0010)\u001a\u00020\u0015\u0012\b\b\u0003\u0010*\u001a\u00020\u0015\u0012\b\b\u0003\u0010+\u001a\u00020\u0015\u0012\b\b\u0003\u0010,\u001a\u00020\u0015\u0012\b\b\u0003\u0010-\u001a\u00020\u0015\u0012\b\b\u0003\u0010.\u001a\u00020\u0015\u0012\b\b\u0002\u0010/\u001a\u000200\u0012\b\b\u0003\u00101\u001a\u00020\u0015\u0012\n\b\u0003\u00102\u001a\u0004\u0018\u00010\u0015\u0012\n\b\u0002\u00103\u001a\u0004\u0018\u000104\u0012\b\b\u0002\u00105\u001a\u000206\u0012\b\b\u0002\u00107\u001a\u00020\u0015\u0012\b\b\u0003\u00108\u001a\u00020\u0015\u0012\b\b\u0003\u00109\u001a\u00020\u0015\u0012\b\b\u0002\u0010:\u001a\u00020;\u0012\b\b\u0002\u0010<\u001a\u00020\u0003\u0012\n\b\u0002\u0010=\u001a\u0004\u0018\u00010>\u0012\b\b\u0002\u0010?\u001a\u00020\u0015\u0012\b\b\u0002\u0010@\u001a\u00020\u0003\u0012\b\b\u0002\u0010A\u001a\u00020\u0003\u0012\b\b\u0002\u0010B\u001a\u00020\u0003\u0012\b\b\u0002\u0010C\u001a\u00020\u0015\u0012\b\b\u0002\u0010D\u001a\u00020\u0003\u0012\b\b\u0002\u0010E\u001a\u00020\u0003\u0012\n\b\u0002\u0010F\u001a\u0004\u0018\u000100\u0012\b\b\u0003\u0010G\u001a\u00020\u0015\u0012\b\b\u0002\u0010H\u001a\u00020\u0003\u0012\b\b\u0002\u0010I\u001a\u00020\u0003\u0012\n\b\u0002\u0010J\u001a\u0004\u0018\u00010K\u0012\u0010\b\u0002\u0010L\u001a\n\u0012\u0004\u0012\u00020K\u0018\u00010M\u0012\b\b\u0003\u0010N\u001a\u00020\n\u0012\b\b\u0003\u0010O\u001a\u00020\u0015\u0012\n\b\u0002\u0010P\u001a\u0004\u0018\u00010K\u0012\b\b\u0003\u0010Q\u001a\u00020\u0015\u0012\n\b\u0003\u0010R\u001a\u0004\u0018\u00010\u0015\u0012\n\b\u0003\u0010S\u001a\u0004\u0018\u00010\u0015\u0012\n\b\u0003\u0010T\u001a\u0004\u0018\u00010\u0015\u0012\n\b\u0003\u0010U\u001a\u0004\u0018\u00010\u0015\u00a2\u0006\u0002\u0010VJ\t\u0010X\u001a\u00020\u0003H\u00c6\u0003J\t\u0010Y\u001a\u00020\u0003H\u00c6\u0003J\t\u0010Z\u001a\u00020\u0003H\u00c6\u0003J\t\u0010[\u001a\u00020\u0003H\u00c6\u0003J\t\u0010\\\u001a\u00020\u0015H\u00c6\u0003J\t\u0010]\u001a\u00020\u0003H\u00c6\u0003J\t\u0010^\u001a\u00020\u0003H\u00c6\u0003J\t\u0010_\u001a\u00020\u0003H\u00c6\u0003J\t\u0010`\u001a\u00020\u0003H\u00c6\u0003J\t\u0010a\u001a\u00020\u0015H\u00c6\u0003J\t\u0010b\u001a\u00020\nH\u00c6\u0003J\t\u0010c\u001a\u00020\u0003H\u00c6\u0003J\t\u0010d\u001a\u00020\u0003H\u00c6\u0003J\t\u0010e\u001a\u00020\u0015H\u00c6\u0003J\t\u0010f\u001a\u00020\u0015H\u00c6\u0003J\t\u0010g\u001a\u00020\nH\u00c6\u0003J\t\u0010h\u001a\u00020\u0015H\u00c6\u0003J\t\u0010i\u001a\u00020\nH\u00c6\u0003J\t\u0010j\u001a\u00020\nH\u00c6\u0003J\t\u0010k\u001a\u00020\nH\u00c6\u0003J\t\u0010l\u001a\u00020\u0015H\u00c6\u0003J\t\u0010m\u001a\u00020\u0015H\u00c6\u0003J\t\u0010n\u001a\u00020\u0006H\u00c6\u0003J\t\u0010o\u001a\u00020\nH\u00c6\u0003J\t\u0010p\u001a\u00020\u0015H\u00c6\u0003J\t\u0010q\u001a\u00020\u0015H\u00c6\u0003J\t\u0010r\u001a\u00020\u0015H\u00c6\u0003J\t\u0010s\u001a\u00020\u0015H\u00c6\u0003J\t\u0010t\u001a\u00020\u0015H\u00c6\u0003J\t\u0010u\u001a\u00020\u0015H\u00c6\u0003J\t\u0010v\u001a\u00020\u0015H\u00c6\u0003J\t\u0010w\u001a\u00020\u0015H\u00c6\u0003J\t\u0010x\u001a\u000200H\u00c6\u0003J\t\u0010y\u001a\u00020\bH\u00c6\u0003J\t\u0010z\u001a\u00020\u0015H\u00c6\u0003J\u0010\u0010{\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003\u00a2\u0006\u0002\u0010|J\u000b\u0010}\u001a\u0004\u0018\u000104H\u00c6\u0003J\t\u0010~\u001a\u000206H\u00c6\u0003J\t\u0010\u007f\u001a\u00020\u0015H\u00c6\u0003J\n\u0010\u0080\u0001\u001a\u00020\u0015H\u00c6\u0003J\n\u0010\u0081\u0001\u001a\u00020\u0015H\u00c6\u0003J\n\u0010\u0082\u0001\u001a\u00020;H\u00c6\u0003J\n\u0010\u0083\u0001\u001a\u00020\u0003H\u00c6\u0003J\f\u0010\u0084\u0001\u001a\u0004\u0018\u00010>H\u00c6\u0003J\n\u0010\u0085\u0001\u001a\u00020\nH\u00c6\u0003J\n\u0010\u0086\u0001\u001a\u00020\u0015H\u00c6\u0003J\n\u0010\u0087\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0088\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0089\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u008a\u0001\u001a\u00020\u0015H\u00c6\u0003J\n\u0010\u008b\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u008c\u0001\u001a\u00020\u0003H\u00c6\u0003J\f\u0010\u008d\u0001\u001a\u0004\u0018\u000100H\u00c6\u0003J\n\u0010\u008e\u0001\u001a\u00020\u0015H\u00c6\u0003J\n\u0010\u008f\u0001\u001a\u00020\u0003H\u00c6\u0003J\n\u0010\u0090\u0001\u001a\u00020\nH\u00c6\u0003J\n\u0010\u0091\u0001\u001a\u00020\u0003H\u00c6\u0003J\f\u0010\u0092\u0001\u001a\u0004\u0018\u00010KH\u00c6\u0003J\u0012\u0010\u0093\u0001\u001a\n\u0012\u0004\u0012\u00020K\u0018\u00010MH\u00c6\u0003J\n\u0010\u0094\u0001\u001a\u00020\nH\u00c6\u0003J\n\u0010\u0095\u0001\u001a\u00020\u0015H\u00c6\u0003J\f\u0010\u0096\u0001\u001a\u0004\u0018\u00010KH\u00c6\u0003J\n\u0010\u0097\u0001\u001a\u00020\u0015H\u00c6\u0003J\u0011\u0010\u0098\u0001\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003\u00a2\u0006\u0002\u0010|J\u0011\u0010\u0099\u0001\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003\u00a2\u0006\u0002\u0010|J\u0011\u0010\u009a\u0001\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003\u00a2\u0006\u0002\u0010|J\n\u0010\u009b\u0001\u001a\u00020\nH\u00c6\u0003J\u0011\u0010\u009c\u0001\u001a\u0004\u0018\u00010\u0015H\u00c6\u0003\u00a2\u0006\u0002\u0010|J\n\u0010\u009d\u0001\u001a\u00020\u000eH\u00c6\u0003J\n\u0010\u009e\u0001\u001a\u00020\u0010H\u00c6\u0003J\u00e8\u0005\u0010\u009f\u0001\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0003\u0010\t\u001a\u00020\n2\b\b\u0003\u0010\u000b\u001a\u00020\n2\b\b\u0003\u0010\f\u001a\u00020\n2\b\b\u0002\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u0011\u001a\u00020\u00032\b\b\u0002\u0010\u0012\u001a\u00020\u00032\b\b\u0002\u0010\u0013\u001a\u00020\u00032\b\b\u0003\u0010\u0014\u001a\u00020\u00152\b\b\u0002\u0010\u0016\u001a\u00020\u00032\b\b\u0002\u0010\u0017\u001a\u00020\u00032\b\b\u0002\u0010\u0018\u001a\u00020\u00032\b\b\u0002\u0010\u0019\u001a\u00020\u00032\b\b\u0002\u0010\u001a\u001a\u00020\u00152\b\b\u0002\u0010\u001b\u001a\u00020\n2\b\b\u0002\u0010\u001c\u001a\u00020\u00032\b\b\u0002\u0010\u001d\u001a\u00020\u00152\b\b\u0002\u0010\u001e\u001a\u00020\u00152\b\b\u0003\u0010\u001f\u001a\u00020\n2\b\b\u0003\u0010 \u001a\u00020\u00152\b\b\u0003\u0010!\u001a\u00020\n2\b\b\u0003\u0010\"\u001a\u00020\n2\b\b\u0003\u0010#\u001a\u00020\n2\b\b\u0003\u0010$\u001a\u00020\u00152\b\b\u0003\u0010%\u001a\u00020\u00152\b\b\u0003\u0010&\u001a\u00020\n2\b\b\u0003\u0010\'\u001a\u00020\u00152\b\b\u0003\u0010(\u001a\u00020\u00152\b\b\u0003\u0010)\u001a\u00020\u00152\b\b\u0003\u0010*\u001a\u00020\u00152\b\b\u0003\u0010+\u001a\u00020\u00152\b\b\u0003\u0010,\u001a\u00020\u00152\b\b\u0003\u0010-\u001a\u00020\u00152\b\b\u0003\u0010.\u001a\u00020\u00152\b\b\u0002\u0010/\u001a\u0002002\b\b\u0003\u00101\u001a\u00020\u00152\n\b\u0003\u00102\u001a\u0004\u0018\u00010\u00152\n\b\u0002\u00103\u001a\u0004\u0018\u0001042\b\b\u0002\u00105\u001a\u0002062\b\b\u0002\u00107\u001a\u00020\u00152\b\b\u0003\u00108\u001a\u00020\u00152\b\b\u0003\u00109\u001a\u00020\u00152\b\b\u0002\u0010:\u001a\u00020;2\b\b\u0002\u0010<\u001a\u00020\u00032\n\b\u0002\u0010=\u001a\u0004\u0018\u00010>2\b\b\u0002\u0010?\u001a\u00020\u00152\b\b\u0002\u0010@\u001a\u00020\u00032\b\b\u0002\u0010A\u001a\u00020\u00032\b\b\u0002\u0010B\u001a\u00020\u00032\b\b\u0002\u0010C\u001a\u00020\u00152\b\b\u0002\u0010D\u001a\u00020\u00032\b\b\u0002\u0010E\u001a\u00020\u00032\n\b\u0002\u0010F\u001a\u0004\u0018\u0001002\b\b\u0003\u0010G\u001a\u00020\u00152\b\b\u0002\u0010H\u001a\u00020\u00032\b\b\u0002\u0010I\u001a\u00020\u00032\n\b\u0002\u0010J\u001a\u0004\u0018\u00010K2\u0010\b\u0002\u0010L\u001a\n\u0012\u0004\u0012\u00020K\u0018\u00010M2\b\b\u0003\u0010N\u001a\u00020\n2\b\b\u0003\u0010O\u001a\u00020\u00152\n\b\u0002\u0010P\u001a\u0004\u0018\u00010K2\b\b\u0003\u0010Q\u001a\u00020\u00152\n\b\u0003\u0010R\u001a\u0004\u0018\u00010\u00152\n\b\u0003\u0010S\u001a\u0004\u0018\u00010\u00152\n\b\u0003\u0010T\u001a\u0004\u0018\u00010\u00152\n\b\u0003\u0010U\u001a\u0004\u0018\u00010\u0015H\u00c6\u0001\u00a2\u0006\u0003\u0010\u00a0\u0001J\n\u0010\u00a1\u0001\u001a\u00020\u0015H\u00d6\u0001J\u0016\u0010\u00a2\u0001\u001a\u00020\u00032\n\u0010\u00a3\u0001\u001a\u0005\u0018\u00010\u00a4\u0001H\u00d6\u0003J\n\u0010\u00a5\u0001\u001a\u00020\u0015H\u00d6\u0001J\n\u0010\u00a6\u0001\u001a\u00020KH\u00d6\u0001J\u001e\u0010\u00a7\u0001\u001a\u00030\u00a8\u00012\b\u0010\u00a9\u0001\u001a\u00030\u00aa\u00012\u0007\u0010\u00ab\u0001\u001a\u00020\u0015H\u00d6\u0001R\u0012\u0010Q\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00101\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u00102\u001a\u0004\u0018\u00010\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0004\n\u0002\u0010WR\u0012\u0010/\u001a\u0002008\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010B\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010A\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010@\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001d\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001e\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0016\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010(\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010$\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010#\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\"\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010!\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010 \u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001f\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0019\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0018\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010%\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0007\u001a\u00020\b8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\t\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010G\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010F\u001a\u0004\u0018\u0001008\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0005\u001a\u00020\u00068\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010P\u001a\u0004\u0018\u00010K8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010O\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010N\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u00103\u001a\u0004\u0018\u0001048\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001c\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010D\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010E\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\r\u001a\u00020\u000e8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\'\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010&\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0004\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0002\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001b\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010=\u001a\u0004\u0018\u00010>8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010?\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010L\u001a\n\u0012\u0004\u0012\u00020K\u0018\u00010M8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010J\u001a\u0004\u0018\u00010K8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010.\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010-\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u001a\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010,\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010+\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010*\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010)\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0017\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010<\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00105\u001a\u0002068\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00107\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00109\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010:\u001a\u00020;8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u00108\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0014\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010C\u001a\u00020\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u000f\u001a\u00020\u00108\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0012\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0011\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010I\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u0013\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010H\u001a\u00020\u00038\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0012\u0010\u000b\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010T\u001a\u0004\u0018\u00010\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0004\n\u0002\u0010WR\u0016\u0010R\u001a\u0004\u0018\u00010\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0004\n\u0002\u0010WR\u0016\u0010U\u001a\u0004\u0018\u00010\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0004\n\u0002\u0010WR\u0016\u0010S\u001a\u0004\u0018\u00010\u00158\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0004\n\u0002\u0010WR\u0012\u0010\f\u001a\u00020\n8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u00ac\u0001"}, d2 = {"Lcom/yuyan/imemodule/libs/cropper/CropImageOptions;", "Landroid/os/Parcelable;", "imageSourceIncludeGallery", "", "imageSourceIncludeCamera", "cropShape", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropShape;", "cornerShape", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropCornerShape;", "cropCornerRadius", "", "snapRadius", "touchRadius", "guidelines", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$Guidelines;", "scaleType", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$ScaleType;", "showCropOverlay", "showCropLabel", "showProgressBar", "progressBarColor", "", "autoZoomEnabled", "multiTouchEnabled", "centerMoveEnabled", "canChangeCropWindow", "maxZoom", "initialCropWindowPaddingRatio", "fixAspectRatio", "aspectRatioX", "aspectRatioY", "borderLineThickness", "borderLineColor", "borderCornerThickness", "borderCornerOffset", "borderCornerLength", "borderCornerColor", "circleCornerFillColorHexValue", "guidelinesThickness", "guidelinesColor", "backgroundColor", "minCropWindowWidth", "minCropWindowHeight", "minCropResultWidth", "minCropResultHeight", "maxCropResultWidth", "maxCropResultHeight", "activityTitle", "", "activityMenuIconColor", "activityMenuTextColor", "customOutputUri", "Landroid/net/Uri;", "outputCompressFormat", "Landroid/graphics/Bitmap$CompressFormat;", "outputCompressQuality", "outputRequestWidth", "outputRequestHeight", "outputRequestSizeOptions", "Lcom/yuyan/imemodule/libs/cropper/CropImageView$RequestSizeOptions;", "noOutputImage", "initialCropWindowRectangle", "Landroid/graphics/Rect;", "initialRotation", "allowRotation", "allowFlipping", "allowCounterRotation", "rotationDegrees", "flipHorizontally", "flipVertically", "cropMenuCropButtonTitle", "cropMenuCropButtonIcon", "skipEditing", "showIntentChooser", "intentChooserTitle", "", "intentChooserPriorityList", "", "cropperLabelTextSize", "cropperLabelTextColor", "cropperLabelText", "activityBackgroundColor", "toolbarColor", "toolbarTitleColor", "toolbarBackButtonColor", "toolbarTintColor", "(ZZLcom/yuyan/imemodule/libs/cropper/CropImageView$CropShape;Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropCornerShape;FFFLcom/yuyan/imemodule/libs/cropper/CropImageView$Guidelines;Lcom/yuyan/imemodule/libs/cropper/CropImageView$ScaleType;ZZZIZZZZIFZIIFIFFFIIFIIIIIIIILjava/lang/CharSequence;ILjava/lang/Integer;Landroid/net/Uri;Landroid/graphics/Bitmap$CompressFormat;IIILcom/yuyan/imemodule/libs/cropper/CropImageView$RequestSizeOptions;ZLandroid/graphics/Rect;IZZZIZZLjava/lang/CharSequence;IZZLjava/lang/String;Ljava/util/List;FILjava/lang/String;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;)V", "Ljava/lang/Integer;", "component1", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component18", "component19", "component2", "component20", "component21", "component22", "component23", "component24", "component25", "component26", "component27", "component28", "component29", "component3", "component30", "component31", "component32", "component33", "component34", "component35", "component36", "component37", "component38", "component39", "component4", "component40", "component41", "()Ljava/lang/Integer;", "component42", "component43", "component44", "component45", "component46", "component47", "component48", "component49", "component5", "component50", "component51", "component52", "component53", "component54", "component55", "component56", "component57", "component58", "component59", "component6", "component60", "component61", "component62", "component63", "component64", "component65", "component66", "component67", "component68", "component69", "component7", "component70", "component8", "component9", "copy", "(ZZLcom/yuyan/imemodule/libs/cropper/CropImageView$CropShape;Lcom/yuyan/imemodule/libs/cropper/CropImageView$CropCornerShape;FFFLcom/yuyan/imemodule/libs/cropper/CropImageView$Guidelines;Lcom/yuyan/imemodule/libs/cropper/CropImageView$ScaleType;ZZZIZZZZIFZIIFIFFFIIFIIIIIIIILjava/lang/CharSequence;ILjava/lang/Integer;Landroid/net/Uri;Landroid/graphics/Bitmap$CompressFormat;IIILcom/yuyan/imemodule/libs/cropper/CropImageView$RequestSizeOptions;ZLandroid/graphics/Rect;IZZZIZZLjava/lang/CharSequence;IZZLjava/lang/String;Ljava/util/List;FILjava/lang/String;ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;)Lcom/yuyan/imemodule/libs/cropper/CropImageOptions;", "describeContents", "equals", "other", "", "hashCode", "toString", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "yuyansdk_offlineDebug"})
@kotlinx.parcelize.Parcelize()
public final class CropImageOptions implements android.os.Parcelable {
    @kotlin.jvm.JvmField()
    public boolean imageSourceIncludeGallery;
    @kotlin.jvm.JvmField()
    public boolean imageSourceIncludeCamera;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape;
    @kotlin.jvm.JvmField()
    public float cropCornerRadius;
    
    /**
     * An edge of the crop window will snap to the corresponding edge of a specified bounding box when
     * the crop window edge is less than or equal to this distance away from the bounding
     * box edge.
     */
    @kotlin.jvm.JvmField()
    public float snapRadius;
    
    /**
     * The radius of the touchable area around the handle.
     */
    @kotlin.jvm.JvmField()
    public float touchRadius;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType;
    @kotlin.jvm.JvmField()
    public boolean showCropOverlay;
    @kotlin.jvm.JvmField()
    public boolean showCropLabel;
    @kotlin.jvm.JvmField()
    public boolean showProgressBar;
    @kotlin.jvm.JvmField()
    public int progressBarColor;
    @kotlin.jvm.JvmField()
    public boolean autoZoomEnabled;
    
    /**
     * Multitouch allows to resize and drag the cropping window at the same time.
     */
    @kotlin.jvm.JvmField()
    public boolean multiTouchEnabled;
    
    /**
     * If the crop window can be moved by dragging the crop window in the center.
     */
    @kotlin.jvm.JvmField()
    public boolean centerMoveEnabled;
    
    /**
     * If you are allowed to change the crop window by resizing it.
     */
    @kotlin.jvm.JvmField()
    public boolean canChangeCropWindow;
    @kotlin.jvm.JvmField()
    public int maxZoom;
    
    /**
     * In percentage. 0.1 means 10% on both sides.
     */
    @kotlin.jvm.JvmField()
    public float initialCropWindowPaddingRatio;
    @kotlin.jvm.JvmField()
    public boolean fixAspectRatio;
    @kotlin.jvm.JvmField()
    public int aspectRatioX;
    @kotlin.jvm.JvmField()
    public int aspectRatioY;
    @kotlin.jvm.JvmField()
    public float borderLineThickness;
    @kotlin.jvm.JvmField()
    public int borderLineColor;
    @kotlin.jvm.JvmField()
    public float borderCornerThickness;
    @kotlin.jvm.JvmField()
    public float borderCornerOffset;
    @kotlin.jvm.JvmField()
    public float borderCornerLength;
    @kotlin.jvm.JvmField()
    public int borderCornerColor;
    @kotlin.jvm.JvmField()
    public int circleCornerFillColorHexValue;
    @kotlin.jvm.JvmField()
    public float guidelinesThickness;
    @kotlin.jvm.JvmField()
    public int guidelinesColor;
    @kotlin.jvm.JvmField()
    public int backgroundColor;
    @kotlin.jvm.JvmField()
    public int minCropWindowWidth;
    @kotlin.jvm.JvmField()
    public int minCropWindowHeight;
    @kotlin.jvm.JvmField()
    public int minCropResultWidth;
    @kotlin.jvm.JvmField()
    public int minCropResultHeight;
    @kotlin.jvm.JvmField()
    public int maxCropResultWidth;
    @kotlin.jvm.JvmField()
    public int maxCropResultHeight;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public java.lang.CharSequence activityTitle;
    @kotlin.jvm.JvmField()
    public int activityMenuIconColor;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.Integer activityMenuTextColor;
    
    /**
     * The Android Uri to save the cropped image to.
     */
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public android.net.Uri customOutputUri;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public android.graphics.Bitmap.CompressFormat outputCompressFormat;
    @kotlin.jvm.JvmField()
    public int outputCompressQuality;
    
    /**
     * The width to resize the cropped image to.
     */
    @kotlin.jvm.JvmField()
    public int outputRequestWidth;
    
    /**
     * The height to resize the cropped image to.
     */
    @kotlin.jvm.JvmField()
    public int outputRequestHeight;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.NotNull()
    public com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions;
    
    /**
     * If the result of crop image activity should not save the cropped image bitmap.
     */
    @kotlin.jvm.JvmField()
    public boolean noOutputImage;
    
    /**
     * Will be set after the image has loaded.
     */
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public android.graphics.Rect initialCropWindowRectangle;
    
    /**
     * Will be set after the image has loaded.
     */
    @kotlin.jvm.JvmField()
    public int initialRotation;
    @kotlin.jvm.JvmField()
    public boolean allowRotation;
    @kotlin.jvm.JvmField()
    public boolean allowFlipping;
    @kotlin.jvm.JvmField()
    public boolean allowCounterRotation;
    
    /**
     * The amount of degrees to rotate clockwise or counter-clockwise.
     */
    @kotlin.jvm.JvmField()
    public int rotationDegrees;
    @kotlin.jvm.JvmField()
    public boolean flipHorizontally;
    @kotlin.jvm.JvmField()
    public boolean flipVertically;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.CharSequence cropMenuCropButtonTitle;
    @kotlin.jvm.JvmField()
    public int cropMenuCropButtonIcon;
    @kotlin.jvm.JvmField()
    public boolean skipEditing;
    
    /**
     * Enabling this option replaces the current AlertDialog to choose the image source with an Intent chooser.
     */
    @kotlin.jvm.JvmField()
    public boolean showIntentChooser;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.String intentChooserTitle;
    
    /**
     * Reorders intent list displayed with the app package names passed here.
     */
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.util.List<java.lang.String> intentChooserPriorityList;
    @kotlin.jvm.JvmField()
    public float cropperLabelTextSize;
    @kotlin.jvm.JvmField()
    public int cropperLabelTextColor;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.String cropperLabelText;
    @kotlin.jvm.JvmField()
    public int activityBackgroundColor;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.Integer toolbarColor;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.Integer toolbarTitleColor;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.Integer toolbarBackButtonColor;
    @kotlin.jvm.JvmField()
    @org.jetbrains.annotations.Nullable()
    public java.lang.Integer toolbarTintColor;
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions() {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize, @androidx.annotation.ColorInt()
    int cropperLabelTextColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize, @androidx.annotation.ColorInt()
    int cropperLabelTextColor, @org.jetbrains.annotations.Nullable()
    java.lang.String cropperLabelText) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize, @androidx.annotation.ColorInt()
    int cropperLabelTextColor, @org.jetbrains.annotations.Nullable()
    java.lang.String cropperLabelText, @androidx.annotation.ColorInt()
    int activityBackgroundColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize, @androidx.annotation.ColorInt()
    int cropperLabelTextColor, @org.jetbrains.annotations.Nullable()
    java.lang.String cropperLabelText, @androidx.annotation.ColorInt()
    int activityBackgroundColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize, @androidx.annotation.ColorInt()
    int cropperLabelTextColor, @org.jetbrains.annotations.Nullable()
    java.lang.String cropperLabelText, @androidx.annotation.ColorInt()
    int activityBackgroundColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarTitleColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize, @androidx.annotation.ColorInt()
    int cropperLabelTextColor, @org.jetbrains.annotations.Nullable()
    java.lang.String cropperLabelText, @androidx.annotation.ColorInt()
    int activityBackgroundColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarTitleColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarBackButtonColor) {
        super();
    }
    
    @kotlin.jvm.JvmOverloads()
    public CropImageOptions(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize, @androidx.annotation.ColorInt()
    int cropperLabelTextColor, @org.jetbrains.annotations.Nullable()
    java.lang.String cropperLabelText, @androidx.annotation.ColorInt()
    int activityBackgroundColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarTitleColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarBackButtonColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarTintColor) {
        super();
    }
    
    public final boolean component1() {
        return false;
    }
    
    public final boolean component10() {
        return false;
    }
    
    public final boolean component11() {
        return false;
    }
    
    public final boolean component12() {
        return false;
    }
    
    public final int component13() {
        return 0;
    }
    
    public final boolean component14() {
        return false;
    }
    
    public final boolean component15() {
        return false;
    }
    
    public final boolean component16() {
        return false;
    }
    
    public final boolean component17() {
        return false;
    }
    
    public final int component18() {
        return 0;
    }
    
    public final float component19() {
        return 0.0F;
    }
    
    public final boolean component2() {
        return false;
    }
    
    public final boolean component20() {
        return false;
    }
    
    public final int component21() {
        return 0;
    }
    
    public final int component22() {
        return 0;
    }
    
    public final float component23() {
        return 0.0F;
    }
    
    public final int component24() {
        return 0;
    }
    
    public final float component25() {
        return 0.0F;
    }
    
    public final float component26() {
        return 0.0F;
    }
    
    public final float component27() {
        return 0.0F;
    }
    
    public final int component28() {
        return 0;
    }
    
    public final int component29() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.CropImageView.CropShape component3() {
        return null;
    }
    
    public final float component30() {
        return 0.0F;
    }
    
    public final int component31() {
        return 0;
    }
    
    public final int component32() {
        return 0;
    }
    
    public final int component33() {
        return 0;
    }
    
    public final int component34() {
        return 0;
    }
    
    public final int component35() {
        return 0;
    }
    
    public final int component36() {
        return 0;
    }
    
    public final int component37() {
        return 0;
    }
    
    public final int component38() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final java.lang.CharSequence component39() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape component4() {
        return null;
    }
    
    public final int component40() {
        return 0;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer component41() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final android.net.Uri component42() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final android.graphics.Bitmap.CompressFormat component43() {
        return null;
    }
    
    public final int component44() {
        return 0;
    }
    
    public final int component45() {
        return 0;
    }
    
    public final int component46() {
        return 0;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions component47() {
        return null;
    }
    
    public final boolean component48() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final android.graphics.Rect component49() {
        return null;
    }
    
    public final float component5() {
        return 0.0F;
    }
    
    public final int component50() {
        return 0;
    }
    
    public final boolean component51() {
        return false;
    }
    
    public final boolean component52() {
        return false;
    }
    
    public final boolean component53() {
        return false;
    }
    
    public final int component54() {
        return 0;
    }
    
    public final boolean component55() {
        return false;
    }
    
    public final boolean component56() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.CharSequence component57() {
        return null;
    }
    
    public final int component58() {
        return 0;
    }
    
    public final boolean component59() {
        return false;
    }
    
    public final float component6() {
        return 0.0F;
    }
    
    public final boolean component60() {
        return false;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component61() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.util.List<java.lang.String> component62() {
        return null;
    }
    
    public final float component63() {
        return 0.0F;
    }
    
    public final int component64() {
        return 0;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.String component65() {
        return null;
    }
    
    public final int component66() {
        return 0;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer component67() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer component68() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer component69() {
        return null;
    }
    
    public final float component7() {
        return 0.0F;
    }
    
    @org.jetbrains.annotations.Nullable()
    public final java.lang.Integer component70() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines component8() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType component9() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final com.yuyan.imemodule.libs.cropper.CropImageOptions copy(boolean imageSourceIncludeGallery, boolean imageSourceIncludeCamera, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropShape cropShape, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.CropCornerShape cornerShape, @androidx.annotation.Px()
    float cropCornerRadius, @androidx.annotation.Px()
    float snapRadius, @androidx.annotation.Px()
    float touchRadius, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.Guidelines guidelines, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.ScaleType scaleType, boolean showCropOverlay, boolean showCropLabel, boolean showProgressBar, @androidx.annotation.ColorInt()
    int progressBarColor, boolean autoZoomEnabled, boolean multiTouchEnabled, boolean centerMoveEnabled, boolean canChangeCropWindow, int maxZoom, float initialCropWindowPaddingRatio, boolean fixAspectRatio, int aspectRatioX, int aspectRatioY, @androidx.annotation.Px()
    float borderLineThickness, @androidx.annotation.ColorInt()
    int borderLineColor, @androidx.annotation.Px()
    float borderCornerThickness, @androidx.annotation.Px()
    float borderCornerOffset, @androidx.annotation.Px()
    float borderCornerLength, @androidx.annotation.ColorInt()
    int borderCornerColor, @androidx.annotation.ColorInt()
    int circleCornerFillColorHexValue, @androidx.annotation.Px()
    float guidelinesThickness, @androidx.annotation.ColorInt()
    int guidelinesColor, @androidx.annotation.ColorInt()
    int backgroundColor, @androidx.annotation.Px()
    int minCropWindowWidth, @androidx.annotation.Px()
    int minCropWindowHeight, @androidx.annotation.Px()
    int minCropResultWidth, @androidx.annotation.Px()
    int minCropResultHeight, @androidx.annotation.Px()
    int maxCropResultWidth, @androidx.annotation.Px()
    int maxCropResultHeight, @org.jetbrains.annotations.NotNull()
    java.lang.CharSequence activityTitle, @androidx.annotation.ColorInt()
    int activityMenuIconColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer activityMenuTextColor, @org.jetbrains.annotations.Nullable()
    android.net.Uri customOutputUri, @org.jetbrains.annotations.NotNull()
    android.graphics.Bitmap.CompressFormat outputCompressFormat, int outputCompressQuality, @androidx.annotation.Px()
    int outputRequestWidth, @androidx.annotation.Px()
    int outputRequestHeight, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.libs.cropper.CropImageView.RequestSizeOptions outputRequestSizeOptions, boolean noOutputImage, @org.jetbrains.annotations.Nullable()
    android.graphics.Rect initialCropWindowRectangle, int initialRotation, boolean allowRotation, boolean allowFlipping, boolean allowCounterRotation, int rotationDegrees, boolean flipHorizontally, boolean flipVertically, @org.jetbrains.annotations.Nullable()
    java.lang.CharSequence cropMenuCropButtonTitle, @androidx.annotation.DrawableRes()
    int cropMenuCropButtonIcon, boolean skipEditing, boolean showIntentChooser, @org.jetbrains.annotations.Nullable()
    java.lang.String intentChooserTitle, @org.jetbrains.annotations.Nullable()
    java.util.List<java.lang.String> intentChooserPriorityList, @androidx.annotation.Px()
    float cropperLabelTextSize, @androidx.annotation.ColorInt()
    int cropperLabelTextColor, @org.jetbrains.annotations.Nullable()
    java.lang.String cropperLabelText, @androidx.annotation.ColorInt()
    int activityBackgroundColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarTitleColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarBackButtonColor, @androidx.annotation.ColorInt()
    @org.jetbrains.annotations.Nullable()
    java.lang.Integer toolbarTintColor) {
        return null;
    }
    
    @java.lang.Override()
    public int describeContents() {
        return 0;
    }
    
    @java.lang.Override()
    public boolean equals(@org.jetbrains.annotations.Nullable()
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override()
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override()
    @org.jetbrains.annotations.NotNull()
    public java.lang.String toString() {
        return null;
    }
    
    @java.lang.Override()
    public void writeToParcel(@org.jetbrains.annotations.NotNull()
    android.os.Parcel parcel, int flags) {
    }
}
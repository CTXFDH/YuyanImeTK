package com.yuyan.inputmethod.core;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0015\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0011\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0007H\u0086 J\u001e\u0010\b\u001a\u0012\u0012\u000e\u0012\f\u0012\u0006\u0012\u0004\u0018\u00010\n\u0018\u00010\t0\tH\u0086 \u00a2\u0006\u0002\u0010\u000bJ\u001b\u0010\f\u001a\u0012\u0012\u000e\u0012\f\u0012\u0006\u0012\u0004\u0018\u00010\n\u0018\u00010\t0\t\u00a2\u0006\u0002\u0010\u000bJ\u000b\u0010\r\u001a\u0004\u0018\u00010\nH\u0087 J\u000e\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u0010J\u001b\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u00102\b\u0010\u0012\u001a\u0004\u0018\u00010\nH\u0086 J\u0013\u0010\u0013\u001a\u00020\u00042\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0086 J\t\u0010\u0016\u001a\u00020\u0017H\u0086 J\t\u0010\u0018\u001a\u00020\u0004H\u0086 J\t\u0010\u0019\u001a\u00020\u0004H\u0086 J\u000e\u0010\u001a\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u0007J\u0006\u0010\u001c\u001a\u00020\u0017R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001d"}, d2 = {"Lcom/yuyan/inputmethod/core/HandWriting;", "", "()V", "initialized", "", "activeMode", "mode", "", "getCandidates", "", "", "()[[Ljava/lang/String;", "getCandidatesPyComposition", "getPackageName", "init", "context", "Landroid/content/Context;", "initWithDirectory", "str", "inputHWPoints", "iArr", "", "release", "", "reloadConfig", "reset", "selectInputMode", "i", "setProperties", "yuyansdk_offlineDebug"})
public final class HandWriting {
    private static boolean initialized = false;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.inputmethod.core.HandWriting INSTANCE = null;
    
    private HandWriting() {
        super();
    }
    
    public final boolean init(@org.jetbrains.annotations.NotNull()
    android.content.Context context) {
        return false;
    }
    
    public final void setProperties() {
    }
    
    public final boolean selectInputMode(int i) {
        return false;
    }
    
    @kotlin.jvm.Throws(exceptionClasses = {java.lang.NumberFormatException.class})
    @org.jetbrains.annotations.NotNull()
    public final java.lang.String[][] getCandidatesPyComposition() throws java.lang.NumberFormatException {
        return null;
    }
    
    @androidx.annotation.Keep()
    @org.jetbrains.annotations.Nullable()
    public final native java.lang.String getPackageName() {
        return null;
    }
    
    public final native boolean activeMode(int mode) {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull()
    public final native java.lang.String[][] getCandidates() {
        return null;
    }
    
    public final native boolean initWithDirectory(@org.jetbrains.annotations.NotNull()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    java.lang.String str) {
        return false;
    }
    
    public final native boolean inputHWPoints(@org.jetbrains.annotations.Nullable()
    int[] iArr) {
        return false;
    }
    
    public final native void release() {
    }
    
    public final native boolean reloadConfig() {
        return false;
    }
    
    public final native boolean reset() {
        return false;
    }
}
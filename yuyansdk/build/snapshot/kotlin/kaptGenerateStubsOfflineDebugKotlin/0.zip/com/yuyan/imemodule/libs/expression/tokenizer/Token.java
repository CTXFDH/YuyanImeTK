package com.yuyan.imemodule.libs.expression.tokenizer;

/**
 * Abstract class for tokens used by exp4j to tokenize expressions
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\n\n\u0002\b\u0003\b\'\u0018\u0000 \u00052\u00020\u0001:\u0001\u0005B\u000f\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004R\u0010\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0006"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/Token;", "", "type", "", "(S)V", "Companion", "yuyansdk_offlineDebug"})
public abstract class Token {
    @kotlin.jvm.JvmField()
    public final short type = 0;
    public static final short TOKEN_NUMBER = (short)1;
    public static final short TOKEN_OPERATOR = (short)2;
    public static final short TOKEN_FUNCTION = (short)3;
    public static final short TOKEN_PARENTHESES_OPEN = (short)4;
    public static final short TOKEN_PARENTHESES_CLOSE = (short)5;
    public static final short TOKEN_VARIABLE = (short)6;
    public static final short TOKEN_SEPARATOR = (short)7;
    @org.jetbrains.annotations.NotNull()
    public static final com.yuyan.imemodule.libs.expression.tokenizer.Token.Companion Companion = null;
    
    public Token(short type) {
        super();
    }
    
    @kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\n\n\u0002\b\u0007\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000b"}, d2 = {"Lcom/yuyan/imemodule/libs/expression/tokenizer/Token$Companion;", "", "()V", "TOKEN_FUNCTION", "", "TOKEN_NUMBER", "TOKEN_OPERATOR", "TOKEN_PARENTHESES_CLOSE", "TOKEN_PARENTHESES_OPEN", "TOKEN_SEPARATOR", "TOKEN_VARIABLE", "yuyansdk_offlineDebug"})
    public static final class Companion {
        
        private Companion() {
            super();
        }
    }
}
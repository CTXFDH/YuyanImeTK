package com.yuyan.imemodule.keyboard.container;

/**
 * 手写键盘容器
 *
 * 包含手写键盘[HandwritingKeyboard]及拼音选择界面。
 *
 * 与九宫格键盘容器[T9TextContainer]、九宫格候选词键盘容器[CandidatesContainer]不同的是，手写键盘容器拼音选择栏在键盘右侧。
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\b\u0010\u000e\u001a\u00020\u000fH\u0002J\b\u0010\u0010\u001a\u00020\u000fH\u0016R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0011"}, d2 = {"Lcom/yuyan/imemodule/keyboard/container/HandwritingContainer;", "Lcom/yuyan/imemodule/keyboard/container/InputBaseContainer;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "mLlAddSymbol", "Landroid/widget/LinearLayout;", "mRVRightSymbols", "Lcom/yuyan/imemodule/libs/recyclerview/SwipeRecyclerView;", "mSideSymbolsPinyin", "", "Lcom/yuyan/imemodule/database/entry/SideSymbol;", "updateKeyboardView", "", "updateSkbLayout", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class HandwritingContainer extends com.yuyan.imemodule.keyboard.container.InputBaseContainer {
    @org.jetbrains.annotations.NotNull()
    private final java.util.List<com.yuyan.imemodule.database.entry.SideSymbol> mSideSymbolsPinyin = null;
    @org.jetbrains.annotations.NotNull()
    private com.yuyan.imemodule.libs.recyclerview.SwipeRecyclerView mRVRightSymbols;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.LinearLayout mLlAddSymbol = null;
    
    public HandwritingContainer(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null, null);
    }
    
    /**
     * 更新软键盘布局
     */
    @java.lang.Override()
    public void updateSkbLayout() {
    }
    
    private final void updateKeyboardView() {
    }
}
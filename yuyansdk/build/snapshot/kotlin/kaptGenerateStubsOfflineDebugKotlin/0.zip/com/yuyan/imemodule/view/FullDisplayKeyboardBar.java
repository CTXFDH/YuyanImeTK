package com.yuyan.imemodule.view;

/**
 * 全面屏键盘优化
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0017\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u0010\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0002J\u0010\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0012\u001a\u00020\u0013H\u0002J\u0018\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u00112\u0006\u0010\u0018\u001a\u00020\u0011H\u0014J\u0010\u0010\u0019\u001a\u00020\n2\u0006\u0010\u001a\u001a\u00020\u001bH\u0017J\u000e\u0010\u001c\u001a\u00020\u00152\u0006\u0010\u001d\u001a\u00020\u0011R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0001X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001e"}, d2 = {"Lcom/yuyan/imemodule/view/FullDisplayKeyboardBar;", "Landroid/widget/LinearLayout;", "context", "Landroid/content/Context;", "inputView", "Lcom/yuyan/imemodule/keyboard/InputView;", "(Landroid/content/Context;Lcom/yuyan/imemodule/keyboard/InputView;)V", "lastEventX", "", "mCenterModeMove", "", "mIVKeyLeft", "Landroid/widget/ImageView;", "mIVKeyRight", "mInputView", "mLLCenter", "getIcon", "", "keyMode", "Lcom/yuyan/imemodule/prefs/behavior/FullDisplayKeyMode;", "onClick", "", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "onTouchEvent", "me", "Landroid/view/MotionEvent;", "updateTheme", "textColor", "yuyansdk_offlineDebug"})
@android.annotation.SuppressLint(value = {"ViewConstructor"})
public final class FullDisplayKeyboardBar extends android.widget.LinearLayout {
    @org.jetbrains.annotations.NotNull()
    private final com.yuyan.imemodule.keyboard.InputView mInputView = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ImageView mIVKeyLeft = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.LinearLayout mLLCenter = null;
    @org.jetbrains.annotations.NotNull()
    private final android.widget.ImageView mIVKeyRight = null;
    private final boolean mCenterModeMove = false;
    private float lastEventX = -1.0F;
    
    public FullDisplayKeyboardBar(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.keyboard.InputView inputView) {
        super(null);
    }
    
    private final int getIcon(com.yuyan.imemodule.prefs.behavior.FullDisplayKeyMode keyMode) {
        return 0;
    }
    
    private final void onClick(com.yuyan.imemodule.prefs.behavior.FullDisplayKeyMode keyMode) {
    }
    
    @java.lang.Override()
    @android.annotation.SuppressLint(value = {"ClickableViewAccessibility"})
    public boolean onTouchEvent(@org.jetbrains.annotations.NotNull()
    android.view.MotionEvent me) {
        return false;
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    public final void updateTheme(int textColor) {
    }
}
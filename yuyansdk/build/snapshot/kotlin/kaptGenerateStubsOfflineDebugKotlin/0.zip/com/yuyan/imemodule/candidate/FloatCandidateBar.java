package com.yuyan.imemodule.candidate;

/**
 * 物理键盘候选词集装箱
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\r\b\u0007\u0018\u00002\u00020\u0001B\u0019\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006J\u0006\u0010\u001e\u001a\u00020\bJ\u000e\u0010\u001f\u001a\u00020\b2\u0006\u0010 \u001a\u00020\bJ\b\u0010!\u001a\u00020\"H\u0002J\u000e\u0010#\u001a\u00020\"2\u0006\u0010$\u001a\u00020\u0018J\u0006\u0010%\u001a\u00020&J\u0018\u0010\'\u001a\u00020\"2\u0006\u0010(\u001a\u00020\b2\u0006\u0010)\u001a\u00020\bH\u0014J\u000e\u0010*\u001a\u00020\"2\u0006\u0010+\u001a\u00020\bJ\b\u0010,\u001a\u00020\"H\u0002J\u0010\u0010-\u001a\u00020\"2\u0006\u0010.\u001a\u00020\bH\u0002J\u0006\u0010/\u001a\u00020\"J\u000e\u00100\u001a\u00020\"2\u0006\u0010+\u001a\u00020\bJ\u000e\u00101\u001a\u00020\"2\u0006\u00102\u001a\u00020\bR\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\u00020\b8BX\u0082\u0004\u00a2\u0006\u0006\u001a\u0004\b\f\u0010\rR\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082.\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\b0\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u00063"}, d2 = {"Lcom/yuyan/imemodule/candidate/FloatCandidateBar;", "Landroid/widget/RelativeLayout;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "activeCandidatePosition", "", "candidatesData", "Landroid/widget/LinearLayout;", "displayedActivePosition", "getDisplayedActivePosition", "()I", "displayedCandidates", "", "Lcom/yuyan/inputmethod/core/CandidateListItem;", "firstVisiblePosition", "mCandidatesAdapter", "Lcom/yuyan/imemodule/adapter/FloatCandidatesBarAdapter;", "mCandidatesDataContainer", "mComposingView", "Landroid/widget/TextView;", "mCvListener", "Lcom/yuyan/imemodule/callback/CandidateViewListener;", "mFloatCandidateBarWidth", "mRVCandidates", "Landroidx/recyclerview/widget/RecyclerView;", "pageStarts", "Lkotlin/collections/ArrayDeque;", "getActiveCandNo", "getVisibleCandPosition", "visibleNo", "initCandidateView", "", "initialize", "cvListener", "isActiveCand", "", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "pageChange", "keyCode", "refreshVisibleCandidates", "selectCandidate", "position", "showCandidates", "updateActiveCandidateNo", "updateTheme", "textColor", "yuyansdk_offlineDebug"})
public final class FloatCandidateBar extends android.widget.RelativeLayout {
    private int mFloatCandidateBarWidth = 0;
    private com.yuyan.imemodule.callback.CandidateViewListener mCvListener;
    private android.widget.LinearLayout mCandidatesDataContainer;
    private android.widget.TextView mComposingView;
    private androidx.recyclerview.widget.RecyclerView mRVCandidates;
    private com.yuyan.imemodule.adapter.FloatCandidatesBarAdapter mCandidatesAdapter;
    private android.widget.LinearLayout candidatesData;
    private int activeCandidatePosition = androidx.recyclerview.widget.RecyclerView.NO_POSITION;
    private int firstVisiblePosition = 0;
    @org.jetbrains.annotations.NotNull()
    private java.util.List<com.yuyan.inputmethod.core.CandidateListItem> displayedCandidates;
    @org.jetbrains.annotations.NotNull()
    private final kotlin.collections.ArrayDeque<java.lang.Integer> pageStarts = null;
    
    public FloatCandidateBar(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null);
    }
    
    public final void initialize(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.callback.CandidateViewListener cvListener) {
    }
    
    private final void initCandidateView() {
    }
    
    /**
     * 显示候选词
     */
    public final void showCandidates() {
    }
    
    private final void refreshVisibleCandidates() {
    }
    
    private final void selectCandidate(int position) {
    }
    
    private final int getDisplayedActivePosition() {
        return 0;
    }
    
    /**
     * 更新激活的候选词
     */
    public final void updateActiveCandidateNo(int keyCode) {
    }
    
    public final int getVisibleCandPosition(int visibleNo) {
        return 0;
    }
    
    /**
     * 获取激活的候选词
     */
    public final int getActiveCandNo() {
        return 0;
    }
    
    /**
     * 翻页功能
     */
    public final void pageChange(int keyCode) {
    }
    
    /**
     * 是否操作选词
     */
    public final boolean isActiveCand() {
        return false;
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    public final void updateTheme(int textColor) {
    }
}
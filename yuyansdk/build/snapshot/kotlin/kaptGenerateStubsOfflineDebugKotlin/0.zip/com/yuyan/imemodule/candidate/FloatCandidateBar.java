package com.yuyan.imemodule.candidate;

/**
 * 候选词集装箱
 */
@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\t\b\u0007\u0018\u00002\u00020\u0001B\u0019\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\u0002\u0010\u0006J\u0006\u0010\u0016\u001a\u00020\bJ\b\u0010\u0017\u001a\u00020\u0018H\u0002J\u000e\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u001a\u001a\u00020\u0012J\u0006\u0010\u001b\u001a\u00020\u001cJ\u0018\u0010\u001d\u001a\u00020\u00182\u0006\u0010\u001e\u001a\u00020\b2\u0006\u0010\u001f\u001a\u00020\bH\u0014J\u0006\u0010 \u001a\u00020\u0018J\u000e\u0010!\u001a\u00020\u00182\u0006\u0010\"\u001a\u00020\bJ\u000e\u0010#\u001a\u00020\u00182\u0006\u0010$\u001a\u00020\bR\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\nX\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006%"}, d2 = {"Lcom/yuyan/imemodule/candidate/FloatCandidateBar;", "Landroid/widget/RelativeLayout;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "(Landroid/content/Context;Landroid/util/AttributeSet;)V", "activeCandNo", "", "candidatesData", "Landroid/widget/LinearLayout;", "mCandidatesAdapter", "Lcom/yuyan/imemodule/adapter/CandidatesBarAdapter;", "mCandidatesDataContainer", "mComposingTagContainer", "mComposingView", "Landroid/widget/TextView;", "mCvListener", "Lcom/yuyan/imemodule/callback/CandidateViewListener;", "mFloatCandidateBarWidth", "mRVCandidates", "Landroidx/recyclerview/widget/RecyclerView;", "getActiveCandNo", "initCandidateView", "", "initialize", "cvListener", "isActiveCand", "", "onMeasure", "widthMeasureSpec", "heightMeasureSpec", "showCandidates", "updateActiveCandidateNo", "keyCode", "updateTheme", "textColor", "yuyansdk_offlineDebug"})
public final class FloatCandidateBar extends android.widget.RelativeLayout {
    private int mFloatCandidateBarWidth = 0;
    private com.yuyan.imemodule.callback.CandidateViewListener mCvListener;
    private android.widget.LinearLayout mCandidatesDataContainer;
    private android.widget.LinearLayout mComposingTagContainer;
    private android.widget.TextView mComposingView;
    private androidx.recyclerview.widget.RecyclerView mRVCandidates;
    private com.yuyan.imemodule.adapter.CandidatesBarAdapter mCandidatesAdapter;
    private android.widget.LinearLayout candidatesData;
    private int activeCandNo = 0;
    
    public FloatCandidateBar(@org.jetbrains.annotations.Nullable()
    android.content.Context context, @org.jetbrains.annotations.Nullable()
    android.util.AttributeSet attrs) {
        super(null);
    }
    
    public final void initialize(@org.jetbrains.annotations.NotNull()
    com.yuyan.imemodule.callback.CandidateViewListener cvListener) {
    }
    
    private final void initCandidateView() {
    }
    
    /**
     * 显示候选词
     */
    public final void showCandidates() {
    }
    
    /**
     * 更新激活的候选词
     */
    public final void updateActiveCandidateNo(int keyCode) {
    }
    
    /**
     * 获取激活的候选词
     */
    public final int getActiveCandNo() {
        return 0;
    }
    
    /**
     * 是否操作选词
     */
    public final boolean isActiveCand() {
        return false;
    }
    
    @java.lang.Override()
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
    }
    
    public final void updateTheme(int textColor) {
    }
}